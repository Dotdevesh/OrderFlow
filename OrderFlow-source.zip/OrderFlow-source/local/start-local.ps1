<#
.SYNOPSIS
    Starts OrderFlow locally with Docker (no Azure subscription required).
.PARAMETER Mode
    DockerApps : Runs infra AND all 4 apps inside Docker Compose (--profile apps).
    Host       : Runs infra in Docker and launches all 4 apps on the host in separate windows.
.PARAMETER SkipBuild
    Skip image rebuild when using DockerApps mode.
#>
[CmdletBinding()]
param(
    [ValidateSet("DockerApps", "Host")]
    [string]$Mode = "Host",
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$SqlPassword = if ($env:MSSQL_SA_PASSWORD) { $env:MSSQL_SA_PASSWORD } else { "OrderFlow!Passw0rd" }

function Require-Tool([string]$Name, [string]$Help) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required tool '$Name' was not found on PATH. $Help"
    }
}

function Wait-TcpPort([string]$HostName, [int]$Port, [int]$TimeoutSeconds = 90) {
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        $client = [System.Net.Sockets.TcpClient]::new()
        try {
            $ar = $client.BeginConnect($HostName, $Port, $null, $null)
            if ($ar.AsyncWaitHandle.WaitOne(500) -and $client.Connected) {
                $client.EndConnect($ar)
                return
            }
        }
        catch { }
        finally { $client.Dispose() }
        Start-Sleep -Seconds 2
    }
    throw "Timed out waiting for ${HostName}:${Port} after ${TimeoutSeconds}s."
}

function Ensure-LocalSettings([string]$ProjectDir) {
    $target = Join-Path $ProjectDir "local.settings.json"
    $example = Join-Path $ProjectDir "local.settings.example.json"
    if (-not (Test-Path $target) -and (Test-Path $example)) {
        Copy-Item $example $target
        Write-Host "Created $target from local.settings.example.json" -ForegroundColor DarkGray
    }
}

Require-Tool "docker" "Install Docker Desktop and make sure it is running."

Push-Location $PSScriptRoot
try {
    if ($Mode -eq "DockerApps") {
        Write-Host "Starting OrderFlow infrastructure + all 4 apps in Docker..." -ForegroundColor Cyan
        $composeArgs = @("compose", "--profile", "apps", "up", "-d")
        if (-not $SkipBuild) { $composeArgs += "--build" }
        & docker @composeArgs
        if ($LASTEXITCODE -ne 0) { throw "docker compose failed." }

        Write-Host "Waiting for OrderApi (localhost:5080) and Action Center (localhost:4200)..." -ForegroundColor Cyan
        Wait-TcpPort "127.0.0.1" 5080 120
        Wait-TcpPort "127.0.0.1" 4200 120
    }
    else {
        Require-Tool "dotnet" "Install the .NET 10 SDK."
        Require-Tool "func" "Install Azure Functions Core Tools v4 (npm i -g azure-functions-core-tools@4 --unsafe-perm true)."
        Require-Tool "npm" "Install Node.js 20+."

        Ensure-LocalSettings (Join-Path $RepoRoot "src\services\OrderFlow.Orchestrator")
        Ensure-LocalSettings (Join-Path $RepoRoot "src\services\OrderFlow.EmailIntake")

        Write-Host "Starting Docker infrastructure (SQL Edge, Azurite, Service Bus)..." -ForegroundColor Cyan
        & docker compose up -d
        if ($LASTEXITCODE -ne 0) { throw "docker compose up failed." }

        Write-Host "Waiting for emulators (SQL :1433, Azurite :10000, Service Bus :5672)..." -ForegroundColor Cyan
        Wait-TcpPort "127.0.0.1" 1433 90
        Wait-TcpPort "127.0.0.1" 10000 60
        Wait-TcpPort "127.0.0.1" 5672 90

        $sqlConn = "Server=localhost,1433;Database=OrderFlow;User Id=sa;Password=$SqlPassword;TrustServerCertificate=true;Encrypt=false"
        $sbConn  = "Endpoint=sb://localhost;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=SAS_KEY_VALUE;UseDevelopmentEmulator=true;"

        $apiDir  = Join-Path $RepoRoot "src\services\OrderFlow.OrderApi"
        $orchDir = Join-Path $RepoRoot "src\services\OrderFlow.Orchestrator"
        $intDir  = Join-Path $RepoRoot "src\services\OrderFlow.EmailIntake"
        $webDir  = Join-Path $RepoRoot "src\clients\action-center"

        if (-not (Test-Path (Join-Path $webDir "node_modules"))) {
            Write-Host "Installing Action Center npm packages..." -ForegroundColor Cyan
            Push-Location $webDir
            try { npm install } finally { Pop-Location }
        }

        Write-Host "Launching apps in separate PowerShell windows..." -ForegroundColor Cyan
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "`$env:ConnectionStrings__Sql='$sqlConn'; `$env:ServiceBus='$sbConn'; cd '$apiDir'; dotnet run --urls http://localhost:5080"
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$orchDir'; func start --port 7072"
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$intDir'; func start --port 7071"
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$webDir'; npm start"
    }

    Write-Host ""
    Write-Host "OrderFlow is starting up:" -ForegroundColor Green
    Write-Host "  Action Center : http://localhost:4200"
    Write-Host "  Order API     : http://localhost:5080/health"
    Write-Host "  Orchestrator  : http://localhost:7072"
    Write-Host "  EmailIntake   : http://localhost:7071"
    Write-Host ""
    Write-Host "Send a sample order:" -ForegroundColor Yellow
    Write-Host "  cd $PSScriptRoot\send-test-order; dotnet run -- acme-title high"
}
finally {
    Pop-Location
}
