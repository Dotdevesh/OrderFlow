using System.Text;
using OrderFlow.Domain;
using OrderFlow.Orchestrator;
using OrderFlow.Orchestrator.Services;
using Xunit;

namespace OrderFlow.Tests;

public sealed class DocumentConverterTests
{
    [Fact]
    public async Task ConvertAsync_ProducesValidPdfHeaderAndTrailer()
    {
        var converter = new PassthroughDocumentConverter();
        var email = new FetchedEmail(
            Guid.NewGuid(),
            "orders@contoso.com",
            "msg-1",
            "Title Order TI-10045",
            "escrow@acmetitle.com",
            "<p>Hello world</p>",
            [new EmailAttachment("order.txt", "text/plain", Encoding.UTF8.GetBytes("body"))]);

        var pdfs = await converter.ConvertAsync(email);

        Assert.Equal(2, pdfs.Count);
        foreach (var doc in pdfs)
        {
            var text = Encoding.ASCII.GetString(doc.Content);
            Assert.StartsWith("%PDF-1.4", text);
            Assert.Contains("xref", text);
            Assert.Contains("%%EOF", text);
        }
    }

    [Fact]
    public void ValidationTask_EscalateUpdatesStatusAssigneeAndCount()
    {
        var task = new ValidationTask
        {
            OrderId = Guid.NewGuid(),
            OrchestrationInstanceId = "abc",
            Priority = Priority.High,
            SlaDueAtUtc = DateTimeOffset.UtcNow.AddMinutes(15)
        };

        var newDue = DateTimeOffset.UtcNow.AddMinutes(5);
        task.Escalate("mgr-1", newDue);

        Assert.Equal(Domain.TaskStatus.Escalated, task.Status);
        Assert.Equal("mgr-1", task.AssignedToUserId);
        Assert.Equal(1, task.EscalationCount);
        Assert.Equal(newDue, task.SlaDueAtUtc);
    }
}
