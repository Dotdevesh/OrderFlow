namespace OrderFlow.Domain;

/// <summary>An Action Center user (validator). Managers own the reportees whose ManagerId == their Id.</summary>
public sealed class AppUser
{
    public required string Id { get; init; }            // Entra object id
    public required string DisplayName { get; set; }
    public string? Email { get; set; }
    public UserRole Role { get; set; }

    /// <summary>The managing user's id. Null for top-level managers.</summary>
    public string? ManagerId { get; set; }

    public bool IsManager => Role == UserRole.Manager;
}
