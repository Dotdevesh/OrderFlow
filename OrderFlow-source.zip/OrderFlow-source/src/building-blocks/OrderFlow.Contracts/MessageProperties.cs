namespace OrderFlow.Contracts;

/// <summary>Service Bus application-property keys and topic/subscription names shared by publishers and consumers.</summary>
public static class MessageProperties
{
    public const string Priority = "priority";
    public const string CustomerId = "customerId";
    public const string CorrelationId = "correlationId";
    public const string EventType = "eventType";
    public const string SchemaVersion = "schemaVersion";
}

/// <summary>Canonical Service Bus entity names (also provisioned by Bicep).</summary>
public static class Topics
{
    public const string Orders = "orders";

    public const string SubHigh = "sub-high";
    public const string SubStandard = "sub-standard";
    public const string SubLow = "sub-low";
}
