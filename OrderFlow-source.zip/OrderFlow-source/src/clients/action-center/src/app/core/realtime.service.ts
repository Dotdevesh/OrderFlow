import { Injectable, inject, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { environment } from '../../environments/environment';
import { Session } from './session';

/** Wraps the SignalR connection to the Tasks hub for realtime inbox + SLA updates. */
@Injectable({ providedIn: 'root' })
export class RealtimeService {
  private readonly session = inject(Session);
  private connection?: signalR.HubConnection;
  readonly lastEvent = signal<{ type: string; payload: unknown } | null>(null);

  async connect(teamManagerId: string): Promise<void> {
    if (this.connection) return;

    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(environment.hubUrl, {
        headers: environment.devAuth.enabled
          ? {
              'X-Debug-UserId': this.session.userId(),
              'X-Debug-Role': this.session.role(),
            }
          : undefined,
      })
      .withAutomaticReconnect()
      .build();

    this.connection.on('taskCreated', (p) => this.lastEvent.set({ type: 'taskCreated', payload: p }));
    this.connection.on('taskChanged', (p) => this.lastEvent.set({ type: 'taskChanged', payload: p }));

    await this.connection.start();
    await this.connection.invoke('JoinTeam', teamManagerId);
  }
}
