import { Injectable, signal } from '@angular/core';
import { environment } from '../../environments/environment';

export interface DevPersona {
  userId: string;
  role: 'Manager' | 'Reportee';
  name: string;
}

/** Current user/session. In production this is populated from MSAL account + role claims. */
@Injectable({ providedIn: 'root' })
export class Session {
  readonly userId = signal(environment.devAuth.userId);
  readonly role = signal<'Manager' | 'Reportee'>(environment.devAuth.role);
  readonly name = signal(environment.devAuth.name);

  readonly devPersonas: DevPersona[] = [
    { userId: 'mgr-1', role: 'Manager', name: 'Morgan (Manager)' },
    { userId: 'rep-1', role: 'Reportee', name: 'Riley (Reportee)' },
    { userId: 'rep-2', role: 'Reportee', name: 'Jordan (Reportee)' },
  ];

  isManager(): boolean {
    return this.role() === 'Manager';
  }

  switchPersona(userId: string): void {
    const found = this.devPersonas.find((p) => p.userId === userId);
    if (!found) return;
    this.userId.set(found.userId);
    this.role.set(found.role);
    this.name.set(found.name);
  }
}
