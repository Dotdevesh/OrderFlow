import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { environment } from '../../environments/environment';
import { Session } from './session';

/**
 * Local-dev interceptor: reads the active Session signals and adds X-Debug-* headers consumed
 * by the API's DevAuthenticationHandler so you can switch between Manager and Reportee live
 * without Entra. In production this is replaced by an MSAL token interceptor.
 */
export const devAuthInterceptor: HttpInterceptorFn = (req, next) => {
  if (!environment.devAuth.enabled) {
    return next(req);
  }
  const session = inject(Session);
  const cloned = req.clone({
    setHeaders: {
      'X-Debug-UserId': session.userId(),
      'X-Debug-Role': session.role(),
      'X-Debug-Name': session.name(),
    },
  });
  return next(cloned);
};
