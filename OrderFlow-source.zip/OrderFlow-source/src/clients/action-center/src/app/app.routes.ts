import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'inbox' },
  {
    path: 'select-customer',
    loadComponent: () =>
      import('./features/customer-select/customer-select.component').then((m) => m.CustomerSelectComponent),
  },
  {
    path: 'inbox',
    loadComponent: () => import('./features/inbox/inbox.component').then((m) => m.InboxComponent),
  },
  {
    path: 'tasks/:id',
    loadComponent: () =>
      import('./features/validation/validation-workspace.component').then((m) => m.ValidationWorkspaceComponent),
  },
  { path: '**', redirectTo: 'inbox' },
];
