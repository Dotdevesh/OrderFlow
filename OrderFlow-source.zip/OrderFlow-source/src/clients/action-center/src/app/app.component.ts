import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { environment } from '../environments/environment';
import { Session } from './core/session';
import { CustomerContext } from './core/customer-context';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  template: `
    <header class="topbar">
      <a routerLink="/inbox" class="brand">OrderFlow · Action Center</a>
      @if (ctx.selected(); as c) {
        <span class="cust-chip">
          {{ c.displayName }}
          <button class="link" (click)="changeCustomer()">change</button>
        </span>
      }
      <span class="spacer"></span>
      @if (devAuthEnabled) {
        <select class="persona-select" [value]="session.userId()" (change)="onPersonaChange($event)" title="Switch local persona">
          @for (p of session.devPersonas; track p.userId) {
            <option [value]="p.userId">{{ p.name }}</option>
          }
        </select>
      } @else {
        <span class="user">
          {{ session.name() }}
          <span class="role" [class.mgr]="session.isManager()">{{ session.role() }}</span>
        </span>
      }
    </header>
    <main class="content">
      <router-outlet />
    </main>
  `,
  styles: [`
    .cust-chip { margin-left: 14px; background: #1e293b; color: #cbd5e1; padding: 4px 10px;
      border-radius: 14px; font-size: 13px; display: inline-flex; gap: 8px; align-items: center; }
    .link { background: none; border: none; color: #93c5fd; cursor: pointer; font-size: 12px; padding: 0; }
    .persona-select { background: #1e293b; color: #e2e8f0; border: 1px solid #334155;
      border-radius: 6px; padding: 4px 8px; font-size: 13px; cursor: pointer; }
  `],
})
export class AppComponent {
  readonly session = inject(Session);
  readonly ctx = inject(CustomerContext);
  private readonly router = inject(Router);
  readonly devAuthEnabled = environment.devAuth.enabled;

  changeCustomer(): void {
    this.router.navigate(['/select-customer']);
  }

  onPersonaChange(event: Event): void {
    const id = (event.target as HTMLSelectElement).value;
    this.session.switchPersona(id);
    this.router.navigate(['/inbox']);
  }
}
