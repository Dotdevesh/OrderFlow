import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { routes } from './app.routes';
import { devAuthInterceptor } from './core/dev-auth.interceptor';
import { provideUiIcons } from './shared/ui';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideAnimationsAsync(),
    provideUiIcons(),
    provideRouter(routes),
    provideHttpClient(withInterceptors([devAuthInterceptor])),
  ],
};
