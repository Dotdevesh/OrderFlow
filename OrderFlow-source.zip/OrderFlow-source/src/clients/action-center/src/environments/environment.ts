export const environment = {
  production: false,
  // Order API base URL (BFF).
  apiBaseUrl: 'http://localhost:5080',
  // SignalR hub.
  hubUrl: 'http://localhost:5080/hubs/tasks',
  // Local dev: impersonate a user without Entra. Switch role to 'Reportee' to test that flow.
  devAuth: {
    enabled: true,
    userId: 'mgr-1',
    role: 'Manager' as 'Manager' | 'Reportee',
    name: 'Morgan (Manager)',
  },
};
