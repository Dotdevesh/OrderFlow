using Microsoft.EntityFrameworkCore;
using OrderFlow.Domain;

namespace OrderFlow.OrderApi.Data;

public sealed class OrderFlowDbContext(DbContextOptions<OrderFlowDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderDocument> OrderDocuments => Set<OrderDocument>();
    public DbSet<OrderLine> OrderLines => Set<OrderLine>();
    public DbSet<OrderField> OrderFields => Set<OrderField>();
    public DbSet<ValidationTask> ValidationTasks => Set<ValidationTask>();
    public DbSet<CustomerProfile> Customers => Set<CustomerProfile>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();
    public DbSet<OutboxMessage> Outbox => Set<OutboxMessage>();
    public DbSet<IntakeLedgerEntry> IntakeLedger => Set<IntakeLedgerEntry>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Order>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.CustomerId).HasMaxLength(128).IsRequired();
            e.Property(x => x.Status).HasConversion<int>();
            e.Property(x => x.Priority).HasConversion<int>();
            e.Property(x => x.SubjectLine).HasMaxLength(1024);
            e.Property(x => x.SenderAddress).HasMaxLength(512);
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasIndex(x => x.CorrelationId).IsUnique();
            e.HasIndex(x => x.OrchestrationInstanceId);
            e.HasMany(x => x.Documents).WithOne().HasForeignKey(d => d.OrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Lines).WithOne().HasForeignKey(l => l.OrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Fields).WithOne().HasForeignKey(f => f.OrderId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<OrderDocument>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Kind).HasConversion<int>();
            e.Property(x => x.FileName).HasMaxLength(512).IsRequired();
            e.Property(x => x.BlobPath).HasMaxLength(1024).IsRequired();
            e.Property(x => x.ContentType).HasMaxLength(256);
            e.Property(x => x.AnalyzeModelId).HasMaxLength(256);
        });

        b.Entity<OrderLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Ignore(x => x.LineTotal);
            e.Property(x => x.Sku).HasMaxLength(128);
            e.Property(x => x.Description).HasMaxLength(1024);
            e.Property(x => x.Quantity).HasPrecision(18, 4);
            e.Property(x => x.UnitPrice).HasPrecision(18, 4);
        });

        b.Entity<OrderField>(e =>
        {
            e.HasKey(x => x.Id);
            e.Ignore(x => x.IsCorrected);
            e.Property(x => x.Name).HasMaxLength(256).IsRequired();
            e.Property(x => x.ExtractedValue).HasMaxLength(2048);
            e.Property(x => x.ValidatedValue).HasMaxLength(2048);
            e.Property(x => x.CandidatesJson); // nvarchar(max) — list of candidate values/regions
        });

        b.Entity<ValidationTask>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Status).HasConversion<int>();
            e.Property(x => x.Priority).HasConversion<int>();
            e.Property(x => x.AssignmentKind).HasConversion<int>();
            e.Property(x => x.OrchestrationInstanceId).HasMaxLength(256).IsRequired();
            e.Property(x => x.AssignedToUserId).HasMaxLength(128);
            e.Property(x => x.ClaimedByUserId).HasMaxLength(128);
            e.Property(x => x.TeamManagerId).HasMaxLength(128);
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasIndex(x => new { x.Status, x.Priority, x.SlaDueAtUtc });
            e.HasIndex(x => new { x.AssignedToUserId, x.Status });
            e.HasIndex(x => x.OrderId);
        });

        b.Entity<CustomerProfile>(e =>
        {
            e.HasKey(x => x.CustomerId);
            e.Property(x => x.CustomerId).HasMaxLength(128);
            e.Property(x => x.DisplayName).HasMaxLength(256).IsRequired();
            e.Property(x => x.Tier).HasConversion<int>();
            e.Ignore(x => x.Priority);
            e.Property(x => x.SenderDomains)
                .HasConversion(
                    v => string.Join(';', v),
                    v => v.Split(';', StringSplitOptions.RemoveEmptyEntries).ToList())
                .HasMaxLength(2048)
                .Metadata.SetValueComparer(new Microsoft.EntityFrameworkCore.ChangeTracking.ValueComparer<IList<string>>(
                    (a, c) => (a ?? new List<string>()).SequenceEqual(c ?? new List<string>()),
                    v => v.Aggregate(0, (h, s) => HashCode.Combine(h, s.GetHashCode())),
                    v => v.ToList()));
        });

        b.Entity<AppUser>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasMaxLength(128);
            e.Property(x => x.DisplayName).HasMaxLength(256).IsRequired();
            e.Property(x => x.Email).HasMaxLength(256);
            e.Property(x => x.Role).HasConversion<int>();
            e.Property(x => x.ManagerId).HasMaxLength(128);
            e.Ignore(x => x.IsManager);
            e.HasIndex(x => x.ManagerId);
        });

        b.Entity<AuditEvent>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Action).HasMaxLength(128).IsRequired();
            e.Property(x => x.UserId).HasMaxLength(128);
            e.HasIndex(x => x.OrderId);
        });

        b.Entity<OutboxMessage>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Type).HasMaxLength(256).IsRequired();
            e.HasIndex(x => x.ProcessedAtUtc);
        });

        b.Entity<IntakeLedgerEntry>(e =>
        {
            e.HasKey(x => x.GraphMessageId);
            e.Property(x => x.GraphMessageId).HasMaxLength(256);
            e.Property(x => x.Mailbox).HasMaxLength(256).IsRequired();
            e.Property(x => x.CustomerId).HasMaxLength(128);
            e.Property(x => x.Status).HasConversion<int>();
            e.Property(x => x.Priority).HasConversion<int>();
            e.HasIndex(x => x.Status);
            e.HasIndex(x => x.ReceivedAtUtc);
        });
    }
}
