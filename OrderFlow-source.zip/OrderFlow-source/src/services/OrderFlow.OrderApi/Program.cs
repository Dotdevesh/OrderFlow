using Azure.Identity;
using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.CustomerModel;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Data;
using OrderFlow.OrderApi.Endpoints;
using OrderFlow.OrderApi.Hubs;
using OrderFlow.OrderApi.Services;

var builder = WebApplication.CreateBuilder(args);
var cfg = builder.Configuration;

// ---------- Persistence ----------
builder.Services.AddDbContext<OrderFlowDbContext>(o =>
    o.UseSqlServer(cfg.GetConnectionString("Sql")
        ?? "Server=(localdb)\\mssqllocaldb;Database=OrderFlow;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=true",
        sql => sql.EnableRetryOnFailure(          // transient SQL fault resilience
            maxRetryCount: 6,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null)));

// ---------- AuthN: Entra (JWT) in prod, Dev header scheme locally ----------
var authority = cfg["Entra:Authority"];
if (!string.IsNullOrWhiteSpace(authority))
{
    builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(options =>
        {
            options.Authority = authority;
            options.Audience = cfg["Entra:Audience"];
            options.TokenValidationParameters.RoleClaimType = "roles";
        });
}
else
{
    builder.Services.AddAuthentication(DevAuthenticationHandler.SchemeName)
        .AddScheme<AuthenticationSchemeOptions, DevAuthenticationHandler>(DevAuthenticationHandler.SchemeName, _ => { });
}

builder.Services.AddAuthorizationBuilder().AddOrderFlowPolicies(cfg["InternalAuth:ApiKey"]);

// ---------- Optional Service Bus publisher for OutboxDispatcher ----------
var sbNs = cfg["ServiceBus:FullyQualifiedNamespace"];
var sbConn = cfg["ServiceBus"] ?? cfg.GetConnectionString("ServiceBus");
if (!string.IsNullOrWhiteSpace(sbNs) || !string.IsNullOrWhiteSpace(sbConn))
{
    builder.Services.AddSingleton(_ => !string.IsNullOrWhiteSpace(sbNs)
        ? new ServiceBusClient(sbNs, new DefaultAzureCredential())
        : new ServiceBusClient(sbConn!));
    builder.Services.AddSingleton<IEventPublisher, ServiceBusEventPublisher>();
}

// ---------- Realtime ----------
builder.Services.AddSignalR();

// ---------- Blob storage ----------
builder.Services.AddSingleton(sp =>
{
    var endpoint = cfg["Storage:BlobEndpoint"];
    return string.IsNullOrWhiteSpace(endpoint)
        ? new BlobServiceClient(cfg.GetConnectionString("Storage") ?? "UseDevelopmentStorage=true")
        : new BlobServiceClient(new Uri(endpoint), new DefaultAzureCredential());
});
builder.Services.AddSingleton<IBlobDocumentStore>(sp => new BlobDocumentStore(
    sp.GetRequiredService<BlobServiceClient>(),
    cfg["Storage:Container"] ?? "order-documents",
    sp.GetRequiredService<ILogger<BlobDocumentStore>>()));

// ---------- Durable workflow client (resume orchestrations) ----------
builder.Services.Configure<DurableTaskOptions>(cfg.GetSection(DurableTaskOptions.Section));
builder.Services.AddHttpClient<IWorkflowClient, DurableHttpWorkflowClient>();

// ---------- Application services ----------
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<CurrentUser>();
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<ITaskService, TaskService>();
builder.Services.AddCustomerSchemas();
builder.Services.AddScoped<ITaskNotifier, SignalRTaskNotifier>();
builder.Services.AddHostedService<OutboxDispatcher>();

builder.Services.AddProblemDetails();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .WithOrigins(cfg.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:4200"])
    .AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

var app = builder.Build();

app.UseExceptionHandler();
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();

// Liveness: process is up. Readiness: dependencies reachable (SQL).
app.MapGet("/health", () => Results.Ok(new { status = "healthy", service = "OrderApi" })).WithTags("Health");
app.MapGet("/health/ready", async (OrderFlowDbContext db, CancellationToken ct) =>
{
    var sqlOk = await db.Database.CanConnectAsync(ct);
    return sqlOk
        ? Results.Ok(new { status = "ready", sql = true })
        : Results.Json(new { status = "degraded", sql = false }, statusCode: StatusCodes.Status503ServiceUnavailable);
}).WithTags("Health");

app.MapInternalEndpoints();
app.MapTaskEndpoints();
app.MapDocumentEndpoints();
app.MapCustomerEndpoints();
app.MapUserEndpoints();
app.MapHub<TasksHub>("/hubs/tasks");

// ---------- Dev: ensure DB + seed ----------
if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<OrderFlowDbContext>();
    try { await SeedData.EnsureSeededAsync(db); }
    catch (Exception ex) { app.Logger.LogWarning(ex, "DB seed skipped (no SQL available in this environment)."); }
}

app.Run();

public partial class Program;
