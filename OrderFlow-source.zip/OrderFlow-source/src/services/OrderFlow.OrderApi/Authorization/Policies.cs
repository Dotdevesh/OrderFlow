using Microsoft.AspNetCore.Authorization;

namespace OrderFlow.OrderApi.Authorization;

public static class Policies
{
    /// <summary>Any authenticated validator (Manager or Reportee).</summary>
    public const string Validator = "Validator";
    /// <summary>Manager-only operations: assign, delegate, team view, escalations.</summary>
    public const string ManagerOnly = "ManagerOnly";
    /// <summary>Service-to-service (orchestrator / intake) internal endpoints.</summary>
    public const string Internal = "Internal";

    public static AuthorizationBuilder AddOrderFlowPolicies(this AuthorizationBuilder builder, string? internalApiKey = null) =>
        builder
            .AddPolicy(Validator, p => p.RequireAuthenticatedUser()
                .RequireRole("Manager", "Reportee"))
            .AddPolicy(ManagerOnly, p => p.RequireAuthenticatedUser()
                .RequireRole("Manager"))
            .AddPolicy(Internal, p => p.RequireAssertion(ctx =>
            {
                if (string.IsNullOrWhiteSpace(internalApiKey))
                    return true; // local dev without internal key

                if (ctx.Resource is HttpContext http
                    && http.Request.Headers.TryGetValue("X-Internal-ApiKey", out var header)
                    && string.Equals(header.FirstOrDefault(), internalApiKey, StringComparison.Ordinal))
                    return true;

                return ctx.User.Identity?.IsAuthenticated == true && ctx.User.IsInRole("InternalService");
            }));
}
