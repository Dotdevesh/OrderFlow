using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace OrderFlow.OrderApi.Authorization;

/// <summary>
/// Local-development authentication: reads <c>X-Debug-UserId</c> / <c>X-Debug-Role</c> headers to
/// impersonate a Manager or Reportee without Entra. NEVER registered in production (Entra/JWT is used).
/// </summary>
public sealed class DevAuthenticationHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "Dev";

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var userId = Request.Headers["X-Debug-UserId"].FirstOrDefault() ?? "mgr-1";
        var role = Request.Headers["X-Debug-Role"].FirstOrDefault() ?? "Manager";
        var name = Request.Headers["X-Debug-Name"].FirstOrDefault() ?? userId;

        var claims = new[]
        {
            new Claim("oid", userId),
            new Claim(ClaimTypes.NameIdentifier, userId),
            new Claim("name", name),
            new Claim(ClaimTypes.Role, role)
        };
        var identity = new ClaimsIdentity(claims, SchemeName);
        var ticket = new AuthenticationTicket(new ClaimsPrincipal(identity), SchemeName);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}
