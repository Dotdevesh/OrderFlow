using Microsoft.EntityFrameworkCore;
using OrderFlow.BuildingBlocks;
using OrderFlow.Contracts;
using OrderFlow.CustomerModel;
using OrderFlow.Domain;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Services;

public interface ITaskService
{
    Task<IReadOnlyList<TaskSummaryDto>> GetInboxAsync(string scope, string? customerId, int? status, CancellationToken ct);
    Task<Result<TaskDetailDto>> GetDetailAsync(Guid taskId, CancellationToken ct);
    Task<Result> OpenAsync(Guid taskId, CancellationToken ct);
    Task<Result> ClaimAsync(Guid taskId, CancellationToken ct);
    Task<Result> AssignAsync(Guid taskId, string targetUserId, CancellationToken ct);
    Task<Result> DelegateAsync(Guid taskId, string targetUserId, CancellationToken ct);
    Task<Result<SubmitOutcome>> SubmitAsync(Guid taskId, SubmitValidationRequest request, CancellationToken ct);
    Task MarkOutboxDispatchedAsync(Guid outboxMessageId, CancellationToken ct);
}

public sealed record ValidationResumeEnvelope(string OrchestrationInstanceId, ValidationCompletedPayload Payload);

public sealed record SubmitOutcome(
    Guid OrderId,
    string OrchestrationInstanceId,
    ValidationCompletedPayload Payload,
    Guid OutboxMessageId);

/// <summary>
/// Human-side task operations for the Action Center. Authorization (Manager/Reportee rules) is
/// enforced by the endpoint-level policies; this service enforces ownership, domain invariants,
/// schema validation (<see cref="ICustomerSchemaRegistry"/>), and optimistic concurrency.
/// </summary>
public sealed class TaskService(
    OrderFlowDbContext db,
    CurrentUser user,
    ICustomerSchemaRegistry schemas,
    ITaskNotifier notifier,
    ILogger<TaskService> logger) : ITaskService
{
    public async Task<IReadOnlyList<TaskSummaryDto>> GetInboxAsync(
        string scope, string? customerId, int? status, CancellationToken ct)
    {
        // Join tasks to their order so we can scope by customer and project order metadata.
        var q = from t in db.ValidationTasks.AsNoTracking()
                join o in db.Orders.AsNoTracking() on t.OrderId equals o.Id
                select new { t, o };

        q = scope switch
        {
            "mine" => q.Where(x => x.t.ClaimedByUserId == user.Id || x.t.AssignedToUserId == user.Id),
            "pool" => q.Where(x => x.t.Status == Domain.TaskStatus.Pending && x.t.TeamManagerId == ManagerScope()),
            "team" when user.IsManager => q.Where(x => x.t.TeamManagerId == user.Id),
            _ => q.Where(x => x.t.ClaimedByUserId == user.Id || x.t.AssignedToUserId == user.Id)
        };

        if (!string.IsNullOrWhiteSpace(customerId))
            q = q.Where(x => x.o.CustomerId == customerId);

        if (status is { } s)
            q = q.Where(x => (int)x.t.Status == s);

        var rows = await q
            .OrderBy(x => x.t.Priority).ThenBy(x => x.t.SlaDueAtUtc)
            .Take(500)
            .Select(x => new { x.t, x.o.CustomerId, x.o.SubjectLine })
            .ToListAsync(ct);

        // Confidence per order (min across its documents) for the inbox column.
        var orderIds = rows.Select(r => r.t.OrderId).Distinct().ToList();
        var conf = await db.OrderDocuments.AsNoTracking()
            .Where(d => orderIds.Contains(d.OrderId))
            .GroupBy(d => d.OrderId)
            .Select(g => new { OrderId = g.Key, Min = g.Min(d => d.MinConfidence) })
            .ToDictionaryAsync(x => x.OrderId, x => x.Min, ct);

        var now = DateTimeOffset.UtcNow;
        return rows.Select(r => new TaskSummaryDto(
            r.t.Id, r.t.OrderId, r.CustomerId, r.t.Priority, r.t.Status, r.t.AssignmentKind,
            r.t.AssignedToUserId, r.SubjectLine,
            conf.TryGetValue(r.t.OrderId, out var c) ? c : 1.0,
            r.t.SlaDueAtUtc,
            (int)Math.Max(0, (r.t.SlaDueAtUtc - now).TotalSeconds))).ToList();
    }

    public async Task<Result<TaskDetailDto>> GetDetailAsync(Guid taskId, CancellationToken ct)
    {
        var task = await db.ValidationTasks.AsNoTracking().FirstOrDefaultAsync(t => t.Id == taskId, ct);
        if (task is null) return Result<TaskDetailDto>.Failure("Task not found", "task_not_found");

        var order = await db.Orders.AsNoTracking()
            .Include(o => o.Fields).Include(o => o.Lines).Include(o => o.Documents)
            .FirstAsync(o => o.Id == task.OrderId, ct);

        var now = DateTimeOffset.UtcNow;
        var minConf = order.Documents.Count > 0 ? order.Documents.Min(d => d.MinConfidence) : 1.0;
        var summary = new TaskSummaryDto(task.Id, task.OrderId, order.CustomerId, task.Priority, task.Status,
            task.AssignmentKind, task.AssignedToUserId, order.SubjectLine, minConf, task.SlaDueAtUtc,
            (int)Math.Max(0, (task.SlaDueAtUtc - now).TotalSeconds));

        // Bind extracted/validated field values straight into the customer's code-first entity class.
        var valueMap = order.Fields.ToDictionary(
            f => f.Name,
            f => f.ValidatedValue ?? f.ExtractedValue,
            StringComparer.OrdinalIgnoreCase);
        var boundEntity = schemas.Bind(order.CustomerId, valueMap);

        var detail = new TaskDetailDto(
            summary,
            order.Fields.Select(f => new FieldDto(
                f.Id, f.Name, f.ExtractedValue, f.ValidatedValue, f.Confidence, f.BoundingRegionJson,
                DeserializeCandidates(f.CandidatesJson))).ToList(),
            order.Lines.Select(l => new LineDto(l.Id, l.Sku, l.Description, l.Quantity, l.UnitPrice, l.Confidence, l.IsCorrected)).ToList(),
            order.Documents.Select(d => new DocumentRefDto(d.Id, d.FileName, d.Kind, d.ContentType)).ToList(),
            boundEntity);

        return Result<TaskDetailDto>.Success(detail);
    }

    public async Task<Result> OpenAsync(Guid taskId, CancellationToken ct) =>
        await MutateAsync(taskId, t =>
        {
            if (t.Status is Domain.TaskStatus.Completed or Domain.TaskStatus.Cancelled)
                return;
            if (!CanActOnTask(t))
                throw new InvalidOperationException("Task is assigned to another user.");
            if (t.Status == Domain.TaskStatus.Pending)
                t.Claim(user.Id);
            t.Open(user.Id);
        }, "Opened", ct);

    public async Task<Result> ClaimAsync(Guid taskId, CancellationToken ct) =>
        await MutateAsync(taskId, t =>
        {
            if (t.Status != Domain.TaskStatus.Pending && !user.IsManager && t.AssignedToUserId != user.Id)
                throw new InvalidOperationException("Only pending tasks can be claimed by a reportee.");
            t.Claim(user.Id);
        }, "Claimed", ct);

    public async Task<Result> AssignAsync(Guid taskId, string targetUserId, CancellationToken ct) =>
        await MutateAsync(taskId, t => t.AssignTo(targetUserId), "Assigned", ct);

    public async Task<Result> DelegateAsync(Guid taskId, string targetUserId, CancellationToken ct) =>
        await MutateAsync(taskId, t => t.DelegateTo(targetUserId), "Delegated", ct);

    public async Task<Result<SubmitOutcome>> SubmitAsync(Guid taskId, SubmitValidationRequest req, CancellationToken ct)
    {
        var task = await db.ValidationTasks.FirstOrDefaultAsync(t => t.Id == taskId, ct);
        if (task is null) return Result<SubmitOutcome>.Failure("Task not found", "task_not_found");
        if (task.Status is Domain.TaskStatus.Completed or Domain.TaskStatus.Cancelled)
            return Result<SubmitOutcome>.Failure("Task already closed", "task_closed");
        if (!CanActOnTask(task))
            return Result<SubmitOutcome>.Failure("You are not assigned to this task.", "forbidden_task_owner");

        var order = await db.Orders.Include(o => o.Fields).Include(o => o.Lines)
            .FirstAsync(o => o.Id == task.OrderId, ct);

        // Enforce the customer entity class's validation rules (Required / Regex) when approving.
        var submittedMap = req.Fields
            .GroupBy(f => f.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Last().Value, StringComparer.OrdinalIgnoreCase);

        if (req.Approved)
        {
            var validationErrors = schemas.Validate(order.CustomerId, submittedMap);
            if (validationErrors.Count > 0)
                return Result<SubmitOutcome>.Failure(string.Join(" ", validationErrors), "validation_failed");
        }

        // Bind to the customer's code-first entity class for strongly-typed audit metadata.
        var boundEntity = schemas.Bind(order.CustomerId, submittedMap);

        // Apply human corrections to the order aggregate.
        foreach (var vf in req.Fields)
        {
            var field = order.Fields.FirstOrDefault(f => f.Name == vf.Name);
            if (field is not null) field.ValidatedValue = vf.Value;
            else
            {
                var added = new OrderField { OrderId = order.Id, Name = vf.Name, ValidatedValue = vf.Value };
                order.Fields.Add(added);
                db.OrderFields.Add(added);
            }
        }
        foreach (var vl in req.Lines)
        {
            var line = vl.Id is { } id ? order.Lines.FirstOrDefault(l => l.Id == id) : null;
            if (line is not null)
            {
                line.IsCorrected = line.Sku != vl.Sku || line.Description != vl.Description
                    || line.Quantity != vl.Quantity || line.UnitPrice != vl.UnitPrice;
                line.Sku = vl.Sku; line.Description = vl.Description;
                line.Quantity = vl.Quantity; line.UnitPrice = vl.UnitPrice;
            }
            else
            {
                var addedLine = new OrderLine { OrderId = order.Id, Sku = vl.Sku, Description = vl.Description, Quantity = vl.Quantity, UnitPrice = vl.UnitPrice, IsCorrected = true };
                order.Lines.Add(addedLine);
                db.OrderLines.Add(addedLine);
            }
        }

        task.Complete();
        order.Advance(OrderStatus.Validated);

        var payload = new ValidationCompletedPayload(
            order.Id, user.Id, req.Approved, req.Fields, req.Lines, req.Note);

        // Transactional outbox: guarantees the Durable orchestration is resumed even if the
        // Orchestrator is unreachable at the moment the human clicks Submit.
        var outboxEntry = new OutboxMessage
        {
            Type = "ValidationCompleted",
            CorrelationId = order.CorrelationId,
            Payload = System.Text.Json.JsonSerializer.Serialize(
                new ValidationResumeEnvelope(task.OrchestrationInstanceId, payload))
        };
        db.Outbox.Add(outboxEntry);

        db.AuditEvents.Add(new AuditEvent
        {
            OrderId = order.Id,
            TaskId = task.Id,
            Action = req.Approved ? "ValidationSubmitted" : "ValidationRejected",
            UserId = user.Id,
            DataJson = boundEntity is not null ? System.Text.Json.JsonSerializer.Serialize(boundEntity) : null
        });

        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            return Result<SubmitOutcome>.Failure("Task was modified by someone else. Refresh and retry.", "concurrency_conflict");
        }

        await notifier.NotifyTaskChangedAsync(task, "completed", ct);

        logger.LogInformation("Task {TaskId} submitted by {User} ({EntityType}); resuming orchestration {Instance}",
            taskId, user.Id, boundEntity?.GetType().Name ?? "untyped", task.OrchestrationInstanceId);
        return Result<SubmitOutcome>.Success(new SubmitOutcome(order.Id, task.OrchestrationInstanceId, payload, outboxEntry.Id));
    }

    public async Task MarkOutboxDispatchedAsync(Guid outboxMessageId, CancellationToken ct)
    {
        var msg = await db.Outbox.FirstOrDefaultAsync(m => m.Id == outboxMessageId, ct);
        if (msg is null || msg.ProcessedAtUtc is not null) return;
        msg.ProcessedAtUtc = DateTimeOffset.UtcNow;
        msg.Attempts++;
        await db.SaveChangesAsync(ct);
    }

    private bool CanActOnTask(ValidationTask t) =>
        user.IsManager
        || t.Status == Domain.TaskStatus.Pending
        || t.AssignedToUserId == user.Id
        || t.ClaimedByUserId == user.Id;

    private async Task<Result> MutateAsync(Guid taskId, Action<ValidationTask> mutate, string action, CancellationToken ct)
    {
        var task = await db.ValidationTasks.FirstOrDefaultAsync(t => t.Id == taskId, ct);
        if (task is null) return Result.Failure("Task not found", "task_not_found");
        try
        {
            mutate(task);
            db.AuditEvents.Add(new AuditEvent { OrderId = task.OrderId, TaskId = task.Id, Action = action, UserId = user.Id });
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            return Result.Failure("Task was modified concurrently. Refresh and retry.", "concurrency_conflict");
        }
        catch (InvalidOperationException ex)
        {
            return Result.Failure(ex.Message, "invalid_operation");
        }
        await notifier.NotifyTaskChangedAsync(task, action.ToLowerInvariant(), ct);
        return Result.Success();
    }

    private static IReadOnlyList<FieldCandidateDto>? DeserializeCandidates(string? json) =>
        string.IsNullOrWhiteSpace(json)
            ? null
            : System.Text.Json.JsonSerializer.Deserialize<List<FieldCandidateDto>>(json);

    private string ManagerScope() => user.IsManager ? user.Id : LookupManagerId();
    private string LookupManagerId() =>
        db.Users.AsNoTracking().Where(u => u.Id == user.Id).Select(u => u.ManagerId).FirstOrDefault() ?? "mgr-1";
}
