using System.Security.Claims;
using OrderFlow.Domain;

namespace OrderFlow.OrderApi.Services;

/// <summary>Resolves the authenticated user's id and role from the incoming claims principal.</summary>
public sealed class CurrentUser(IHttpContextAccessor accessor)
{
    private ClaimsPrincipal? Principal => accessor.HttpContext?.User;

    public string Id =>
        Principal?.FindFirstValue("oid")
        ?? Principal?.FindFirstValue(ClaimTypes.NameIdentifier)
        ?? Principal?.FindFirstValue("sub")
        ?? "anonymous";

    public string DisplayName => Principal?.FindFirstValue("name") ?? Id;

    public UserRole Role =>
        Principal?.IsInRole("Manager") == true ? UserRole.Manager : UserRole.Reportee;

    public bool IsManager => Role == UserRole.Manager;
}
