using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.DurableTask;
using Microsoft.DurableTask.Client;
using Microsoft.Extensions.Logging;
using OrderFlow.Contracts;

namespace OrderFlow.Orchestrator;

/// <summary>
/// One Service Bus trigger per priority subscription keeps high-priority starts isolated from a
/// low-priority backlog (bulkhead). Each starts an orchestration with a deterministic instance id
/// (== correlation id) so duplicate deliveries do not create duplicate orchestrations.
/// </summary>
public sealed class PriorityStarters(ILogger<PriorityStarters> logger)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    [Function("Start_High")]
    public Task StartHigh(
        [ServiceBusTrigger(Topics.Orders, Topics.SubHigh, Connection = "ServiceBus")] string body,
        [DurableClient] DurableTaskClient client, CancellationToken ct) => StartAsync(body, client, ct);

    [Function("Start_Standard")]
    public Task StartStandard(
        [ServiceBusTrigger(Topics.Orders, Topics.SubStandard, Connection = "ServiceBus")] string body,
        [DurableClient] DurableTaskClient client, CancellationToken ct) => StartAsync(body, client, ct);

    [Function("Start_Low")]
    public Task StartLow(
        [ServiceBusTrigger(Topics.Orders, Topics.SubLow, Connection = "ServiceBus")] string body,
        [DurableClient] DurableTaskClient client, CancellationToken ct) => StartAsync(body, client, ct);

    private async Task StartAsync(string body, DurableTaskClient client, CancellationToken ct)
    {
        var evt = JsonSerializer.Deserialize<OrderReceived>(body, Json)
                  ?? throw new InvalidOperationException("Invalid OrderReceived message body.");

        var instanceId = evt.CorrelationId.ToString("N");
        var options = new StartOrchestrationOptions(InstanceId: instanceId);

        // Idempotent start: if the instance already exists, do not start a second one.
        var existing = await client.GetInstanceAsync(instanceId, ct);
        if (existing is not null)
        {
            logger.LogInformation("Orchestration {InstanceId} already exists ({Status}); skipping duplicate.",
                instanceId, existing.RuntimeStatus);
            return;
        }

        await client.ScheduleNewOrchestrationInstanceAsync(nameof(OrderOrchestrator), evt, options, ct);
        logger.LogInformation("Started orchestration {InstanceId} for customer {Customer} priority {Priority}",
            instanceId, evt.CustomerId, evt.Priority);
    }
}
