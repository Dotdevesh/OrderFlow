using Azure.Identity;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.CustomerModel;
using OrderFlow.Orchestrator.Services;

var builder = FunctionsApplication.CreateBuilder(args);
var cfg = builder.Configuration;

builder.Services.AddApplicationInsightsTelemetryWorkerService();

// Blob storage (Managed Identity in Azure; Azurite/connection string locally).
builder.Services.AddSingleton(_ =>
{
    var endpoint = cfg["Storage:BlobEndpoint"];
    return string.IsNullOrWhiteSpace(endpoint)
        ? new BlobServiceClient(cfg["Storage:ConnectionString"] ?? "UseDevelopmentStorage=true")
        : new BlobServiceClient(new Uri(endpoint), new DefaultAzureCredential());
});
builder.Services.AddSingleton<IBlobDocumentStore>(sp => new BlobDocumentStore(
    sp.GetRequiredService<BlobServiceClient>(),
    cfg["Storage:Container"] ?? "order-documents",
    sp.GetRequiredService<ILogger<BlobDocumentStore>>()));

// Typed Order API client (service-to-service).
builder.Services.AddHttpClient<IOrderApiClient, OrderApiClient>(c =>
{
    c.BaseAddress = new Uri(cfg["OrderApi:BaseUrl"] ?? "http://localhost:5080");
    var apiKey = cfg["OrderApi:InternalApiKey"];
    if (!string.IsNullOrWhiteSpace(apiKey))
        c.DefaultRequestHeaders.Add("X-Internal-ApiKey", apiKey);
});

// Pipeline collaborators (Graph reader / converter / Doc Intelligence) behind interfaces.
builder.Services.AddSingleton<IEmailReader, GraphEmailReader>();
builder.Services.AddSingleton<IDocumentConverter, PassthroughDocumentConverter>();
builder.Services.AddSingleton<IEntityExtractor, DocumentIntelligenceExtractor>();

// Code-first per-customer schemas: the same entity classes drive extraction plans here and
// form rendering in the Order API.
builder.Services.AddCustomerSchemas();

builder.Build().Run();
