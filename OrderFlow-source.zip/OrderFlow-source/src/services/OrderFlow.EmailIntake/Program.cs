using Azure.Identity;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.EmailIntake.Services;

var builder = FunctionsApplication.CreateBuilder(args);
builder.ConfigureFunctionsWebApplication();

var cfg = builder.Configuration;

// Application Insights (Functions worker). The worker also wires AI logging automatically.
builder.Services.AddApplicationInsightsTelemetryWorkerService();

// Service Bus client (Managed Identity in Azure, connection string locally).
builder.Services.AddSingleton(_ =>
{
    var ns = cfg["ServiceBus:FullyQualifiedNamespace"];
    return string.IsNullOrWhiteSpace(ns)
        ? new ServiceBusClient(cfg["ServiceBus"] ?? cfg.GetConnectionString("ServiceBus"))
        : new ServiceBusClient(ns, new DefaultAzureCredential());
});

builder.Services.AddHttpClient<IIntakeLedgerClient, HttpIntakeLedgerClient>(c =>
{
    c.BaseAddress = new Uri(cfg["OrderApi:BaseUrl"] ?? "http://localhost:5080");
    c.Timeout = TimeSpan.FromSeconds(3); // keep Graph webhook fast
    var apiKey = cfg["OrderApi:InternalApiKey"];
    if (!string.IsNullOrWhiteSpace(apiKey))
        c.DefaultRequestHeaders.Add("X-Internal-ApiKey", apiKey);
});

builder.Services.AddSingleton<IEventPublisher, ServiceBusEventPublisher>();
builder.Services.AddSingleton<ICustomerResolver, CustomerResolver>();
builder.Services.AddSingleton<ISeenMessageStore, InMemorySeenMessageStore>();

builder.Build().Run();
