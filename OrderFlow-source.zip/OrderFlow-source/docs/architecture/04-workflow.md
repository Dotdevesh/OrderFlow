# 04 — End-to-End Workflow

This document describes the complete order lifecycle as a **state machine** and the key
**sequence flows**, including failure and SLA paths.

## 1. Order state machine

```mermaid
stateDiagram-v2
    [*] --> Received : OrderReceived event
    Received --> Stored : StoreDocuments
    Stored --> Extracted : AnalyzeDocument (fan-in)
    Extracted --> PendingValidation : CreateValidationTask
    PendingValidation --> Validated : ValidationCompleted (human submit)
    PendingValidation --> PendingValidation : SLA breach -> Escalate -> re-wait
    Validated --> Finalized : FinalizeOrder
    Received --> Failed : unrecoverable error (DLQ)
    Stored --> Failed
    Extracted --> Failed
    Finalized --> [*]
    Failed --> [*]
```

## 2. Validation task state machine

```mermaid
stateDiagram-v2
    [*] --> Pending : task created (pool) 
    Pending --> Assigned : Manager assigns
    Pending --> Claimed : Reportee/Manager claims from pool
    Assigned --> Claimed : assignee opens
    Claimed --> InProgress : editing
    InProgress --> Completed : submit
    Assigned --> Assigned : Manager re-delegates
    Pending --> Escalated : SLA breach
    Assigned --> Escalated : SLA breach
    Escalated --> Assigned : Manager re-assigns
    Completed --> [*]
```

## 3. Golden path sequence

(See the full sequence diagram in [01-HLD.md §4](01-HLD.md) and
[diagrams/seq-01-happy-path.md](diagrams/seq-01-happy-path.md).)

Summary of stages and the component that owns each:

| Stage | Owner | Output |
|-------|-------|--------|
| Notification received | Email Intake | `OrderReceived` on Service Bus |
| Orchestration started | Orchestrator (SB trigger) | instance id persisted |
| Email fetched | `FetchEmail` activity (Graph) | MIME + attachments |
| Converted to PDF | `ConvertToPdf` activity | PDF per document |
| Stored | `StoreDocuments` activity | blob paths |
| Order created | `CreateOrder` → Order API | `OrderId`, status `Received` |
| Entities extracted | `AnalyzeDocument` (fan-out/fan-in) | fields + confidence |
| Task created & routed | `CreateValidationTask` → Order API | `ValidationTask` (Pending/Assigned) |
| **Human validates** | Action Center + Order API | corrected fields |
| Workflow resumes | Order API raises `ValidationCompleted` | orchestrator continues |
| Finalized | `FinalizeOrder` | status `Finalized`, downstream handoff |

## 4. Human-in-the-loop resume (the critical mechanism)

```mermaid
sequenceDiagram
    autonumber
    participant OR as Orchestrator
    participant DT as Durable runtime (state store)
    participant API as Order API
    participant U as Validator

    OR->>DT: WaitForExternalEvent("ValidationCompleted") + CreateTimer(SlaDueAt)
    Note over OR,DT: Orchestrator is dehydrated (no compute cost while waiting)
    U->>API: POST /api/tasks/{id}/submit (validated data)
    API->>API: Persist corrections, Task=Completed, concurrency check
    API->>DT: RaiseEventAsync(instanceId, "ValidationCompleted", payload)
    DT-->>OR: Rehydrate + deliver event (timer cancelled)
    OR->>API: FinalizeOrder
    API-->>U: SignalR task-completed
```

**SLA breach branch:** if the timer fires before the event, the orchestrator calls `Escalate`
(reassign to a manager, raise alert) and **re-arms** the wait with a new (shorter) timer, so the
task is never lost.

## 5. Failure & compensation

- Any activity failure retries per policy; exhausted retries fail the orchestration and the
  triggering Service Bus message dead-letters after max delivery → alert + manual replay.
- `CreateOrder` is idempotent (upsert by `CorrelationId`) so a replay after partial success does
  not duplicate orders.
- Because the order is created early (`Received`), **no inbound email is ever lost** even if later
  stages fail — it can be retried or triaged manually.

## 6. Volume & backpressure

At ~1 order/sec sustained (with bursts), Service Bus absorbs spikes; orchestrator scale-out is
bounded; Document Intelligence calls are rate-limited by a semaphore. The human stage is the
slowest and is decoupled by design — orchestrations waiting on humans consume **no compute**.
See [07-priority-sla.md](07-priority-sla.md) for per-tier throughput targets.
