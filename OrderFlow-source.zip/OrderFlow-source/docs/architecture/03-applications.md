# 03 — Applications & Boundaries

This solution is composed of **four deployable applications** plus **three shared libraries** and
**one infrastructure project**. Each application is independently deployable, scalable, and owned
by a single team.

## Why these boundaries?

The system has three distinct runtime concerns with very different scaling and failure profiles:

1. **Ingestion** — spiky, I/O-bound, must ack Graph in < 30s, must never lose a notification.
2. **Long-running orchestration** — stateful, hours-to-days lifetime (waiting on a human), needs
   checkpointing and replay.
3. **Interactive request/response** — low-latency reads/commands for humans, transactional writes
   to SQL, realtime push.

Mixing these in one process would couple their scaling and failure domains. Hence the split.

```mermaid
flowchart LR
    subgraph Ingest[1. Ingestion]
        EI[Email Intake Function]
    end
    subgraph Orchestrate[2. Orchestration]
        OR[Orchestrator Durable Functions]
    end
    subgraph Interact[3. Interactive]
        API[Order API]
        AC[Action Center SPA]
    end
    EI -->|Service Bus| OR
    OR -->|HTTPS create/finalize| API
    API -->|raise external event| OR
    AC <-->|HTTPS + SignalR| API
```

---

## 1. Email Intake — `OrderFlow.EmailIntake`

**Type:** Azure Functions (.NET 10 isolated).
**Triggers:**
- `HttpTrigger` **`GraphWebhook`** — receives Microsoft Graph **change notifications** for new
  mail in the monitored shared mailbox(es). Handles the **validation handshake** and the
  **notification** POSTs.
- `TimerTrigger` **`SubscriptionRenewal`** — renews Graph subscriptions before expiry.

**Responsibilities:**
- Validate notification authenticity (clientState, token validation).
- De-duplicate (`messageId` already seen?) using a small state store (Table/Blob).
- Resolve the **customer** + **priority tier** from the sender/recipient/domain rules.
- Publish an `OrderReceived` integration event to the Service Bus **topic** with
  `priority` and `customerId` message properties.
- **It does NOT** download the email body/attachments — that heavy lifting is a durable,
  retryable activity in the Orchestrator. Intake stays fast to meet Graph's ack window.

**Why a Function:** event-driven, scales to zero, elastic for bursts, cheap.

---

## 2. Orchestrator — `OrderFlow.Orchestrator`

**Type:** Azure **Durable Functions** (.NET 10 isolated).
**Triggers:**
- `ServiceBusTrigger` (one per priority subscription) → **starts** an orchestration instance.
- `OrchestrationTrigger` → the orchestrator function (deterministic coordination code).
- `ActivityTrigger` → the idempotent units of work.

**Orchestration steps** (see [06-durable-functions.md](06-durable-functions.md)):
1. `FetchEmailActivity` — Graph: download MIME, body, attachments.
2. `ConvertToPdfActivity` — email body → PDF; normalize each attachment → PDF.
3. `StoreDocumentsActivity` — persist all PDFs to Blob (`{customer}/{orderId}/...`).
4. `CreateOrderActivity` — create the Order aggregate (via Order API / SQL) → `OrderId`.
5. **Fan-out/fan-in** `AnalyzeDocumentActivity` — Document Intelligence per PDF → entities.
6. `CreateValidationTaskActivity` — persist extraction + create a **validation task** assigned
   per customer routing rules.
7. `WaitForExternalEvent("ValidationCompleted")` **with an SLA `CreateTimer`** — the
   human-in-the-loop pause.
8. `FinalizeOrderActivity` on success **or** `EscalateActivity` on SLA breach (then re-wait).

**Why Durable Functions:** native support for long-running, stateful workflows with
checkpoint/replay, built-in **external events** for human-in-the-loop, **durable timers** for
SLA, and fan-out/fan-in for parallel document analysis. See
[ADR-0002](../adr/0002-durable-functions-for-orchestration.md).

---

## 3. Order API — `OrderFlow.OrderApi`

**Type:** ASP.NET Core **Minimal API** (.NET 10), EF Core 10 → **SQL Server**, SignalR.
**Responsibilities (BFF for the Action Center):**
- **Orders**: create (called by orchestrator), read, finalize.
- **Validation tasks**: list (inbox), get detail (entities + document SAS URLs), claim, assign,
  delegate, submit.
- **Role & authorization**: Manager vs Reportee rules (see
  [08-action-center-roles.md](08-action-center-roles.md)).
- **Resume the workflow**: on submit, use the Durable **orchestration client** to
  `RaiseEventAsync(instanceId, "ValidationCompleted", payload)`.
- **Realtime**: SignalR hub pushes task assignment / SLA-countdown updates to the UI.
- **Outbox**: domain events persisted transactionally then dispatched to Service Bus.

**Why a dedicated API:** humans need low-latency, transactional, authorized access to SQL and a
shape tailored to the UI. Keeping this out of the Function apps isolates interactive traffic from
batch/orchestration scaling.

---

## 4. Action Center — `action-center`

**Type:** **Angular 20** SPA (standalone components, signals, Angular Material).
**Key features:**
- **MSAL** login (Entra ID), role claims drive the UI.
- **Task inbox**: My Tasks / Team Pending / Assigned, filtered by priority & SLA countdown.
- **Validation workspace**: **PDF viewer and entity form side-by-side**, field-level confidence
  highlighting, inline correction, keyboard-first.
- **Manager**: self-validate+submit, **assign/delegate** to team members, reassign.
- **Reportee**: claim from pending pool, validate + complete; **cannot delegate**.
- **Realtime** SLA countdown + new-task toast via SignalR.

---

## Shared libraries

| Library | Contents |
|---------|----------|
| `OrderFlow.Contracts` | Integration event contracts (`OrderReceived`, `OrderExtracted`, `ValidationCompleted`), message property keys, API DTOs. The *only* thing services share. |
| `OrderFlow.Domain` | Entities & value objects (`Order`, `OrderLine`, `ValidationTask`, `CustomerProfile`), enums (`CustomerTier`, `Priority`, `OrderStatus`, `TaskStatus`, `UserRole`), domain events. |
| `OrderFlow.BuildingBlocks` | Cross-cutting: Service Bus publisher/consumer abstractions, Blob storage gateway, `Result<T>`, telemetry/correlation, guard clauses, retry policies. |

## Infrastructure — `infra/`

**Bicep** modules: Service Bus (topic + priority subscriptions), Storage (blobs + durable task
hub), SQL Server + DB, Function Apps, App Service for the API, Static Web App for Angular,
Document Intelligence, Key Vault, Application Insights, Managed Identities + RBAC.

## Deployment topology

```mermaid
flowchart TB
    subgraph Azure
        subgraph FA[Function Apps - Elastic/Flex]
            EI[Email Intake]
            OR[Orchestrator]
        end
        API[App Service: Order API]
        SWA[Static Web App: Action Center]
        SB[(Service Bus)]
        BLOB[(Blob Storage)]
        SQL[(Azure SQL)]
        DI[Document Intelligence]
        KV[Key Vault]
        AI[App Insights]
    end
    GRAPH[Microsoft Graph] --> EI
    EI --> SB --> OR
    OR --> BLOB
    OR --> DI
    OR --> API --> SQL
    SWA --> API
    API -. SignalR .-> SWA
    FA & API --> KV
    FA & API & SWA --> AI
```
