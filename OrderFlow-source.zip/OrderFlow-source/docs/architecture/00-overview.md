# 00 — Architecture Overview

## Business case

A B2B operation receives **customer orders by email** — potentially **one order per second** at
peak. Each email may contain an order in the body and/or as attachments (PDF, scanned images,
Office docs). The business needs to:

1. **Ingest** the email the moment it arrives.
2. **Normalize** it: convert the email body and every attachment to **PDF**.
3. **Create an order** record immediately (so nothing is lost) and **store all files** durably.
4. **Extract structured entities** (customer, PO number, line items, totals, dates, addresses…)
   from every PDF using **Azure AI Document Intelligence**.
5. Route the extraction to a **human validator** (the *Action Center*) who sees the **PDF and a
   pre-filled form side-by-side**, corrects/validates the data, and **submits**.
6. On submit, the long-running process **resumes** and **finalizes** the order downstream
   (ERP/fulfilment).
7. Honour **per-customer priority and SLA** — a Platinum customer's order must be validated far
   faster than a Silver customer's, and high-priority work must never get stuck behind a backlog.

## Architecture style

- **Event-driven + orchestration (Saga via Durable Functions).** Ingestion is reactive (Graph
  change notifications → Service Bus). The long-running, stateful business transaction is an
  **orchestrator** that coordinates idempotent **activities** and includes a durable
  **human-in-the-loop** wait.
- **Microservices with clear boundaries**, deployed independently, communicating via
  **integration events** on Azure Service Bus and **HTTPS** for synchronous reads/commands.
- **CQRS-lite** in the Order API: write model (EF Core aggregates) separated from read models
  optimized for the Action Center task inbox.
- **BFF (Backend-for-Frontend)**: the Order API is tailored to the Action Center.

## Guiding principles (quality attributes)

| Attribute | How it is achieved |
|-----------|--------------------|
| **Scalability** (1 order/sec, bursty) | Stateless functions + elastic scale; Service Bus buffering; fan-out/fan-in for document analysis; priority isolation. |
| **Reliability / exactly-once effect** | Durable Functions checkpointing; idempotent activities keyed by `MessageId`/`OrderId`; Service Bus dedup window; outbox pattern in Order API. |
| **Resilience** | Retries with exponential backoff (activity retry policies + Polly), dead-letter queues, circuit breakers on external deps (Graph, Doc Intelligence). |
| **Latency / SLA** | Priority-segregated subscriptions, dedicated concurrency per tier, durable SLA timers with escalation. |
| **Security** | Entra ID everywhere, Managed Identity for Azure resource access, no secrets in code (Key Vault), least-privilege RBAC, PII handling. |
| **Observability** | OpenTelemetry traces correlated by `OrderId`/`CorrelationId` end-to-end, Application Insights, structured logs, business KPIs. |
| **Maintainability** | DDD-lite domain model, Clean Architecture layering, shared contracts package, ADRs. |

## The 10 business points mapped to the design

| # | Business point | Design element |
|---|----------------|----------------|
| 1 | Email arrives | **Graph change notification** → Email Intake Function (webhook) |
| 2 | Convert email + attachments to PDF | Orchestrator activity `ConvertToPdfActivity` (email MIME → PDF; attachments normalized) |
| 3 | Durable function reads it, creates an order | `OrchestrationTrigger` + `CreateOrderActivity` (writes to SQL via Order API) |
| 4 | Store files in Blob | `StoreDocumentsActivity` → Blob container per customer/order |
| 5 | Document Intelligence extracts entities | `AnalyzeDocumentActivity` fan-out/fan-in per document |
| 6 | Human-in-the-loop Angular form + PDF | Action Center + Order API; validation **task** created and assigned |
| 7 | User validates & submits | Order API command → raises **external event** `ValidationCompleted` |
| 8 | Durable function resumes after validation | `WaitForExternalEvent("ValidationCompleted")` + SLA durable timer |
| 9 | Read email with Graph API | Email Intake + `FetchEmailActivity` (Graph SDK, app-only auth) |
| 10 | Per-customer priority & SLA, very high volume | Service Bus **topic + priority subscriptions**, customer tier config, SLA timers, escalation |

See the diagrams in [`diagrams/`](diagrams/) and the deep-dives numbered 04–08.
