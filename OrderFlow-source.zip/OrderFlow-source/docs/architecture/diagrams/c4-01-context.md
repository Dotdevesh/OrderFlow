# C4 Level 1 — System Context

```mermaid
C4Context
    title System Context — OrderFlow

    Person(customer, "Customer", "Sends order emails with attachments")
    Person(manager, "Manager", "Validates/submits, assigns & delegates tasks")
    Person(reportee, "Reportee", "Claims & validates assigned/pending tasks")

    System(orderflow, "OrderFlow Platform", "Ingests order emails, extracts entities, routes human validation, finalizes orders")

    System_Ext(graph, "Microsoft Graph", "Email change notifications & content")
    System_Ext(di, "Azure AI Document Intelligence", "OCR + entity extraction")
    System_Ext(entra, "Microsoft Entra ID", "Identity & access")
    System_Ext(erp, "Downstream ERP / Fulfilment", "Receives finalized orders")

    Rel(customer, graph, "Sends email to monitored mailbox")
    Rel(graph, orderflow, "Change notifications / message content", "HTTPS/webhook, Graph API")
    Rel(orderflow, di, "Analyze documents", "HTTPS")
    Rel(manager, orderflow, "Validate / assign / delegate", "HTTPS (Action Center)")
    Rel(reportee, orderflow, "Claim / validate / complete", "HTTPS (Action Center)")
    Rel(orderflow, entra, "AuthN/Z (MSAL, MI, app-only)", "OIDC/OAuth2")
    Rel(orderflow, erp, "Finalized order handoff", "HTTPS/queue")
```
