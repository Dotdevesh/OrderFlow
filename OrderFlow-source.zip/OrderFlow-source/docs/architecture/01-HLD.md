# 01 — High Level Design (HLD)

## 1. Purpose & scope

OrderFlow ingests inbound customer order emails and produces **validated orders** through an
automated extraction pipeline with a mandatory **human validation** gate. This HLD describes the
system context, major building blocks, data flow, cross-cutting concerns, and non-functional
design at a level suitable for architects and stakeholders. Component-level detail is in the
[LLD](02-LLD.md).

## 2. System context (C4 Level 1)

See [`diagrams/c4-01-context.md`](diagrams/c4-01-context.md).

**Actors & external systems**
- **Customers** — send order emails to a monitored shared mailbox.
- **Validator (Manager / Reportee)** — internal users who validate extractions in the Action Center.
- **Microsoft Graph** — source of email change notifications and message content.
- **Azure AI Document Intelligence** — OCR + entity extraction.
- **Entra ID** — identity provider for users and service principals.
- **Downstream ERP / Fulfilment** (out of scope, integration point) — receives finalized orders.

## 3. Logical building blocks (C4 Level 2)

See [`diagrams/c4-02-container.md`](diagrams/c4-02-container.md).

| Block | Role |
|-------|------|
| Email Intake Function | Graph webhook receiver → publish `OrderReceived`. |
| Service Bus (topic + subscriptions) | Priority-segregated durable buffer / backbone. |
| Orchestrator (Durable Functions) | Stateful saga: fetch → PDF → store → create → extract → **wait for human** → finalize. |
| Blob Storage | Immutable document store (email PDF + attachment PDFs + extraction JSON). |
| Document Intelligence | Entity extraction. |
| Order API | BFF + SQL write/read + workflow resume + SignalR. |
| SQL Server | System of record for Orders, Tasks, Customers, Users, Audit. |
| Action Center (Angular) | Human-in-the-loop UI. |
| Key Vault / App Insights / Managed Identity | Secrets, observability, identity. |

## 4. End-to-end data flow (happy path)

```mermaid
sequenceDiagram
    autonumber
    participant C as Customer
    participant G as MS Graph
    participant EI as Email Intake
    participant SB as Service Bus
    participant OR as Orchestrator
    participant BL as Blob
    participant DI as Doc Intelligence
    participant API as Order API
    participant DB as SQL
    participant U as Validator (Action Center)

    C->>G: Sends order email
    G-->>EI: Change notification (webhook)
    EI->>EI: Validate, de-dupe, resolve customer+priority
    EI->>SB: Publish OrderReceived {msgId, customerId, priority}
    SB-->>OR: Deliver (priority subscription)
    OR->>G: FetchEmail (MIME + attachments)
    OR->>OR: ConvertToPdf (body + attachments)
    OR->>BL: StoreDocuments
    OR->>API: CreateOrder -> OrderId
    API->>DB: Persist Order (Received)
    par Fan-out per document
        OR->>DI: AnalyzeDocument(pdf)
        DI-->>OR: Entities + confidence
    end
    OR->>API: CreateValidationTask (entities)
    API->>DB: Persist Task (Pending) + route/assign
    API-->>U: SignalR: new task
    U->>API: Open task (entities + PDF SAS)
    U->>API: Submit validated data
    API->>DB: Save corrections, Task=Completed
    API->>OR: RaiseEvent ValidationCompleted
    OR->>API: FinalizeOrder
    API->>DB: Order=Finalized
    API-->>U: SignalR: task done
```

## 5. Priority & SLA (high volume)

- Customers are classified into **tiers** (Platinum / Gold / Silver) → mapped to a **Priority**
  (High / Standard / Low) and an **SLA** (validation deadline in minutes).
- A single Service Bus **topic** `orders` with **per-priority subscriptions** and SQL filter rules
  gives independent, isolated consumers. High priority gets more concurrency and its own scale.
- The human-validation SLA is enforced by a **durable timer**; breach triggers **escalation**
  (reassign to manager / notify) without failing the workflow.
- See [07-priority-sla.md](07-priority-sla.md).

## 6. Human-in-the-loop & workflow resume

The orchestrator persists its state and **suspends** on `WaitForExternalEvent`. The Order API,
upon user submit, raises the named event through the Durable **orchestration client**, which the
runtime matches to the suspended instance and **resumes** execution from the checkpoint. A
parallel **durable timer** races the event for SLA. See [06-durable-functions.md](06-durable-functions.md).

## 7. Security (HLD)

- **AuthN**: Entra ID. Users → Action Center via **MSAL** (Auth Code + PKCE). Services → Azure
  resources via **Managed Identity**. Graph → **app-only** (client credentials) with least Graph
  scopes (`Mail.Read` on specific mailboxes via Application Access Policy).
- **AuthZ**: Role-based (Manager/Reportee) + resource-based checks (own team / own task).
- **Secrets**: Key Vault; no secrets in config/code.
- **Data protection**: TLS in transit; encryption at rest (platform); PII minimization; blob SAS
  are short-lived, user-scoped, read-only.
- **Webhook integrity**: `clientState` + validation token + optional encrypted resource data.

## 8. Observability (HLD)

- **Distributed tracing** via OpenTelemetry; `CorrelationId` = `OrderId` propagated across
  Service Bus (message app-properties), HTTP (headers), and Durable context.
- **Application Insights**: requests, dependencies, exceptions, custom business events
  (`OrderReceived`, `ExtractionCompleted`, `ValidationSubmitted`, `SlaBreached`).
- **Dashboards & alerts**: queue depth per priority, orchestration backlog, SLA breach rate,
  Doc Intelligence latency, DLQ counts.

## 9. Reliability & failure handling (HLD)

| Failure | Handling |
|---------|----------|
| Graph transient error | Activity retry (exp. backoff); circuit breaker. |
| Doc Intelligence throttling | Retry + fan-in tolerance; low-confidence → always goes to human anyway. |
| Order API down | Service Bus retains message; orchestrator activity retries. |
| Poison message | Max delivery → **dead-letter queue** + alert. |
| Human never responds | SLA timer → escalation loop, never silently lost. |
| Duplicate notification | De-dup by `messageId`; idempotent activities. |

## 10. Scalability model

- Email Intake & Orchestrator on **Functions Flex Consumption** (elastic, scale to zero).
- Order API on **App Service**/Container Apps with autoscale on CPU + request queue length.
- Document analysis parallelized via **fan-out/fan-in**, bounded by a semaphore to respect
  Doc Intelligence TPS.
- SQL: appropriately sized tier, read models/indexes tuned for inbox queries; partitioning by
  customer if needed.

## 11. Environments

`dev` → `test` → `prod`, provisioned by Bicep, promoted via CI/CD (GitHub Actions / Azure
DevOps). Per-environment Service Bus, Storage, SQL, Function Apps, Key Vault.

## 12. Assumptions & open questions

- One or more **shared mailboxes** are the ingestion point (not per-customer mailboxes).
- Customer identification is rule-based (sender domain) with a fallback to "unassigned/triage".
- Finalization target (ERP) is a stub integration point in this POC.
- Attachment formats: PDF, PNG/JPG/TIFF, DOCX/XLSX; rendered to PDF for a uniform viewer.
