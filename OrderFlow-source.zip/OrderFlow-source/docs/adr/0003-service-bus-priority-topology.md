# ADR-0003 — Service Bus topic + priority subscriptions

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

Different customers have different tiers → priorities and SLAs. High-priority orders must not be
starved by a low-priority backlog, and routing should be extensible without changing the publisher.

## Decision

Publish `OrderReceived` **once** to a single Service Bus **topic `orders`** with a `priority`
message property. Create **per-priority subscriptions** (`sub-high`, `sub-standard`, `sub-low`)
with **SQL filter rules**. Each subscription has its own starter function and independent scaling.
Enable duplicate detection (by `MessageId`) and dead-letter queues. Offer optional **sessions**
(`SessionId = customerId`) where strict per-customer ordering is required.

## Options considered

1. **Single queue with message priority** — Service Bus has no true priority queue; head-of-line
   blocking.
2. **One queue per priority** — works, but publisher must know all routes; less extensible.
3. **Topic + priority subscriptions (chosen)** — publish once, route by rules, add subscriptions
   (triage/VIP) without touching the publisher; independent scaling per priority = bulkhead.

## Consequences

- ➕ Priority isolation; extensible routing; one publish.
- ➕ DLQ + dedup built in.
- ➖ Slightly more topology to provision (automated via Bicep).
- ➖ Sessions reduce intra-customer parallelism → opt-in per tier.
