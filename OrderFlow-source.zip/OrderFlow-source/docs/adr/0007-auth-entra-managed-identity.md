# ADR-0007 — Entra ID + Managed Identity for all auth

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

We need user auth for the Action Center, service-to-Azure auth (Service Bus, Storage, SQL, Key
Vault, Document Intelligence), and app-only access to Microsoft Graph — all with least privilege
and no secrets in code.

## Decision

- **Users → Action Center**: MSAL (Auth Code + PKCE), Entra ID; role claims (Manager/Reportee)
  drive UI + API policies.
- **Services → Azure resources**: **Managed Identity** + RBAC (Service Bus Data Sender/Receiver,
  Storage Blob Data Contributor, SQL AAD auth, Key Vault Secrets User, Cognitive Services User).
- **App → Graph**: app-only (client credentials via MI federation or cert in Key Vault) with
  `Mail.Read` scoped to specific mailboxes via **Application Access Policy**.
- **Secrets**: Key Vault only; local dev via user-secrets.

## Consequences

- ➕ No secrets in code/config; least privilege; central identity.
- ➖ Requires Entra app registrations, RBAC assignments, and Graph application access policy setup
  (captured in infra + runbooks).
