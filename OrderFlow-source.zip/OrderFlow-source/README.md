# OrderFlow — Intelligent Order Intake & Validation Platform

OrderFlow turns inbound customer **emails** into validated **orders** using an event-driven,
Durable-Functions orchestration with a **human-in-the-loop** validation step performed in the
**Action Center** (Angular) app.

> As soon as an email arrives → convert the email + attachments to PDF → create an order →
> store files in Blob → extract entities with **Azure AI Document Intelligence** → route a
> validation task to a human (Manager / Reportee) → on submit, the Durable orchestration
> **resumes** and finalizes the order. Every customer has their own **priority** and **SLA**.

## Repository layout

```
POC/
├─ docs/
│  ├─ architecture/        HLD, LLD, applications, workflow, deep-dives
│  │  └─ diagrams/         C4 (context/container/component), sequence, state (Mermaid)
│  └─ adr/                 Architecture Decision Records
├─ src/
│  ├─ OrderFlow.sln
│  ├─ building-blocks/     Shared contracts, domain, cross-cutting
│  ├─ services/
│  │  ├─ OrderFlow.EmailIntake/       Azure Function — Graph webhook → Service Bus
│  │  ├─ OrderFlow.Orchestrator/      Durable Functions — the core workflow
│  │  └─ OrderFlow.OrderApi/          .NET 10 Web API — BFF for Action Center + SQL
│  └─ clients/
│     └─ action-center/    Angular 20 — human-in-the-loop UI
└─ infra/                  Bicep IaC (Azure)
```

## Applications (deployable units)

| # | Application | Type | Tech | Responsibility |
|---|-------------|------|------|----------------|
| 1 | **Email Intake** | Azure Function (isolated) | .NET 10 | Receive Graph change notifications, de-dupe, enrich with customer/priority, publish to Service Bus |
| 2 | **Orchestrator** | Azure Durable Functions (isolated) | .NET 10 | Fetch email, email→PDF, store blobs, create order, Document Intelligence extraction, **wait for human validation**, finalize/escalate |
| 3 | **Order API** | ASP.NET Core Minimal API | .NET 10 + EF Core 10 + SQL Server | BFF for Action Center, task assignment/delegation, raises the external event that resumes the orchestration, SignalR realtime |
| 4 | **Action Center** | SPA | Angular 20 + Material + MSAL | Task inbox, side-by-side PDF + entity form, validate/submit, Manager/Reportee roles |
| — | **Building Blocks** | Class libraries | .NET 10 | `Contracts` (integration events/DTOs), `Domain` (entities/enums), `BuildingBlocks` (Service Bus, Blob, telemetry) |

See [`docs/architecture/03-applications.md`](docs/architecture/03-applications.md) for the full rationale.

## Documentation index

- [00 — Architecture Overview](docs/architecture/00-overview.md)
- [01 — High Level Design (HLD)](docs/architecture/01-HLD.md)
- [02 — Low Level Design (LLD)](docs/architecture/02-LLD.md)
- [03 — Applications & Boundaries](docs/architecture/03-applications.md)
- [04 — End-to-End Workflow](docs/architecture/04-workflow.md)
- [05 — Email Ingestion with Microsoft Graph](docs/architecture/05-email-graph.md)
- [06 — Durable Functions & Human-in-the-Loop Resume](docs/architecture/06-durable-functions.md)
- [07 — Priority & SLA with Service Bus](docs/architecture/07-priority-sla.md)
- [08 — Action Center Roles, Delegation & Assignment](docs/architecture/08-action-center-roles.md)
- [09 — Resilience & "Never Lose an Order"](docs/architecture/09-resilience-no-order-loss.md)
- [10 — Customer-Configurable Validation Forms](docs/architecture/10-configurable-forms.md)
- [11 — Document Intelligence Accuracy & Field Localization](docs/architecture/11-extraction-accuracy.md)
- [12 — Code-First Class-Per-Customer Schema](docs/architecture/13-code-first-customer-schema.md)
- [Diagrams (C4 / Sequence / State)](docs/architecture/diagrams/)
- [Architecture Decision Records](docs/adr/)
- [Running Locally with Docker (no Azure)](docs/local-dev-docker.md)

## Tech stack (latest)

.NET 10 / C# 14 · Azure Functions isolated worker · Durable Functions · ASP.NET Core Minimal APIs ·
EF Core 10 · Azure Service Bus (topics + subscriptions, sessions) · Azure Blob Storage ·
Azure AI Document Intelligence · Microsoft Graph SDK v5 · SignalR · Entra ID (MSAL) ·
Angular 20 (standalone + signals) · OpenTelemetry + Application Insights · Bicep.

## Getting started

```powershell
# .NET solution
cd src
dotnet restore
dotnet build

# Angular app
cd clients/action-center
npm install
npm start
```

See each project's README and the [LLD](docs/architecture/02-LLD.md) for configuration details.
