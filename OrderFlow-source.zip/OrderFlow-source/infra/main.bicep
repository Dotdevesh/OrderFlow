// OrderFlow — core Azure infrastructure (per environment).
// Deploy: az deployment group create -g <rg> -f infra/main.bicep -p env=dev
targetScope = 'resourceGroup'

@description('Environment short name, e.g. dev/test/prod')
param env string = 'dev'
@description('Azure region')
param location string = resourceGroup().location
@description('Base name for resources')
param baseName string = 'orderflow'

var suffix = '${baseName}-${env}'
var tags = { app: 'orderflow', env: env }

// ---------------- Observability ----------------
resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'log-${suffix}'
  location: location
  tags: tags
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: 'appi-${suffix}'
  location: location
  kind: 'web'
  tags: tags
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: logAnalytics.id
  }
}

// ---------------- Storage (blobs + durable task hub) ----------------
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: toLower(replace('st${suffix}', '-', ''))
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    allowBlobPublicAccess: false
    minimumTlsVersion: 'TLS1_2'
  }
  resource blob 'blobServices@2023-05-01' = {
    name: 'default'
    resource container 'containers@2023-05-01' = {
      name: 'order-documents'
    }
  }
}

// ---------------- Service Bus (topic + priority subscriptions) ----------------
resource sb 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' = {
  name: 'sb-${suffix}'
  location: location
  tags: tags
  sku: { name: 'Standard', tier: 'Standard' }

  resource ordersTopic 'topics@2022-10-01-preview' = {
    name: 'orders'
    properties: {
      requiresDuplicateDetection: true
      duplicateDetectionHistoryTimeWindow: 'PT10M'
    }

    resource subHigh 'subscriptions@2022-10-01-preview' = {
      name: 'sub-high'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 10, lockDuration: 'PT5M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'priority-high'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'priority = 0' } }
      }
    }
    resource subStandard 'subscriptions@2022-10-01-preview' = {
      name: 'sub-standard'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 10, lockDuration: 'PT5M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'priority-standard'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'priority = 1' } }
      }
    }
    resource subLow 'subscriptions@2022-10-01-preview' = {
      name: 'sub-low'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 10, lockDuration: 'PT5M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'priority-low'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'priority = 2' } }
      }
    }
  }
}

// ---------------- SQL (system of record) ----------------
@description('SQL admin login')
param sqlAdminLogin string = 'orderflowadmin'
@secure()
@description('SQL admin password')
param sqlAdminPassword string

resource sqlServer 'Microsoft.Sql/servers@2023-05-01-preview' = {
  name: 'sql-${suffix}'
  location: location
  tags: tags
  properties: {
    administratorLogin: sqlAdminLogin
    administratorLoginPassword: sqlAdminPassword
    minimalTlsVersion: '1.2'
  }
  resource db 'databases@2023-05-01-preview' = {
    name: 'OrderFlow'
    location: location
    sku: { name: 'S1', tier: 'Standard' }
  }
}

// ---------------- Document Intelligence ----------------
resource docIntelligence 'Microsoft.CognitiveServices/accounts@2023-10-01-preview' = {
  name: 'di-${suffix}'
  location: location
  tags: tags
  kind: 'FormRecognizer'
  sku: { name: 'S0' }
  properties: { customSubDomainName: 'di-${suffix}' }
}

// ---------------- Key Vault ----------------
resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: 'kv-${suffix}'
  location: location
  tags: tags
  properties: {
    sku: { family: 'A', name: 'standard' }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
  }
}

output serviceBusNamespace string = sb.name
output storageAccount string = storage.name
output sqlServerFqdn string = sqlServer.properties.fullyQualifiedDomainName
output documentIntelligenceEndpoint string = docIntelligence.properties.endpoint
output appInsightsConnectionString string = appInsights.properties.ConnectionString
