# Developer setup — documents to follow

This is the only document that tells you **which existing page to open, in which order**.
The architecture set (`docs/architecture/`, `docs/adr/`) explains the design. It is not a
setup procedure. `infra/main.bicep` provisions the **data and AI plane only**. Compute,
Entra, Microsoft Graph, and CI/CD are still manual.

Do the sections below in order. Do not start with Bicep.

## 1. What you are standing up

| Piece | Project | Local port | Talks to |
|-------|---------|------------|----------|
| Email Intake | `src/services/OrderFlow.EmailIntake` | 7071 | Graph (or skipped locally), Service Bus, Order API (via S2S auth) |
| Orchestrator | `src/services/OrderFlow.Orchestrator` | **7072** (fixed) | Service Bus, Blob, Document Intelligence, Order API (via S2S auth), Graph |
| Identity Sync | `src/services/OrderFlow.IdentitySync` | 7073 | Microsoft Graph (AD Groups + App Roles webhook & sync), Identity API (via S2S auth) |
| Order API | `src/services/OrderFlow.OrderApi` | 5080 | SQL (`dbo.*`), Blob, Identity API, Orchestrator (`raiseEvent`) |
| Identity API | `src/services/OrderFlow.IdentityApi` | 5085 | SQL (`identity.*` + `dbo.Users`), Entra ID / Windows Negotiate SSO |
| Action Center | `src/clients/action-center` | 4200 | Identity API (SSO / `/api/auth/me`) + Order API + SignalR |

Shared libraries (`Contracts`, `Domain`, `BuildingBlocks`, `CustomerModel`) are not deployed.
Customer forms are **C# classes**, not admin configuration. Adding a customer means a code change
([13](architecture/13-code-first-customer-schema.md)).

Write ownership, so you do not point the wrong app at SQL:

| Store | Who writes | Who must not |
|-------|------------|--------------|
| Service Bus topic `orders` | Email Intake publishes `OrderReceived` | Action Center |
| SQL (`dbo.*`: orders, tasks, audit) | Order API only | Functions do not use EF Core |
| SQL (`identity.*` + `dbo.Users` sync) | Identity API only (fed by `OrderFlow.IdentitySync`) | Functions do not use EF Core |
| Blob `order-documents` | Orchestrator stores PDFs; API issues read SAS | Email Intake |
| Durable task hub (Azurite / Storage) | Orchestrator runtime | Do not share this account's tables with ad-hoc apps |
| Intake ledger | Email Intake, before it acks Graph | — |

## 2. Read these before you install anything

Skim in this order. Stop when you can name the four apps and the resume event
`ValidationCompleted`.

| Order | Document | You need it for |
|------:|----------|-----------------|
| 1 | [README](../README.md) | Map of the repo and the tech stack |
| 2 | [00 — Overview](architecture/00-overview.md) | Why the system exists and the quality attributes |
| 3 | [01 — HLD](architecture/01-HLD.md) | Context, happy path, security and failure at a high level |
| 4 | [03 — Applications](architecture/03-applications.md) | Why ingest, orchestration, and the API are separate processes |
| 5 | [C4 context](architecture/diagrams/c4-01-context.md), [C4 container](architecture/diagrams/c4-02-container.md), [happy path](architecture/diagrams/seq-01-happy-path.md) | The picture that matches the HLD |
| 6 | [ADR index](adr/README.md) | Decisions already made. Read [0001](adr/0001-event-driven-microservices.md), [0002](adr/0002-durable-functions-for-orchestration.md), [0003](adr/0003-service-bus-priority-topology.md), [0007](adr/0007-auth-entra-managed-identity.md), [0008](adr/0008-graph-webhooks-over-polling.md). Do not reopen those choices while setting up. |

## 3. Run it locally — follow this document

**Procedure:** [Running locally with Docker](local-dev-docker.md).

That page is the setup. It covers both modes (everything in Docker, or emulators in Docker and
apps on the host), the test publisher under `local/send-test-order`, the three local personas,
and teardown.

Read these only to know what “working” looks like while you click through:

| Document | Use it to check |
|----------|-----------------|
| [02 — LLD](architecture/02-LLD.md) §8 and §11 | API routes and the **real** configuration keys (section 5 below) |
| [04 — Workflow](architecture/04-workflow.md) | Order and task state after you submit |
| [08 — Roles](architecture/08-action-center-roles.md) | What Morgan / Riley / Jordan are allowed to do |
| [Action Center README](../src/clients/action-center/README.md) | Dev auth header and `npm start` |

Host prerequisites for the debug mode: Docker Desktop, .NET 10 SDK, Azure Functions Core Tools v4,
Node 20+. Docker-only mode needs Docker Desktop.

Local substitutes (no Azure subscription): SQL Edge, Azurite, Service Bus emulator. Empty
`Graph:*`, `DocumentIntelligence:Endpoint`, and `Entra:Authority` switch those calls to sample
data and the dev auth handler. Do not fill those keys until section 6.

Definition of a successful local run:

1. `local/send-test-order` publishes `OrderReceived` for a known customer (`acme-title`, `high`).
2. The orchestrator log shows an instance id.
3. Action Center inbox shows a task for that customer’s form.
4. Submit returns the task to completed and the orchestrator log shows it resumed.

Orchestrator **must** stay on port **7072**. Order API raises the external event there
(`DurableTask:BaseUrl`).

## 4. Open a deep-dive only when the task needs it

| If you are changing… | Follow |
|----------------------|--------|
| A customer’s fields, groups, or a new customer class | [10](architecture/10-configurable-forms.md) then [13](architecture/13-code-first-customer-schema.md). The class is the source of truth. There is no JSON form catalog. |
| Extraction models, confidence, or field disambiguation | [11](architecture/11-extraction-accuracy.md) |
| Priority filters, concurrency, or SLA minutes | [07](architecture/07-priority-sla.md) and [ADR-0003](adr/0003-service-bus-priority-topology.md) |
| The Graph webhook, subscription renewal, or mailbox scope | [05](architecture/05-email-graph.md) and [ADR-0008](adr/0008-graph-webhooks-over-polling.md) |
| The wait/resume, timers, or activity code | [06](architecture/06-durable-functions.md). Orchestrator code must stay deterministic. |
| “What if this step crashes?” | [09](architecture/09-resilience-no-order-loss.md). The short DLQ replay in §6 is the procedure. The fuller runbook is [14](architecture/14-design-intent.md). |
| Private networking, sessions, a second read store, or an ERP URL | [14](architecture/14-design-intent.md). Do not add them during setup. |
| PDF conversion choices | [ADR-0006](adr/0006-email-to-pdf-strategy.md) |
| Who may claim, assign, or submit | [08](architecture/08-action-center-roles.md) and [ADR-0005](adr/0005-action-center-roles.md) |
| Why SQL is the system of record | [ADR-0004](adr/0004-sql-server-system-of-record.md) |

## 5. Configuration keys that actually exist

[LLD §11](architecture/02-LLD.md) matches these names. Copy from the example files, do not invent keys.

| Key | Email Intake | Orchestrator | Order API | Local value |
|-----|:---:|:---:|:---:|-------------|
| `ServiceBus` | yes | yes | | Emulator connection string in `local.settings.example.json` |
| `AzureWebJobsStorage` | yes | yes | | `UseDevelopmentStorage=true` (Azurite) |
| `OrderApi:BaseUrl` | yes | yes | | `http://localhost:5080` |
| `Graph:TenantId`, `Graph:ClientId`, `Graph:Mailboxes` | yes | yes | | Empty = sample email |
| `Graph:ClientState` | yes | | | Shared secret; must match the Graph subscription |
| `Storage:ConnectionString` | | yes | | Used only when `Storage:BlobEndpoint` is empty. Defaults to `UseDevelopmentStorage=true`; Docker sets the Azurite string. |
| `Storage:BlobEndpoint`, `Storage:Container` | | yes | yes | Container `order-documents`. In Docker, API also needs `Storage:PublicBlobBaseUrl=http://localhost:10000` so the PDF iframe can load SAS URLs. |
| `DocumentIntelligence:Endpoint`, `DocumentIntelligence:ModelId` | | yes | | Empty endpoint = sample extractor. Model default `prebuilt-invoice`. |
| `ConnectionStrings:Sql` | | | yes | Docker SQL Edge string in [local-dev-docker.md](local-dev-docker.md). `appsettings.json` points at LocalDB and is **not** the Docker path. |
| `ConnectionStrings:Storage` | | | yes | `UseDevelopmentStorage=true` |
| `DurableTask:BaseUrl`, `DurableTask:SystemKey` | | | yes | `http://localhost:7072`. System key empty locally. |
| `Entra:Authority`, `Entra:Audience` | | | yes | Empty = `DevAuthenticationHandler`, allowed only when `ASPNETCORE_ENVIRONMENT=Development` |
| `Cors:Origins` | | | yes | `http://localhost:4200` |

Example files:

- `src/services/OrderFlow.EmailIntake/local.settings.example.json`
- `src/services/OrderFlow.Orchestrator/local.settings.example.json`
- `src/services/OrderFlow.OrderApi/appsettings.json`

`local.settings.json` is created by `local/start-local.ps1` and is gitignored. Do not commit it.

Azure (section 6) replaces the emulator connection string with Managed Identity settings
`ServiceBus:FullyQualifiedNamespace` and `Storage:BlobEndpoint`. Leave the local `ServiceBus`
connection string out of Azure app settings.

## 6. Azure — what the repo creates, and what you still do by hand

### 6.1 Provision the data plane from the repo

`infra/main.bicep` creates, per environment: Log Analytics, Application Insights, a Storage
account with container `order-documents`, Service Bus namespace + topic `orders` + subscriptions
`sub-high` / `sub-standard` / `sub-low`, Azure SQL database `OrderFlow`, a Document Intelligence
account, and a Key Vault (RBAC authorization on, no secrets seeded).

```powershell
az group create -n rg-orderflow-dev -l <region>
az deployment group create -g rg-orderflow-dev -f infra/main.bicep -p env=dev sqlAdminPassword='<secret>'
```

SQL admin password is a deployment parameter. Do not put it in a file in the repo. After deploy,
store it in Key Vault and switch the API to Entra authentication for SQL when identities exist
(they are not created by this template).

Deploy outputs you will copy into app settings: Service Bus namespace, storage account name,
SQL FQDN, Document Intelligence endpoint, App Insights connection string.

### 6.2 Create these yourself — they are in the design, not in the template

| Item | Follow | Done when |
|------|--------|-----------|
| Function App for Email Intake | [03](architecture/03-applications.md), [deployment diagram](architecture/diagrams/deployment.md) | `GraphWebhook` is a public HTTPS URL |
| Function App for Orchestrator | same | Durable hub uses the storage account from Bicep; HTTP extension is reachable from the API on the raise-event URL |
| Host for Order API (App Service or Container Apps) | [01 §10](architecture/01-HLD.md) | `/health` passes against Azure SQL and Blob |
| Host for Action Center (Static Web App or the nginx image) | [Action Center README](../src/clients/action-center/README.md) | Browser origin is listed in `Cors:Origins` |
| User-assigned or system Managed Identities + RBAC | [ADR-0007](adr/0007-auth-entra-managed-identity.md) | Each app can reach only the resources in the table below |
| Entra app: Action Center (SPA, auth code + PKCE + Windows Seamless SSO) | [ADR-0007](adr/0007-auth-entra-managed-identity.md), [01 §7](architecture/01-HLD.md) | `ssoSilent` / Windows credentials log in without prompt; audience is `api://orderflow-orderapi` |
| Entra app: Order API + Identity API (App Roles: `Manager`, `Reportee`, `InternalService`, `DirectorySync`) | same | `Entra:Authority`, `Entra:Audience`, and `Identity:BaseUrl` set; dev auth handler is off |
| Entra Security Groups (`AccessGroupId`, `ManagerGroupId`, `ReporteeGroupId`) + `OrderFlow.IdentitySync` Function App | [ADR-0007](adr/0007-auth-entra-managed-identity.md) | Graph permissions `GroupMember.Read.All`, `User.Read.All`, `Application.Read.All` granted; `/api/graph/directory-webhook` subscribed on groups |
| Entra app: Graph (app-only `Mail.Read`) + Application Access Policy on the shared mailbox | [05 §2](architecture/05-email-graph.md) | The app cannot read other mailboxes |
| Graph subscription | [05 §1](architecture/05-email-graph.md) | `notificationUrl` is the intake webhook, `clientState` equals `Graph:ClientState`, renewal timer is running |
| Key Vault secrets and references | [ADR-0007](adr/0007-auth-entra-managed-identity.md) | SQL password, Graph client credential, Durable system key are not in app settings as plain text |
| Document Intelligence model | [11](architecture/11-extraction-accuracy.md) | `DocumentIntelligence:Endpoint` points at the Bicep account; model id matches the customer plan |
| Alerts | [01 §8](architecture/01-HLD.md), [09 §6](architecture/09-resilience-no-order-loss.md) | DLQ count, high-priority backlog, orchestration failures |

RBAC each identity needs ([ADR-0007](adr/0007-auth-entra-managed-identity.md)):

| App | Roles |
|-----|--------|
| Email Intake | Service Bus Data Sender; Key Vault Secrets User |
| Orchestrator | Service Bus Data Receiver; Storage Blob Data Contributor; Cognitive Services User; Key Vault Secrets User |
| Order API | Storage Blob Data Reader (SAS); Key Vault Secrets User; SQL Entra user once AAD auth is on |

There is **no** GitHub Actions or Azure DevOps pipeline in the repo. [HLD §11](architecture/01-HLD.md)
names `dev → test → prod` as the target. Promote by repeating section 6.1 with a different `env`
and deploying each app separately. Do not share a Service Bus namespace or SQL server across environments.

### 6.3 Turn local substitutes off

Set the keys in [local-dev-docker.md §6](local-dev-docker.md). Empty values mean “stay on the fake.”
Order API refuses to start outside `Development` when `Entra:Authority` is empty, so the dev
authentication handler cannot run in a hosted environment. Set `Entra:Authority` and
`Entra:Audience` before the first Azure deployment.

## 7. Design intent — do not build these to finish setup

[14 — Design intent](architecture/14-design-intent.md) is the record for five items that the
other docs mention and that this repo does not implement. Read it so you do not treat them as
missing setup steps. Leave current behaviour in place:

| Item | Leave this in place |
|------|---------------------|
| Private networking | Public endpoints from Bicep and from local Docker |
| DLQ replay | The short procedure in [09 §6](architecture/09-resilience-no-order-loss.md) only |
| Second read store | One EF Core model; inbox queries hit the same tables as writes |
| Service Bus sessions | `RequiresSession` false. Publishers may set `SessionId`; consumers ignore it |
| ERP endpoint | `FinalizeOrder` writes `OrderFinalized` to the SQL outbox and returns |

Also still absent, and also not required to finish section 6:

| Claim in the docs | What is actually here |
|-------------------|------------------------|
| Bicep modules for Function Apps, App Service, Static Web App, Managed Identity, RBAC | Not in `infra/main.bicep`. See section 6.2. |
| CI/CD promotes environments | No pipeline files. |
| Email Intake C4 component diagram | Not drawn. Behaviour is [05](architecture/05-email-graph.md) and [03 §1](architecture/03-applications.md). |

## 8. Checklist

**Local**

- [ ] Read section 2 (overview, HLD, applications, three diagrams, five ADRs).
- [ ] Follow [local-dev-docker.md](local-dev-docker.md) to a submitted task.
- [ ] Confirm orchestrator port 7072 and the persona switch (Manager vs Reportee).

**One Azure environment**

- [ ] Bicep deployment succeeded and outputs are recorded.
- [ ] Four app hosts exist and use those outputs.
- [ ] Identities and the three Entra apps from section 6.2 exist.
- [ ] Graph subscription is renewing and `clientState` matches.
- [ ] A real or test mailbox message becomes one task, and submit resumes the orchestration.
- [ ] Dev auth is off (`Entra:Authority` set).
- [ ] Secrets are in Key Vault.
