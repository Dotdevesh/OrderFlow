# Running OrderFlow locally with Docker (no Azure subscription)

You can run the whole platform on your machine. Docker provides the three **stateful** Azure
dependencies through official emulators, and you can run the four apps either **inside Docker**
(`--profile apps` — zero host SDKs required) or **on the host** (`dotnet` / `func` / `npm` for
fast edit-debug cycles). The two Azure **AI/identity** services have no emulator, so the code
falls back to safe local behaviour (sample data + a dev auth header).

## 1. What maps to what

| Cloud dependency | Local substitute | How |
|---|---|---|
| Azure SQL Database | **Azure SQL Edge** container | `docker compose` (`sqledge`) |
| Azure Blob Storage | **Azurite** container | `docker compose` (`azurite`) |
| Azure Service Bus (topic + subscriptions) | **Service Bus emulator** container | `docker compose` (`servicebus`) + `local/servicebus-config.json` |
| Durable Functions task hub | Azurite (tables/queues/blobs) | built in — Functions use `AzureWebJobsStorage` |
| Azure Document Intelligence | **Sample extractor** (no container) | `DocumentIntelligence:Endpoint` left empty → extractor returns representative fields per the customer's class |
| Microsoft Graph (email) | **Sample email reader** (no container) | `Graph:*` left empty → orchestrator fabricates a customer-matched email + PDF |
| Entra ID (auth) | **Dev auth header** | `Entra:Authority` empty → `DevAuthenticationHandler`; Angular sends a dev user header |

```mermaid
flowchart LR
  subgraph host["Apps (Docker --profile apps OR Host)"]
    AC["Angular Action Center :4200"]
    API["OrderApi :5080"]
    ORCH["Orchestrator (Durable) :7072"]
    EMAIL["EmailIntake (Functions) :7071"]
  end
  subgraph docker["Docker Compose (Stateful Emulators)"]
    SB["Service Bus emulator :5672"]
    AZ["Azurite :10000-10002"]
    SQL["SQL Edge :1433"]
  end
  AC --> API
  API -->|EF Core| SQL
  API -->|blobs| AZ
  API -->|raiseEvent HTTP| ORCH
  EMAIL -->|publish OrderReceived| SB
  SB -->|priority subs| ORCH
  ORCH -->|state| AZ
  ORCH -->|REST| API
```

## 2. Two ways to run

### Option A — Full stack in Docker (simplest, needs only Docker Desktop)

```powershell
cd c:\Project\POC\local
.\start-local.ps1 -Mode DockerApps
# or directly:
# docker compose --profile apps up -d --build
```

This builds and starts all 3 emulators (`sqledge`, `azurite`, `servicebus`) **and** all 4 apps
(`orderapi`, `orchestrator`, `emailintake`, `action-center`).

### Option B — Emulators in Docker + Apps on Host (for debugging code)

Prerequisites on host: **.NET 10 SDK**, **Azure Functions Core Tools v4** (`func`), **Node 20+**.

```powershell
cd c:\Project\POC\local
.\start-local.ps1 -Mode Host
```

`start-local.ps1` automatically:
1. Copies `local.settings.example.json` → `local.settings.json` for both Functions apps if missing.
2. Runs `docker compose up -d` and waits for SQL (`1433`), Azurite (`10000`), and Service Bus (`5672`).
3. Opens four PowerShell windows running OrderApi (`:5080`), Orchestrator (`:7072`), EmailIntake (`:7071`), and Action Center (`:4200`).

> First run pulls a few GB of images and the Service Bus emulator waits for SQL Edge to become
> healthy — give it ~30–60s before the topic is ready.

## 3. Manual step-by-step (without the launcher script)

If you prefer running each step yourself:

```powershell
# 1) Start the three emulators
cd c:\Project\POC\local
docker compose up -d
docker compose ps

# 2) Ensure Functions local settings exist (first clone only)
copy src\services\OrderFlow.Orchestrator\local.settings.example.json src\services\OrderFlow.Orchestrator\local.settings.json
copy src\services\OrderFlow.EmailIntake\local.settings.example.json src\services\OrderFlow.EmailIntake\local.settings.json

# 3) Order API  (http://localhost:5080)
$env:ConnectionStrings__Sql = "Server=localhost,1433;Database=OrderFlow;User Id=sa;Password=OrderFlow!Passw0rd;TrustServerCertificate=true;Encrypt=false"
cd c:\Project\POC\src\services\OrderFlow.OrderApi
dotnet run --urls http://localhost:5080

# 4) Orchestrator (Durable Functions)  — MUST be port 7072 (OrderApi raises events here)
cd c:\Project\POC\src\services\OrderFlow.Orchestrator
func start --port 7072

# 5) EmailIntake (Functions)  — port 7071 (optional for happy path)
cd c:\Project\POC\src\services\OrderFlow.EmailIntake
func start --port 7071

# 6) Angular Action Center  (http://localhost:4200)
cd c:\Project\POC\src\clients\action-center
npm install
npm start
```

On first launch in `Development`, `OrderApi` creates the schema and seeds customers/users
automatically (`SeedData.EnsureSeededAsync`).

## 4. Drive an end-to-end run without real email

Because there's no Graph locally, start a run by dropping an `OrderReceived` message on the topic:

```powershell
cd c:\Project\POC\local\send-test-order
dotnet run -- acme-title high      # customerId + priority (routes to sub-high)
# other examples:
# dotnet run -- first-national standard
# dotnet run -- acme high
# dotnet run -- globex standard
# dotnet run -- initech low
```

What happens next:

1. The Orchestrator's `Start_High` (or `Start_Standard` / `Start_Low`) trigger fires and starts
   the saga with a deterministic instance id (`= correlationId`).
2. `GraphEmailReader` (no Graph configured) returns a sample email + valid PDF for that customer;
   `PassthroughDocumentConverter` writes renderable PDFs to Azurite.
3. The order is created in SQL via `/internal/orders`.
4. `DocumentIntelligenceExtractor` returns sample values **shaped by the customer's entity class**
   (`AcmeTitleOrder`, `FirstNationalTitleOrder`, `AcmeOrder`, `GlobexOrder`, `InitechOrder`) —
   the same class that renders the form.
5. A validation task is created and the orchestrator **waits** on the `ValidationCompleted` event
   with an SLA durable timer.
6. Open the Action Center at `http://localhost:4200`, pick the customer, open the task, review the
   PDF + dynamically-rendered form, and submit. The Order API validates against the entity class
   and raises the event back to the orchestrator, which finalizes the order.

## 5. Auth & personas locally

No Entra needed. `OrderApi` uses `DevAuthenticationHandler` when `Entra:Authority` is empty.
Use the **persona dropdown in the top-right bar** of the Action Center to switch live between:
- `Morgan (Manager)` (`mgr-1`) — can view Team, assign/delegate, validate & submit
- `Riley (Reportee)` (`rep-1`) — can claim from Pending Pool, validate & submit (cannot delegate)
- `Jordan (Reportee)` (`rep-2`)

## 6. Turning on the real services later

Each substitute swaps to the real thing by setting config — no code change. Local examples use a
`ServiceBus` connection string; in Azure remove that string and set
`ServiceBus:FullyQualifiedNamespace` so the apps use Managed Identity. The full key list and the
resources Bicep does **not** create are in [developer-setup.md](developer-setup.md).

| Setting | Effect |
|---|---|
| `DocumentIntelligence:Endpoint` | Switches the extractor from sample data to the real Doc Intelligence client |
| `Graph:TenantId` / `Graph:ClientId` + webhook | Switches EmailIntake/orchestrator to real Microsoft Graph |
| `Entra:Authority` + `Entra:Audience` | Switches the API to real JWT bearer auth |
| `ServiceBus:FullyQualifiedNamespace` | Uses a real Service Bus namespace with Managed Identity (replaces the local `ServiceBus` connection string) |
| `Storage:BlobEndpoint` | Uses a real Storage account with Managed Identity |
| `ConnectionStrings:Sql` | Points at Azure SQL |

`infra/main.bicep` provisions Service Bus, Storage, SQL, Document Intelligence, Key Vault, and
Application Insights. It does not create the Function Apps, the API, the Action Center, or Entra apps.

## 7. Tear down

```powershell
cd c:\Project\POC\local
.\stop-local.ps1                  # stops containers (keeps SQL/Azurite volumes)
.\stop-local.ps1 -CleanVolumes    # stops containers and deletes volumes (fresh DB next time)
```

## Troubleshooting

- **Service Bus client can't connect / topic not found** — the emulator needs SQL Edge healthy
  first; `docker compose restart servicebus` after SQL is up, and confirm `local/servicebus-config.json`
  is mounted (`docker compose logs servicebus`).
- **API can't reach SQL** — verify `docker compose ps` shows `orderflow-sql` healthy and that the
  `ConnectionStrings__Sql` env var is set in the same terminal that runs the API.
- **`raiseEvent` 404 from the API** — the Orchestrator isn't running on port 7072, or the instance
  id differs; check the orchestrator console for the started instance id.
- **PDF iframe blank in Docker mode** — ensure `Storage__PublicBlobBaseUrl=http://localhost:10000`
  is set on `orderapi` (already configured in `local/docker-compose.yml`) so SAS URLs rewrite from
  `azurite:10000` to `localhost:10000`.
- **Azurite auth errors** — ensure ports 10000–10002 are free and not taken by a previously
  installed Azurite.
