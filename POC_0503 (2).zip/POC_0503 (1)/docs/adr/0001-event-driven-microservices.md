# ADR-0001 — Event-driven microservices architecture

- **Status:** Accepted
- **Date:** 2026-11-12
- **Deciders:** Architecture team

## Context

OrderFlow must ingest ~1 order/second (bursty), run a multi-stage pipeline with an unbounded human
wait, and serve an interactive validation UI. These three concerns (ingestion, orchestration,
interaction) have very different scaling and failure profiles.

## Decision

Adopt an **event-driven microservices** architecture with four independently deployable apps
(Email Intake, Orchestrator, Order API, Action Center) communicating via **integration events**
over Azure Service Bus and HTTPS for synchronous commands/reads. Shared code limited to a small
`Contracts` package.

## Options considered

1. **Monolith** — simplest, but couples ingestion bursts, long-running waits, and UI traffic into
   one scaling/failure domain; hard to meet SLA isolation.
2. **Event-driven microservices (chosen)** — independent scaling, fault isolation, clear ownership.
3. **Pure choreography (no orchestrator)** — hard to reason about a long-running saga with a human
   wait, compensation, and SLA timers.

## Consequences

- ➕ Independent scale & deploy; fault isolation; natural fit for Service Bus + Functions.
- ➕ Human-wait instances cost no compute.
- ➖ Operational complexity (more pipelines, distributed tracing required) — mitigated by shared
  building blocks, OpenTelemetry, and IaC.
