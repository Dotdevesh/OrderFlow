# ADR-0008 — Graph change notifications over polling

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

We must react to new mail "as soon as it arrives" at high volume, without hammering Graph or
missing messages.

## Decision

Use Microsoft Graph **change notifications** (webhooks) for `created` messages on the monitored
mailbox(es). Renew subscriptions on a timer. Run a periodic **delta-query reconciliation** to
catch any missed notifications. Optionally use **rich notifications with encrypted resource data**
to receive payloads inline and avoid an extra fetch.

## Options considered

1. **Polling (delta query on a schedule)** — simple but latency vs. cost trade-off; higher load.
2. **Webhooks (chosen)** — near-real-time, low overhead; requires a public endpoint + renewal.
3. **Webhooks + reconciliation (chosen refinement)** — webhooks for latency, delta for safety net.

## Consequences

- ➕ Low latency, low overhead, resilient with reconciliation.
- ➖ Must host a public HTTPS validation endpoint, manage subscription lifecycle & `clientState`
  verification, and handle the 30s ack window (kept fast by deferring work to the orchestrator).
