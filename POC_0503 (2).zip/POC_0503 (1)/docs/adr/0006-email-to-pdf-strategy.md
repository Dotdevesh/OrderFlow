# ADR-0006 — Email & attachment → PDF conversion strategy

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

The email body and heterogeneous attachments (PDF, images, Office) must become a uniform set of
PDFs so the Action Center has one viewer and Document Intelligence has consistent input.

## Decision

Introduce an `IDocumentConverter` abstraction executed as the durable **`ConvertToPdf`** activity:

- **Email body (HTML/MIME) → PDF** via headless Chromium (`PuppeteerSharp`) rendering sanitized
  HTML (remote content stripped for security).
- **PDF** attachments kept as-is.
- **Images** wrapped into PDF pages.
- **Office** docs converted via a headless LibreOffice sidecar (pluggable).

Conversion lives in a retryable activity so slow/failed conversions don't block ingestion.

## Options considered

1. **Chromium + pluggable converters (chosen)** — faithful rendering, flexible, swappable engines.
2. **Single commercial all-in-one SDK** — simpler but licensing + less control.
3. **Convert only attachments, keep email as HTML** — breaks the uniform single-viewer UX.

## Consequences

- ➕ Uniform viewer + uniform extraction input; security via sanitization.
- ➖ Chromium/LibreOffice require a container image with those binaries (documented in infra).
- ➖ Conversion is CPU-bound → bounded concurrency to control cost.
