# ADR-0002 — Durable Functions for the long-running workflow

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

The core business transaction spans seconds of compute but minutes–days of wall-clock time due to
a mandatory human validation step. We need stateful, resumable execution, human-in-the-loop
events, SLA timers, parallel document analysis, and automatic retries.

## Decision

Use **Azure Durable Functions** (.NET 10 isolated worker) for the orchestration. Use
`WaitForExternalEvent` for the human-in-the-loop resume, `CreateTimer` for SLA, and
fan-out/fan-in for document analysis.

## Options considered

1. **Durable Functions (chosen)** — native external events, durable timers, checkpoint/replay,
   fan-out/fan-in, serverless scale, cheap waiting.
2. **Logic Apps** — good for low-code, but weaker for custom .NET domain logic and testing.
3. **Custom saga + database state machine + queues** — maximum control but we would rebuild
   checkpointing, timers, replay, and idempotency ourselves.
4. **Azure Container Apps Jobs / workflow engine (e.g. Temporal)** — powerful, but adds infra and
   ops burden vs. a managed Azure-native option for this team.

## Consequences

- ➕ Minimal code for durable waits/timers; survives restarts/deploys; scales to many in-flight
  waits at ~zero cost.
- ➕ Deterministic replay model enforces clean I/O-in-activities design.
- ➖ Determinism constraints in orchestrator code (no `DateTime.Now`, I/O, etc.) — documented in
  [06-durable-functions.md](../architecture/06-durable-functions.md).
- ➖ Task-hub storage must be sized/monitored.
