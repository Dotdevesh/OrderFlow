# ADR-0007 — Entra ID, Windows Seamless SSO, Identity Microservice & Directory Sync

- **Status:** Accepted (Updated 2026-11-21)
- **Date:** 2026-11-12 (Revised 2026-11-21)

## Context

We require:
1. **Windows Credential Seamless Login**: Validators on corporate Windows workstations must sign into the Action Center automatically using their logged-in Windows credentials without password prompts.
2. **Dual AD Group + App Registration Role Governance**: Roles (`Manager`, `Reportee`) are managed in Azure App Registration App Roles and Entra/AD Security Groups, while a logged-in user **must** belong to **both** an authorized AD Security Group **and** hold an assigned Role.
3. **Database-Backed Real-Time Directory Sync**: Our SQL database must remain synchronized whenever AD Group memberships or Azure App Registration role assignments change.
4. **Central Identity Microservice for User & Service-to-Service Auth**: All user requests and microservice intercommunication (`EmailIntake`, `Orchestrator`, `OrderApi`, `IdentitySync`) must authenticate through a dedicated Identity microservice (`OrderFlow.IdentityApi`) and Entra Managed Identity.

## Decision

1. **Windows Credential Login (Dual-Mode SSO)**:
   - **Primary (Cloud / Hybrid Entra Joined)**: Angular Action Center uses `@azure/msal-browser` (`ssoSilent` + Auth Code PKCE) leveraging Microsoft Entra Seamless SSO / Windows Primary Refresh Token (PRT) / Kerberos ticket.
   - **Fallback (Intranet / On-Prem AD Domain)**: `OrderFlow.IdentityApi` exposes `GET /api/auth/windows-sso` backed by `Microsoft.AspNetCore.Authentication.Negotiate` (Kerberos / NTLM), exchanging verified Windows credentials for a short-lived signed OrderFlow JWT.

2. **Dedicated Identity Microservice (`OrderFlow.IdentityApi`)**:
   - Owns the isolated `identity` schema (`DirectoryUsers`, `DirectoryGroups`, `UserGroupMemberships`, `UserAppRoleAssignments`, `DirectorySyncAudits`) inside the OrderFlow SQL database and maintains the `dbo.Users` validator projection.
   - Exposes `/api/auth/me` and `/api/auth/introspect` so `OrderFlow.OrderApi` (and future APIs) enforce that every authenticated user is `AccountEnabled`, belongs to a required **AD Security Group**, and holds an assigned **Role** (`Manager` or `Reportee`).
   - Authenticates microservice-to-microservice calls via Entra Managed Identity (`InternalService` / `DirectorySync` App Roles) and `/api/auth/service-token` (`ServiceToServiceBearerHandler`).

3. **Event-Driven + Scheduled Directory Sync Function (`OrderFlow.IdentitySync`)**:
   - **`EntraDirectoryWebhookFunction`** (`POST /api/graph/directory-webhook`): Receives Microsoft Graph change notifications on watched AD Security Groups (`groups/{id}`) and immediately syncs membership & role updates into `OrderFlow.IdentityApi`.
   - **`DirectoryRoleAndGroupSyncTimer`** (`TimerTrigger` every 15m + `POST /api/sync/run`): Renews Graph group webhook subscriptions and reconciles `servicePrincipals/{id}/appRoleAssignedTo` + `transitiveMembers` + `users/{id}/manager` so App Registration role changes are reflected even when no group webhook fires.

4. **Azure Resources & Secrets**:
   - Services → Azure resources use **Managed Identity** + RBAC (`infra/main.bicep` provisions dedicated user-assigned Managed Identities per service).
   - Secrets (when required outside Managed Identity) reside exclusively in Azure Key Vault.

## Consequences

- ➕ Zero-prompt Windows credential login across Entra-joined, Hybrid-joined, and intranet AD domain workstations.
- ➕ Immediate revocation when a user is removed from an AD Security Group or Azure App Registration role.
- ➕ Uniform S2S authentication (`ServiceToServiceBearerHandler`) across all APIs and Azure Functions.
- ➖ Requires Entra App Registrations (SPA + API App Roles + Seamless SSO) and Microsoft Graph read permissions (`GroupMember.Read.All`, `User.Read.All`, `Application.Read.All`) for `OrderFlow.IdentitySync`.
