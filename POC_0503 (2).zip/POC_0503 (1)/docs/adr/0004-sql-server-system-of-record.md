# ADR-0004 — SQL Server as the system of record

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

Orders, validation tasks, customers, users, and audit require strong consistency, relational
integrity, transactional writes, optimistic concurrency for simultaneous validators, and
rich query shapes for the task inbox.

## Decision

Use **Azure SQL (SQL Server)** with **EF Core 10** (code-first). Apply optimistic concurrency via
`RowVersion` on `Orders` and `ValidationTasks`. Use the **Outbox pattern** for reliable event
publishing. Inbox queries use these same tables and their indexes. A second read schema in this
database is [design intent](../architecture/14-design-intent.md) and is not built.

## Options considered

1. **SQL Server (chosen)** — relational integrity, transactions, concurrency tokens, mature
   tooling; required by the brief.
2. **Cosmos DB** — great scale, but we need relational joins, transactions across entities, and
   strong consistency for task ownership.
3. **Blob/table only** — insufficient for relational/transactional needs.

## Consequences

- ➕ Strong consistency, concurrency control, familiar ops.
- ➕ Outbox guarantees no lost domain events.
- ➖ Must manage scale (indexing, possibly partition by customer) for very high volume — monitored
  and tier-sized.
