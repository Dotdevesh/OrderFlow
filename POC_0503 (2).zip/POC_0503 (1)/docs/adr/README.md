# Architecture Decision Records (ADRs)

Each ADR captures a significant decision, its context, the options considered, and consequences.
Format: [MADR](https://adr.github.io/madr/)-style. Status: Proposed · Accepted · Superseded.

| ADR | Title | Status |
|-----|-------|--------|
| [0001](0001-event-driven-microservices.md) | Event-driven microservices architecture | Accepted |
| [0002](0002-durable-functions-for-orchestration.md) | Durable Functions for the long-running workflow | Accepted |
| [0003](0003-service-bus-priority-topology.md) | Service Bus topic + priority subscriptions | Accepted |
| [0004](0004-sql-server-system-of-record.md) | SQL Server as the system of record | Accepted |
| [0005](0005-action-center-roles.md) | Action Center roles & task ownership model | Accepted |
| [0006](0006-email-to-pdf-strategy.md) | Email & attachment → PDF conversion strategy | Accepted |
| [0007](0007-auth-entra-managed-identity.md) | Entra ID + Managed Identity for all auth | Accepted |
| [0008](0008-graph-webhooks-over-polling.md) | Graph change notifications over polling | Accepted |
