# ADR-0005 — Action Center roles & task ownership model

- **Status:** Accepted
- **Date:** 2026-11-12

## Context

Two roles validate orders: **Manager** and **Reportee**. The brief: a Manager can self-validate &
submit and can assign/delegate work to another; a Reportee can validate and complete but cannot
delegate — they can pick up (assign to self) pending tasks and complete them.

## Decision

Model ownership with `AssignedToUserId`, `ClaimedByUserId`, and `AssignmentKind`
(`Pool | Assigned | Delegated | SelfClaimed`). Enforce the following server-side with ASP.NET Core
authorization policies + a resource-based handler:

- **Manager**: claim, open/edit/submit any task in their team; **assign** new; **delegate**
  existing; re-handle escalations.
- **Reportee**: **claim** pending tasks in scope and complete; submit tasks assigned to them;
  **cannot** assign/delegate to others.

Optimistic concurrency (`RowVersion`) prevents double-claim/double-submit.

## Options considered

1. **Pure assignment (manager pushes all)** — no self-service; managers become a bottleneck.
2. **Pool + claim + manager override (chosen)** — reportees self-serve pending work; managers
   distribute and intervene; matches the brief and balances load.
3. **Full RBAC engine (e.g. external PDP)** — overkill for two roles at this stage.

## Consequences

- ➕ Clear, auditable ownership transitions; load-balances humans; honours the brief.
- ➖ Interpretation of "reportee can assign pending task" as **self-claim** is an assumption; the
  policy table is the single place to change if the business means otherwise.
