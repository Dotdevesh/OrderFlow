# 10 — Customer-Configurable Validation Forms

Different customers need different validation forms — one may expose **13 fields across 3 groups**,
another **21+ fields across 5 groups** or **30+ fields plus line items**, with different labels,
grouping, mandatory/readonly/disabled rules, and which extracted entity feeds each field.

This is driven by a **code-first entity class per customer** (see [13 — Code-First Class-Per-Customer Schema](13-code-first-customer-schema.md)),
compiled into a `FormTemplateDto` by `ReflectionCustomerSchemaRegistry` and rendered dynamically
by the Angular Action Center.

## 1. Concept

```mermaid
flowchart LR
    CLS["Customer Entity Class<br/>(inherits Master Base)"] --> REG["ReflectionCustomerSchemaRegistry"]
    REG --> TPL["FormTemplateDto<br/>(sections, fields, rules)"]
    DI[Doc Intelligence fields] --> MAP{map by ExtractionField}
    TPL --> REN[Angular dynamic form renderer]
    MAP --> REN
    REN --> U[Validator edits/confirms]
    U --> SUB[Submit -> Validate + Bind + OrderFields]
```

- Each customer has a **C# entity class** inheriting from a master base (`TitleInsuranceOrderBase` or `PurchaseOrderBase`).
- The Action Center **renders the form dynamically** from `GET /api/customers/{customerId}/form-template`.
- Each form field optionally maps to an **extracted entity** (`ExtractionField`) so the extracted
  value pre-fills it; fields can also be **manual-only** (no extraction) for human-entered data.
- The validator can **override any value** (extraction is a suggestion, the human is authoritative),
  except fields explicitly marked `ReadOnly` or `Disabled`.

## 2. Field definition properties

Declared via `[FieldConfig(...)]` on properties of the customer class and projected to `FormFieldDef`:

| Property | Meaning |
|----------|---------|
| `Key` | Camel-cased property name (used as `OrderField.Name` when no `ExtractionField`). |
| `Label` | Display label. |
| `Type` | `text \| number \| date \| select \| textarea \| checkbox`. |
| `Required` | Client + server validation. |
| `ReadOnly` / `Disabled` | Visible to the validator, non-editable (`ReadOnly`) or greyed-out (`Disabled`). |
| `ExtractionField` | Name of the Document Intelligence field that pre-fills this input. Omit for manual-only. |
| `Regex` / `Options` | Client + server validation constraints. |
| `Localized` | Field has **multiple detected candidates** (see [11](11-extraction-accuracy.md)); UI shows a picker. |
| `Group` | Section key declared on the master base via `[FormGroup]`. |

## 3. API

| Route | Purpose |
|-------|---------|
| `GET /api/customers/{customerId}/form-template` | Resolved `FormTemplateDto` built from the customer's entity class. |

## 4. Rendering & validation (Angular + API)

- `ValidationWorkspaceComponent` iterates `sections` → `fields`, creating controls by `type`.
- Pre-fill: for each field with `extractionField`, binds the matching extracted value + confidence
  (or `boundEntity[key]` from the hydrated customer class); low confidence (`< 0.80`) is highlighted.
- `localized` fields render a **candidate picker** (`value + confidence + role label`).
- Classes decorated with `[FormLineItems]` render the line-item grid (`type === 'table'`).
- Client-side validation checks `required` and `regex`; the Order API re-runs `ICustomerSchemaRegistry.Validate(...)`
  server-side on `Approve & Submit` and binds the submitted values onto the typed customer class (`schemas.Bind(...)`) for auditability.

## 5. Submit mapping

On submit, each rendered field produces a `{ name, value }` where `name` is `extractionField`
(updating the matching `OrderField`) or `key` for manual-only fields (creating an `OrderField`).
This keeps the write model uniform regardless of how many fields a customer defines.
