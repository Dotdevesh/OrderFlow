# 13 — Code-First Class-Per-Customer Schema

This is the **single authoring model** for per-customer forms and extraction. Each customer is
modelled as a **C# class in the API**, and a single set of attributes drives **both** form
rendering **and** Document Intelligence extraction. There is no JSON catalog/config or
database-stored form template — the class is the only source of truth.

## 1. The idea

```mermaid
flowchart LR
    MASTER["Master base class<br/>TitleInsuranceOrderBase<br/>[FormGroup] x5 (the groups + their config)"]
    C1["AcmeTitleOrder : base<br/>mapped properties (its subset)<br/>[FieldConfig] per property"]
    C2["FirstNationalTitleOrder : base<br/>mapped properties (its subset)<br/>[FieldConfig] per property"]
    MASTER --> C1
    MASTER --> C2
    C1 --> REG{{ReflectionCustomerSchemaRegistry}}
    C2 --> REG
    REG --> TPL["FormTemplateDto<br/>(render only this customer's fields)"]
    REG --> PLAN["ExtractionPlan<br/>(extract only this customer's fields)"]
    TPL --> UI[Angular dynamic renderer]
    PLAN --> DI[Doc Intelligence extractor]
```

- The **master class** (`TitleInsuranceOrderBase`) declares the full catalog of **groups** via
  `[FormGroup(key, title, order)]`. Subclasses inherit the group catalog.
- Each **per-customer class** derives from the master and declares only the **mapped properties**
  it actually uses. Every property carries a `[FieldConfig(...)]` with its group, label, type,
  behaviour (`Required` / `ReadOnly` / `Disabled`), and the `ExtractionField` it maps to.
- One declaration, two outputs: the registry reflects the class once and produces both the
  **render template** and the **extraction plan**. There is no drift between "what we extract" and
  "what we show".

## 2. Where the code lives

| Concern | Type | Project |
|---|---|---|
| Attributes | `FormGroupAttribute`, `FieldConfigAttribute` | `OrderFlow.CustomerModel` |
| Master | `TitleInsuranceOrderBase` | `OrderFlow.CustomerModel` |
| Customers | `AcmeTitleOrder`, `FirstNationalTitleOrder` | `OrderFlow.CustomerModel/Customers` |
| Schema model | `CustomerSchema`, `ExtractionPlan`, `ExtractionFieldPlan` | `OrderFlow.CustomerModel` |
| Registry | `ICustomerSchemaRegistry` → `ReflectionCustomerSchemaRegistry` | `OrderFlow.CustomerModel` |
| Wiring | `services.AddCustomerSchemas()` | `OrderFlow.CustomerModel` |

## 3. Attribute model

```csharp
[AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
public sealed class FormGroupAttribute(string key, string title, int order = 0) : Attribute;

[AttributeUsage(AttributeTargets.Property)]
public sealed class FieldConfigAttribute : Attribute
{
    public required string Group { get; init; }
    public required string Label { get; init; }
    public string Type { get; init; } = "text";   // text|number|date|select|textarea|checkbox
    public int Order { get; init; }
    public bool Required { get; init; }
    public bool ReadOnly { get; init; }
    public bool Disabled { get; init; }
    public string? ExtractionField { get; init; }  // Doc AI field + OrderField name
    public bool Localized { get; init; }            // needs candidate disambiguation
    public string? Regex { get; init; }
    public string[]? Options { get; init; }
}
```

## 4. Master + a customer

```csharp
[FormGroup("order", "Order / File", 1)]
[FormGroup("property", "Property", 2)]
[FormGroup("buyer", "Buyer / Borrower", 3)]
[FormGroup("seller", "Seller", 4)]
[FormGroup("lender", "Lender / Loan", 5)]
public abstract class TitleInsuranceOrderBase
{
    public string? CustomerId { get; set; }
}

public sealed class AcmeTitleOrder : TitleInsuranceOrderBase
{
    [FieldConfig(Group = "order", Label = "File Number", Order = 1, Required = true, ExtractionField = "FileNumber")]
    public string? FileNumber { get; set; }

    [FieldConfig(Group = "property", Label = "Property Address", Order = 2, Localized = true, ExtractionField = "PropertyAddress")]
    public string? PropertyAddress { get; set; }
    // ... only the groups/fields this customer uses ...
}
```

`AcmeTitleOrder` uses 3 of the 5 groups; `FirstNationalTitleOrder` uses all 5 with a fuller set.
Groups with no mapped property for a customer are **not rendered**.

## 5. The registry

`ReflectionCustomerSchemaRegistry` maps `customerId → Type` and, on first use, reflects the class to
build a cached `CustomerSchema`:

- `Describe(customerId)` → `CustomerSchema { FormTemplateDto Template; ExtractionPlan Plan }`
- `Resolve(customerId)` → the CLR `Type`
- `Bind(customerId, extracted)` → a typed entity instance with Doc AI values bound onto the mapped
  properties by `ExtractionField`

Adding a customer = write a class + add one line in `AddCustomerSchemas()`:

```csharp
["acme-title"]     = typeof(AcmeTitleOrder),
["first-national"] = typeof(FirstNationalTitleOrder),
```

## 6. How it plugs into the flow

1. **Order API — form template.** `GET /api/customers/{id}/form-template` resolves the template
   straight from the registry (`schemas.Describe(customerId).Template`); customers without a
   registered class get a `404`. The Angular renderer consumes the resulting `FormTemplateDto`.
2. **Orchestrator — extraction.** `AnalyzeInput` carries `CustomerId`. The
   `DocumentIntelligenceExtractor` calls `schemas.Describe(customerId).Plan` to decide the model and
   the exact fields to pull; `Localized` fields emit candidates for disambiguation. The class
   literally drives extraction.
3. **Binding.** Extracted values are keyed by `ExtractionField`, which is exactly what both the
   template fields and `Bind(...)` use — so values land on the right inputs with no mapping layer.

## 7. Properties of the model

| | Code-first classes |
|---|---|
| Authoring | C# + attributes, compiler-checked |
| Type safety | Strong (typed properties, `Bind`) |
| New customer | New class + 1 registration (redeploy) |
| Drift risk | None — one declaration drives render + extraction |

Adding a customer is a code change (new class + one registration line), kept intentionally simple
and type-safe. There is no runtime JSON config or database form template to keep in sync.
