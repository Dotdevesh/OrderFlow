# 11 — Document Intelligence: Accuracy Strategy & Field Localization

"Extraction should be a well-planned way to achieve more accuracy." This document defines the
model strategy, the confidence/validation policy, and how we **locate the right value when the
same kind of entity (e.g. a name or address) appears in multiple places**.

## 1. Model strategy (layered, highest accuracy first)

```mermaid
flowchart TB
    A[Classify document type] --> B{Known layout?}
    B -- yes --> C[Custom extraction model<br/>trained per document type]
    B -- no  --> D[Prebuilt model<br/>invoice / receipt / contract]
    C --> E[Composed model routes to best sub-model]
    D --> E
    E --> F[Field confidence + bounding regions]
    F --> G{confidence >= threshold?}
    G -- no --> H[Flag for mandatory human review]
    G -- yes --> I[Pre-fill, still human-confirmable]
```

1. **Document classification** first (custom classifier) to pick the right model per attachment
   (PO vs invoice vs packing list vs cover email).
2. **Custom extraction models** trained on *your* historical PDFs give the best accuracy for known
   layouts; **composed models** bundle several so one call routes to the best sub-model.
3. **Prebuilt models** (`prebuilt-invoice`, `prebuilt-document` key-value pairs, `prebuilt-layout`
   tables) as a fallback for unknown/one-off layouts.
4. **Query fields / add-on features** (e.g. specific field queries, high-resolution OCR, formula/
   barcode add-ons) to target hard fields.

## 2. Accuracy techniques

| Technique | Benefit |
|-----------|---------|
| **Train custom models on labelled real docs** | Dramatically higher field accuracy than prebuilt for known senders/layouts. |
| **Per-sender model routing** (customer → model id) | Each customer's template/layout uses the model trained for it. |
| **Confidence thresholds per field** | Low-confidence fields are forced into human review; high-confidence pre-fill but remain editable. |
| **Table/line-item extraction** (`prebuilt-layout`) | Robust line-item grids with row/column structure. |
| **Normalization & validation rules** | Dates, currency, PO regex, totals = Σ(line totals) cross-checks catch mis-reads. |
| **High-resolution OCR add-on** | Better reads on scans/photos. |
| **Human-in-the-loop feedback loop** | Every human correction is captured as **labelled training data** → periodically **retrain** the custom model → accuracy compounds over time. |
| **Multi-model ensemble / re-ask** | On low confidence, re-query with a targeted query field. |

## 3. Confidence & validation policy

- Each field returns a **confidence (0–1)** and **bounding regions** (page + polygon).
- Policy: `confidence >= 0.80` ⇒ pre-filled (green); `< 0.80` ⇒ **mandatory review** (amber/red)
  and must be explicitly confirmed before submit.
- `MinConfidence` per document drives the inbox "confidence" column and routing priority for
  review.
- Business cross-checks (totals, required fields, regex) run server-side on submit regardless of
  confidence.

## 4. Field localization — "find the right name among many"

A PDF often contains the same *type* of entity in several places: **Sold-To**, **Ship-To**, and
**Bill-To** names/addresses; a buyer contact and a supplier contact; multiple dates. Picking the
right one is a disambiguation problem solved with **structure + labels + candidates**:

```mermaid
flowchart LR
    DI[Doc Intelligence] --> KV[Key-value pairs + labels]
    DI --> REG[Bounding regions per value]
    KV --> ROLE[Role inference:<br/>Ship-To vs Bill-To vs Sold-To]
    REG --> CAND[Candidate list per form field]
    ROLE --> CAND
    CAND --> UI[UI: candidate picker +<br/>highlight region on PDF]
    UI --> HUMAN[Human confirms the right one]
```

How it works:

1. **Prefer labelled fields.** Custom/prebuilt models return *typed* fields (`ShipToName`,
   `BillToAddress`) rather than a bag of "names" — the label *is* the disambiguation. This is why a
   **custom model per layout** is the single biggest accuracy win.
2. **Candidates with regions.** When ambiguity remains, we surface **all detected candidates** for
   a form field, each with its **value, confidence, label, and bounding region**. The field is
   marked `localized` in the form template.
3. **Role inference heuristics** fill gaps: proximity to anchor keywords ("Ship To", "Deliver to"),
   section position, and association via key-value pairs.
4. **Human picks + we learn.** The validator selects the correct candidate (or edits it); the
   choice is logged and **fed back as training data**, so future extractions label it correctly.

### Data shape

Extraction yields, per field:

```jsonc
{
  "name": "ShipToName",
  "value": "Acme Receiving Dept",     // best guess
  "confidence": 0.74,
  "boundingRegionJson": "{\"page\":1,\"polygon\":[...]}",
  "candidates": [
    { "value": "Acme Receiving Dept", "confidence": 0.74, "label": "Ship-To", "boundingRegionJson": "..." },
    { "value": "Acme HQ Billing",     "confidence": 0.68, "label": "Bill-To", "boundingRegionJson": "..." },
    { "value": "Acme Corp",           "confidence": 0.91, "label": "Sold-To", "boundingRegionJson": "..." }
  ]
}
```

The Action Center renders a **candidate picker** for `localized` fields and, when a candidate is
focused, **highlights its region on the PDF** (polygon overlay) so the human can visually confirm
the right name/address instantly.

## 5. Feedback loop (continuous improvement)

```mermaid
sequenceDiagram
    participant U as Validator
    participant API as Order API
    participant Store as Labelled dataset (Blob)
    participant DI as Doc Intelligence (training)
    U->>API: Correct/confirm fields (+ chosen candidate)
    API->>Store: Persist corrected labels + document
    Note over Store,DI: Periodic retrain job
    Store->>DI: Train new custom model version
    DI-->>API: New modelId (per customer/layout)
```

Every validation is training data. Over time the custom model needs fewer corrections, confidence
rises, and more fields clear the auto-fill threshold — accuracy improves with usage.

## 6. Mapping to the implementation

- `OrderField` carries `ExtractedValue`, `ValidatedValue`, `Confidence`, `BoundingRegionJson`, and
  a **`CandidatesJson`** list (value/confidence/label/region).
- The orchestrator's `IEntityExtractor` returns these; the Order API persists them; the form
  template marks `localized` fields; the Action Center renders the candidate picker + PDF highlight.
- Model id is resolved **per customer** (`CustomerProfile` → model id) so each sender uses its best
  trained model.
