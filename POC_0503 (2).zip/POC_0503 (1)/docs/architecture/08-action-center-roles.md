# 08 — Action Center: Roles, Delegation & Assignment

The **Action Center** (Angular) is where humans validate extracted order data. This document
defines the two roles, the task-ownership model, and the exact authorization matrix.

## 1. Roles

| Role | Can do |
|------|--------|
| **Manager** | Validate & submit any task in their team's scope; **assign** a task to a team member; **delegate** (reassign) a task already owned by someone to another person; claim from pool; re-assign escalated tasks; complete. |
| **Reportee** | **Claim** a pending task from the pool and validate & **complete** it; validate & submit tasks **assigned to them**. **Cannot delegate/reassign** to someone else. |

> Interpretation of the requirement: a Reportee can *self-pick* (claim) pending work and finish
> it, but cannot hand work to another person. A Manager can both do the work and distribute it
> (assign new, delegate existing) across their reportees and peers. This assumption is recorded in
> [ADR-0005](../adr/0005-action-center-roles.md); adjust the policy table if the business differs.

## 2. Team / ownership model

- `AppUser { Id, Role, ManagerId }` — a Manager owns the reportees whose `ManagerId == manager.Id`.
- A task's **scope** = the team (manager + reportees) determined by customer routing rules.
- Task ownership fields: `AssignedToUserId` (intended owner), `ClaimedByUserId` (actively editing),
  `AssignmentKind` (`Pool | Assigned | Delegated | SelfClaimed`).

## 3. Task inbox views

```mermaid
flowchart LR
    subgraph Inbox
        M[My Tasks<br/>assigned/claimed by me]
        P[Pending Pool<br/>unassigned, my scope]
        T[Team<br/>Manager only: all team tasks]
    end
```

- **My Tasks** — `AssignedToUserId == me OR ClaimedByUserId == me`.
- **Pending Pool** — `Status == Pending AND scope contains me`.
- **Team** — Manager only: every task in the manager's team, any status.
- Each row shows priority, customer, SLA countdown (live via SignalR), confidence summary.

## 4. Authorization matrix

| Operation | Reportee | Manager | Rule |
|-----------|:--------:|:-------:|------|
| View pool (own scope) | ✅ | ✅ | scope membership |
| View team (all) | ❌ | ✅ | manager of scope |
| Claim pending | ✅ | ✅ | task in scope, status Pending |
| Open/edit | ✅ (if owner/claimer) | ✅ (any in team) | ownership or manager |
| Submit/complete | ✅ (own/claimed) | ✅ (any in team) | ownership or manager |
| **Assign** to user | ❌ | ✅ | target is in manager's team |
| **Delegate/reassign** | ❌ | ✅ | source + target in team |
| Re-handle escalated | ❌ | ✅ | manager of scope |

Implemented server-side as ASP.NET Core **policies** + a **resource-based** handler
(`TaskOperationRequirement` → `TaskOperationHandler`) that loads the task and checks role +
ownership + manager→reportee relationship. The UI hides disallowed actions, but the **API is the
source of truth** (never trust the client).

## 5. State transitions by action

| Action (actor) | Pre-state | Post-state | Sets |
|----------------|-----------|-----------|------|
| Claim (Rep/Mgr) | Pending | Claimed | `ClaimedByUserId=me`, `AssignmentKind=SelfClaimed` |
| Assign (Mgr) | Pending | Assigned | `AssignedToUserId=target`, `AssignmentKind=Assigned` |
| Delegate (Mgr) | Assigned/Claimed | Assigned | `AssignedToUserId=target`, `ClaimedByUserId=null`, `AssignmentKind=Delegated` |
| Open (owner) | Assigned/Claimed | InProgress | `ClaimedByUserId=me` |
| Submit (owner/Mgr) | InProgress/Claimed | Completed | corrections saved, raises `ValidationCompleted` |
| Escalate (system) | Pending/Assigned | Escalated | alert, routed to Manager |

**Optimistic concurrency** (`RowVersion`) prevents two users from claiming/submitting the same
task simultaneously — the loser gets a 409 and a refreshed view.

## 6. Validation workspace UX

```mermaid
flowchart LR
    subgraph Screen[Validation workspace]
        PDF[PDF viewer<br/>page nav, zoom,<br/>field highlight on focus]
        FORM[Entity form<br/>header fields + line items<br/>confidence color, inline edit]
    end
    PDF <--> FORM
    FORM --> ACT[Actions: Save draft · Submit · Assign/Delegate Mgr · Reject]
```

- **Side-by-side**: PDF on the left, form on the right; focusing a field highlights its region on
  the PDF (bounding boxes from Document Intelligence).
- **Confidence coloring**: low-confidence fields flagged for mandatory review.
- **Keyboard-first**: tab through fields, `Ctrl+Enter` to submit.
- **Realtime**: SLA countdown + "task reassigned/completed elsewhere" notifications via SignalR.

## 7. Audit

Every action (claim/assign/delegate/submit/escalate) writes an `AuditEvent` with actor, before/
after, and timestamp — required for compliance and dispute resolution.
