# 05 — Email Ingestion with Microsoft Graph

How OrderFlow detects, authenticates, reads, and converts inbound order emails.

## 1. Detection: change notifications (webhooks), not polling

Graph **change notifications** push a lightweight POST to our webhook whenever new mail arrives
in a monitored mailbox. This is far more scalable and timely than polling.

```mermaid
sequenceDiagram
    autonumber
    participant EI as Email Intake
    participant G as MS Graph
    EI->>G: POST /subscriptions (resource=users/{mbx}/messages, changeType=created)
    G-->>EI: GET webhook?validationToken=... (handshake)
    EI-->>G: 200 text/plain echo token
    G-->>EI: 201 subscription (expires in <= ~3 days for mail)
    Note over EI,G: Timer renews subscription every 30 min
    G-->>EI: POST notification {resource, clientState} on new mail
```

### Subscription creation (app-only)

- Resource: `users/{mailbox}/mailFolders('Inbox')/messages`, `changeType=created`.
- `notificationUrl`: the public HTTPS endpoint of the Email Intake `GraphWebhook`.
- `clientState`: a secret we store and verify on every notification (anti-spoofing).
- `expirationDateTime`: max ~4230 min for messages → **renewed by a timer** every 30 min.
- Optionally **rich notifications with encrypted resource data** to receive the message payload
  inline (requires an app certificate for decryption) — avoids an extra round-trip.

## 2. AuthN/AuthZ

- **App-only** (client credentials) via **Managed Identity** federation or a cert in Key Vault.
- Graph application permission **`Mail.Read`** constrained to the specific shared mailbox(es)
  using an **Application Access Policy** (`New-ApplicationAccessPolicy`) — least privilege, so the
  app cannot read the whole tenant's mail.
- `Mail.Send` only if we later send acknowledgements.

## 3. Webhook handler contract

```
POST /api/graph/webhook
  ?validationToken=...            -> 200 text/plain (echo) [handshake only]
  body: ChangeNotificationCollection {
     value: [{ subscriptionId, clientState, resource, resourceData{ id }, changeType }]
  }                               -> 202 Accepted (fast)
```

Steps in the handler (kept < 30s to satisfy Graph):
1. Handshake: if `validationToken` present, echo it and return.
2. Verify each `clientState` equals our stored secret; reject otherwise.
3. For each notification: extract `messageId`, resolve **customer + priority** (see §5),
   **de-dup** by `messageId`.
4. Publish `OrderReceived` to Service Bus and return `202` immediately.

> The handler never downloads the email — that is a durable, retryable activity, so a slow Graph
> read can never cause us to miss the ack window or drop a notification.

## 4. Reading the email (orchestrator activity `FetchEmail`)

Using **Microsoft Graph SDK v5** (app-only `GraphServiceClient`):

```csharp
// message metadata + body
var msg = await graph.Users[mailbox].Messages[messageId]
    .GetAsync(r => r.QueryParameters.Select =
        ["subject","from","receivedDateTime","body","hasAttachments","internetMessageId"]);

// MIME (for faithful email->PDF) 
var mime = await graph.Users[mailbox].Messages[messageId].Content.GetAsync(); // $value -> Stream

// attachments
var atts = await graph.Users[mailbox].Messages[messageId].Attachments.GetAsync();
foreach (var a in atts.Value.OfType<FileAttachment>())
    use(a.Name, a.ContentType, a.ContentBytes);
```

## 5. Customer & priority resolution

- Primary: match the sender domain (or `from`/`to`) against `CustomerProfile.SenderDomains`.
- Fallback: a per-recipient alias (`orders+acme@contoso.com`) or subject rule.
- No match → `customerId = "triage"`, `Priority = Low`, task routed to a triage queue for manual
  tagging.
- The resolved `Priority` (derived from `CustomerTier`) becomes the Service Bus message property
  that selects the subscription. See [07-priority-sla.md](07-priority-sla.md).

## 6. Email → PDF conversion (activity `ConvertToPdf`)

Goals: a faithful, archivable PDF of the email body plus a normalized PDF for every attachment so
the Action Center has a single viewer.

- **Email body (HTML/MIME) → PDF**: render the sanitized HTML to PDF (headless Chromium via
  `PuppeteerSharp`, or a managed HTML-to-PDF library). Strip tracking/remote content for security.
- **Attachments**:
  - PDF → kept as-is (optionally re-stamped).
  - Images (PNG/JPG/TIFF) → wrapped into a PDF page.
  - Office (DOCX/XLSX) → converted to PDF (LibreOffice headless in a sidecar, or a conversion
    service). For the POC a pluggable `IDocumentConverter` abstracts the engine.
- Output: ordered list of `PdfDoc { kind, fileName, bytes }` → handed to `StoreDocuments`.

## 7. Resilience & edge cases

| Case | Handling |
|------|----------|
| Duplicate notification | De-dup store keyed by `messageId` (TTL). |
| Subscription expired/missed | Renewal timer + periodic reconciliation (delta query) to catch gaps. |
| Large attachments (>4MB) | Stream via attachment `$value`; store directly to blob. |
| Malware | Attachments scanned (Defender for Storage) before human access. |
| Throttling (429) | Graph SDK retry handler honours `Retry-After`. |
| Mailbox outage | Notifications buffered by Graph; reconciliation on recovery. |
