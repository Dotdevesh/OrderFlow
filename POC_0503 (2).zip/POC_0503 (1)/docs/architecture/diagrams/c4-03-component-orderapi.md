# C4 Level 3 — Component (Order API)

```mermaid
C4Component
    title Component Diagram — Order API

    Container(spa, "Action Center", "Angular SPA")
    Container(orch, "Orchestrator", "Durable Functions")
    ContainerDb(sql, "SQL Server")
    ContainerQueue(sb, "Service Bus")

    Container_Boundary(api, "Order API") {
        Component(orderEp, "Order Endpoints", "Minimal API", "internal create/finalize")
        Component(taskEp, "Task Endpoints", "Minimal API", "inbox, claim, assign, delegate, submit")
        Component(docEp, "Document Endpoints", "Minimal API", "short-lived blob SAS")
        Component(hub, "Tasks SignalR Hub", "SignalR", "realtime task + SLA push")
        Component(authz, "AuthZ", "Policies + resource handler", "Manager/Reportee + ownership rules")
        Component(appsvc, "Application Services", "Services", "OrderService, TaskService, AssignmentService")
        Component(dur, "Durable Client", "DurableTaskClient", "RaiseEvent ValidationCompleted")
        Component(repo, "EF Core DbContext", "EF Core 10", "aggregates; inbox reads the same tables")
        Component(outbox, "Outbox Dispatcher", "HostedService", "domain events → Service Bus")
    }

    Rel(spa, taskEp, "REST", "HTTPS")
    Rel(spa, hub, "subscribe", "WSS")
    Rel(orch, orderEp, "create/finalize", "HTTPS")
    Rel(taskEp, authz, "enforce")
    Rel(taskEp, appsvc, "invoke")
    Rel(appsvc, repo, "read/write")
    Rel(repo, sql, "EF Core")
    Rel(appsvc, dur, "on submit")
    Rel(dur, orch, "RaiseEvent")
    Rel(appsvc, hub, "notify")
    Rel(outbox, sb, "publish")
```
