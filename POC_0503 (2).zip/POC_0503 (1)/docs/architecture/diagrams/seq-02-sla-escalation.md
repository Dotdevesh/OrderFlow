# Sequence — SLA breach & escalation (human-in-the-loop)

```mermaid
sequenceDiagram
    autonumber
    participant OR as OrderOrchestrator
    participant DT as Durable runtime
    participant API as Order API
    participant DB as SQL
    actor Mgr as Manager

    OR->>DT: WaitForExternalEvent("ValidationCompleted") + CreateTimer(SlaDueAt)
    Note over OR,DT: instance dehydrated (no compute while waiting)
    DT-->>OR: timer fires (no submit in time)
    OR->>API: Escalate(orderId, attempt)
    API->>DB: Task=Escalated, reassign to Manager
    API-->>Mgr: SignalR: escalated task
    OR->>DT: re-arm WaitForExternalEvent + CreateTimer(now + escalationInterval)
    Mgr->>API: POST submit(validated)
    API->>DB: save, Task=Completed
    API->>OR: RaiseEvent("ValidationCompleted")
    DT-->>OR: rehydrate + resume
    OR->>API: FinalizeOrder
```
