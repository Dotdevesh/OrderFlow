# C4 Level 3 — Component (Orchestrator)

```mermaid
C4Component
    title Component Diagram — Orchestrator (Durable Functions)

    ContainerQueue(sb, "Service Bus", "Topic subscriptions")
    System_Ext(graph, "Microsoft Graph")
    System_Ext(di, "Document Intelligence")
    Container(api, "Order API")
    ContainerDb(blob, "Blob Storage")

    Container_Boundary(orch, "Orchestrator") {
        Component(starter, "Priority Starters", "ServiceBus-triggered", "Start_High/Standard/Low → start orchestration (deterministic instanceId)")
        Component(orchestrator, "OrderOrchestrator", "OrchestrationTrigger", "Coordinates activities, fan-out/fan-in, SLA timer, external-event wait")
        Component(aFetch, "FetchEmail", "Activity", "Graph: MIME + attachments")
        Component(aPdf, "ConvertToPdf", "Activity", "Email/body + attachments → PDF")
        Component(aStore, "StoreDocuments", "Activity", "Write PDFs to Blob (deterministic paths)")
        Component(aCreate, "CreateOrder", "Activity", "Call Order API (idempotent upsert)")
        Component(aAnalyze, "AnalyzeDocument", "Activity", "Doc Intelligence (semaphore-bounded)")
        Component(aTask, "CreateValidationTask", "Activity", "Persist entities + create/route task")
        Component(aFinal, "FinalizeOrder", "Activity", "Finalize / downstream handoff")
        Component(aEsc, "Escalate", "Activity", "Reassign + alert on SLA breach")
    }

    Rel(sb, starter, "Deliver OrderReceived")
    Rel(starter, orchestrator, "StartNew(instanceId)")
    Rel(orchestrator, aFetch, "CallActivity")
    Rel(aFetch, graph, "read")
    Rel(orchestrator, aPdf, "CallActivity")
    Rel(orchestrator, aStore, "CallActivity")
    Rel(aStore, blob, "write")
    Rel(orchestrator, aCreate, "CallActivity")
    Rel(aCreate, api, "POST /internal/orders")
    Rel(orchestrator, aAnalyze, "fan-out/fan-in")
    Rel(aAnalyze, di, "analyze")
    Rel(orchestrator, aTask, "CallActivity")
    Rel(aTask, api, "POST validation-task")
    Rel(orchestrator, aFinal, "CallActivity")
    Rel(orchestrator, aEsc, "CallActivity (on SLA breach)")
```
