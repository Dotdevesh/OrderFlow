# Sequence — Happy Path (email → finalized order)

```mermaid
sequenceDiagram
    autonumber
    actor C as Customer
    participant G as MS Graph
    participant EI as Email Intake
    participant SB as Service Bus (orders topic)
    participant ST as Priority Starter
    participant OR as OrderOrchestrator
    participant BL as Blob
    participant DI as Doc Intelligence
    participant API as Order API
    participant DB as SQL
    actor U as Validator

    C->>G: order email + attachments
    G-->>EI: change notification (webhook)
    EI->>EI: verify clientState, de-dup, resolve customer+priority
    EI->>SB: OrderReceived {corrId, msgId, customerId, priority}
    SB-->>ST: deliver (sub-high/standard/low)
    ST->>OR: StartNew(instanceId = corrId)
    OR->>G: FetchEmail (MIME + attachments)
    OR->>OR: ConvertToPdf
    OR->>BL: StoreDocuments
    OR->>API: CreateOrder(corrId, blobs, instanceId)
    API->>DB: insert Order(Received)
    par fan-out per document
        OR->>DI: AnalyzeDocument
        DI-->>OR: entities + confidence + bboxes
    end
    OR->>API: CreateValidationTask(orderId, entities)
    API->>DB: insert Task(Pending/Assigned), SlaDueAt
    API-->>U: SignalR new-task
    U->>API: GET task detail + document SAS
    U->>API: POST submit(validated fields)
    API->>DB: save corrections, Task=Completed (RowVersion check)
    API->>OR: RaiseEvent("ValidationCompleted", payload)
    OR->>API: FinalizeOrder
    API->>DB: Order=Finalized
    API-->>U: SignalR task-completed
```
