# C4 Level 2 — Container

```mermaid
C4Container
    title Container Diagram — OrderFlow

    Person(customer, "Customer")
    Person(validator, "Manager / Reportee")
    System_Ext(graph, "Microsoft Graph")
    System_Ext(di, "Document Intelligence")
    System_Ext(entra, "Entra ID")

    System_Boundary(of, "OrderFlow") {
        Container(intake, "Email Intake", "Azure Function .NET 10", "Receives Graph webhooks, de-dupes, resolves customer+priority, publishes OrderReceived")
        ContainerQueue(sb, "Service Bus", "Topic + priority subscriptions", "Durable, priority-segregated backbone")
        Container(orch, "Orchestrator", "Durable Functions .NET 10", "Fetch→PDF→Store→Create→Extract→Wait(human)→Finalize")
        Container(api, "Order API", "ASP.NET Core Minimal API .NET 10", "BFF, tasks, assignment, workflow resume, SignalR")
        ContainerDb(sql, "SQL Server", "Azure SQL", "Orders, Tasks, Customers, Users, Audit, Outbox")
        ContainerDb(blob, "Blob Storage", "Azure Storage", "Email PDF + attachment PDFs + extraction JSON; durable task hub")
        Container(spa, "Action Center", "Angular 20 SPA", "Human-in-the-loop validation UI")
    }
    System_Ext(erp, "ERP / Fulfilment")

    Rel(customer, graph, "Email")
    Rel(graph, intake, "Change notifications", "HTTPS webhook")
    Rel(intake, sb, "Publish OrderReceived", "AMQP")
    Rel(sb, orch, "Deliver by priority", "AMQP trigger")
    Rel(orch, graph, "Fetch email + attachments", "Graph API")
    Rel(orch, blob, "Store documents", "HTTPS")
    Rel(orch, di, "Analyze documents", "HTTPS")
    Rel(orch, api, "Create order / task / finalize", "HTTPS (internal)")
    Rel(api, sql, "Read/write", "EF Core")
    Rel(api, orch, "RaiseEvent ValidationCompleted", "Durable client")
    Rel(spa, api, "REST + SignalR", "HTTPS/WSS")
    Rel(validator, spa, "Uses", "HTTPS")
    Rel(api, erp, "Finalized order (design intent, not built)", "none")
    Rel(spa, entra, "Login (MSAL)", "OIDC")
```
