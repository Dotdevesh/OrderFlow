# Deployment / Infrastructure (Azure)

```mermaid
flowchart TB
    subgraph Internet
        C[Customer email]
        U[Validators - browser]
    end
    GRAPH[Microsoft Graph]
    ENTRA[Entra ID]

    subgraph RG[Azure Resource Group - per environment]
        subgraph FLEX[Functions - Flex Consumption]
            EI[Email Intake Function App]
            OR[Orchestrator Function App]
        end
        API[App Service / Container Apps: Order API]
        SWA[Static Web App: Action Center]
        SB[(Service Bus Namespace<br/>topic: orders + subs)]
        BLOB[(Storage Account<br/>documents + durable hub)]
        SQL[(Azure SQL Database)]
        DI[Document Intelligence]
        KV[(Key Vault)]
        AI[(Application Insights + Log Analytics)]
        MI{{Managed Identities}}
    end
    ERP[Downstream ERP]

    C --> GRAPH --> EI
    EI --> SB --> OR
    OR --> GRAPH
    OR --> BLOB
    OR --> DI
    OR --> API --> SQL
    U --> SWA --> API
    API -. SignalR .-> U
    SWA --> ENTRA
    API --> ENTRA
    EI & OR & API -->|secrets| KV
    EI & OR & API -->|MI auth| MI
    EI & OR & API & SWA --> AI
    API --> ERP
```

**Notes**
- All intra-Azure access uses **Managed Identity** + RBAC (no connection strings where avoidable).
- The `API --> ERP` edge and private endpoints (SQL, Service Bus, Storage, Key Vault, Document
  Intelligence) are [design intent](../14-design-intent.md). They are not in `infra/main.bicep`.
- Bicep today provisions the data and AI plane only. App hosts are deployed separately. See
  [developer setup](../../developer-setup.md).
