# 14 — Design intent (not built)

These five items are agreed direction. They are **not** part of local setup, **not** in
`infra/main.bicep`, and **not** something a developer enables while standing up an environment.
Build one only when its trigger below is true. Until then, leave the current behaviour in place.

| Item | Current behaviour | Build it when |
|------|-------------------|---------------|
| Private networking | Public endpoints on the resources Bicep creates | A production environment requires the data plane off the public internet |
| DLQ replay runbook | The short procedure in [09 §6](09-resilience-no-order-loss.md) | Operators need a standalone replay document, or a tool that resubmits dead letters |
| Second read store | Inbox queries use the same EF Core tables as writes | Inbox reads contend with order/task writes |
| Service Bus sessions | Subscriptions are non-session. Publishers already stamp `SessionId` | A tier needs FIFO processing per customer |
| ERP endpoint | `FinalizeOrder` writes `OrderFinalized` to the outbox and stops | A real fulfilment system must receive the finalized order |

## 1. Private networking

**Intent.** Production traffic to SQL, Service Bus, Storage (blobs and the Durable Functions
task hub), Key Vault, and Document Intelligence goes through private endpoints on a per-environment
VNet. Email Intake, the Orchestrator, and Order API integrate with that VNet and route outbound
Azure traffic through it. The Action Center stays a public SPA and calls Order API on the API’s
public HTTPS front (the app endpoint or an application gateway), authenticated with Entra ID.

The Graph webhook stays reachable from the internet. Microsoft Graph cannot call a private
endpoint. Protect that URL with `clientState` as in [05](05-email-graph.md); do not move the
webhook onto the private network.

**Leave in place.** Local Docker and the first Azure environment in
[developer setup](../developer-setup.md) use public endpoints. The deployment diagram’s private-endpoint
note is this section, not a template that exists today.

## 2. DLQ replay document

**Intent.** A standalone operations document (and, later, a resubmit tool) covers dead letters on
`sub-high`, `sub-standard`, and `sub-low`:

1. Peek the dead letter. Record `MessageId` (the Graph message id), `correlationId`, `customerId`, `priority`, and the dead-letter reason.
2. Fix the cause (bug, config, or downstream outage). Do not resubmit first.
3. Resubmit the original body onto the topic `orders` with the **same** `MessageId` and application properties. Duplicate detection and idempotent activities make a second delivery safe.
4. Confirm the intake ledger row for that `MessageId` advanced, and that a new dead letter was not created.

The same document will hold each environment’s RPO/RTO once private networking and redundant SKUs
are chosen. `infra/main.bicep` uses LRS storage and a single SQL database, so those numbers are
not meaningful yet.

**Leave in place.** [09 §6](09-resilience-no-order-loss.md) is the only procedure. There is no
replay script and no per-environment RPO/RTO page.

## 3. Second read store

**Intent.** Azure SQL remains the system of record ([ADR-0004](../adr/0004-sql-server-system-of-record.md)).
If the Action Center inbox contends with transactional writes, add a **read schema in the same
database**, projected in the same transaction as the write or from the outbox. Order API keeps
serving the inbox. The Action Center does not gain a second connection.

**Leave in place.** One EF Core model. Inbox queries read `Orders` and `ValidationTasks`. Do not
provision Cosmos DB, a replica database, or another server for reads.

## 4. Service Bus sessions

**Intent.** When a tier needs strict per-customer order, set `requiresSession` on the priority
subscriptions that serve that tier and switch those Orchestrator triggers to session receivers
(`SessionId = customerId`). One consumer then processes a customer’s messages FIFO; other
customers still run in parallel. Expect less parallelism inside a customer, so this stays opt-in
per tier ([ADR-0003](../adr/0003-service-bus-priority-topology.md)).

**Leave in place.** `local/servicebus-config.json` and `infra/main.bicep` leave
`RequiresSession` false. Email Intake and the `OrderFinalized` outbox publisher already set
`SessionId` to the customer id; non-session subscriptions ignore it. Do not turn sessions on
during setup — in-flight messages and the emulator topology are non-session.

## 5. ERP endpoint

**Intent.** A later subscription on the topic `orders` (for example `sub-erp`, filtered to
`OrderFinalized`) is consumed by an adapter that calls the fulfilment system. The handoff payload
is the existing contract `OrderFinalized(OrderId, CustomerId, FinalizedAtUtc)` in
`OrderFlow.Contracts`. The adapter owns retries and its own dead-letter queue. Order API does not
take an ERP base URL.

**Leave in place.** `FinalizeOrder` advances the order to `Finalized`, writes `OrderFinalized`
to the SQL outbox, and returns. When Service Bus is configured, the outbox dispatcher publishes
it to `orders`. The priority subscriptions filter on `eventType = 'OrderReceived'`, so no
subscription receives it today. No ERP host, credential, or app setting exists. The C4 context
diagram and the deployment diagram show this future edge so the boundary stays visible.

## What a developer does now

Follow [developer setup](../developer-setup.md) and stop. Do not add private endpoints, a second
database, session-enabled subscriptions, an ERP URL, or a replay tool to complete an environment.
