# 07 — Priority & SLA with Service Bus

How OrderFlow keeps a **Platinum** customer's order moving fast while **Silver** traffic surges,
at ~1 order/second sustained.

## 1. Customer tiers → priority → SLA

Each customer has a `CustomerProfile` with a **Tier** that maps to a runtime **Priority** and an
**SLA** (validation deadline). Fully data-driven (table), no code changes to onboard a customer.

| Tier | Priority | Validation SLA | Escalation interval | Consumer concurrency |
|------|----------|----------------|---------------------|----------------------|
| Platinum | High (0) | 15 min | 5 min | 32 |
| Gold | Standard (1) | 60 min | 20 min | 16 |
| Silver | Low (2) | 240 min | 60 min | 4 |

## 2. Topology: one topic, priority subscriptions

```mermaid
flowchart LR
    EI[Email Intake] -->|OrderReceived priority=p| T{{Topic: orders}}
    T -->|filter priority=0| SH[sub-high]
    T -->|filter priority=1| SS[sub-standard]
    T -->|filter priority=2| SL[sub-low]
    SH --> OH[Orchestrator starter High]
    SS --> OS[Orchestrator starter Standard]
    SL --> OL[Orchestrator starter Low]
    SH -. DLQ .-> DLH[(dead-letter)]
    SS -. DLQ .-> DLS[(dead-letter)]
    SL -. DLQ .-> DLL[(dead-letter)]
```

- **Topic `orders`** with **SQL rule filters** on the `priority` message property creates three
  independent streams from one publish.
- Each subscription has its **own starter function** and **own scaling**, so a Silver backlog can
  never block Platinum processing (resource isolation / bulkhead).
- **Dead-letter queue** per subscription for poison messages (max delivery 10) + alerting.
- **Duplicate detection** on the topic keyed by `MessageId = GraphMessageId`.

### Why topic+subscriptions over N queues
A topic lets us publish **once** and evolve routing (add a "triage" or "VIP" subscription) without
touching the publisher. See [ADR-0003](../adr/0003-service-bus-priority-topology.md).

## 3. Ordering per customer (design intent)

Per-customer FIFO via Service Bus sessions is [design intent](14-design-intent.md). Subscriptions
stay non-session. Do not set `requiresSession` while standing an environment up. The intended
shape, when a tier needs it: `SessionId = customerId`, one active consumer per session, other
customers still parallel. Sessions reduce parallelism inside a customer, so the change is opt-in
per tier.

## 4. Concurrency & throughput tuning

`host.json` (Orchestrator) controls per-app concurrency; each priority app is deployed/scaled
independently:

```jsonc
{
  "extensions": {
    "serviceBus": { "maxConcurrentCalls": 32, "prefetchCount": 64 },
    "durableTask": {
      "maxConcurrentActivityFunctions": 40,
      "maxConcurrentOrchestratorFunctions": 20
    }
  }
}
```

- **Document Intelligence** is the external bottleneck → a global **semaphore / token bucket**
  bounds concurrent analyze calls to the provisioned TPS; fan-out respects it.
- High-priority app gets a larger instance budget and higher concurrency.

## 5. SLA enforcement (human stage)

- `Order.SlaDueAtUtc = ReceivedAtUtc + CustomerProfile.SlaMinutes` (computed at creation using
  `ctx.CurrentUtcDateTime`).
- A **durable timer** in the orchestrator races the `ValidationCompleted` external event
  (see [06](06-durable-functions.md)).
- On breach: `Escalate` activity reassigns the task to a Manager and emits an alert; the wait is
  re-armed with the tier's escalation interval. SLA state and countdown are pushed to the UI via
  SignalR so validators see time remaining.
- **Metrics**: SLA breach rate per tier, time-to-validate percentiles, queue depth per priority.

## 6. Volume handling (1 order/sec, bursty)

| Pressure point | Mitigation |
|----------------|------------|
| Ingestion bursts | Service Bus buffers; Email Intake stays light (publish only). |
| Orchestration backlog | Elastic Functions scale-out per priority; waiting-on-human is free. |
| Extraction throughput | Fan-out bounded by Doc Intelligence TPS semaphore; batch where possible. |
| SQL write contention | Outbox + indexes on the same tables the inbox reads. A second read schema is [design intent](14-design-intent.md). |
| Human capacity | Priority routing ensures high-value orders validated first; pool + assignment balances load. |

## 7. Autoscale signals

- Functions: scale on Service Bus queue/subscription **message count** (target-based scaling).
- Order API: scale on HTTP concurrency + CPU.
- Alerts when `ActiveMessageCount(sub-high)` or SLA-breach rate crosses thresholds.
