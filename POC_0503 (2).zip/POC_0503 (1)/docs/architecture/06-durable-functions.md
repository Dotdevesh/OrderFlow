# 06 — Durable Functions & Human-in-the-Loop Resume

The orchestrator is the heart of OrderFlow. This document explains the chosen patterns, the
determinism rules, and exactly **how the workflow resumes after a human validates**.

## 1. Why Durable Functions

The business transaction spans **seconds of compute** but **minutes-to-days of wall-clock time**
(waiting on a human). We need:

- **Stateful, resumable** execution with automatic checkpointing (survives restarts/deploys).
- **External events** to resume on human action — native in Durable Functions.
- **Durable timers** for SLA without a thread/compute being held.
- **Fan-out/fan-in** for parallel document analysis.
- **At-least-once activity execution** with built-in retries.

See [ADR-0002](../adr/0002-durable-functions-for-orchestration.md).

## 2. Function types used

| Type | Function | Notes |
|------|----------|-------|
| Client/Starter | `Start_High/Standard/Low` | Service Bus-triggered; start one orchestration per message. |
| Orchestrator | `OrderOrchestrator` | Deterministic coordination; **no I/O**. |
| Activity | `FetchEmail`, `ConvertToPdf`, `StoreDocuments`, `CreateOrder`, `AnalyzeDocument`, `CreateValidationTask`, `FinalizeOrder`, `Escalate` | Do the real work; idempotent. |
| Client (external) | Order API uses `DurableTaskClient.RaiseEventAsync` | Resumes the orchestration. |

## 3. Orchestrator code (the full pattern)

```csharp
[Function(nameof(OrderOrchestrator))]
public async Task RunAsync([OrchestrationTrigger] TaskOrchestrationContext ctx)
{
    var input = ctx.GetInput<OrderReceived>()!;
    var log = ctx.CreateReplaySafeLogger<OrderOrchestrator>();

    var retry = TaskOptions.FromRetryPolicy(new RetryPolicy(
        maxNumberOfAttempts: 5,
        firstRetryInterval: TimeSpan.FromSeconds(2),
        backoffCoefficient: 2.0,
        maxRetryInterval: TimeSpan.FromMinutes(2)));

    var email  = await ctx.CallActivityAsync<FetchedEmail>(nameof(FetchEmail), input, retry);
    var pdfs   = await ctx.CallActivityAsync<IReadOnlyList<PdfDoc>>(nameof(ConvertToPdf), email, retry);
    var stored = await ctx.CallActivityAsync<StoredDocuments>(
                     nameof(StoreDocuments), new StoreRequest(input, pdfs), retry);
    var order  = await ctx.CallActivityAsync<OrderCreated>(
                     nameof(CreateOrder), new CreateOrderRequest(input, stored), retry);

    // Fan-out / fan-in — analyze every document in parallel
    var analyses = stored.Blobs
        .Select(b => ctx.CallActivityAsync<DocumentEntities>(nameof(AnalyzeDocument), b, retry))
        .ToList();
    var entities = await Task.WhenAll(analyses);

    await ctx.CallActivityAsync(
        nameof(CreateValidationTask),
        new CreateTaskRequest(order.OrderId, ctx.InstanceId, entities), retry);

    // ---------- HUMAN IN THE LOOP ----------
    var outcome = await WaitForValidationWithSlaAsync(ctx, order, log);

    if (outcome is { Approved: true })
        await ctx.CallActivityAsync(nameof(FinalizeOrder), outcome, retry);
    else
        await ctx.CallActivityAsync(nameof(FinalizeOrder),   // rejected -> close as rejected
            outcome ?? new ValidationCompletedPayload(order.OrderId, "system", false, [], "SLA/abandoned"),
            retry);
}
```

## 4. The human-in-the-loop wait with SLA (resume mechanism)

```csharp
private static async Task<ValidationCompletedPayload?> WaitForValidationWithSlaAsync(
    TaskOrchestrationContext ctx, OrderCreated order, ILogger log)
{
    var slaDeadline = order.SlaDueAtUtc;
    var maxEscalations = 3;

    for (var attempt = 0; attempt <= maxEscalations; attempt++)
    {
        using var cts = new CancellationTokenSource();
        var slaTimer = ctx.CreateTimer(slaDeadline, cts.Token);
        var validated = ctx.WaitForExternalEvent<ValidationCompletedPayload>("ValidationCompleted");

        var winner = await Task.WhenAny(validated, slaTimer);
        if (winner == validated)
        {
            cts.Cancel();              // stop the durable timer
            return validated.Result;   // RESUME — human submitted
        }

        // SLA breached -> escalate and re-arm with a shorter window
        await ctx.CallActivityAsync(nameof(Escalate),
            new EscalateRequest(order.OrderId, attempt + 1));
        slaDeadline = ctx.CurrentUtcDateTime.AddMinutes(order.EscalationIntervalMinutes);
    }
    return null; // abandoned after max escalations
}
```

### What actually happens on resume

1. The orchestrator calls `WaitForExternalEvent("ValidationCompleted")`. The runtime writes a
   checkpoint to the task hub (Storage) and **dehydrates** the instance — zero compute while waiting.
2. The validator submits in the Action Center → Order API persists and calls
   `durableClient.RaiseEventAsync(instanceId, "ValidationCompleted", payload)`.
3. The runtime appends the event to the instance history, **rehydrates** the orchestrator, replays
   its history deterministically up to the `await`, and delivers the event — execution continues at
   the exact line after the wait. The SLA timer is cancelled.

The **`instanceId`** is the link: it is generated when the orchestration starts, stored on the
`Order`/`ValidationTask` rows (`OrchestrationInstanceId`), and used by the API to target the event.

## 5. Determinism rules (must-follow)

Orchestrator code is **replayed**; it must be deterministic:

- ❌ No `DateTime.Now`, `Guid.NewGuid()`, random, direct I/O, `Task.Delay`, non-durable async.
- ✅ Use `ctx.CurrentUtcDateTime`, `ctx.NewGuid()`, `ctx.CreateTimer`, and **activities** for all
  I/O. Use `ctx.CreateReplaySafeLogger` for logging.
- Keep orchestrator inputs/outputs serializable; keep activities small and idempotent.

## 6. Idempotency

- Starter sets a **deterministic `instanceId`** = `OrderReceived.CorrelationId` → a duplicate
  Service Bus delivery won't start a second orchestration (`StartNew` is a no-op if running).
- `CreateOrder` upserts by `CorrelationId`; `StoreDocuments` uses deterministic blob paths;
  `AnalyzeDocument` caches by content hash.

## 7. Scaling & isolation

- Separate **starter functions per priority subscription** keep high-priority starts from being
  starved by a low-priority backlog.
- `maxConcurrentActivityFunctions` / `maxConcurrentOrchestratorFunctions` tuned in `host.json`.
- Waiting-on-human instances cost nothing, so millions can be "in flight" cheaply.

## 8. Observability

- `CorrelationId` == `OrderId` propagated into every activity + the API + Service Bus properties.
- Custom events emitted at each stage; orchestration status queryable via the Durable HTTP APIs
  and surfaced on an ops dashboard.
