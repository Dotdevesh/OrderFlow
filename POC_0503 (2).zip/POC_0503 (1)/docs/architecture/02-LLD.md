# 02 — Low Level Design (LLD)

Component-level design: contracts, data model, function signatures, APIs, idempotency,
configuration, and error handling.

## 1. Solution structure

```
src/
├─ OrderFlow.sln
├─ building-blocks/
│  ├─ OrderFlow.Contracts/      integration events, DTOs, message keys
│  ├─ OrderFlow.Domain/         entities, value objects, enums, domain events
│  └─ OrderFlow.BuildingBlocks/ Service Bus, Blob, Result<T>, telemetry, guards
├─ services/
│  ├─ OrderFlow.EmailIntake/
│  ├─ OrderFlow.Orchestrator/
│  └─ OrderFlow.OrderApi/
└─ clients/action-center/
```

## 2. Integration events (Service Bus)

`OrderFlow.Contracts` — versioned, immutable records. `CorrelationId` flows through all.

```csharp
public sealed record OrderReceived(
    Guid CorrelationId,
    string GraphMessageId,
    string MailboxAddress,
    string CustomerId,
    Priority Priority,
    DateTimeOffset ReceivedAtUtc);

public sealed record OrderExtracted(
    Guid CorrelationId, Guid OrderId, int DocumentCount, double MinConfidence);

public sealed record ValidationCompletedPayload(
    Guid OrderId, string ValidatedByUserId, bool Approved,
    IReadOnlyList<ValidatedField> Fields, string? Note);
```

**Message application properties** (used for routing/filtering, see §7):
`priority`, `customerId`, `correlationId`, `eventType`, `schemaVersion`.

## 3. Domain model (`OrderFlow.Domain`)

```mermaid
classDiagram
    class Order {
        +Guid Id
        +string CustomerId
        +OrderStatus Status
        +Guid CorrelationId
        +string? OrchestrationInstanceId
        +DateTimeOffset ReceivedAtUtc
        +DateTimeOffset SlaDueAtUtc
        +List~OrderDocument~ Documents
        +List~OrderLine~ Lines
    }
    class OrderDocument {
        +Guid Id
        +string BlobPath
        +DocumentKind Kind
        +string? AnalyzeModelId
        +double MinConfidence
    }
    class OrderLine {
        +Guid Id
        +string Sku
        +string Description
        +decimal Quantity
        +decimal UnitPrice
        +FieldConfidence Confidence
    }
    class ValidationTask {
        +Guid Id
        +Guid OrderId
        +TaskStatus Status
        +string? AssignedToUserId
        +string? ClaimedByUserId
        +Priority Priority
        +DateTimeOffset SlaDueAtUtc
        +AssignmentKind AssignmentKind
    }
    class CustomerProfile {
        +string CustomerId
        +CustomerTier Tier
        +Priority Priority
        +int SlaMinutes
        +string[] SenderDomains
    }
    class AppUser {
        +string Id
        +UserRole Role
        +string? ManagerId
    }
    Order "1" --> "*" OrderDocument
    Order "1" --> "*" OrderLine
    Order "1" --> "1" ValidationTask
    CustomerProfile "1" --> "*" Order
```

Enums:
```csharp
public enum CustomerTier { Platinum, Gold, Silver }
public enum Priority { High = 0, Standard = 1, Low = 2 }
public enum OrderStatus { Received, Stored, Extracted, PendingValidation, Validated, Finalized, Failed }
public enum TaskStatus { Pending, Assigned, Claimed, InProgress, Completed, Escalated, Cancelled }
public enum UserRole { Reportee, Manager }
public enum AssignmentKind { Pool, Assigned, Delegated, SelfClaimed }
public enum DocumentKind { EmailBody, Attachment, ExtractionResult }
```

## 4. SQL Server schema (EF Core 10, code-first)

```
Customers(CustomerId PK, Tier, Priority, SlaMinutes, SenderDomainsJson)
Users(Id PK, DisplayName, Role, ManagerId FK->Users)
Orders(Id PK, CustomerId FK, Status, CorrelationId, OrchestrationInstanceId,
       ReceivedAtUtc, SlaDueAtUtc, FinalizedAtUtc, RowVersion)
OrderDocuments(Id PK, OrderId FK, Kind, BlobPath, AnalyzeModelId, MinConfidence)
OrderLines(Id PK, OrderId FK, Sku, Description, Quantity, UnitPrice,
           ConfidenceJson, IsCorrected)
OrderFields(Id PK, OrderId FK, Name, ExtractedValue, ValidatedValue, Confidence) -- header fields
ValidationTasks(Id PK, OrderId FK, Status, Priority, AssignmentKind,
                AssignedToUserId FK->Users, ClaimedByUserId FK->Users,
                SlaDueAtUtc, CreatedAtUtc, CompletedAtUtc, RowVersion)
OutboxMessages(Id PK, Type, Payload, OccurredAtUtc, ProcessedAtUtc)
AuditEvents(Id PK, OrderId, TaskId, UserId, Action, DataJson, AtUtc)
```

- **Optimistic concurrency** via `RowVersion` (rowversion/timestamp) on `Orders` and
  `ValidationTasks` to prevent two validators clobbering each other.
- **Indexes**: `ValidationTasks(Status, Priority, SlaDueAtUtc)`, `(AssignedToUserId, Status)`,
  `Orders(CorrelationId)`, `Orders(OrchestrationInstanceId)`.
- **Outbox** dispatched by a background `IHostedService` → Service Bus (transactional safety).

## 5. Email Intake — functions

```csharp
[Function("GraphWebhook")]
public async Task<HttpResponseData> Webhook(
    [HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req)
// 1. If ?validationToken present -> echo it (text/plain 200) — subscription handshake.
// 2. Else parse ChangeNotificationCollection, verify clientState,
//    for each: resolve customer+priority, de-dup by messageId,
//    publish OrderReceived to topic with properties.
// 3. Return 202 quickly (<30s). Heavy work is deferred to the orchestrator.

[Function("SubscriptionRenewal")]
public Task Renew([TimerTrigger("0 */30 * * * *")] TimerInfo t) // renew before expiry
```

De-dup store: Azure Table `SeenMessages(PartitionKey=mailbox, RowKey=messageId, ttl)`.

## 6. Orchestrator — functions & signatures

```csharp
// Starter: one per priority subscription (keeps scaling isolated)
[Function("Start_High")]
public Task StartHigh(
    [ServiceBusTrigger("orders", "sub-high", Connection="Sb")] ServiceBusReceivedMessage m,
    [DurableClient] DurableTaskClient client) => StartAsync(m, client);

[Function("OrderOrchestrator")]
public async Task RunOrchestrator([OrchestrationTrigger] TaskOrchestrationContext ctx)
{
    var input = ctx.GetInput<OrderReceived>();
    var email  = await ctx.CallActivityAsync<FetchedEmail>(nameof(FetchEmail), input);
    var pdfs   = await ctx.CallActivityAsync<IReadOnlyList<PdfDoc>>(nameof(ConvertToPdf), email);
    var stored = await ctx.CallActivityAsync<StoredDocs>(nameof(StoreDocuments), new(input, pdfs));
    var order  = await ctx.CallActivityAsync<OrderCreated>(nameof(CreateOrder), new(input, stored));

    // fan-out / fan-in extraction
    var tasks = stored.Blobs.Select(b => ctx.CallActivityAsync<DocEntities>(nameof(AnalyzeDocument), b));
    var results = await Task.WhenAll(tasks);

    await ctx.CallActivityAsync(nameof(CreateValidationTask), new(order.OrderId, results));

    // Human-in-the-loop with SLA (durable timer races external event)
    var validation = await WaitForValidationWithSla(ctx, order);

    if (validation is null)  // SLA breach path
        await ctx.CallActivityAsync(nameof(Escalate), order.OrderId);
    else
        await ctx.CallActivityAsync(nameof(FinalizeOrder), validation);
}
```

`WaitForValidationWithSla` uses `ctx.WaitForExternalEvent<ValidationCompletedPayload>("ValidationCompleted")`
raced against `ctx.CreateTimer(order.SlaDueAtUtc, cts.Token)`; on breach it escalates and
re-arms the wait. Full code and determinism rules in [06-durable-functions.md](06-durable-functions.md).

**Activities** (each idempotent, keyed by `CorrelationId`/`OrderId`):
`FetchEmail`, `ConvertToPdf`, `StoreDocuments`, `CreateOrder`, `AnalyzeDocument`,
`CreateValidationTask`, `FinalizeOrder`, `Escalate`.

## 7. Service Bus topology

- Topic `orders`. Subscriptions: `sub-high` (filter `priority = 0 AND eventType = 'OrderReceived'`),
  `sub-standard` (`priority = 1 AND …`), `sub-low` (`priority = 2 AND …`). The `eventType` clause
  keeps other events on the topic, such as `OrderFinalized` from the Order API outbox, away from the
  orchestrator starters. No subscription consumes `OrderFinalized` yet. All three are **non-session** (`RequiresSession` false in Bicep and in
  `local/servicebus-config.json`). Publishers may stamp `SessionId = customerId`; consumers
  ignore it. Turning sessions on is [design intent](14-design-intent.md).
- Dead-letter on each subscription; max delivery 10; lock duration 5 min; duplicate detection on.
- Consumer concurrency: High = 32, Standard = 16, Low = 4 (tunable via host.json).
- Full rationale: [07-priority-sla.md](07-priority-sla.md).

## 8. Order API — endpoints (Minimal API)

| Verb & route | Role | Purpose |
|--------------|------|---------|
| `POST /internal/orders` | svc | Orchestrator creates order (Managed Identity / API key). |
| `POST /internal/orders/{id}/validation-task` | svc | Orchestrator creates task with entities. |
| `POST /internal/orders/{id}/finalize` | svc | Orchestrator finalizes. |
| `GET /api/tasks` | Mgr/Rep | Inbox query: `?scope=mine|team|pool&priority=&status=`. |
| `GET /api/tasks/{id}` | Mgr/Rep | Task detail: header fields, lines, confidence, document SAS URLs. |
| `POST /api/tasks/{id}/claim` | Rep/Mgr | Claim from pool. |
| `POST /api/tasks/{id}/assign` | Mgr | Assign to a user (reportee/manager). |
| `POST /api/tasks/{id}/delegate` | Mgr | Delegate (reassign) to another. |
| `POST /api/tasks/{id}/submit` | Mgr/Rep | Submit validated data → raises `ValidationCompleted`. |
| `GET /api/documents/{orderId}/{docId}/sas` | Mgr/Rep | Short-lived read SAS for the PDF. |
| `/hubs/tasks` (SignalR) | Mgr/Rep | Realtime task + SLA updates. |

Submit handler (the **resume** point):
```csharp
app.MapPost("/api/tasks/{id}/submit", async (Guid id, SubmitDto dto,
        ITaskService tasks, DurableTaskClient durable, ClaimsPrincipal user) =>
{
    var result = await tasks.SubmitAsync(id, dto, user);        // persist + authz + concurrency
    if (result.IsFailure) return Results.BadRequest(result.Error);
    await durable.RaiseEventAsync(
        result.Value.OrchestrationInstanceId, "ValidationCompleted",
        new ValidationCompletedPayload(result.Value.OrderId, user.GetUserId(), dto.Approved,
                                       dto.Fields, dto.Note));
    return Results.Ok();
}).RequireAuthorization();
```

## 9. Authorization rules (LLD)

See the policy matrix in [08-action-center-roles.md](08-action-center-roles.md). Implemented as
ASP.NET Core **authorization policies** + a resource-based handler (`TaskOperationRequirement`)
that checks role, ownership, and manager→reportee relationships.

## 10. Idempotency & concurrency

- **Service Bus dedup** window on the topic (by `MessageId = GraphMessageId`).
- **Activities**: `CreateOrder` upserts by `CorrelationId`; `StoreDocuments` writes
  deterministic blob paths; `AnalyzeDocument` caches by content hash.
- **Durable** replay-safe code: no `DateTime.Now`, no `Guid.NewGuid()`, no I/O in orchestrator —
  use `ctx.CurrentUtcDateTime`, `ctx.NewGuid()`, activities for I/O.
- **SQL** optimistic concurrency via `RowVersion`.

## 11. Configuration (per service)

Names below are the keys in `local.settings.example.json` and `appsettings.json`. The full
local-versus-Azure matrix is in [Developer setup §5](../developer-setup.md).

| Setting | Used by |
|---------|---------|
| `Graph:TenantId`, `Graph:ClientId`, `Graph:Mailboxes` | Email Intake, Orchestrator |
| `Graph:ClientState` | Email Intake (must match the Graph subscription) |
| `ServiceBus` | Email Intake, Orchestrator. Local emulator connection string. In Azure, replace with `ServiceBus:FullyQualifiedNamespace` and Managed Identity. Do not deploy the emulator connection string. |
| `AzureWebJobsStorage` | Email Intake, Orchestrator (Durable task hub + Functions runtime) |
| `OrderApi:BaseUrl` | Email Intake, Orchestrator |
| `Storage:ConnectionString` | Orchestrator, only when `Storage:BlobEndpoint` is empty |
| `Storage:BlobEndpoint`, `Storage:Container` (`order-documents`) | Orchestrator, Order API. Docker also sets `Storage:PublicBlobBaseUrl` on the API so browser SAS URLs reach Azurite. |
| `ConnectionStrings:Storage` | Order API (`UseDevelopmentStorage=true` locally) |
| `DocumentIntelligence:Endpoint`, `DocumentIntelligence:ModelId` | Orchestrator. Empty endpoint selects the sample extractor. |
| `ConnectionStrings:Sql` | Order API. Docker uses SQL Edge; `appsettings.json` defaults to LocalDB. |
| `DurableTask:BaseUrl`, `DurableTask:SystemKey` | Order API. Base URL is the Orchestrator HTTP endpoint (`http://localhost:7072` locally). |
| `Entra:Authority`, `Entra:Audience` | Order API. Empty authority selects `DevAuthenticationHandler` in `Development`; any other environment fails at startup. |
| `Cors:Origins` | Order API |

Azure secrets go through **Key Vault references** and **Managed Identity**. Local functions use
`local.settings.json` (gitignored, copied from the example by `local/start-local.ps1`).

## 12. Error handling policies

- Activity `TaskOptions` with `RetryPolicy(maxAttempts: 5, firstRetryInterval: 2s, backoff: 2x)`.
- External deps wrapped with Polly (timeout + retry + circuit breaker) inside activities.
- Validation/business errors returned as `Result<T>` (no exceptions for control flow).
- Global exception → ProblemDetails (RFC 9457) in the API.
