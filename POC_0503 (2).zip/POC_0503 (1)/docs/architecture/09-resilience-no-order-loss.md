# 09 — Resilience & "Never Lose an Order"

This document is the **durability contract**: for every stage, what happens if that component (or
its dependency) crashes, restarts, or is unreachable — and why **no inbound order can be lost**.

## 1. The core guarantee

> Every email that Graph tells us about results in **exactly one order** that is either
> **finalized** or **parked in a dead-letter/triage state with an alert** — never silently dropped.

Two independent safety nets back this:

1. **Durable buffers** — Microsoft Graph and Azure Service Bus both **retry delivery** and **retain**
   work until we positively acknowledge it. Nothing is acked until it is safely persisted.
2. **A reconciliation ledger** — every notification is recorded in an **Intake Ledger** before we
   ack Graph, and a scheduled **delta-query reconciliation** compares the mailbox against the ledger
   to catch anything Graph never delivered (missed webhook, subscription gap).

```mermaid
flowchart LR
    G[Graph retries + retention] --> EI[Email Intake]
    EI -->|write ledger, then ack| L[(Intake Ledger)]
    EI --> SB[Service Bus retries + DLQ + dedup]
    SB --> OR[Durable Functions checkpointed state]
    OR --> DB[(SQL: order created early)]
    REC[Delta reconciliation timer] -.compares.-> L
    REC -.backfills missing.-> SB
```

## 2. Failure handling per stage

| Stage | If it goes down / fails | Why no order is lost |
|-------|-------------------------|----------------------|
| **Graph → Email Intake** | Email Intake instance crashes mid-notification | Graph **re-delivers** notifications that weren't `202`-acked (with backoff). We only ack **after** writing the Intake Ledger + publishing to Service Bus. |
| **Missed webhook entirely** | Webhook endpoint was down past Graph's retry window, or subscription lapsed | **Delta-query reconciliation** (timer) lists mailbox messages since the last watermark and backfills any `messageId` not in the ledger. |
| **De-dup** | Email Intake restarts (in-memory cache lost) | De-dup is **not** the safety mechanism — **Service Bus duplicate detection** keyed on `MessageId = GraphMessageId` (10-min window) is the durable guard; the in-memory cache is only a fast-path optimization. |
| **Email Intake → Service Bus** | Publish fails | The Graph notification is **not acked**, so Graph re-delivers → we retry publish. |
| **Service Bus → Orchestrator** | Orchestrator app down / scaled to zero | Messages **stay in the subscription** until a consumer is healthy; lock renews or message returns to the queue. No loss. |
| **Poison message** | Same message fails `maxDeliveryCount` (10) times | Routed to the **dead-letter queue** (not dropped) + alert. Replay uses the short procedure in §6. A standalone runbook is [design intent](14-design-intent.md). |
| **Orchestrator crash mid-workflow** | Host restarts / deploy | **Durable Functions checkpoints** every step to the task hub (Storage). On restart the instance **rehydrates and replays** to the last checkpoint and continues. Activities are **at-least-once** + idempotent. |
| **Order API down (CreateOrder)** | `CreateOrder` activity fails | Activity **retries** (5×, exp. backoff); Service Bus message stays locked/returns; orchestration resumes. `CreateOrder` is an **upsert by `CorrelationId`** so retries never duplicate. |
| **SQL transient outage** | EF Core command fails | `EnableRetryOnFailure` (SqlServer execution strategy) retries transient faults; outer activity retry covers the rest. |
| **Blob outage** | `StoreDocuments` fails | Activity retry; deterministic blob paths make re-upload idempotent. |
| **Document Intelligence down / throttled** | `AnalyzeDocument` fails | Activity retry + `Retry-After`; if extraction is poor/low-confidence it **still proceeds to a human** (validation is mandatory), so a DI outage degrades to "human fills more fields", never data loss. |
| **Human never responds** | Validator offline | **Durable SLA timer** fires → **escalate** to manager + re-arm; after max escalations the order is parked as `PendingValidation`/`Failed` with an alert, still present in SQL. |
| **Order API submit → RaiseEvent fails** | API saved corrections but couldn't reach the orchestrator | Submit is **transactional + outbox**: the resume event is also written to the **outbox** and retried by the dispatcher, so the orchestration is always resumed (idempotent raise). |
| **Outbox dispatcher down** | Events not published | Rows stay unprocessed and are picked up when it restarts (at-least-once). |

## 3. Idempotency (what makes retries safe)

- **Service Bus duplicate detection** by `MessageId = GraphMessageId`.
- **Deterministic orchestration `instanceId` = `CorrelationId`** → a duplicate start is a no-op.
- **`CreateOrder` upserts** by `CorrelationId`; **`CreateValidationTask`** no-ops if a task exists.
- **Deterministic blob paths** (`{customer}/{correlationId}/{file}`) → re-upload overwrites, no dupes.
- **`AnalyzeDocument`** cache by content hash.
- **Optimistic concurrency** (`RowVersion`) on `Orders`/`ValidationTasks` prevents double-submit.

## 4. The Intake Ledger (new)

A durable record for every notification, written **before** acking Graph:

```
IntakeLedger(
  GraphMessageId PK, Mailbox, CustomerId, Priority,
  ReceivedAtUtc, PublishedAtUtc, CorrelationId, Status /* Received|Published|Orchestrated|Failed */)
```

- Lets reconciliation answer "did we see and publish this message?" authoritatively.
- Powers an **ops dashboard**: messages received vs published vs orchestrated vs finalized.
- Watermark (`max ReceivedAtUtc`) drives the incremental delta query.

## 5. Delta-query reconciliation (new)

`SubscriptionRenewal` timer also runs reconciliation:

1. Renew/repair the Graph subscription (create if missing).
2. **Delta query** the Inbox since the last watermark.
3. For each message not in the Intake Ledger → publish `OrderReceived` (dedup makes this safe).
4. Advance the watermark.

This closes the only real gap in pure webhooks (a missed push) without reprocessing everything.

## 6. Health, detection & recovery

- **Health checks** (`/health`, `/health/ready`) on the API: SQL, Blob, Service Bus, Durable hub.
- **Liveness/readiness** gate traffic and autoscale.
- **Alerts**: DLQ count > 0, `ActiveMessageCount(sub-high)` backlog, SLA-breach rate, orchestration
  failure rate, ledger `Received`-but-not-`Orchestrated` older than N minutes.
- **Replay (in force today):** inspect the subscription DLQ, fix the cause, then resubmit the
  `OrderReceived` message with the same `MessageId`. Duplicate detection and idempotent activities
  make the replay safe. Confirm the intake ledger row advanced. A standalone replay document and
  any resubmit tool are [design intent](14-design-intent.md).
- **DR** is part of that same design intent (private networking and redundant SKUs). Bicep uses
  LRS storage and a single SQL database. Do not invent per-environment RPO/RTO until that work
  is built.

## 7. Delivery semantics summary

| Hop | Semantics |
|-----|-----------|
| Graph → Intake | at-least-once (ack-after-persist) |
| Intake → Service Bus | at-least-once + dedup → **effectively once** |
| Orchestrator activities | at-least-once + idempotent → **effectively once** |
| Submit → resume | at-least-once (outbox) + idempotent raise |

Net effect: **effectively-once** processing with **no silent loss** at any hop.
