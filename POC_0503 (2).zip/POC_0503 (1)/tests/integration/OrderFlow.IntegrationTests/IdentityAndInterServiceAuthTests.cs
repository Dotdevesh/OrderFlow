using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.IdentityApi;
using OrderFlow.IdentityApi.Data;
using OrderFlow.IdentitySync.Functions;
using OrderFlow.IdentitySync.Services;
using OrderFlow.Orchestrator.Services;
using OrderFlow.OrderApi;
using OrderFlow.OrderApi.Data;
using OrderFlow.OrderApi.Services;
using Xunit;

namespace OrderFlow.IntegrationTests;

/// <summary>
/// End-to-end integration tests verifying:
/// 1) Windows credential SSO login (<c>/api/auth/windows-sso</c>) + AD Security Group &amp; App Role verification
/// 2) Mandatory AD Group + Role gate (users missing either are rejected with 403 Forbidden)
/// 3) Live AD Group &amp; Azure App Registration Role sync via <c>EntraDirectoryWebhookFunction</c> -> <c>IdentityApi</c> -> <c>OrderApi</c>
/// 4) Microservice-to-microservice intercommunication via <c>ServiceToServiceBearerHandler</c> &amp; <c>IdentityApi</c>
/// </summary>
public sealed class IdentityAndInterServiceAuthTests : IAsyncLifetime
{
    private const string SharedS2SSecret = "test-s2s-shared-secret-value-2026!";
    private const string SigningKey = "orderflow-integration-test-signing-key-32bytes+";

    private IdentityTestFactory _identityFactory = null!;
    private OrderApiWithIdentityTestFactory _orderApiFactory = null!;

    public Task InitializeAsync()
    {
        var sharedDbRoot = new Microsoft.EntityFrameworkCore.Storage.InMemoryDatabaseRoot();
        var sharedDbName = $"OrderFlow_IdentityShared_{Guid.NewGuid():N}";

        _identityFactory = new IdentityTestFactory(sharedDbName, sharedDbRoot, SigningKey, SharedS2SSecret);
        _ = _identityFactory.CreateClient(); // ensure TestServer is started
        _orderApiFactory = new OrderApiWithIdentityTestFactory(
            sharedDbName,
            sharedDbRoot,
            SigningKey,
            SharedS2SSecret,
            () => _identityFactory.Server.CreateHandler());

        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {
        await _orderApiFactory.DisposeAsync();
        await _identityFactory.DisposeAsync();
    }

    [Fact]
    public async Task WindowsSsoLogin_UserInAdGroupAndRole_CanAuthenticateAndAccessOrderApi()
    {
        using var identityClient = _identityFactory.CreateClient();
        identityClient.DefaultRequestHeaders.Add("X-Debug-WindowsUser", "CONTOSO\\morgan");

        // 1) Authenticate using Windows credentials against IdentityApi
        var ssoRes = await identityClient.GetAsync("/api/auth/windows-sso");
        Assert.Equal(HttpStatusCode.OK, ssoRes.StatusCode);

        var exchange = await ssoRes.Content.ReadFromJsonAsync<WindowsSsoExchangeResponse>();
        Assert.NotNull(exchange);
        Assert.True(exchange.Authenticated);
        Assert.True(exchange.Authorized);
        Assert.False(string.IsNullOrWhiteSpace(exchange.AccessToken));
        Assert.Equal("mgr-1", exchange.Principal.UserId);
        Assert.Equal(UserRole.Manager, exchange.Principal.Role);
        Assert.Contains("grp-orderflow-managers", exchange.Principal.Groups);

        // 2) Call OrderApi using the Windows-SSO-minted Bearer token -> IdentityApi verifies AD group + role
        using var orderClient = _orderApiFactory.CreateClient();
        orderClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", exchange.AccessToken);

        var users = await orderClient.GetFromJsonAsync<List<UserSummaryDto>>("/api/users");
        Assert.NotNull(users);
        Assert.Equal(3, users.Count);

        var tasksRes = await orderClient.GetAsync("/api/tasks?scope=team");
        Assert.Equal(HttpStatusCode.OK, tasksRes.StatusCode);
    }

    [Fact]
    public async Task UserMissingAdGroup_OrMissingRole_IsDeniedWith403()
    {
        var s2sClient = CreateAuthenticatedSyncClient();

        // Provision two test users via Directory Sync:
        // - user-no-group: has App Role 'Reportee' in Azure App Reg, but NOT in any AD Security Group
        // - user-no-role : is in 'grp-orderflow-access' AD Group, but has NO App Role and NO role-mapped AD Group
        var syncBatch = new DirectorySyncBatchRequest(
            SyncSource: "TestSetup",
            IsFullAppRoleSnapshot: false,
            Groups:
            [
                new SyncedGroupConfigDto("grp-orderflow-access", "SG-OrderFlow-ActionCenter-Users", IsRequiredAccessGroup: true, MappedRole: null)
            ],
            Users:
            [
                new SyncedUserDto("user-no-group", "Alex NoGroup", "alex@contoso.com", "alex@contoso.com", "CONTOSO\\alex", null, true),
                new SyncedUserDto("user-no-role", "Taylor NoRole", "taylor@contoso.com", "taylor@contoso.com", "CONTOSO\\taylor", null, true)
            ],
            Memberships:
            [
                new SyncedGroupMembershipDto("grp-orderflow-access", ["mgr-1", "rep-1", "rep-2", "user-no-role"], IsFullSnapshot: true)
            ],
            AppRoleAssignments:
            [
                new SyncedAppRoleAssignmentDto("assign-alex-rep", "user-no-group", "approle-reportee", "Reportee")
            ]);

        await s2sClient.PushSyncBatchAsync(syncBatch);

        var tokenIssuer = new InternalTokenService(SigningKey);

        // Case A: User has App Role, but is NOT in AD Group -> Windows SSO returns 403 missing_ad_group
        using var winNoGroupClient = _identityFactory.CreateClient();
        winNoGroupClient.DefaultRequestHeaders.Add("X-Debug-WindowsUser", "CONTOSO\\alex");
        var noGroupSso = await winNoGroupClient.GetAsync("/api/auth/windows-sso");
        Assert.Equal(HttpStatusCode.Forbidden, noGroupSso.StatusCode);
        var noGroupPayload = await noGroupSso.Content.ReadFromJsonAsync<WindowsSsoExchangeResponse>();
        Assert.Equal("missing_ad_group", noGroupPayload?.Principal.DenialCode);

        // Even if a Bearer token carries 'Reportee' claim, OrderApi introspects IdentityApi and denies with 403!
        var (forgedRoleJwt, _) = tokenIssuer.CreateUserToken(
            new AuthenticatedPrincipalDto(true, true, null, null, "user-no-group", "alex@contoso.com", "alex@contoso.com", "Alex", UserRole.Reportee, null, [], ["Reportee"], "EntraJwt"),
            "api://orderflow-orderapi",
            TimeSpan.FromMinutes(15));

        using var orderNoGroupClient = _orderApiFactory.CreateClient();
        orderNoGroupClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", forgedRoleJwt);
        var orderDenied1 = await orderNoGroupClient.GetAsync("/api/tasks");
        Assert.Equal(HttpStatusCode.Forbidden, orderDenied1.StatusCode);

        // Case B: User is in AD Group, but has NO assigned Role -> Windows SSO returns 403 missing_role
        using var winNoRoleClient = _identityFactory.CreateClient();
        winNoRoleClient.DefaultRequestHeaders.Add("X-Debug-WindowsUser", "CONTOSO\\taylor");
        var noRoleSso = await winNoRoleClient.GetAsync("/api/auth/windows-sso");
        Assert.Equal(HttpStatusCode.Forbidden, noRoleSso.StatusCode);
        var noRolePayload = await noRoleSso.Content.ReadFromJsonAsync<WindowsSsoExchangeResponse>();
        Assert.Equal("missing_role", noRolePayload?.Principal.DenialCode);
    }

    [Fact]
    public async Task EntraDirectoryWebhookFunction_UpdatesDatabaseOnAdGroupAndRoleChange_AndImmediatelyEnforcesAccess()
    {
        // Step 1: Riley (rep-1) and Jordan (rep-2) log in via Windows credentials while initially Reportees
        using var rileySsoClient = _identityFactory.CreateClient();
        rileySsoClient.DefaultRequestHeaders.Add("X-Debug-WindowsUser", "CONTOSO\\riley");
        var rileyExchange = await (await rileySsoClient.GetAsync("/api/auth/windows-sso"))
            .Content.ReadFromJsonAsync<WindowsSsoExchangeResponse>();
        Assert.True(rileyExchange!.Authorized);

        using var jordanSsoClient = _identityFactory.CreateClient();
        jordanSsoClient.DefaultRequestHeaders.Add("X-Debug-WindowsUser", "CONTOSO\\jordan");
        var jordanExchange = await (await jordanSsoClient.GetAsync("/api/auth/windows-sso"))
            .Content.ReadFromJsonAsync<WindowsSsoExchangeResponse>();
        Assert.True(jordanExchange!.Authorized);
        Assert.Equal(UserRole.Reportee, jordanExchange.Principal.Role);

        // Step 2: Simulate AD Group & Azure App Registration Role change in Microsoft Graph:
        //   - Riley (rep-1) is REMOVED from all AD Security Groups
        //   - Jordan (rep-2) is PROMOTED to Manager in Azure App Registration + Managers AD Group
        var updatedDirectoryState = new DirectorySyncBatchRequest(
            SyncSource: "GraphDirectoryWebhook",
            IsFullAppRoleSnapshot: true,
            Groups:
            [
                new SyncedGroupConfigDto("grp-orderflow-access", "SG-OrderFlow-ActionCenter-Users", IsRequiredAccessGroup: true, MappedRole: null),
                new SyncedGroupConfigDto("grp-orderflow-managers", "SG-OrderFlow-Managers", IsRequiredAccessGroup: true, MappedRole: UserRole.Manager),
                new SyncedGroupConfigDto("grp-orderflow-reportees", "SG-OrderFlow-Reportees", IsRequiredAccessGroup: true, MappedRole: UserRole.Reportee)
            ],
            Users:
            [
                new SyncedUserDto("mgr-1", "Morgan (Manager)", "morgan@contoso.com", "morgan@contoso.com", "CONTOSO\\morgan", null, true),
                new SyncedUserDto("rep-1", "Riley (Removed)", "riley@contoso.com", "riley@contoso.com", "CONTOSO\\riley", "mgr-1", true),
                new SyncedUserDto("rep-2", "Jordan (Promoted Manager)", "jordan@contoso.com", "jordan@contoso.com", "CONTOSO\\jordan", null, true)
            ],
            Memberships:
            [
                new SyncedGroupMembershipDto("grp-orderflow-access", ["mgr-1", "rep-2"], IsFullSnapshot: true),
                new SyncedGroupMembershipDto("grp-orderflow-managers", ["mgr-1", "rep-2"], IsFullSnapshot: true),
                new SyncedGroupMembershipDto("grp-orderflow-reportees", [], IsFullSnapshot: true)
            ],
            AppRoleAssignments:
            [
                new SyncedAppRoleAssignmentDto("seed-role-mgr-1", "mgr-1", "approle-manager", "Manager"),
                new SyncedAppRoleAssignmentDto("promoted-jordan-mgr", "rep-2", "approle-manager", "Manager")
            ]);

        var syncClient = CreateAuthenticatedSyncClient();
        var fakeGraphProvider = new StubEntraDirectoryProvider(updatedDirectoryState);
        var cfg = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["Graph:ClientState"] = "webhook-secret-123" })
            .Build();

        var webhookFn = new EntraDirectoryWebhookFunction(
            fakeGraphProvider,
            syncClient,
            cfg,
            NullLogger<EntraDirectoryWebhookFunction>.Instance);

        // Verify Graph webhook handshake (?validationToken=...)
        var handshakeCtx = new DefaultHttpContext();
        handshakeCtx.Request.QueryString = new QueryString("?validationToken=graph-handshake-ok");
        var handshakeResult = Assert.IsType<ContentResult>(await webhookFn.Run(handshakeCtx.Request, CancellationToken.None));
        Assert.Equal("graph-handshake-ok", handshakeResult.Content);

        // Fire Graph group change notification
        var notificationJson = JsonSerializer.Serialize(new
        {
            value = new[]
            {
                new
                {
                    subscriptionId = "sub-1",
                    clientState = "webhook-secret-123",
                    changeType = "updated",
                    resource = "groups/grp-orderflow-managers"
                }
            }
        });
        var notifyCtx = new DefaultHttpContext();
        notifyCtx.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(notificationJson));
        var notifyResult = await webhookFn.Run(notifyCtx.Request, CancellationToken.None);
        Assert.IsType<AcceptedResult>(notifyResult);

        // Step 3: Even with Riley's previously issued token, OrderApi introspects IdentityApi -> 403 Forbidden!
        using var rileyOrderClient = _orderApiFactory.CreateClient();
        rileyOrderClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", rileyExchange.AccessToken);
        var rileyAfterRemoval = await rileyOrderClient.GetAsync("/api/tasks");
        Assert.Equal(HttpStatusCode.Forbidden, rileyAfterRemoval.StatusCode);

        // Step 4: Jordan's existing token is dynamically enriched from DB with Manager role -> can view /api/users & team scope!
        using var jordanOrderClient = _orderApiFactory.CreateClient();
        jordanOrderClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", jordanExchange.AccessToken);
        var activeUsers = await jordanOrderClient.GetFromJsonAsync<List<UserSummaryDto>>("/api/users");
        Assert.NotNull(activeUsers);
        Assert.DoesNotContain(activeUsers, u => u.Id == "rep-1"); // Riley removed from active directory
        var jordanEntry = Assert.Single(activeUsers, u => u.Id == "rep-2");
        Assert.Equal(UserRole.Manager, jordanEntry.Role);
    }

    [Fact]
    public async Task InterServiceCommunication_RequiresValidServiceToken_AndSucceedsViaIdentityMicroservice()
    {
        // 1) Unauthenticated call to OrderApi /internal/orders is rejected when S2S auth is enforced
        using var unauthenticatedClient = _orderApiFactory.CreateClient();
        var rejected = await unauthenticatedClient.PostAsJsonAsync("/internal/orders", new CreateOrderRequest(
            Guid.NewGuid(), "acme", Priority.High, "inst-unauth", "buyer@acme.com", "PO-1", DateTimeOffset.UtcNow, []));
        Assert.True(rejected.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden);

        // 2) Orchestrator's OrderApiClient configured with ServiceToServiceBearerHandler exchanges credentials
        //    with IdentityApi (/api/auth/service-token) and calls OrderApi (/internal/orders) seamlessly
        var s2sOptions = Options.Create(new IdentityClientOptions
        {
            BaseUrl = "http://identity.local",
            ServiceName = "Orchestrator",
            TargetAudience = "api://orderflow-internal",
            ServiceSharedSecret = SharedS2SSecret
        });

        using var identityHttp = _identityFactory.CreateClient();
        identityHttp.BaseAddress = new Uri("http://identity.local");

        using var s2sHandler = new ServiceToServiceBearerHandler(
            s2sOptions,
            NullLogger<ServiceToServiceBearerHandler>.Instance,
            identityHttp)
        {
            InnerHandler = _orderApiFactory.Server.CreateHandler()
        };

        using var orchestratorHttp = new HttpClient(s2sHandler)
        {
            BaseAddress = _orderApiFactory.Server.BaseAddress
        };

        var orderApiClient = new OrderApiClient(orchestratorHttp);
        var corrId = Guid.NewGuid();
        var created = await orderApiClient.CreateOrderAsync(new CreateOrderRequest(
            corrId, "acme", Priority.High, corrId.ToString("N"),
            "buyer@acme.com", "PO-S2S-Verified", DateTimeOffset.UtcNow, []));

        Assert.NotEqual(Guid.Empty, created.OrderId);
    }

    private IDirectorySyncApiClient CreateAuthenticatedSyncClient()
    {
        var opts = Options.Create(new IdentityClientOptions
        {
            BaseUrl = "http://identity.local",
            ServiceName = "IdentitySync",
            TargetAudience = "api://orderflow-internal",
            ServiceSharedSecret = SharedS2SSecret
        });

        var tokenClient = _identityFactory.CreateClient();
        tokenClient.BaseAddress = new Uri("http://identity.local");

        var bearerHandler = new ServiceToServiceBearerHandler(
            opts,
            NullLogger<ServiceToServiceBearerHandler>.Instance,
            tokenClient)
        {
            InnerHandler = _identityFactory.Server.CreateHandler()
        };

        var syncHttp = new HttpClient(bearerHandler)
        {
            BaseAddress = _identityFactory.Server.BaseAddress
        };

        return new HttpDirectorySyncApiClient(syncHttp);
    }

    private sealed class StubEntraDirectoryProvider(DirectorySyncBatchRequest snapshot) : IEntraDirectoryProvider
    {
        public Task<DirectorySyncBatchRequest> ReadDirectoryStateAsync(
            string syncSource,
            IReadOnlyCollection<string>? filterGroupIds = null,
            CancellationToken ct = default) =>
            Task.FromResult(snapshot with { SyncSource = syncSource });

        public Task EnsureGroupWebhookSubscriptionsAsync(
            IReadOnlyList<DirectoryGroupStateDto> currentGroups,
            IDirectorySyncApiClient apiClient,
            CancellationToken ct = default) =>
            Task.CompletedTask;
    }
}

public sealed class IdentityTestFactory(
    string dbName,
    Microsoft.EntityFrameworkCore.Storage.InMemoryDatabaseRoot dbRoot,
    string signingKey,
    string sharedSecret) : WebApplicationFactory<IdentityApiMarker>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.UseSetting("IdentityService:EnableWindowsNegotiate", "false");
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["IdentityService:EnableWindowsNegotiate"] = "false",
                ["IdentityService:JwtSigningKey"] = signingKey,
                ["IdentityService:ServiceSharedSecret"] = sharedSecret,
                ["IdentityService:Issuer"] = "https://identity.orderflow.internal",
                ["IdentityService:UserTokenAudience"] = "api://orderflow-orderapi"
            });
        });

        builder.ConfigureServices(services =>
        {
            services.RemoveAll<IDbContextOptionsConfiguration<IdentityDbContext>>();
            services.RemoveAll<DbContextOptions<IdentityDbContext>>();
            services.RemoveAll<IdentityDbContext>();
            services.AddDbContext<IdentityDbContext>(o => o.UseInMemoryDatabase(dbName, dbRoot));
        });
    }
}

public sealed class OrderApiWithIdentityTestFactory(
    string dbName,
    Microsoft.EntityFrameworkCore.Storage.InMemoryDatabaseRoot dbRoot,
    string signingKey,
    string sharedSecret,
    Func<HttpMessageHandler> createIdentityHandler) : WebApplicationFactory<OrderApiMarker>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Identity:BaseUrl"] = "http://localhost",
                ["Identity:ServiceName"] = "OrderApi",
                ["Identity:ServiceSharedSecret"] = sharedSecret,
                ["Identity:InternalJwtSigningKey"] = signingKey,
                ["Identity:InternalJwtIssuer"] = "https://identity.orderflow.internal",
                ["Identity:IntrospectionCacheSeconds"] = "0" // disable cache in test for instant revocation assertions
            });
        });

        builder.ConfigureServices(services =>
        {
            services.RemoveAll<IDbContextOptionsConfiguration<OrderFlowDbContext>>();
            services.RemoveAll<DbContextOptions<OrderFlowDbContext>>();
            services.RemoveAll<OrderFlowDbContext>();
            services.AddDbContext<OrderFlowDbContext>(o => o.UseInMemoryDatabase(dbName, dbRoot));

            services.RemoveAll<IWorkflowClient>();
            services.AddSingleton<IWorkflowClient>(new FakeWorkflowClient());

            services.RemoveAll<IBlobDocumentStore>();
            services.AddSingleton<IBlobDocumentStore, InMemoryBlobStore>();

            // Route OrderApi -> IdentityApi introspection calls in-memory through IdentityTestFactory.Server
            services.RemoveAll<IIdentityServiceClient>();
            services.AddSingleton<IIdentityServiceClient>(sp =>
            {
                var opts = sp.GetRequiredService<IOptions<IdentityClientOptions>>();
                var tokenClient = new HttpClient(createIdentityHandler())
                {
                    BaseAddress = new Uri("http://localhost")
                };

                var s2sHandler = new ServiceToServiceBearerHandler(
                    opts,
                    NullLogger<ServiceToServiceBearerHandler>.Instance,
                    tokenClient)
                {
                    InnerHandler = createIdentityHandler()
                };

                var http = new HttpClient(s2sHandler)
                {
                    BaseAddress = new Uri("http://localhost")
                };

                return new HttpIdentityServiceClient(
                    http,
                    opts,
                    NullLogger<HttpIdentityServiceClient>.Instance);
            });
        });
    }
}
