using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.OrderApi;
using OrderFlow.OrderApi.Data;
using OrderFlow.OrderApi.Services;
using Xunit;

namespace OrderFlow.IntegrationTests;

public sealed class OrderApiIntegrationTests : IClassFixture<OrderApiFactory>
{
    private readonly OrderApiFactory _factory;
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public OrderApiIntegrationTests(OrderApiFactory factory) => _factory = factory;

    [Theory]
    [InlineData("acme-title", "AcmeTitleOrder")]
    [InlineData("first-national", "FirstNationalTitleOrder")]
    [InlineData("acme", "AcmeOrder")]
    [InlineData("globex", "GlobexOrder")]
    [InlineData("initech", "InitechOrder")]
    public async Task FormTemplate_ResolvesAllCustomersFromClassRegistry(string customerId, string expectedName)
    {
        using var client = _factory.CreateClient();
        var tpl = await client.GetFromJsonAsync<FormTemplateDto>($"/api/customers/{customerId}/form-template");

        Assert.NotNull(tpl);
        Assert.Equal(customerId, tpl.CustomerId);
        Assert.Equal(expectedName, tpl.Name);
        Assert.NotEmpty(tpl.Sections);
    }

    [Fact]
    public async Task FormTemplate_Returns404ForUnknownCustomer()
    {
        using var client = _factory.CreateClient();
        var res = await client.GetAsync("/api/customers/unknown-customer/form-template");
        Assert.Equal(HttpStatusCode.NotFound, res.StatusCode);
    }

    [Fact]
    public async Task EndToEnd_IntakeToSubmit_WithRbacValidationAndOutboxRetry()
    {
        _factory.Workflow.ShouldFail = false;
        _factory.Workflow.RaisedEvents.Clear();

        using var managerClient = _factory.CreateClient();
        var corrId = Guid.NewGuid();
        var msgId = $"msg-{corrId:N}";

        // 1) Intake ledger + order creation + validation task creation
        var intakeRes = await managerClient.PostAsJsonAsync("/internal/intake",
            new RecordIntakeRequest(msgId, "orders@contoso.com", "acme-title", Priority.High, corrId));
        intakeRes.EnsureSuccessStatusCode();

        var createOrderRes = await managerClient.PostAsJsonAsync("/internal/orders", new CreateOrderRequest(
            corrId, "acme-title", Priority.High, corrId.ToString("N"),
            "escrow@acmetitle.com", "Title Order TI-10045", DateTimeOffset.UtcNow,
            [new StoredDocumentDto(DocumentKind.Attachment, "ti.pdf", $"acme-title/{corrId}/ti.pdf", "application/pdf", 1024)],
            msgId));
        createOrderRes.EnsureSuccessStatusCode();
        var created = await createOrderRes.Content.ReadFromJsonAsync<CreateOrderResponse>();
        Assert.NotNull(created);

        var taskRes = await managerClient.PostAsJsonAsync($"/internal/orders/{created.OrderId}/validation-task",
            new CreateValidationTaskRequest(
                created.OrderId,
                corrId.ToString("N"),
                [
                    new ExtractedFieldDto("FileNumber", "TI-10045", 0.95, null),
                    new ExtractedFieldDto("OrderDate", "2026-11-12", 0.92, null),
                    new ExtractedFieldDto("APN", "104-22-019", 0.91, null),
                    new ExtractedFieldDto("LenderName", "First Horizon Bank", 0.72, null),
                    new ExtractedFieldDto("LoanAmount", "350000", 0.89, null)
                ],
                [],
                MinConfidence: 0.72,
                ModelId: "prebuilt-document"));
        taskRes.EnsureSuccessStatusCode();

        // 2) Inbox scoped by customer shows real confidence (0.72)
        var inbox = await managerClient.GetFromJsonAsync<List<TaskSummaryDto>>("/api/tasks?scope=pool&customerId=acme-title");
        var summary = Assert.Single(inbox!, t => t.OrderId == created.OrderId);
        Assert.Equal(0.72, summary.MinConfidence, 2);

        // 3) Task detail returns BoundEntity hydrated from AcmeTitleOrder
        var detail = await managerClient.GetFromJsonAsync<TaskDetailDto>($"/api/tasks/{summary.TaskId}");
        Assert.NotNull(detail?.BoundEntity);
        var boundJson = JsonSerializer.Serialize(detail!.BoundEntity, Json);
        Assert.Contains("TI-10045", boundJson);
        Assert.Contains("104-22-019", boundJson);

        // 4) RBAC: Reportee cannot assign or delegate, CAN claim
        using var reporteeClient = _factory.CreateClient();
        reporteeClient.DefaultRequestHeaders.Add("X-Debug-UserId", "rep-1");
        reporteeClient.DefaultRequestHeaders.Add("X-Debug-Role", "Reportee");

        var assignDenied = await reporteeClient.PostAsJsonAsync($"/api/tasks/{summary.TaskId}/assign", new AssignRequest("rep-2"));
        Assert.Equal(HttpStatusCode.Forbidden, assignDenied.StatusCode);

        var claimOk = await reporteeClient.PostAsync($"/api/tasks/{summary.TaskId}/claim", null);
        Assert.Equal(HttpStatusCode.OK, claimOk.StatusCode);

        // 5) Server-side class validation rejects invalid FileNumber regex on approve
        var badSubmit = await reporteeClient.PostAsJsonAsync($"/api/tasks/{summary.TaskId}/submit", new SubmitValidationRequest(
            Approved: true,
            Fields:
            [
                new ValidatedField("FileNumber", "INVALID"),
                new ValidatedField("OrderDate", "2026-11-12"),
                new ValidatedField("APN", "104-22-019"),
                new ValidatedField("LenderName", "First Horizon Bank"),
                new ValidatedField("LoanAmount", "350000")
            ],
            Lines: [],
            Note: null));
        Assert.Equal(HttpStatusCode.BadRequest, badSubmit.StatusCode);

        // 6) Simulate Orchestrator down on Submit -> 202 Accepted + queued in Outbox -> OutboxDispatcher retries & succeeds
        _factory.Workflow.ShouldFail = true;
        var submitAccepted = await reporteeClient.PostAsJsonAsync($"/api/tasks/{summary.TaskId}/submit", new SubmitValidationRequest(
            Approved: true,
            Fields:
            [
                new ValidatedField("FileNumber", "TI-10045"),
                new ValidatedField("OrderDate", "2026-11-12"),
                new ValidatedField("APN", "104-22-019"),
                new ValidatedField("LenderName", "First Horizon Bank"),
                new ValidatedField("LoanAmount", "350000")
            ],
            Lines: [],
            Note: "Verified"));
        Assert.Equal(HttpStatusCode.Accepted, submitAccepted.StatusCode);
        Assert.Empty(_factory.Workflow.RaisedEvents);

        // Orchestrator recovers -> OutboxDispatcher replays ValidationCompleted
        _factory.Workflow.ShouldFail = false;
        using var scope = _factory.Services.CreateScope();
        var dispatcher = _factory.Services.GetServices<IHostedService>().OfType<OutboxDispatcher>().Single();
        var dispatched = await dispatcher.DispatchBatchAsync(CancellationToken.None);

        Assert.Equal(1, dispatched);
        var raised = Assert.Single(_factory.Workflow.RaisedEvents);
        Assert.Equal(corrId.ToString("N"), raised.InstanceId);
        Assert.True(raised.Payload.Approved);
    }
}

public sealed class OrderApiFactory : WebApplicationFactory<OrderApiMarker>
{
    public FakeWorkflowClient Workflow { get; } = new();
    private readonly string _dbName = $"OrderFlowTest_{Guid.NewGuid():N}";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<IDbContextOptionsConfiguration<OrderFlowDbContext>>();
            services.RemoveAll<DbContextOptions<OrderFlowDbContext>>();
            services.RemoveAll<OrderFlowDbContext>();
            services.AddDbContext<OrderFlowDbContext>(o => o.UseInMemoryDatabase(_dbName));

            services.RemoveAll<IWorkflowClient>();
            services.AddSingleton<IWorkflowClient>(Workflow);

            services.RemoveAll<IBlobDocumentStore>();
            services.AddSingleton<IBlobDocumentStore, InMemoryBlobStore>();
        });
    }
}

public sealed class FakeWorkflowClient : IWorkflowClient
{
    public bool ShouldFail { get; set; }
    public List<(string InstanceId, ValidationCompletedPayload Payload)> RaisedEvents { get; } = [];

    public Task RaiseValidationCompletedAsync(string instanceId, ValidationCompletedPayload payload, CancellationToken ct = default)
    {
        if (ShouldFail) throw new HttpRequestException("Simulated Orchestrator outage");
        RaisedEvents.Add((instanceId, payload));
        return Task.CompletedTask;
    }
}

public sealed class InMemoryBlobStore : IBlobDocumentStore
{
    public Task<string> UploadAsync(string blobPath, Stream content, string contentType, CancellationToken ct = default)
        => Task.FromResult(blobPath);

    public Task<Stream> OpenReadAsync(string blobPath, CancellationToken ct = default)
        => Task.FromResult<Stream>(new MemoryStream());

    public Task<Uri> GetReadSasAsync(string blobPath, TimeSpan validFor, CancellationToken ct = default)
        => Task.FromResult(new Uri($"http://localhost:10000/devstoreaccount1/order-documents/{blobPath}?sig=test"));
}
