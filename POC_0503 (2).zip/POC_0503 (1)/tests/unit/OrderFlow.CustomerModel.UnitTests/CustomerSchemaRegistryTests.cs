using Microsoft.Extensions.DependencyInjection;
using OrderFlow.CustomerModel.Customers;

namespace OrderFlow.CustomerModel.UnitTests;

public sealed class CustomerSchemaRegistryTests
{
    private static ICustomerSchemaRegistry CreateRegistry()
    {
        var services = new ServiceCollection();
        services.AddCustomerSchemas();
        return services.BuildServiceProvider().GetRequiredService<ICustomerSchemaRegistry>();
    }

    [Theory]
    [InlineData("acme-title", typeof(AcmeTitleOrder), "prebuilt-document", 3, false)]
    [InlineData("first-national", typeof(FirstNationalTitleOrder), "prebuilt-document", 5, false)]
    [InlineData("acme", typeof(AcmeOrder), "prebuilt-invoice", 5, true)]
    [InlineData("globex", typeof(GlobexOrder), "prebuilt-invoice", 7, true)]
    [InlineData("initech", typeof(InitechOrder), "prebuilt-invoice", 4, true)]
    public void Describe_BuildsExpectedSectionsAndExtractionPlan(
        string customerId, Type expectedType, string expectedModel, int expectedSectionCount, bool expectsLines)
    {
        var reg = CreateRegistry();

        var schema = reg.Describe(customerId);
        Assert.NotNull(schema);
        Assert.Equal(expectedType, schema.EntityType);
        Assert.Equal(expectedModel, schema.Plan.ModelId);
        Assert.Equal(expectedSectionCount, schema.Template.Sections.Count);
        Assert.Equal(expectsLines, schema.Template.Sections.Any(s => s.Type == "table"));
        Assert.NotEmpty(schema.Plan.Fields);
    }

    [Fact]
    public void Bind_PopulatesMappedPropertiesOnCustomerEntity()
    {
        var reg = CreateRegistry();
        var values = new Dictionary<string, string?>
        {
            ["FileNumber"] = "TI-99001",
            ["APN"] = "104-22-019",
            ["PropertyAddress"] = "742 Evergreen Terrace",
            ["LoanAmount"] = "450000"
        };

        var entity = Assert.IsType<AcmeTitleOrder>(reg.Bind("acme-title", values));
        Assert.Equal("acme-title", entity.CustomerId);
        Assert.Equal("TI-99001", entity.FileNumber);
        Assert.Equal("104-22-019", entity.Apn);
        Assert.Equal("742 Evergreen Terrace", entity.PropertyAddress);
        Assert.Equal("450000", entity.LoanAmount);
    }

    [Fact]
    public void Validate_EnforcesRequiredAndRegexAndSkipsReadOnlyDisabled()
    {
        var reg = CreateRegistry();

        // Missing required fields + invalid FileNumber regex; OrderType (ReadOnly) & TitleOfficer (Disabled) omitted
        var errors = reg.Validate("acme-title", new Dictionary<string, string?>
        {
            ["FileNumber"] = "BAD-123",
            ["OrderDate"] = "2026-11-12",
            ["APN"] = "",
            ["LenderName"] = "First Bank",
            ["LoanAmount"] = "300000"
        });

        Assert.Contains(errors, e => e.Contains("File Number"));
        Assert.Contains(errors, e => e.Contains("APN"));
        Assert.DoesNotContain(errors, e => e.Contains("Order Type"));
        Assert.DoesNotContain(errors, e => e.Contains("Title Officer"));
    }

    [Fact]
    public void Validate_PassesWhenValid()
    {
        var reg = CreateRegistry();

        var errors = reg.Validate("acme-title", new Dictionary<string, string?>
        {
            ["FileNumber"] = "TI-10045",
            ["OrderDate"] = "2026-11-12",
            ["APN"] = "104-22-019",
            ["LenderName"] = "First Bank",
            ["LoanAmount"] = "300000"
        });

        Assert.Empty(errors);
    }
}
