using System.Text;
using OrderFlow.Orchestrator.Services;

namespace OrderFlow.Orchestrator.UnitTests;

public sealed class DocumentConverterTests
{
    [Fact]
    public async Task ConvertAsync_ProducesValidPdfHeaderAndTrailer()
    {
        var converter = new PassthroughDocumentConverter();
        var email = new FetchedEmail(
            Guid.NewGuid(),
            "orders@contoso.com",
            "msg-1",
            "Title Order TI-10045",
            "escrow@acmetitle.com",
            "<p>Hello world</p>",
            [new EmailAttachment("order.txt", "text/plain", Encoding.UTF8.GetBytes("body"))]);

        var pdfs = await converter.ConvertAsync(email);

        Assert.Equal(2, pdfs.Count);
        foreach (var doc in pdfs)
        {
            var text = Encoding.ASCII.GetString(doc.Content);
            Assert.StartsWith("%PDF-1.4", text);
            Assert.Contains("xref", text);
            Assert.Contains("%%EOF", text);
        }
    }
}
