using System.Diagnostics.Metrics;
using Microsoft.Extensions.Logging.Abstractions;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.Contracts;
using OrderFlow.Observability;
using OrderFlow.Orchestrator.Services;

namespace OrderFlow.Orchestrator.UnitTests;

/// <summary>
/// The SLA and finalize activities are where OrderFlow decides a human needs to be told something.
/// These cover what they raise, not how the email looks.
/// </summary>
public sealed class ActivityNotificationTests
{
    private static readonly Guid OrderId = Guid.Parse("8f14e45f-ceea-467a-9575-8f1e4d0a4f21");
    private static readonly Guid CorrelationId = Guid.Parse("11111111-2222-3333-4444-555555555555");

    private static (Activities Activities, RecordingNotificationPublisher Notifications, RecordingOrderApiClient OrderApi) Create()
    {
        var notifications = new RecordingNotificationPublisher();
        var orderApi = new RecordingOrderApiClient();

        var activities = new Activities(
            new UnusedEmailReader(),
            new PassthroughDocumentConverter(),
            new UnusedBlobStore(),
            new UnusedExtractor(),
            orderApi,
            notifications,
            new OrderFlowMetrics(new DummyMeterFactory()),
            NullLogger<Activities>.Instance);

        return (activities, notifications, orderApi);
    }

    [Fact]
    public async Task EscalateCallsTheOrderApiAndRaisesAnSlaBreachNotification()
    {
        var (activities, notifications, orderApi) = Create();
        var newDue = DateTimeOffset.UtcNow.AddMinutes(10);

        await activities.Escalate(
            new EscalateInput(OrderId, "instance-1", Attempt: 2, newDue, "acme-title", CorrelationId),
            CancellationToken.None);

        Assert.Single(orderApi.Escalations);

        var raised = Assert.Single(notifications.Raised);
        Assert.Equal(NotificationKind.SlaBreached, raised.Kind);
        Assert.Equal(NotificationSeverity.Warning, raised.Severity);
        Assert.Equal(OrderId, raised.OrderId);
        Assert.Equal("acme-title", raised.CustomerId);
        Assert.Equal(CorrelationId, raised.CorrelationId);
        Assert.Contains(raised.Facts, f => f is { Label: "Escalation attempt", Value: "2" });
    }

    [Fact]
    public async Task RetryingEscalateReusesTheNotificationIdSoOnlyOneEmailGoesOut()
    {
        var (activities, notifications, _) = Create();
        var input = new EscalateInput(OrderId, "instance-1", Attempt: 1, DateTimeOffset.UtcNow, "acme-title", CorrelationId);

        await activities.Escalate(input, CancellationToken.None);
        await activities.Escalate(input, CancellationToken.None);

        Assert.Equal(2, notifications.Raised.Count);
        Assert.Equal(notifications.Raised[0].NotificationId, notifications.Raised[1].NotificationId);
    }

    [Fact]
    public async Task EachEscalationAttemptGetsItsOwnNotificationId()
    {
        var (activities, notifications, _) = Create();

        await activities.Escalate(new EscalateInput(OrderId, "i", 1, DateTimeOffset.UtcNow, "acme-title", CorrelationId), CancellationToken.None);
        await activities.Escalate(new EscalateInput(OrderId, "i", 2, DateTimeOffset.UtcNow, "acme-title", CorrelationId), CancellationToken.None);

        Assert.NotEqual(notifications.Raised[0].NotificationId, notifications.Raised[1].NotificationId);
    }

    [Fact]
    public async Task FinalizingAfterAHumanSubmitsRaisesAnInformationalNotification()
    {
        var (activities, notifications, orderApi) = Create();
        var payload = new ValidationCompletedPayload(OrderId, "rep-1", Approved: true, [], [], "Verified");

        await activities.FinalizeOrder(
            new FinalizeActivityInput(payload, "acme-title", CorrelationId, Abandoned: false),
            CancellationToken.None);

        Assert.Single(orderApi.Finalizations);

        var raised = Assert.Single(notifications.Raised);
        Assert.Equal(NotificationKind.OrderFinalized, raised.Kind);
        Assert.Equal(NotificationSeverity.Information, raised.Severity);
        Assert.Contains(raised.Facts, f => f is { Label: "Validated by", Value: "rep-1" });
    }

    [Fact]
    public async Task AnOrderAbandonedAfterTheLastEscalationRaisesACriticalFailureNotification()
    {
        var (activities, notifications, _) = Create();
        var payload = new ValidationCompletedPayload(OrderId, "system", Approved: false, [], [], "Abandoned after max escalations");

        await activities.FinalizeOrder(
            new FinalizeActivityInput(payload, "acme-title", CorrelationId, Abandoned: true),
            CancellationToken.None);

        var raised = Assert.Single(notifications.Raised);
        Assert.Equal(NotificationKind.OrderFailed, raised.Kind);
        Assert.Equal(NotificationSeverity.Critical, raised.Severity);
    }

    private sealed class RecordingNotificationPublisher : INotificationPublisher
    {
        public List<NotificationRequested> Raised { get; } = [];

        public Task NotifyAsync(NotificationRequested notification, CancellationToken ct = default)
        {
            Raised.Add(notification);
            return Task.CompletedTask;
        }
    }

    private sealed class RecordingOrderApiClient : IOrderApiClient
    {
        public List<EscalateOrderRequest> Escalations { get; } = [];
        public List<FinalizeOrderRequest> Finalizations { get; } = [];

        public Task<CreateOrderResponse> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default)
            => throw new NotSupportedException();

        public Task CreateValidationTaskAsync(Guid orderId, CreateValidationTaskRequest request, CancellationToken ct = default)
            => Task.CompletedTask;

        public Task EscalateAsync(Guid orderId, EscalateOrderRequest request, CancellationToken ct = default)
        {
            Escalations.Add(request);
            return Task.CompletedTask;
        }

        public Task FinalizeAsync(Guid orderId, FinalizeOrderRequest request, CancellationToken ct = default)
        {
            Finalizations.Add(request);
            return Task.CompletedTask;
        }
    }

    private sealed class UnusedEmailReader : IEmailReader
    {
        public Task<FetchedEmail> FetchAsync(Guid correlationId, string mailbox, string messageId, string? customerId = null, CancellationToken ct = default)
            => throw new NotSupportedException();
    }

    private sealed class UnusedBlobStore : IBlobDocumentStore
    {
        public Task<string> UploadAsync(string blobPath, Stream content, string contentType, CancellationToken ct = default)
            => throw new NotSupportedException();

        public Task<Stream> OpenReadAsync(string blobPath, CancellationToken ct = default)
            => throw new NotSupportedException();

        public Task<Uri> GetReadSasAsync(string blobPath, TimeSpan validFor, CancellationToken ct = default)
            => throw new NotSupportedException();
    }

    private sealed class UnusedExtractor : IEntityExtractor
    {
        public Task<DocumentEntities> AnalyzeAsync(AnalyzeInput input, Stream pdf, CancellationToken ct = default)
            => throw new NotSupportedException();
    }

    private sealed class DummyMeterFactory : IMeterFactory
    {
        public Meter Create(MeterOptions options) => new(options);
        public void Dispose() { }
    }
}
