using Microsoft.Extensions.Logging.Abstractions;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.Orchestrator.Services;

namespace OrderFlow.Orchestrator.UnitTests;

public sealed class NotificationPublisherTests
{
    private static NotificationRequested Event(Guid? notificationId = null) => new(
        NotificationId: notificationId ?? Guid.NewGuid(),
        Kind: NotificationKind.SlaBreached,
        Severity: NotificationSeverity.Warning,
        Subject: "SLA breached",
        Summary: "Nobody validated this order in time.",
        Recipients: [],
        Facts: [],
        CorrelationId: Guid.NewGuid(),
        CustomerId: "acme-title",
        OrderId: Guid.NewGuid());

    [Fact]
    public async Task TheNotificationIdBecomesTheMessageIdSoDuplicateDetectionSuppressesARepeatEmail()
    {
        var publisher = new RecordingEventPublisher();
        var notificationId = Guid.Parse("8f14e45f-ceea-467a-9575-8f1e4d0a4f21");

        await new NotificationPublisher(NullLogger<NotificationPublisher>.Instance, publisher)
            .NotifyAsync(Event(notificationId));

        var published = Assert.Single(publisher.Published);
        Assert.Equal(notificationId.ToString("N"), published.MessageId);
    }

    [Fact]
    public async Task TheCustomerIdIsCarriedAsTheRoutingPropertyAndSessionId()
    {
        var publisher = new RecordingEventPublisher();

        await new NotificationPublisher(NullLogger<NotificationPublisher>.Instance, publisher).NotifyAsync(Event());

        var published = Assert.Single(publisher.Published);
        Assert.Equal("acme-title", published.CustomerId);
        Assert.Equal("acme-title", published.SessionId);
    }

    [Fact]
    public async Task WithoutServiceBusTheNotificationIsLoggedRatherThanCrashingTheActivity()
    {
        var publisher = new NotificationPublisher(NullLogger<NotificationPublisher>.Instance, events: null);

        await publisher.NotifyAsync(Event());
    }

    private sealed class RecordingEventPublisher : IEventPublisher
    {
        public List<(object Payload, string MessageId, Guid CorrelationId, string CustomerId, Priority Priority, string? SessionId)> Published { get; } = [];

        public Task PublishAsync<T>(
            T payload,
            string messageId,
            Guid correlationId,
            string customerId,
            Priority priority,
            string? sessionId = null,
            CancellationToken ct = default)
        {
            Published.Add((payload!, messageId, correlationId, customerId, priority, sessionId));
            return Task.CompletedTask;
        }
    }
}
