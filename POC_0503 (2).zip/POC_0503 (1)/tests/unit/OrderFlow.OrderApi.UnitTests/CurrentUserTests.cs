using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.OrderApi.Services;

namespace OrderFlow.OrderApi.UnitTests;

/// <summary>
/// Every authorization decision in the Order API reads from <see cref="CurrentUser"/>, so the claim
/// shapes that Entra, the Identity API, and local dev auth each produce all have to land correctly.
/// </summary>
public sealed class CurrentUserTests
{
    private static CurrentUser From(params Claim[] claims)
    {
        var context = new DefaultHttpContext
        {
            User = new ClaimsPrincipal(new ClaimsIdentity(claims, authenticationType: "Test", nameType: "name", roleType: "roles"))
        };

        return new CurrentUser(new HttpContextAccessor { HttpContext = context });
    }

    [Fact]
    public void TheObjectIdClaimIdentifiesTheUser()
    {
        var user = From(new Claim(OrderFlowIdentityConstants.ClaimObjectId, "mgr-1"));

        Assert.Equal("mgr-1", user.Id);
    }

    [Fact]
    public void TheEntraObjectIdentifierClaimIsAcceptedAsAFallback()
    {
        var user = From(new Claim("http://schemas.microsoft.com/identity/claims/objectidentifier", "entra-oid"));

        Assert.Equal("entra-oid", user.Id);
    }

    [Fact]
    public void AnUnauthenticatedRequestResolvesToAnonymousRatherThanThrowing()
    {
        Assert.Equal("anonymous", new CurrentUser(new HttpContextAccessor()).Id);
    }

    [Fact]
    public void TheDisplayNameFallsBackToTheUserIdWhenNoNameClaimIsPresent()
    {
        var user = From(new Claim(OrderFlowIdentityConstants.ClaimObjectId, "rep-7"));

        Assert.Equal("rep-7", user.DisplayName);
    }

    [Theory]
    [InlineData(OrderFlowIdentityConstants.RoleManager, UserRole.Manager, true)]
    [InlineData(OrderFlowIdentityConstants.RoleReportee, UserRole.Reportee, false)]
    public void TheRoleClaimDecidesTheRoleAndManagerFlag(string role, UserRole expected, bool isManager)
    {
        var user = From(
            new Claim(OrderFlowIdentityConstants.ClaimObjectId, "u1"),
            new Claim("roles", role));

        Assert.Equal(expected, user.Role);
        Assert.Equal(isManager, user.IsManager);
        Assert.True(user.HasValidRole);
    }

    [Fact]
    public void AUserWithNoOrderFlowRoleIsRejectedRatherThanDefaultingToReportee()
    {
        var user = From(
            new Claim(OrderFlowIdentityConstants.ClaimObjectId, "u1"),
            new Claim("roles", "SomeOtherAppRole"));

        Assert.False(user.HasValidRole);
        Assert.Throws<UnauthorizedAccessException>(() => user.Role);
    }

    [Fact]
    public void TheAdGroupVerifiedClaimIsReadCaseInsensitivelyAndDefaultsToFalse()
    {
        Assert.True(From(new Claim(OrderFlowIdentityConstants.ClaimAdGroupVerified, "True")).IsAdGroupVerified);
        Assert.False(From(new Claim(OrderFlowIdentityConstants.ClaimAdGroupVerified, "false")).IsAdGroupVerified);
        Assert.False(From(new Claim(OrderFlowIdentityConstants.ClaimObjectId, "u1")).IsAdGroupVerified);
    }

    [Fact]
    public void TheManagerIdClaimScopesAReporteeToTheirManager()
    {
        var user = From(
            new Claim(OrderFlowIdentityConstants.ClaimObjectId, "rep-1"),
            new Claim(OrderFlowIdentityConstants.ClaimManagerId, "mgr-1"));

        Assert.Equal("mgr-1", user.ManagerId);
    }
}
