using Microsoft.Extensions.Configuration;
using OrderFlow.Domain;
using OrderFlow.EmailIntake.Services;

namespace OrderFlow.EmailIntake.UnitTests;

public sealed class CustomerResolverTests
{
    private static CustomerResolver Resolver(params (string Key, string Value)[] settings) =>
        new(new ConfigurationBuilder()
            .AddInMemoryCollection(settings.Select(s => new KeyValuePair<string, string?>(s.Key, s.Value)))
            .Build());

    [Theory]
    [InlineData("escrow@acmetitle.com", "acme-title", Priority.High)]
    [InlineData("orders@fntitle.com", "first-national", Priority.Standard)]
    [InlineData("ap@globex.com", "globex", Priority.Standard)]
    [InlineData("billing@initech.com", "initech", Priority.Low)]
    public void AKnownSenderDomainMapsToItsCustomerAndTier(string sender, string customerId, Priority priority)
    {
        var resolved = Resolver().Resolve(sender);

        Assert.Equal(customerId, resolved.CustomerId);
        Assert.Equal(priority, resolved.Priority);
    }

    [Fact]
    public void DomainMatchingIgnoresCase()
    {
        Assert.Equal("acme-title", Resolver().Resolve("Escrow@AcmeTitle.COM").CustomerId);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("someone@unknown-partner.com")]
    public void AnUnrecognisedSenderGoesToTriageAtTheLowestPriority(string? sender)
    {
        var resolved = Resolver().Resolve(sender);

        Assert.Equal("triage", resolved.CustomerId);
        Assert.Equal(Priority.Low, resolved.Priority);
    }

    [Fact]
    public void ConfigurationOnboardsANewCustomerWithoutACodeChange()
    {
        var resolved = Resolver(("Customers:DomainMap:newco.com", "newco:High")).Resolve("orders@newco.com");

        Assert.Equal("newco", resolved.CustomerId);
        Assert.Equal(Priority.High, resolved.Priority);
    }

    [Fact]
    public void ConfigurationOverridesTheBuiltInTierForAKnownDomain()
    {
        var resolved = Resolver(("Customers:DomainMap:initech.com", "initech:High")).Resolve("billing@initech.com");

        Assert.Equal("initech", resolved.CustomerId);
        Assert.Equal(Priority.High, resolved.Priority);
    }

    [Fact]
    public void AnOverrideWithAnUnparseableTierFallsBackToStandard()
    {
        var resolved = Resolver(("Customers:DomainMap:newco.com", "newco:Urgent")).Resolve("orders@newco.com");

        Assert.Equal("newco", resolved.CustomerId);
        Assert.Equal(Priority.Standard, resolved.Priority);
    }
}

public sealed class SeenMessageStoreTests
{
    [Fact]
    public async Task TheFirstSightingOfAMessageIsAcceptedAndRepeatsAreSuppressed()
    {
        var store = new InMemorySeenMessageStore();

        Assert.True(await store.TryMarkSeenAsync("orders@contoso.com", "msg-1"));
        Assert.False(await store.TryMarkSeenAsync("orders@contoso.com", "msg-1"));
    }

    [Fact]
    public async Task TheSameMessageIdInADifferentMailboxIsADifferentMessage()
    {
        var store = new InMemorySeenMessageStore();

        Assert.True(await store.TryMarkSeenAsync("orders@contoso.com", "msg-1"));
        Assert.True(await store.TryMarkSeenAsync("support@contoso.com", "msg-1"));
    }

    [Fact]
    public async Task ConcurrentDeliveriesOfOneMessageYieldExactlyOneWinner()
    {
        var store = new InMemorySeenMessageStore();

        var results = await Task.WhenAll(Enumerable.Range(0, 32)
            .Select(_ => store.TryMarkSeenAsync("orders@contoso.com", "msg-race")));

        Assert.Single(results, accepted => accepted);
    }
}
