using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.IdentityApi.Services;

namespace OrderFlow.IdentityApi.UnitTests;

/// <summary>
/// The Identity API is the only service that mints OrderFlow tokens, so the claims it puts in them
/// and the validation it applies on the way back in are its core contract.
/// </summary>
public sealed class InternalTokenServiceTests
{
    private const string SigningKey = "orderflow-unit-test-signing-key-32-bytes-long!";
    private const string Issuer = "https://identity.orderflow.internal";

    private static InternalTokenService Service() => new(SigningKey, Issuer);

    private static AuthenticatedPrincipalDto Principal(UserRole? role = UserRole.Manager) => new(
        IsAuthenticated: true,
        IsAuthorized: true,
        DenialCode: null,
        DenialReason: null,
        UserId: "mgr-1",
        Upn: "morgan@contoso.com",
        Email: "morgan@contoso.com",
        DisplayName: "Morgan",
        Role: role,
        ManagerId: null,
        Groups: ["group-access", "group-managers"],
        AppRoles: [OrderFlowIdentityConstants.RoleManager],
        AuthMethod: "WindowsNegotiate");

    [Fact]
    public void AShortSigningKeyIsRejectedAtConstruction()
    {
        Assert.Throws<ArgumentException>(() => new InternalTokenService("too-short"));
    }

    [Fact]
    public async Task AUserTokenRoundTripsWithItsRoleAndGroupClaims()
    {
        var service = Service();
        var (token, expiresAt) = service.CreateUserToken(Principal(), "api://orderflow-orderapi", TimeSpan.FromMinutes(30));

        Assert.True(expiresAt > DateTimeOffset.UtcNow);

        var result = await service.ValidateAsync(token, "api://orderflow-orderapi");

        Assert.True(result.IsValid);
        var identity = result.ClaimsIdentity;
        Assert.Equal(OrderFlowIdentityConstants.TokenKindUser, identity.FindFirst(OrderFlowIdentityConstants.ClaimTokenKind)?.Value);
        Assert.Equal("mgr-1", identity.FindFirst("sub")?.Value);
        Assert.Contains(identity.FindAll("roles"), c => c.Value == OrderFlowIdentityConstants.RoleManager);
        Assert.Equal(2, identity.FindAll(OrderFlowIdentityConstants.ClaimGroupId).Count());
    }

    [Fact]
    public async Task AServiceTokenIsMarkedAsAServiceTokenAndNamesTheCallingService()
    {
        var service = Service();
        var (token, _) = service.CreateServiceToken(
            "Orchestrator",
            "api://orderflow-internal",
            [OrderFlowIdentityConstants.RoleInternalService],
            TimeSpan.FromMinutes(5));

        var result = await service.ValidateAsync(token, "api://orderflow-internal");

        Assert.True(result.IsValid);
        Assert.Equal(OrderFlowIdentityConstants.TokenKindService, result.ClaimsIdentity.FindFirst(OrderFlowIdentityConstants.ClaimTokenKind)?.Value);
        Assert.Equal("Orchestrator", result.ClaimsIdentity.FindFirst(OrderFlowIdentityConstants.ClaimServiceName)?.Value);
        Assert.Equal("service:Orchestrator", result.ClaimsIdentity.FindFirst("sub")?.Value);
    }

    [Fact]
    public async Task ATokenForOneAudienceIsRejectedByAnother()
    {
        var service = Service();
        var (token, _) = service.CreateServiceToken("Orchestrator", "api://orderflow-internal", [], TimeSpan.FromMinutes(5));

        var result = await service.ValidateAsync(token, "api://some-other-api");

        Assert.False(result.IsValid);
    }

    [Fact]
    public async Task ATokenSignedWithADifferentKeyIsRejected()
    {
        var (token, _) = Service().CreateServiceToken("Orchestrator", "api://orderflow-internal", [], TimeSpan.FromMinutes(5));

        var result = await new InternalTokenService("a-completely-different-key-32-bytes-long!").ValidateAsync(token);

        Assert.False(result.IsValid);
    }

    [Fact]
    public async Task AnExpiredTokenIsRejected()
    {
        var service = Service();
        var (token, _) = service.CreateServiceToken("Orchestrator", "api://orderflow-internal", [], TimeSpan.FromMinutes(-10));

        var result = await service.ValidateAsync(token);

        Assert.False(result.IsValid);
    }

    [Fact]
    public void AnUnauthorizedPrincipalStillMintsATokenButFlagsTheFailedGroupCheck()
    {
        var unauthorized = Principal(role: null) with { IsAuthorized = false };

        var (token, _) = Service().CreateUserToken(unauthorized, "api://orderflow-orderapi", TimeSpan.FromMinutes(5));

        Assert.False(string.IsNullOrWhiteSpace(token));
    }
}

public sealed class IdentityServiceOptionsTests
{
    [Fact]
    public void EveryOrderFlowMicroserviceIsRegisteredForServiceTokenExchangeByDefault()
    {
        var allowed = new IdentityServiceOptions().AllowedServices;

        Assert.Contains("OrderApi", allowed);
        Assert.Contains("Orchestrator", allowed);
        Assert.Contains("EmailIntake", allowed);
        Assert.Contains("IdentitySync", allowed);
    }

    [Fact]
    public void AdGroupMembershipIsMandatoryButAnExplicitAppRoleAssignmentIsNot()
    {
        Assert.False(new IdentityServiceOptions().RequireExplicitAppRoleAssignment);
    }
}
