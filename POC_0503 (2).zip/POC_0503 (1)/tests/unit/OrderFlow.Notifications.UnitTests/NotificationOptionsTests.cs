using OrderFlow.Contracts;
using OrderFlow.Notifications.Services;

namespace OrderFlow.Notifications.UnitTests;

public sealed class NotificationOptionsTests
{
    private static NotificationRequested Event(NotificationKind kind, params string[] recipients) => new(
        NotificationId: Guid.NewGuid(),
        Kind: kind,
        Severity: NotificationSeverity.Warning,
        Subject: "subject",
        Summary: "summary",
        Recipients: recipients,
        Facts: []);

    private static NotificationOptions Options() => new()
    {
        DefaultRecipients = { "default@contoso.com" },
        OperationsRecipients = { "ops@contoso.com" },
        RecipientsByKind = { ["SlaBreached"] = ["sla-team@contoso.com"] }
    };

    [Fact]
    public void ExplicitRecipientsOnTheEventWinOverEveryConfiguredList()
    {
        var resolved = Options().ResolveRecipients(Event(NotificationKind.SlaBreached, "named@contoso.com"));

        Assert.Equal(["named@contoso.com"], resolved);
    }

    [Fact]
    public void APerKindListBeatsTheDefaultList()
    {
        var resolved = Options().ResolveRecipients(Event(NotificationKind.SlaBreached));

        Assert.Equal(["sla-team@contoso.com"], resolved);
    }

    [Theory]
    [InlineData(NotificationKind.ServiceUnhealthy)]
    [InlineData(NotificationKind.ServiceRecovered)]
    [InlineData(NotificationKind.DeadLetterDetected)]
    public void InfrastructureEventsGoToOperationsRatherThanTheDefaultList(NotificationKind kind)
    {
        var resolved = Options().ResolveRecipients(Event(kind));

        Assert.Equal(["ops@contoso.com"], resolved);
    }

    [Fact]
    public void BusinessEventsWithoutAPerKindListFallBackToTheDefaultList()
    {
        var resolved = Options().ResolveRecipients(Event(NotificationKind.OrderFinalized));

        Assert.Equal(["default@contoso.com"], resolved);
    }

    [Fact]
    public void NothingConfiguredResolvesToNoRecipientsRatherThanThrowing()
    {
        var resolved = new NotificationOptions().ResolveRecipients(Event(NotificationKind.OrderFailed));

        Assert.Empty(resolved);
    }
}
