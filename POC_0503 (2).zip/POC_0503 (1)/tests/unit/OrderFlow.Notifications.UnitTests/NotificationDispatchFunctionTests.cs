using System.Diagnostics.Metrics;
using System.Text.Json;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;
using OrderFlow.Notifications.Functions;
using OrderFlow.Notifications.Services;
using OrderFlow.Observability;

namespace OrderFlow.Notifications.UnitTests;

public sealed class NotificationDispatchFunctionTests
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private static string Message(NotificationKind kind = NotificationKind.SlaBreached) => JsonSerializer.Serialize(
        new NotificationRequested(
            NotificationId: Guid.NewGuid(),
            Kind: kind,
            Severity: NotificationSeverity.Warning,
            Subject: "SLA breached",
            Summary: "Nobody validated this order in time.",
            Recipients: [],
            Facts: [],
            CustomerId: "acme-title",
            OrderId: Guid.NewGuid()),
        Json);

    private static NotificationDispatchFunction Create(IEmailSender sender, NotificationOptions options) => new(
        new NotificationRenderer(Options.Create(options)),
        sender,
        Options.Create(options),
        new OrderFlowMetrics(new DummyMeterFactory()),
        NullLogger<NotificationDispatchFunction>.Instance);

    [Fact]
    public async Task AValidMessageIsRenderedAndSentToTheResolvedRecipients()
    {
        var sender = new RecordingEmailSender();
        var options = new NotificationOptions { DefaultRecipients = { "ops@contoso.com" } };

        await Create(sender, options).DispatchNotification(Message(), CancellationToken.None);

        var sent = Assert.Single(sender.Sent);
        Assert.Equal(["ops@contoso.com"], sent.To);
        Assert.Contains("SLA breached", sent.Subject);
    }

    [Fact]
    public async Task AMalformedMessageThrowsSoServiceBusDeadLettersItRatherThanLosingIt()
    {
        var function = Create(new RecordingEmailSender(), new NotificationOptions());

        await Assert.ThrowsAnyAsync<Exception>(() => function.DispatchNotification("null", CancellationToken.None));
    }

    [Fact]
    public async Task AProviderRejectionThrowsSoTheMessageIsRetried()
    {
        var sender = new RecordingEmailSender { Outcome = EmailSendOutcome.Failed("mailbox quota exceeded") };
        var options = new NotificationOptions { DefaultRecipients = { "ops@contoso.com" } };

        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => Create(sender, options).DispatchNotification(Message(), CancellationToken.None));

        Assert.Contains("mailbox quota exceeded", exception.Message);
    }

    [Fact]
    public async Task AMessageWithNoResolvableRecipientsIsCompletedRatherThanRetriedForever()
    {
        var sender = new RecordingEmailSender();

        await Create(sender, new NotificationOptions()).DispatchNotification(Message(), CancellationToken.None);

        Assert.Empty(sender.Sent);
    }

    [Fact]
    public async Task NothingIsSentWhileNotificationsAreTurnedOff()
    {
        var sender = new RecordingEmailSender();
        var options = new NotificationOptions { Enabled = false, DefaultRecipients = { "ops@contoso.com" } };

        await Create(sender, options).DispatchNotification(Message(), CancellationToken.None);

        Assert.Empty(sender.Sent);
    }

    private sealed class RecordingEmailSender : IEmailSender
    {
        public List<NotificationEmail> Sent { get; } = [];
        public EmailSendOutcome Outcome { get; set; } = EmailSendOutcome.Sent("test");

        public Task<EmailSendOutcome> SendAsync(NotificationEmail email, CancellationToken ct = default)
        {
            if (Outcome.Delivered)
                Sent.Add(email);

            return Task.FromResult(Outcome);
        }
    }

    private sealed class DummyMeterFactory : IMeterFactory
    {
        public Meter Create(MeterOptions options) => new(options);
        public void Dispose() { }
    }
}
