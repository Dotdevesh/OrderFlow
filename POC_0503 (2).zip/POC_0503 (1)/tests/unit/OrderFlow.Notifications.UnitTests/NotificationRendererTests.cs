using Microsoft.Extensions.Options;
using OrderFlow.Contracts;
using OrderFlow.Notifications.Services;

namespace OrderFlow.Notifications.UnitTests;

public sealed class NotificationRendererTests
{
    private static readonly Guid OrderId = Guid.Parse("8f14e45f-ceea-467a-9575-8f1e4d0a4f21");

    private static NotificationRenderer Renderer(Action<NotificationOptions>? configure = null)
    {
        var options = new NotificationOptions
        {
            SubjectPrefix = "[OrderFlow dev]",
            ActionCenterBaseUrl = "https://actioncenter.contoso.com"
        };
        configure?.Invoke(options);
        return new NotificationRenderer(Options.Create(options));
    }

    private static NotificationRequested Event(
        NotificationSeverity severity = NotificationSeverity.Warning,
        string? actionUrl = null) => new(
            NotificationId: Guid.NewGuid(),
            Kind: NotificationKind.SlaBreached,
            Severity: severity,
            Subject: "SLA breached on order",
            Summary: "Nobody validated this order in time.",
            Recipients: [],
            Facts: [new NotificationFact("Escalation attempt", "2")],
            CorrelationId: Guid.Parse("11111111-2222-3333-4444-555555555555"),
            CustomerId: "acme-title",
            OrderId: OrderId,
            ActionUrl: actionUrl,
            RaisedAtUtc: new DateTimeOffset(2026, 11, 21, 9, 30, 0, TimeSpan.Zero));

    [Theory]
    [InlineData(NotificationSeverity.Critical, "[OrderFlow dev] CRITICAL: SLA breached on order")]
    [InlineData(NotificationSeverity.Warning, "[OrderFlow dev] Warning: SLA breached on order")]
    [InlineData(NotificationSeverity.Information, "[OrderFlow dev] SLA breached on order")]
    public void SubjectCarriesThePrefixAndSeverity(NotificationSeverity severity, string expected)
    {
        var email = Renderer().Render(Event(severity), ["ops@contoso.com"]);

        Assert.Equal(expected, email.Subject);
    }

    [Fact]
    public void BothBodiesCarryTheOrderCustomerAndCorrelationId()
    {
        var email = Renderer().Render(Event(), ["ops@contoso.com"]);

        foreach (var body in new[] { email.HtmlBody, email.PlainTextBody })
        {
            Assert.Contains(OrderId.ToString(), body);
            Assert.Contains("acme-title", body);
            Assert.Contains("11111111-2222-3333-4444-555555555555", body);
            Assert.Contains("Escalation attempt", body);
            Assert.Contains("2026-11-21 09:30:00", body);
        }
    }

    [Fact]
    public void TheActionLinkIsBuiltFromTheActionCenterBaseUrlWhenTheEventDoesNotSupplyOne()
    {
        var email = Renderer().Render(Event(), ["ops@contoso.com"]);

        Assert.Contains($"https://actioncenter.contoso.com/validation/{OrderId}", email.PlainTextBody);
    }

    [Fact]
    public void AnExplicitActionUrlOnTheEventWins()
    {
        var email = Renderer().Render(Event(actionUrl: "https://runbooks.contoso.com/dlq"), ["ops@contoso.com"]);

        Assert.Contains("https://runbooks.contoso.com/dlq", email.PlainTextBody);
        Assert.DoesNotContain("/validation/", email.PlainTextBody);
    }

    [Fact]
    public void NoActionLinkIsRenderedWhenTheActionCenterUrlIsNotConfigured()
    {
        var email = Renderer(o => o.ActionCenterBaseUrl = null).Render(Event(), ["ops@contoso.com"]);

        Assert.DoesNotContain("Open in Action Center", email.PlainTextBody);
        Assert.DoesNotContain("Open in Action Center", email.HtmlBody);
    }

    [Fact]
    public void HtmlFromAFactValueIsEncodedRatherThanEmitted()
    {
        var notification = Event() with { Facts = [new NotificationFact("Note", "<script>alert(1)</script>")] };

        var email = Renderer().Render(notification, ["ops@contoso.com"]);

        Assert.DoesNotContain("<script>", email.HtmlBody);
        Assert.Contains("&lt;script&gt;", email.HtmlBody);
    }
}
