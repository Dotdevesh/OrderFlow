using OrderFlow.Notifications.Services;

namespace OrderFlow.Notifications.UnitTests;

public sealed class WatchdogStateStoreTests
{
    private const int Threshold = 2;

    [Fact]
    public void AHealthyServiceNeverReportsATransition()
    {
        var store = new InMemoryWatchdogStateStore();

        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: true, Threshold));
        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: true, Threshold));
    }

    [Fact]
    public void ASingleFailedProbeIsAbsorbedUntilTheThresholdIsReached()
    {
        var store = new InMemoryWatchdogStateStore();

        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: false, Threshold));
        Assert.Equal(WatchdogTransition.WentDown, store.Record("OrderApi", isHealthy: false, Threshold));
    }

    [Fact]
    public void AnOngoingOutageIsReportedOnceRatherThanOnEveryTick()
    {
        var store = new InMemoryWatchdogStateStore();
        store.Record("OrderApi", isHealthy: false, Threshold);
        store.Record("OrderApi", isHealthy: false, Threshold);

        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: false, Threshold));
        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: false, Threshold));
    }

    [Fact]
    public void RecoveryIsReportedOnlyAfterAnOutageWasReported()
    {
        var store = new InMemoryWatchdogStateStore();
        store.Record("OrderApi", isHealthy: false, Threshold);
        store.Record("OrderApi", isHealthy: false, Threshold);

        Assert.Equal(WatchdogTransition.Recovered, store.Record("OrderApi", isHealthy: true, Threshold));
        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: true, Threshold));
    }

    [Fact]
    public void AnIntermittentFailureBelowTheThresholdResetsWithoutNotifying()
    {
        var store = new InMemoryWatchdogStateStore();

        store.Record("OrderApi", isHealthy: false, Threshold);
        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: true, Threshold));
        Assert.Equal(WatchdogTransition.None, store.Record("OrderApi", isHealthy: false, Threshold));
    }

    [Fact]
    public void ServicesAreTrackedIndependently()
    {
        var store = new InMemoryWatchdogStateStore();

        store.Record("OrderApi", isHealthy: false, failureThreshold: 1);
        Assert.Equal(WatchdogTransition.None, store.Record("IdentityApi", isHealthy: true, failureThreshold: 1));
        Assert.Equal(WatchdogTransition.WentDown, store.Record("IdentityApi", isHealthy: false, failureThreshold: 1));
    }
}
