using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.Domain;
using OrderFlow.IdentitySync.Services;

namespace OrderFlow.IdentitySync.UnitTests;

/// <summary>
/// Without a tenant the provider has to return a snapshot that still exercises the downstream sync
/// contract, otherwise local development cannot reach the Identity API's apply path at all.
/// </summary>
public sealed class DirectorySyncTests
{
    private static GraphEntraDirectoryProvider Provider(params (string Key, string Value)[] settings)
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(settings.Select(s => new KeyValuePair<string, string?>(s.Key, s.Value)))
            .Build();

        return new GraphEntraDirectoryProvider(
            configuration,
            Options.Create(new DirectorySyncOptions()),
            new AzureCredentialFactory(configuration, NullLogger<AzureCredentialFactory>.Instance),
            NullLogger<GraphEntraDirectoryProvider>.Instance);
    }

    [Fact]
    public async Task WithoutATenantTheProviderReturnsACompleteSampleSnapshot()
    {
        var batch = await Provider().ReadDirectoryStateAsync("local-sample");

        Assert.Equal("local-sample", batch.SyncSource);
        Assert.NotEmpty(batch.Groups);
        Assert.NotEmpty(batch.Users);
        Assert.NotEmpty(batch.Memberships);
    }

    [Fact]
    public async Task TheSampleSnapshotIsDeterministicSoRepeatedSyncsDoNotChurnTheDatabase()
    {
        var first = await Provider().ReadDirectoryStateAsync("local-sample");
        var second = await Provider().ReadDirectoryStateAsync("local-sample");

        Assert.Equal(
            first.Users.Select(u => u.ObjectId),
            second.Users.Select(u => u.ObjectId));
    }

    [Fact]
    public async Task TheSampleSnapshotCarriesTheRequiredAccessGroupAndARoleMappedGroup()
    {
        var batch = await Provider().ReadDirectoryStateAsync("local-sample");

        Assert.Contains(batch.Groups, g => g.IsRequiredAccessGroup);
        Assert.Contains(batch.Groups, g => g.MappedRole == UserRole.Manager);
    }

    [Fact]
    public async Task EveryMembershipPointsAtAUserInTheSameBatch()
    {
        var batch = await Provider().ReadDirectoryStateAsync("local-sample");
        var userIds = batch.Users.Select(u => u.ObjectId).ToHashSet();

        foreach (var membership in batch.Memberships)
            Assert.All(membership.MemberUserIds, id => Assert.Contains(id, userIds));
    }
}

public sealed class DirectorySyncOptionsTests
{
    [Fact]
    public void OptionsBindFromTheDirectorySyncSection()
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                [$"{DirectorySyncOptions.Section}:AccessGroupId"] = "group-access",
                [$"{DirectorySyncOptions.Section}:ManagerGroupId"] = "group-managers"
            })
            .Build();

        var options = new DirectorySyncOptions();
        configuration.GetSection(DirectorySyncOptions.Section).Bind(options);

        Assert.Equal("group-access", options.AccessGroupId);
        Assert.Equal("group-managers", options.ManagerGroupId);
    }
}
