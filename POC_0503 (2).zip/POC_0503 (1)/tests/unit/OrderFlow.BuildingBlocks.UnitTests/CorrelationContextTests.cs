using System.Diagnostics;
using OrderFlow.BuildingBlocks;
using OrderFlow.Observability;

namespace OrderFlow.BuildingBlocks.UnitTests;

public sealed class CorrelationContextTests
{
    [Fact]
    public void Ensure_AdoptsAnIncomingIdRatherThanMintingANewOne()
    {
        using var activity = new Activity("test").Start();

        var id = CorrelationContext.Ensure("abc-123");

        Assert.Equal("abc-123", id);
        Assert.Equal("abc-123", CorrelationContext.Current);
        Assert.Equal("abc-123", activity.GetBaggageItem(CorrelationContext.BaggageKey));
    }

    [Fact]
    public void Ensure_KeepsTheIdAlreadyInScopeWhenTheCallerSuppliesNothing()
    {
        using var activity = new Activity("test").Start();
        CorrelationContext.Ensure("first");

        Assert.Equal("first", CorrelationContext.Ensure());
        Assert.Equal("first", CorrelationContext.Ensure("  "));
    }

    [Fact]
    public async Task PropagationHandler_StampsTheOutboundRequestWithTheIdInScope()
    {
        using var activity = new Activity("test").Start();
        CorrelationContext.Ensure("corr-xyz");

        var capture = new CapturingHandler();
        using var invoker = new HttpMessageInvoker(new CorrelationIdPropagationHandler { InnerHandler = capture });

        using var request = new HttpRequestMessage(HttpMethod.Get, "http://order-api.local/internal/orders");
        await invoker.SendAsync(request, CancellationToken.None);

        Assert.Equal("corr-xyz", capture.SeenCorrelationId);
    }

    [Fact]
    public async Task PropagationHandler_DoesNotOverwriteAnIdTheCallerAlreadySet()
    {
        using var activity = new Activity("test").Start();
        CorrelationContext.Ensure("ambient");

        var capture = new CapturingHandler();
        using var invoker = new HttpMessageInvoker(new CorrelationIdPropagationHandler { InnerHandler = capture });

        using var request = new HttpRequestMessage(HttpMethod.Get, "http://order-api.local/internal/orders");
        request.Headers.TryAddWithoutValidation(Telemetry.CorrelationIdHeader, "explicit");
        await invoker.SendAsync(request, CancellationToken.None);

        Assert.Equal("explicit", capture.SeenCorrelationId);
    }

    private sealed class CapturingHandler : HttpMessageHandler
    {
        public string? SeenCorrelationId { get; private set; }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            SeenCorrelationId = request.Headers.TryGetValues(Telemetry.CorrelationIdHeader, out var values)
                ? values.FirstOrDefault()
                : null;

            return Task.FromResult(new HttpResponseMessage(System.Net.HttpStatusCode.OK));
        }
    }
}
