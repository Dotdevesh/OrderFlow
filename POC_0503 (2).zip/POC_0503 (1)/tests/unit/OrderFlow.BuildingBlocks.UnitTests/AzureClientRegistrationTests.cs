using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OrderFlow.BuildingBlocks.AzureClients;

namespace OrderFlow.BuildingBlocks.UnitTests;

public sealed class AzureClientRegistrationTests
{
    private const string AzuriteConnectionString =
        "DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;" +
        "AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;" +
        "BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;";

    private static IServiceProvider Build(Action<IServiceCollection, IConfiguration> configure, params (string Key, string Value)[] settings)
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(settings.Select(s => new KeyValuePair<string, string?>(s.Key, s.Value)))
            .Build();

        var services = new ServiceCollection();
        services.AddLogging();
        services.AddSingleton<IConfiguration>(configuration);
        configure(services, configuration);
        return services.BuildServiceProvider();
    }

    [Fact]
    public void BlobServiceClient_UsesTheEndpointAndACredentialWhenOneIsConfigured()
    {
        var provider = Build(
            (services, _) => services.AddOrderFlowBlobServiceClient(),
            ("Storage:BlobEndpoint", "https://storderflowdev.blob.core.windows.net"),
            ("Storage:Credential:Mode", "ManagedIdentity"));

        var client = provider.GetRequiredService<BlobServiceClient>();

        Assert.Equal("storderflowdev", client.AccountName);
        Assert.Equal(new Uri("https://storderflowdev.blob.core.windows.net"), client.Uri);
    }

    [Fact]
    public void BlobServiceClient_FallsBackToAConnectionStringWhenTheResourceIsInConnectionStringMode()
    {
        // An endpoint is present, but the resource is pinned to connection-string access, so the
        // emulator credentials have to win.
        var provider = Build(
            (services, _) => services.AddOrderFlowBlobServiceClient(),
            ("Storage:BlobEndpoint", "https://storderflowdev.blob.core.windows.net"),
            ("Storage:Credential:Mode", "ConnectionString"),
            ("Storage:ConnectionString", AzuriteConnectionString));

        var client = provider.GetRequiredService<BlobServiceClient>();

        Assert.Equal("devstoreaccount1", client.AccountName);
    }

    [Fact]
    public void BlobServiceClient_DefaultsToTheAzuriteDevelopmentAccount()
    {
        var provider = Build((services, _) => services.AddOrderFlowBlobServiceClient());

        Assert.Equal("devstoreaccount1", provider.GetRequiredService<BlobServiceClient>().AccountName);
    }

    [Fact]
    public void TryAddServiceBusClient_ReportsFalseWhenNeitherNamespaceNorConnectionStringIsConfigured()
    {
        var registered = true;
        var provider = Build((services, cfg) => registered = services.TryAddOrderFlowServiceBusClient(cfg));

        Assert.False(registered);
        Assert.Null(provider.GetService<ServiceBusClient>());
    }

    [Fact]
    public void TryAddServiceBusClient_UsesTheNamespaceWithACredential()
    {
        ServiceBusClient? client = null;
        var provider = Build(
            (services, cfg) => services.TryAddOrderFlowServiceBusClient(cfg),
            ("ServiceBus:FullyQualifiedNamespace", "sb-orderflow-dev.servicebus.windows.net"),
            ("ServiceBus:Credential:Mode", "ManagedIdentity"),
            ("ServiceBus:Credential:ClientId", "11111111-1111-1111-1111-111111111111"));

        client = provider.GetService<ServiceBusClient>();

        Assert.NotNull(client);
        Assert.Equal("sb-orderflow-dev.servicebus.windows.net", client.FullyQualifiedNamespace);
    }
}
