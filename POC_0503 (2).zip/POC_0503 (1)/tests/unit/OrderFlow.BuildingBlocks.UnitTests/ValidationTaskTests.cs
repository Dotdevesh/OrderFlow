using OrderFlow.Domain;

namespace OrderFlow.BuildingBlocks.UnitTests;

public sealed class ValidationTaskTests
{
    [Fact]
    public void Escalate_UpdatesStatusAssigneeAndCount()
    {
        var task = new ValidationTask
        {
            OrderId = Guid.NewGuid(),
            OrchestrationInstanceId = "abc",
            Priority = Priority.High,
            SlaDueAtUtc = DateTimeOffset.UtcNow.AddMinutes(15)
        };

        var newDue = DateTimeOffset.UtcNow.AddMinutes(5);
        task.Escalate("mgr-1", newDue);

        Assert.Equal(Domain.TaskStatus.Escalated, task.Status);
        Assert.Equal("mgr-1", task.AssignedToUserId);
        Assert.Equal(1, task.EscalationCount);
        Assert.Equal(newDue, task.SlaDueAtUtc);
    }
}
