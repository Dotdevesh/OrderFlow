using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using OrderFlow.BuildingBlocks.AzureClients;

namespace OrderFlow.BuildingBlocks.UnitTests;

public sealed class AzureCredentialFactoryTests
{
    private static AzureCredentialFactory Create(params (string Key, string Value)[] settings)
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(settings.Select(s => new KeyValuePair<string, string?>(s.Key, s.Value)))
            .Build();

        return new AzureCredentialFactory(configuration, NullLogger<AzureCredentialFactory>.Instance);
    }

    // Azure.Core and Azure.Identity both surface the credential types once the Azure Monitor exporter
    // is in the graph, so the assertion goes through the name rather than a type literal.
    private static void AssertCredentialType(string expected, object? credential)
    {
        Assert.NotNull(credential);
        Assert.Equal(expected, credential.GetType().Name);
    }

    [Fact]
    public void Resolve_DefaultsToTheDefaultAzureCredentialChain()
    {
        var options = Create().Resolve();

        Assert.Equal(AzureCredentialMode.Default, options.Mode);
        AssertCredentialType("DefaultAzureCredential", Create().Create());
    }

    [Fact]
    public void Resolve_AppliesTheGlobalCredentialSectionToEveryResource()
    {
        var factory = Create(
            ("Azure:Credential:Mode", "ManagedIdentity"),
            ("Azure:Credential:ClientId", "11111111-1111-1111-1111-111111111111"));

        var storage = factory.Resolve("Storage");

        Assert.Equal(AzureCredentialMode.ManagedIdentity, storage.Mode);
        Assert.Equal("11111111-1111-1111-1111-111111111111", storage.ClientId);
    }

    [Fact]
    public void Resolve_LetsAResourceOverrideTheGlobalMode()
    {
        // Service Bus reached with the app's user-assigned identity, Blob still on a local emulator.
        var factory = Create(
            ("Azure:Credential:Mode", "ManagedIdentity"),
            ("Azure:Credential:ClientId", "11111111-1111-1111-1111-111111111111"),
            ("Storage:Credential:Mode", "ConnectionString"));

        Assert.Equal(AzureCredentialMode.ManagedIdentity, factory.Resolve("ServiceBus").Mode);
        Assert.Equal(AzureCredentialMode.ConnectionString, factory.Resolve("Storage").Mode);
    }

    [Fact]
    public void Create_ReturnsNullForConnectionStringModeSoCallersFallBackToASecret()
    {
        var factory = Create(("Storage:Credential:Mode", "ConnectionString"));

        Assert.Null(factory.Create("Storage"));
        Assert.Throws<InvalidOperationException>(() => factory.CreateRequired("Storage"));
    }

    [Theory]
    [InlineData("ManagedIdentity", null, "ManagedIdentityCredential")]
    [InlineData("ManagedIdentity", "22222222-2222-2222-2222-222222222222", "ManagedIdentityCredential")]
    [InlineData("WorkloadIdentity", "22222222-2222-2222-2222-222222222222", "WorkloadIdentityCredential")]
    [InlineData("AzureCli", null, "AzureCliCredential")]
    [InlineData("Default", null, "DefaultAzureCredential")]
    public void Create_BuildsTheCredentialTypeTheModeNames(string mode, string? clientId, string expected)
    {
        var settings = new List<(string, string)> { ("Notifications:Credential:Mode", mode) };
        if (clientId is not null)
        {
            settings.Add(("Notifications:Credential:ClientId", clientId));
            settings.Add(("Notifications:Credential:TenantId", "33333333-3333-3333-3333-333333333333"));
        }

        var credential = Create([.. settings]).Create("Notifications");

        AssertCredentialType(expected, credential);
    }

    [Fact]
    public void Create_ClientSecretModeRequiresTheFullTriple()
    {
        var incomplete = Create(
            ("Identity:Credential:Mode", "ClientSecret"),
            ("Identity:Credential:ClientId", "22222222-2222-2222-2222-222222222222"));

        var exception = Assert.Throws<InvalidOperationException>(() => incomplete.Create("Identity"));
        Assert.Contains("TenantId", exception.Message);

        var complete = Create(
            ("Identity:Credential:Mode", "ClientSecret"),
            ("Identity:Credential:TenantId", "33333333-3333-3333-3333-333333333333"),
            ("Identity:Credential:ClientId", "22222222-2222-2222-2222-222222222222"),
            ("Identity:Credential:ClientSecret", "s3cret"));

        AssertCredentialType("ClientSecretCredential", complete.Create("Identity"));
    }

    [Fact]
    public void Resolve_IgnoresBlankPlaceholdersInsteadOfErasingTheGlobalSettings()
    {
        // The shipped example settings list every key with an empty value; binding those verbatim
        // would wipe the identity an operator configured globally.
        var factory = Create(
            ("Azure:Credential:Mode", "ManagedIdentity"),
            ("Azure:Credential:ClientId", "11111111-1111-1111-1111-111111111111"),
            ("Azure:Credential:TenantId", "33333333-3333-3333-3333-333333333333"),
            ("Storage:Credential:Mode", ""),
            ("Storage:Credential:ClientId", ""),
            ("Storage:Credential:TenantId", "   "));

        var storage = factory.Resolve("Storage");

        Assert.Equal(AzureCredentialMode.ManagedIdentity, storage.Mode);
        Assert.Equal("11111111-1111-1111-1111-111111111111", storage.ClientId);
        Assert.Equal("33333333-3333-3333-3333-333333333333", storage.TenantId);
    }

    [Fact]
    public void Resolve_RejectsAnUnknownModeWithAMessageThatNamesTheSetting()
    {
        var factory = Create(("Storage:Credential:Mode", "Kerberos"));

        var exception = Assert.Throws<InvalidOperationException>(() => factory.Resolve("Storage"));

        Assert.Contains("Storage:Credential:Mode", exception.Message);
        Assert.Contains(nameof(AzureCredentialMode.WorkloadIdentity), exception.Message);
    }

    [Fact]
    public void Create_CachesOneCredentialPerResourceSection()
    {
        var factory = Create(("Azure:Credential:Mode", "ManagedIdentity"));

        Assert.Same(factory.Create("Storage"), factory.Create("Storage"));
        Assert.NotSame(factory.Create("Storage"), factory.Create("ServiceBus"));
    }
}
