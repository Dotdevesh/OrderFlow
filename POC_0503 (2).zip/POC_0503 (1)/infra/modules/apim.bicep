// API Management — the single public front door for OrderFlow.
//
// Only the Order API and the Identity API are published. The Function apps (EmailIntake,
// Orchestrator, IdentitySync, Notifications) are triggered by Service Bus, timers, or Graph
// webhooks and have no business being reachable from the internet through the gateway.
targetScope = 'resourceGroup'

@description('Azure region')
param location string
@description('Resource name suffix, e.g. orderflow-dev')
param suffix string
@description('Resource tags')
param tags object

@description('APIM SKU. Developer has no SLA and is intended for non-production only.')
@allowed(['Developer', 'Basic', 'Standard', 'Premium'])
param skuName string = 'Developer'

@description('Publisher email shown on the developer portal and used for service notifications.')
param publisherEmail string
@description('Publisher organisation name shown on the developer portal.')
param publisherName string = 'OrderFlow'

@description('Base URL of the Order API behind the gateway, e.g. https://orderapi-dev.azurewebsites.net')
param orderApiBackendUrl string
@description('Base URL of the Identity API behind the gateway.')
param identityApiBackendUrl string

@description('Browser origin allowed through CORS, i.e. where the Action Center is served from.')
param actionCenterOrigin string

@description('Entra ID tenant used to validate caller tokens.')
param entraTenantId string
@description('Audience (Application ID URI or client id) the Order API expects in Entra tokens.')
param entraAudience string

@description('Issuer of the Identity API internal HMAC tokens. Must match IdentityService:Issuer.')
param internalJwtIssuer string
@description('Audience of the Identity API internal HMAC tokens.')
param internalJwtAudience string
@secure()
@description('HMAC signing key for internal tokens. Must match IdentityService:JwtSigningKey.')
param internalJwtSigningKey string

@description('Application Insights resource id for gateway diagnostics.')
param appInsightsId string
@secure()
@description('Application Insights connection string for gateway diagnostics.')
param appInsightsConnectionString string

resource apim 'Microsoft.ApiManagement/service@2023-05-01-preview' = {
  name: 'apim-${suffix}'
  location: location
  tags: tags
  sku: {
    name: skuName
    capacity: 1
  }
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    publisherEmail: publisherEmail
    publisherName: publisherName
    virtualNetworkType: 'None'
    // The gateway terminates TLS for callers; everything below it speaks TLS 1.2 only.
    customProperties: {
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Tls10': 'False'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Tls11': 'False'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Tls10': 'False'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Tls11': 'False'
    }
  }
}

// ---------------- Named values referenced as {{name}} from the policy XML ----------------
var plainNamedValues = [
  { name: 'action-center-origin', value: actionCenterOrigin }
  { name: 'entra-tenant-id', value: entraTenantId }
  { name: 'entra-audience', value: entraAudience }
  { name: 'internal-jwt-issuer', value: internalJwtIssuer }
  { name: 'internal-jwt-audience', value: internalJwtAudience }
]

resource namedValues 'Microsoft.ApiManagement/service/namedValues@2023-05-01-preview' = [
  for nv in plainNamedValues: {
    parent: apim
    name: nv.name
    properties: {
      displayName: nv.name
      value: nv.value
      secret: false
    }
  }
]

resource internalSigningKey 'Microsoft.ApiManagement/service/namedValues@2023-05-01-preview' = {
  parent: apim
  name: 'internal-jwt-signing-key'
  properties: {
    displayName: 'internal-jwt-signing-key'
    value: base64(internalJwtSigningKey)
    secret: true
  }
}

// ---------------- Gateway-wide policy ----------------
resource globalPolicy 'Microsoft.ApiManagement/service/policies@2023-05-01-preview' = {
  parent: apim
  name: 'policy'
  properties: {
    format: 'rawxml'
    value: loadTextContent('../policies/global.xml')
  }
  dependsOn: [namedValues]
}

// ---------------- Backends ----------------
resource orderApiBackend 'Microsoft.ApiManagement/service/backends@2023-05-01-preview' = {
  parent: apim
  name: 'order-api'
  properties: {
    protocol: 'http'
    url: orderApiBackendUrl
    tls: {
      validateCertificateChain: true
      validateCertificateName: true
    }
  }
}

resource identityApiBackend 'Microsoft.ApiManagement/service/backends@2023-05-01-preview' = {
  parent: apim
  name: 'identity-api'
  properties: {
    protocol: 'http'
    url: identityApiBackendUrl
    tls: {
      validateCertificateChain: true
      validateCertificateName: true
    }
  }
}

// ---------------- APIs ----------------
// A wildcard operation rather than an imported OpenAPI document: the spec is served by the running
// service, which does not exist yet at template-deploy time. Authorisation is enforced in policy.
resource orderApi 'Microsoft.ApiManagement/service/apis@2023-05-01-preview' = {
  parent: apim
  name: 'order-api'
  properties: {
    displayName: 'OrderFlow Order API'
    path: 'orders'
    protocols: ['https']
    serviceUrl: orderApiBackendUrl
    subscriptionRequired: false
  }
}

resource orderApiOperation 'Microsoft.ApiManagement/service/apis/operations@2023-05-01-preview' = {
  parent: orderApi
  name: 'proxy'
  properties: {
    displayName: 'Proxy all'
    method: '*'
    urlTemplate: '/*'
    templateParameters: []
    responses: []
  }
}

resource orderApiPolicy 'Microsoft.ApiManagement/service/apis/policies@2023-05-01-preview' = {
  parent: orderApi
  name: 'policy'
  properties: {
    format: 'rawxml'
    value: loadTextContent('../policies/order-api.xml')
  }
  dependsOn: [namedValues, internalSigningKey, globalPolicy]
}

resource identityApi 'Microsoft.ApiManagement/service/apis@2023-05-01-preview' = {
  parent: apim
  name: 'identity-api'
  properties: {
    displayName: 'OrderFlow Identity API'
    path: 'identity'
    protocols: ['https']
    serviceUrl: identityApiBackendUrl
    subscriptionRequired: false
  }
}

resource identityApiOperation 'Microsoft.ApiManagement/service/apis/operations@2023-05-01-preview' = {
  parent: identityApi
  name: 'proxy'
  properties: {
    displayName: 'Proxy all'
    method: '*'
    urlTemplate: '/*'
    templateParameters: []
    responses: []
  }
}

resource identityApiPolicy 'Microsoft.ApiManagement/service/apis/policies@2023-05-01-preview' = {
  parent: identityApi
  name: 'policy'
  properties: {
    format: 'rawxml'
    value: loadTextContent('../policies/identity-api.xml')
  }
  dependsOn: [namedValues, globalPolicy]
}

// ---------------- Diagnostics ----------------
// The gateway is the first hop of every user-facing trace, so its telemetry lands in the same
// Application Insights resource the services export to via OpenTelemetry.
resource apimLogger 'Microsoft.ApiManagement/service/loggers@2023-05-01-preview' = {
  parent: apim
  name: 'appinsights'
  properties: {
    loggerType: 'applicationInsights'
    resourceId: appInsightsId
    credentials: {
      connectionString: appInsightsConnectionString
    }
  }
}

var diagnosticSettings = {
  loggerId: apimLogger.id
  alwaysLog: 'allErrors'
  httpCorrelationProtocol: 'W3C'
  logClientIp: true
  verbosity: 'information'
  sampling: {
    samplingType: 'fixed'
    percentage: 100
  }
  frontend: {
    request: {
      headers: ['x-correlation-id', 'traceparent']
      body: { bytes: 0 }
    }
    response: {
      headers: ['x-correlation-id']
      body: { bytes: 0 }
    }
  }
  backend: {
    request: {
      headers: ['x-correlation-id', 'traceparent']
      body: { bytes: 0 }
    }
    response: {
      headers: ['x-correlation-id']
      body: { bytes: 0 }
    }
  }
}

resource apimDiagnostic 'Microsoft.ApiManagement/service/diagnostics@2023-05-01-preview' = {
  parent: apim
  name: 'applicationinsights'
  properties: diagnosticSettings
}

resource orderApiDiagnostic 'Microsoft.ApiManagement/service/apis/diagnostics@2023-05-01-preview' = {
  parent: orderApi
  name: 'applicationinsights'
  properties: diagnosticSettings
}

resource identityApiDiagnostic 'Microsoft.ApiManagement/service/apis/diagnostics@2023-05-01-preview' = {
  parent: identityApi
  name: 'applicationinsights'
  properties: diagnosticSettings
}

output apimName string = apim.name
output gatewayUrl string = apim.properties.gatewayUrl
output orderApiUrl string = '${apim.properties.gatewayUrl}/orders'
output identityApiUrl string = '${apim.properties.gatewayUrl}/identity'
output principalId string = apim.identity.principalId
