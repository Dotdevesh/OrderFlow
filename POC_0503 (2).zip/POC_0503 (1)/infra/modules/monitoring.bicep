// Azure Monitor alerting.
//
// This is the outside-in half of service-down detection. The in-repo watchdog (OrderFlow.Notifications)
// polls /health/ready from inside the network and emails on transition; it catches dependency failures
// the platform cannot see, but it is itself a service that can be down. Azure Monitor runs outside
// the deployment and catches the case where the whole environment — watchdog included — is gone.
targetScope = 'resourceGroup'

@description('Environment short name, e.g. dev/test/prod')
param env string
@description('Azure region')
param location string
@description('Resource name suffix, e.g. orderflow-dev')
param suffix string
@description('Resource tags')
param tags object

@description('Email addresses notified when an alert fires.')
param operationsEmails array

@description('Application Insights resource id used by availability tests and failure alerts.')
param appInsightsId string

@description('Service Bus namespace resource id, monitored for dead-lettering.')
param serviceBusNamespaceId string

@description('Public base URL of the Order API, probed by the availability test.')
param orderApiBaseUrl string
@description('Public base URL of the Identity API, probed by the availability test.')
param identityApiBaseUrl string

// ---------------- Action group ----------------
resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: 'ag-orderflow-${env}'
  location: 'global'
  tags: tags
  properties: {
    groupShortName: take('of${env}', 12)
    enabled: true
    emailReceivers: [
      for (address, i) in operationsEmails: {
        name: 'ops-${i}'
        emailAddress: address
        useCommonAlertSchema: true
      }
    ]
  }
}

// ---------------- Availability tests against /health/ready ----------------
// /health/ready, not /health/live: a service that is up but cannot reach SQL or Service Bus cannot
// serve orders, and that is exactly what the on-call engineer needs to be woken for.
var probeLocations = [
  { Id: 'emea-nl-ams-azr' }
  { Id: 'emea-gb-db3-azr' }
  { Id: 'us-il-ch1-azr' }
  { Id: 'apac-sg-sin-azr' }
  { Id: 'us-ca-sjc-azr' }
]

var probedServices = [
  { key: 'orderapi', displayName: 'Order API', url: '${orderApiBaseUrl}/health/ready' }
  { key: 'identityapi', displayName: 'Identity API', url: '${identityApiBaseUrl}/health/ready' }
]

resource availabilityTests 'Microsoft.Insights/webtests@2022-06-15' = [
  for svc in probedServices: {
    name: 'wt-${svc.key}-${suffix}'
    location: location
    tags: union(tags, {
      // Required by the portal to associate the test with its Application Insights resource.
      'hidden-link:${appInsightsId}': 'Resource'
    })
    kind: 'standard'
    properties: {
      Name: '${svc.displayName} readiness'
      SyntheticMonitorId: 'wt-${svc.key}-${suffix}'
      Enabled: true
      Frequency: 300
      Timeout: 30
      Kind: 'standard'
      RetryEnabled: true
      Locations: probeLocations
      Request: {
        RequestUrl: svc.url
        HttpVerb: 'GET'
        ParseDependentRequests: false
      }
      ValidationRules: {
        ExpectedHttpStatusCode: 200
        SSLCheck: true
        SSLCertRemainingLifetimeCheck: 14
      }
    }
  }
]

// Alert when the readiness probe fails from two or more regions, which rules out a single
// probe location having a bad day.
resource availabilityAlerts 'Microsoft.Insights/metricAlerts@2018-03-01' = [
  for (svc, i) in probedServices: {
    name: 'alert-${svc.key}-down-${env}'
    location: 'global'
    tags: tags
    properties: {
      description: '${svc.displayName} readiness probe is failing from multiple regions.'
      severity: 1
      enabled: true
      scopes: [availabilityTests[i].id, appInsightsId]
      evaluationFrequency: 'PT5M'
      windowSize: 'PT15M'
      criteria: {
        'odata.type': 'Microsoft.Azure.Monitor.WebtestLocationAvailabilityCriteria'
        webTestId: availabilityTests[i].id
        componentId: appInsightsId
        failedLocationCount: 2
      }
      actions: [
        {
          actionGroupId: actionGroup.id
        }
      ]
    }
  }
]

// ---------------- Dead-lettering ----------------
// Messages piling up in a dead-letter queue means orders are silently not being processed.
resource deadLetterAlert 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'alert-servicebus-deadletter-${env}'
  location: 'global'
  tags: tags
  properties: {
    description: 'Messages are accumulating in a Service Bus dead-letter queue.'
    severity: 2
    enabled: true
    scopes: [serviceBusNamespaceId]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name: 'deadletteredMessages'
          metricNamespace: 'Microsoft.ServiceBus/namespaces'
          metricName: 'DeadletteredMessages'
          operator: 'GreaterThan'
          threshold: 0
          timeAggregation: 'Maximum'
          criterionType: 'StaticThresholdCriterion'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}

// ---------------- Server-side failures ----------------
resource failureRateAlert 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'alert-failed-requests-${env}'
  location: 'global'
  tags: tags
  properties: {
    description: 'Elevated rate of failed server requests across OrderFlow services.'
    severity: 2
    enabled: true
    scopes: [appInsightsId]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name: 'failedRequests'
          metricNamespace: 'Microsoft.Insights/components'
          metricName: 'requests/failed'
          operator: 'GreaterThan'
          threshold: 20
          timeAggregation: 'Count'
          criterionType: 'StaticThresholdCriterion'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}

// ---------------- SLA breaches ----------------
// OrderFlow.Observability emits this counter from the orchestrator's escalation path. A sustained
// breach rate means the validation queue is not being worked, which no infrastructure metric shows.
resource slaBreachAlert 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: 'alert-sla-breaches-${env}'
  location: location
  tags: tags
  properties: {
    description: 'Orders are breaching their validation SLA faster than they are being cleared.'
    severity: 3
    enabled: true
    scopes: [appInsightsId]
    evaluationFrequency: 'PT15M'
    windowSize: 'PT1H'
    criteria: {
      allOf: [
        {
          query: '''
customMetrics
| where name == "orderflow.sla.breaches"
| summarize Breaches = sum(valueSum)
'''
          timeAggregation: 'Total'
          metricMeasureColumn: 'Breaches'
          operator: 'GreaterThan'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    autoMitigate: true
    actions: {
      actionGroups: [actionGroup.id]
    }
  }
}

output actionGroupId string = actionGroup.id
output actionGroupName string = actionGroup.name
