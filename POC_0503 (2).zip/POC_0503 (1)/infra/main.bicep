// OrderFlow — core Azure infrastructure (per environment).
// Deploy: az deployment group create -g <rg> -f infra/main.bicep -p env=dev
targetScope = 'resourceGroup'

@description('Environment short name, e.g. dev/test/prod')
param env string = 'dev'
@description('Azure region')
param location string = resourceGroup().location
@description('Base name for resources')
param baseName string = 'orderflow'

var suffix = '${baseName}-${env}'
var tags = { app: 'orderflow', env: env }

// ---------------- Observability ----------------
resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'log-${suffix}'
  location: location
  tags: tags
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: 'appi-${suffix}'
  location: location
  kind: 'web'
  tags: tags
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: logAnalytics.id
  }
}

// ---------------- Storage (blobs + durable task hub) ----------------
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: toLower(replace('st${suffix}', '-', ''))
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    allowBlobPublicAccess: false
    minimumTlsVersion: 'TLS1_2'
  }
  resource blob 'blobServices@2023-05-01' = {
    name: 'default'
    resource container 'containers@2023-05-01' = {
      name: 'order-documents'
    }
  }
}

// ---------------- Service Bus (topic + priority subscriptions) ----------------
resource sb 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' = {
  name: 'sb-${suffix}'
  location: location
  tags: tags
  sku: { name: 'Standard', tier: 'Standard' }

  resource ordersTopic 'topics@2022-10-01-preview' = {
    name: 'orders'
    properties: {
      requiresDuplicateDetection: true
      duplicateDetectionHistoryTimeWindow: 'PT10M'
    }

    resource subHigh 'subscriptions@2022-10-01-preview' = {
      name: 'sub-high'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 10, lockDuration: 'PT5M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'priority-high'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'priority = 0 AND eventType = \'OrderReceived\'' } }
      }
    }
    resource subStandard 'subscriptions@2022-10-01-preview' = {
      name: 'sub-standard'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 10, lockDuration: 'PT5M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'priority-standard'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'priority = 1 AND eventType = \'OrderReceived\'' } }
      }
    }
    resource subLow 'subscriptions@2022-10-01-preview' = {
      name: 'sub-low'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 10, lockDuration: 'PT5M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'priority-low'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'priority = 2 AND eventType = \'OrderReceived\'' } }
      }
    }
    // Notifications are filtered on event type rather than priority: an SLA breach and an order
    // failure are both worth an email regardless of how the order itself was prioritised.
    resource subNotifications 'subscriptions@2022-10-01-preview' = {
      name: 'sub-notifications'
      properties: { deadLetteringOnMessageExpiration: true, maxDeliveryCount: 5, lockDuration: 'PT1M' }
      resource rule 'rules@2022-10-01-preview' = {
        name: 'notification-events'
        properties: { filterType: 'SqlFilter', sqlFilter: { sqlExpression: 'eventType = \'NotificationRequested\'' } }
      }
    }
  }
}

// ---------------- SQL (system of record) ----------------
@description('SQL admin login')
param sqlAdminLogin string = 'orderflowadmin'
@secure()
@description('SQL admin password')
param sqlAdminPassword string

resource sqlServer 'Microsoft.Sql/servers@2023-05-01-preview' = {
  name: 'sql-${suffix}'
  location: location
  tags: tags
  properties: {
    administratorLogin: sqlAdminLogin
    administratorLoginPassword: sqlAdminPassword
    minimalTlsVersion: '1.2'
  }
  resource db 'databases@2023-05-01-preview' = {
    name: 'OrderFlow'
    location: location
    sku: { name: 'S1', tier: 'Standard' }
  }
}

// ---------------- Document Intelligence ----------------
resource docIntelligence 'Microsoft.CognitiveServices/accounts@2023-10-01-preview' = {
  name: 'di-${suffix}'
  location: location
  tags: tags
  kind: 'FormRecognizer'
  sku: { name: 'S0' }
  properties: { customSubDomainName: 'di-${suffix}' }
}

// ---------------- Key Vault ----------------
resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: 'kv-${suffix}'
  location: location
  tags: tags
  properties: {
    sku: { family: 'A', name: 'standard' }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
  }
}

// ---------------- User-Assigned Managed Identities (Microservices & Sync Functions) ----------------
resource idIdentityApi 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'id-identityapi-${suffix}'
  location: location
  tags: tags
}

resource idIdentitySync 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'id-identitysync-${suffix}'
  location: location
  tags: tags
}

resource idOrderApi 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'id-orderapi-${suffix}'
  location: location
  tags: tags
}

resource idOrchestrator 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'id-orchestrator-${suffix}'
  location: location
  tags: tags
}

resource idEmailIntake 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'id-emailintake-${suffix}'
  location: location
  tags: tags
}

resource idNotifications 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'id-notifications-${suffix}'
  location: location
  tags: tags
}

// ---------------- Azure Communication Services (outbound email) ----------------
@description('Data residency for Communication Services. Must be a supported ACS data location.')
param communicationDataLocation string = 'United States'

resource emailService 'Microsoft.Communication/emailServices@2023-04-01' = {
  name: 'acs-email-${suffix}'
  location: 'global'
  tags: tags
  properties: {
    dataLocation: communicationDataLocation
  }

  // An Azure-managed domain sends from a random *.azurecomm.net address and is rate limited. It
  // exists so the POC can send real mail on day one; production should add a verified custom domain.
  resource azureManagedDomain 'domains@2023-04-01' = {
    name: 'AzureManagedDomain'
    location: 'global'
    tags: tags
    properties: {
      domainManagement: 'AzureManaged'
      userEngagementTracking: 'Disabled'
    }
  }
}

resource communicationService 'Microsoft.Communication/communicationServices@2023-04-01' = {
  name: 'acs-${suffix}'
  location: 'global'
  tags: tags
  properties: {
    dataLocation: communicationDataLocation
    linkedDomains: [emailService::azureManagedDomain.id]
  }
}

// Notifications authenticates to ACS with its user-assigned identity rather than a connection
// string, which is what AzureCredentialMode.ManagedIdentity selects at runtime.
var acsContributorRoleId = 'b24988ac-6180-42a0-ab88-20f7382dd24c' // Contributor
resource notificationsAcsRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: communicationService
  name: guid(communicationService.id, idNotifications.id, acsContributorRoleId)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', acsContributorRoleId)
    principalId: idNotifications.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// ---------------- API Management (public front door) ----------------
@description('Deploy API Management. Off by default because the Developer SKU takes ~45 minutes to provision.')
param deployApiManagement bool = false
@description('APIM SKU. Developer has no SLA and is intended for non-production only.')
@allowed(['Developer', 'Basic', 'Standard', 'Premium'])
param apimSkuName string = 'Developer'
@description('Publisher email for APIM service notifications.')
param apimPublisherEmail string = 'orderflow-ops@contoso.com'
@description('Base URL of the Order API behind the gateway.')
param orderApiBackendUrl string = 'https://orderapi-${suffix}.azurewebsites.net'
@description('Base URL of the Identity API behind the gateway.')
param identityApiBackendUrl string = 'https://identityapi-${suffix}.azurewebsites.net'
@description('Browser origin allowed through CORS, i.e. where the Action Center is served from.')
param actionCenterOrigin string = 'https://localhost:5173'
@description('Entra ID tenant used to validate caller tokens. Empty disables Entra validation at the gateway.')
param entraTenantId string = subscription().tenantId
@description('Audience the Order API expects in Entra tokens.')
param entraAudience string = 'api://orderflow-${env}'
@description('Issuer of Identity API internal tokens. Must match IdentityService:Issuer.')
param internalJwtIssuer string = 'https://identity.orderflow.internal'
// The gateway only ever sees user tokens. Service-to-service tokens carry api://orderflow-internal
// and are issued for direct calls between services, which never traverse APIM.
@description('Audience of Identity API user tokens. Must match IdentityService:UserTokenAudience.')
param internalJwtAudience string = 'api://orderflow-orderapi'
@secure()
@description('HMAC signing key for internal tokens. Must match IdentityService:JwtSigningKey.')
param internalJwtSigningKey string = ''

module apim 'modules/apim.bicep' = if (deployApiManagement) {
  name: 'apim'
  params: {
    location: location
    suffix: suffix
    tags: tags
    skuName: apimSkuName
    publisherEmail: apimPublisherEmail
    orderApiBackendUrl: orderApiBackendUrl
    identityApiBackendUrl: identityApiBackendUrl
    actionCenterOrigin: actionCenterOrigin
    entraTenantId: entraTenantId
    entraAudience: entraAudience
    internalJwtIssuer: internalJwtIssuer
    internalJwtAudience: internalJwtAudience
    internalJwtSigningKey: internalJwtSigningKey
    appInsightsId: appInsights.id
    appInsightsConnectionString: appInsights.properties.ConnectionString
  }
}

// ---------------- Alerting ----------------
@description('Email addresses notified when an Azure Monitor alert fires.')
param operationsEmails array = ['orderflow-ops@contoso.com']

module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: {
    env: env
    location: location
    suffix: suffix
    tags: tags
    operationsEmails: operationsEmails
    appInsightsId: appInsights.id
    serviceBusNamespaceId: sb.id
    orderApiBaseUrl: deployApiManagement ? apim.outputs.orderApiUrl : orderApiBackendUrl
    identityApiBaseUrl: deployApiManagement ? apim.outputs.identityApiUrl : identityApiBackendUrl
  }
}

output serviceBusNamespace string = sb.name
output storageAccount string = storage.name
output sqlServerFqdn string = sqlServer.properties.fullyQualifiedDomainName
output documentIntelligenceEndpoint string = docIntelligence.properties.endpoint
output appInsightsConnectionString string = appInsights.properties.ConnectionString
output identityApiManagedIdentityClientId string = idIdentityApi.properties.clientId
output identitySyncManagedIdentityClientId string = idIdentitySync.properties.clientId
output orderApiManagedIdentityClientId string = idOrderApi.properties.clientId
output orchestratorManagedIdentityClientId string = idOrchestrator.properties.clientId
output emailIntakeManagedIdentityClientId string = idEmailIntake.properties.clientId
output notificationsManagedIdentityClientId string = idNotifications.properties.clientId
output acsEndpoint string = 'https://${communicationService.properties.hostName}'
output acsSenderDomain string = emailService::azureManagedDomain.properties.mailFromSenderDomain
output apimGatewayUrl string = deployApiManagement ? apim.outputs.gatewayUrl : ''
output alertActionGroupName string = monitoring.outputs.actionGroupName
