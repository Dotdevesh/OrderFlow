[CmdletBinding()]
param(
    [switch]$CleanVolumes
)

$ErrorActionPreference = "Stop"

Push-Location $PSScriptRoot
try {
    $args = @("compose", "--profile", "apps", "down")
    if ($CleanVolumes) { $args += "-v" }
    & docker @args
}
finally {
    Pop-Location
}
