using System.Text.Json;
using Azure.Messaging.ServiceBus;

// Drops a single OrderReceived message on the `orders` topic so the Orchestrator starts a run,
// without needing Microsoft Graph / real email. The orchestrator's GraphEmailReader and the
// Document Intelligence extractor both fall back to sample data when not configured.
//
// Usage:   dotnet run -- [customerId] [priority]
//   customerId : acme-title (default) | first-national | acme | globex | initech
//   priority   : high (default=0) | standard (1) | low (2)   -> routes to sub-high/standard/low

var customerId = args.Length > 0 ? args[0] : "acme-title";
var priority = (args.Length > 1 ? args[1].ToLowerInvariant() : "high") switch
{
    "standard" => 1,
    "low" => 2,
    _ => 0
};

const string connectionString =
    "Endpoint=sb://localhost;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=SAS_KEY_VALUE;UseDevelopmentEmulator=true;";

var correlationId = Guid.NewGuid();
var payload = new
{
    CorrelationId = correlationId,
    GraphMessageId = $"local-{correlationId:N}",
    MailboxAddress = "orders@contoso.com",
    CustomerId = customerId,
    Priority = priority,
    SenderAddress = "buyer@example.com",
    Subject = "Local test order",
    ReceivedAtUtc = DateTimeOffset.UtcNow
};

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web);
await using var client = new ServiceBusClient(connectionString);
var sender = client.CreateSender("orders");

var message = new ServiceBusMessage(BinaryData.FromObjectAsJson(payload, json))
{
    MessageId = payload.GraphMessageId,
    CorrelationId = correlationId.ToString(),
    ContentType = "application/json",
    Subject = "OrderReceived",
};
message.ApplicationProperties["priority"] = priority;
message.ApplicationProperties["customerId"] = customerId;
message.ApplicationProperties["correlationId"] = correlationId.ToString();
message.ApplicationProperties["eventType"] = "OrderReceived";
message.ApplicationProperties["schemaVersion"] = "1.0";

await sender.SendMessageAsync(message);
Console.WriteLine($"Sent OrderReceived corr={correlationId} customer={customerId} priority={priority}");
