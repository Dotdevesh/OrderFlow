namespace OrderFlow.Domain;

/// <summary>A single stored document belonging to an order (email body PDF, attachment PDF, or extraction JSON).</summary>
public sealed class OrderDocument
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrderId { get; init; }

    public DocumentKind Kind { get; init; }
    public required string FileName { get; init; }

    /// <summary>Blob path, e.g. {customerId}/{orderId}/{fileName}. Deterministic for idempotency.</summary>
    public required string BlobPath { get; init; }

    public string ContentType { get; init; } = "application/pdf";
    public long SizeBytes { get; init; }

    /// <summary>Document Intelligence model used to analyze this document, if any.</summary>
    public string? AnalyzeModelId { get; set; }

    /// <summary>Lowest field confidence found in this document (drives mandatory review flags).</summary>
    public double MinConfidence { get; set; } = 1.0;
}
