namespace OrderFlow.Domain;

/// <summary>Transactional outbox entry: a domain/integration event persisted with the aggregate then dispatched to Service Bus.</summary>
public sealed class OutboxMessage
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public required string Type { get; init; }
    public required string Payload { get; init; }
    public Guid CorrelationId { get; init; }
    public DateTimeOffset OccurredAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ProcessedAtUtc { get; set; }
    public int Attempts { get; set; }
}
