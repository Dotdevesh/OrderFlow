namespace OrderFlow.Domain;

/// <summary>An Action Center user (validator). Managers own the reportees whose ManagerId == their Id.</summary>
public sealed class AppUser
{
    public required string Id { get; init; }            // Entra object id (oid)
    public required string DisplayName { get; set; }
    public string? Email { get; set; }
    public string? Upn { get; set; }
    public string? WindowsAccountName { get; set; }
    public UserRole Role { get; set; }

    /// <summary>The managing user's id. Null for top-level managers.</summary>
    public string? ManagerId { get; set; }

    /// <summary>Synced from Entra accountEnabled + AD group membership.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>True only when the user belongs to at least one required Entra/AD security group.</summary>
    public bool IsInAuthorizedGroup { get; set; } = true;

    /// <summary>Last timestamp when Identity sync updated this record.</summary>
    public DateTimeOffset? LastSyncedAtUtc { get; set; }

    public bool IsManager => Role == UserRole.Manager;
}
