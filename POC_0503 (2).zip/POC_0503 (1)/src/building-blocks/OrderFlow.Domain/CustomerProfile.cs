namespace OrderFlow.Domain;

/// <summary>
/// Configuration for a customer: how their email is identified and the priority/SLA
/// their orders receive. Fully data-driven so onboarding a customer needs no code change.
/// </summary>
public sealed class CustomerProfile
{
    public required string CustomerId { get; init; }
    public required string DisplayName { get; set; }
    public CustomerTier Tier { get; set; }

    /// <summary>Email sender domains used to attribute an inbound email to this customer.</summary>
    public IList<string> SenderDomains { get; init; } = [];

    /// <summary>Validation deadline in minutes from receipt (the human-in-the-loop SLA).</summary>
    public int SlaMinutes { get; set; }

    /// <summary>Interval used when re-arming the SLA timer after an escalation.</summary>
    public int EscalationIntervalMinutes { get; set; }

    /// <summary>Priority derived from the tier; used for Service Bus routing.</summary>
    public Priority Priority => Tier switch
    {
        CustomerTier.Platinum => Priority.High,
        CustomerTier.Gold => Priority.Standard,
        _ => Priority.Low
    };
}
