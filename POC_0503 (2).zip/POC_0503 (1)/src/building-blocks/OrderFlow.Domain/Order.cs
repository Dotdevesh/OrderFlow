namespace OrderFlow.Domain;

/// <summary>
/// The order aggregate root. Created early (status <see cref="OrderStatus.Received"/>) so no
/// inbound email is ever lost, then advanced through the pipeline.
/// </summary>
public sealed class Order
{
    public Guid Id { get; init; } = Guid.NewGuid();

    public required string CustomerId { get; init; }

    /// <summary>End-to-end correlation id (== Service Bus/Graph message correlation). Also the durable instance id seed.</summary>
    public required Guid CorrelationId { get; init; }

    /// <summary>The Durable Functions orchestration instance id, used to resume the workflow on validation.</summary>
    public string? OrchestrationInstanceId { get; set; }

    public OrderStatus Status { get; private set; } = OrderStatus.Received;

    public Priority Priority { get; init; }

    public DateTimeOffset ReceivedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset SlaDueAtUtc { get; set; }
    public DateTimeOffset? FinalizedAtUtc { get; private set; }

    public string? SubjectLine { get; set; }
    public string? SenderAddress { get; set; }

    public List<OrderDocument> Documents { get; init; } = [];
    public List<OrderLine> Lines { get; init; } = [];
    public List<OrderField> Fields { get; init; } = [];

    /// <summary>Optimistic concurrency token (SQL rowversion).</summary>
    public byte[]? RowVersion { get; set; }

    public void Advance(OrderStatus to)
    {
        // Guard against illegal backward transitions (Failed is always allowed as a terminal sink).
        if (to != OrderStatus.Failed && to < Status)
            throw new InvalidOperationException($"Cannot move order {Id} from {Status} to {to}.");
        Status = to;
        if (to == OrderStatus.Finalized)
            FinalizedAtUtc = DateTimeOffset.UtcNow;
    }
}
