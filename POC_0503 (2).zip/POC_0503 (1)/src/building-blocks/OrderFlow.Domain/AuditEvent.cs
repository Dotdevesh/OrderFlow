namespace OrderFlow.Domain;

/// <summary>Immutable audit record for compliance (who did what, before/after, when).</summary>
public sealed class AuditEvent
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid? OrderId { get; init; }
    public Guid? TaskId { get; init; }
    public string? UserId { get; init; }
    public required string Action { get; init; }
    public string? DataJson { get; init; }
    public DateTimeOffset AtUtc { get; init; } = DateTimeOffset.UtcNow;
}
