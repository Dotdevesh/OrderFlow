namespace OrderFlow.Domain;

public enum IntakeStatus { Received = 0, Published = 1, Orchestrated = 2, Finalized = 3, Failed = 4 }

/// <summary>
/// Durable record of every inbound notification, written before acking Graph. Powers reconciliation
/// and the "received vs published vs orchestrated vs finalized" audit so no order can be lost.
/// </summary>
public sealed class IntakeLedgerEntry
{
    public required string GraphMessageId { get; init; }
    public required string Mailbox { get; init; }
    public string? CustomerId { get; set; }
    public Priority Priority { get; set; }
    public Guid CorrelationId { get; set; }
    public IntakeStatus Status { get; set; } = IntakeStatus.Received;
    public DateTimeOffset ReceivedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? PublishedAtUtc { get; set; }
}
