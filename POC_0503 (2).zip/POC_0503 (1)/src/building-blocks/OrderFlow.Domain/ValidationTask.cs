namespace OrderFlow.Domain;

/// <summary>
/// A human validation task for an order. Ownership is modeled with assignment + claim fields so a
/// Manager can assign/delegate and a Reportee can self-claim from the pool.
/// </summary>
public sealed class ValidationTask
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public required Guid OrderId { get; init; }

    /// <summary>Durable orchestration instance to resume when this task is submitted.</summary>
    public required string OrchestrationInstanceId { get; init; }

    public TaskStatus Status { get; private set; } = TaskStatus.Pending;
    public Priority Priority { get; init; }
    public AssignmentKind AssignmentKind { get; private set; } = AssignmentKind.Pool;

    /// <summary>Intended owner (set by a Manager assignment/delegation).</summary>
    public string? AssignedToUserId { get; private set; }

    /// <summary>User actively working the task (self-claim or opened an assigned task).</summary>
    public string? ClaimedByUserId { get; private set; }

    /// <summary>The team scope (manager id) the task belongs to, for pool visibility.</summary>
    public string? TeamManagerId { get; set; }

    public DateTimeOffset CreatedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset SlaDueAtUtc { get; set; }
    public DateTimeOffset? CompletedAtUtc { get; private set; }
    public int EscalationCount { get; private set; }

    public byte[]? RowVersion { get; set; }

    // ----- behaviours (invariants enforced here; authorization is enforced in the app layer) -----

    public void Claim(string userId)
    {
        EnsureOpen();
        ClaimedByUserId = userId;
        if (AssignedToUserId is null)
        {
            AssignedToUserId = userId;
            AssignmentKind = AssignmentKind.SelfClaimed;
        }
        Status = TaskStatus.Claimed;
    }

    public void AssignTo(string userId)
    {
        EnsureOpen();
        AssignedToUserId = userId;
        ClaimedByUserId = null;
        AssignmentKind = AssignmentKind.Assigned;
        Status = TaskStatus.Assigned;
    }

    public void DelegateTo(string userId)
    {
        EnsureOpen();
        AssignedToUserId = userId;
        ClaimedByUserId = null;
        AssignmentKind = AssignmentKind.Delegated;
        Status = TaskStatus.Assigned;
    }

    public void Open(string userId)
    {
        EnsureOpen();
        ClaimedByUserId = userId;
        Status = TaskStatus.InProgress;
    }

    public void Complete()
    {
        if (Status is TaskStatus.Completed or TaskStatus.Cancelled)
            throw new InvalidOperationException($"Task {Id} is already {Status}.");
        Status = TaskStatus.Completed;
        CompletedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Escalate(string managerId, DateTimeOffset newSlaDueUtc)
    {
        Status = TaskStatus.Escalated;
        AssignedToUserId = managerId;
        ClaimedByUserId = null;
        AssignmentKind = AssignmentKind.Assigned;
        TeamManagerId = managerId;
        SlaDueAtUtc = newSlaDueUtc;
        EscalationCount++;
    }

    private void EnsureOpen()
    {
        if (Status is TaskStatus.Completed or TaskStatus.Cancelled)
            throw new InvalidOperationException($"Task {Id} is {Status} and cannot be modified.");
    }
}
