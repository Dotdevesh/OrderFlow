namespace OrderFlow.Domain;

/// <summary>An extracted order line item, with per-field confidence and correction tracking.</summary>
public sealed class OrderLine
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrderId { get; init; }

    public string? Sku { get; set; }
    public string? Description { get; set; }
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal => Quantity * UnitPrice;

    /// <summary>Extraction confidence for this line (min across its fields), 0..1.</summary>
    public double Confidence { get; set; } = 1.0;

    /// <summary>True if a human changed any field during validation.</summary>
    public bool IsCorrected { get; set; }
}
