namespace OrderFlow.Domain;

/// <summary>
/// An extracted header-level field (e.g. PONumber, OrderDate, ShipTo, Total). Keeps the original
/// extracted value alongside the human-validated value for audit.
/// </summary>
public sealed class OrderField
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrderId { get; init; }

    public required string Name { get; init; }
    public string? ExtractedValue { get; set; }
    public string? ValidatedValue { get; set; }
    public double Confidence { get; set; } = 1.0;

    /// <summary>Bounding box on the source PDF (JSON: page, polygon) for field highlighting in the UI.</summary>
    public string? BoundingRegionJson { get; set; }

    /// <summary>
    /// JSON array of alternative detected values for this field (value/confidence/label/region).
    /// Used for "localized" fields where the same entity type (e.g. a name/address) appears in
    /// multiple places and the human must pick the right one. See 11-extraction-accuracy.md.
    /// </summary>
    public string? CandidatesJson { get; set; }

    public bool IsCorrected => ValidatedValue is not null && ValidatedValue != ExtractedValue;
}
