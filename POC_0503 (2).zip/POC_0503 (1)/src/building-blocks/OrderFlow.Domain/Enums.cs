namespace OrderFlow.Domain;

/// <summary>Commercial tier of a customer; drives <see cref="Priority"/> and SLA.</summary>
public enum CustomerTier
{
    Platinum = 0,
    Gold = 1,
    Silver = 2
}

/// <summary>Runtime processing priority. Lower value = higher priority (maps to Service Bus subscription).</summary>
public enum Priority
{
    High = 0,
    Standard = 1,
    Low = 2
}

/// <summary>Lifecycle of an order aggregate.</summary>
public enum OrderStatus
{
    Received = 0,
    Stored = 1,
    Extracted = 2,
    PendingValidation = 3,
    Validated = 4,
    Finalized = 5,
    Failed = 6
}

/// <summary>Lifecycle of a human validation task.</summary>
public enum TaskStatus
{
    Pending = 0,
    Assigned = 1,
    Claimed = 2,
    InProgress = 3,
    Completed = 4,
    Escalated = 5,
    Cancelled = 6
}

/// <summary>Role of an Action Center user.</summary>
public enum UserRole
{
    Reportee = 0,
    Manager = 1
}

/// <summary>How a task came to be owned by a user.</summary>
public enum AssignmentKind
{
    Pool = 0,
    Assigned = 1,
    Delegated = 2,
    SelfClaimed = 3
}

/// <summary>Kind of document attached to an order.</summary>
public enum DocumentKind
{
    EmailBody = 0,
    Attachment = 1,
    ExtractionResult = 2
}
