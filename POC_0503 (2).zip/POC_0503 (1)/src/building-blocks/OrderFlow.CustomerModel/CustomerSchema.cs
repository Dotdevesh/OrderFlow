using OrderFlow.Contracts;

namespace OrderFlow.CustomerModel;

/// <summary>A single field the extractor should pull for a customer (derived from the entity class).</summary>
public sealed record ExtractionFieldPlan(
    string ExtractionField,
    string Label,
    string Type,
    bool Localized,
    bool Required);

/// <summary>The extraction plan for a customer: exactly the fields its entity class declares.</summary>
public sealed record ExtractionPlan(
    string CustomerId,
    string ModelId,
    IReadOnlyList<ExtractionFieldPlan> Fields);

/// <summary>
/// Everything derived from a customer entity class: the render template and the extraction plan —
/// the same declaration drives both.
/// </summary>
public sealed record CustomerSchema(
    string CustomerId,
    Type EntityType,
    FormTemplateDto Template,
    ExtractionPlan Plan);
