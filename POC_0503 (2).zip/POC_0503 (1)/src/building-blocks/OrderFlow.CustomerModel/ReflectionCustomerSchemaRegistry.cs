using System.Collections.Concurrent;
using System.Reflection;
using System.Text.RegularExpressions;
using OrderFlow.Contracts;

namespace OrderFlow.CustomerModel;

/// <summary>
/// Reflection-based registry: reads <see cref="FormGroupAttribute"/>, <see cref="ExtractionModelAttribute"/>,
/// <see cref="FormLineItemsAttribute"/>, and <see cref="FieldConfigAttribute"/> off each registered
/// customer entity class to build the render template and extraction plan once, then caches by type.
/// The same attributes drive rendering, extraction, binding, and validation.
/// </summary>
public sealed class ReflectionCustomerSchemaRegistry : ICustomerSchemaRegistry
{
    private readonly IReadOnlyDictionary<string, Type> _byCustomer;
    private readonly ConcurrentDictionary<string, CustomerSchema> _schemaCache = new(StringComparer.OrdinalIgnoreCase);

    public ReflectionCustomerSchemaRegistry(IReadOnlyDictionary<string, Type> byCustomer)
        => _byCustomer = new Dictionary<string, Type>(byCustomer, StringComparer.OrdinalIgnoreCase);

    public bool Has(string customerId) => _byCustomer.ContainsKey(customerId);

    public Type? Resolve(string customerId) => _byCustomer.TryGetValue(customerId, out var t) ? t : null;

    public CustomerSchema? Describe(string customerId)
    {
        if (!_byCustomer.TryGetValue(customerId, out var type))
            return null;

        return _schemaCache.GetOrAdd(customerId, id => Build(id, type));
    }

    public object? Bind(string customerId, IReadOnlyDictionary<string, string?> values)
    {
        if (!_byCustomer.TryGetValue(customerId, out var type))
            return null;

        var entity = Activator.CreateInstance(type)!;
        if (entity is CustomerOrderBase baseEntity)
            baseEntity.CustomerId = customerId;

        foreach (var (prop, cfg) in MappedProperties(type))
        {
            if (prop.PropertyType != typeof(string)) continue;

            var value = LookupValue(prop, cfg, values);
            if (value is not null)
                prop.SetValue(entity, value);
        }

        return entity;
    }

    public IReadOnlyList<string> Validate(string customerId, IReadOnlyDictionary<string, string?> values)
    {
        if (!_byCustomer.TryGetValue(customerId, out var type))
            return [];

        var errors = new List<string>();
        foreach (var (prop, cfg) in MappedProperties(type))
        {
            // Disabled / read-only fields cannot be edited by the user, so skip interactive validation.
            if (cfg.Disabled || cfg.ReadOnly) continue;

            var value = LookupValue(prop, cfg, values);
            if (cfg.Required && string.IsNullOrWhiteSpace(value))
            {
                errors.Add($"{cfg.Label} is required.");
                continue;
            }

            if (!string.IsNullOrWhiteSpace(cfg.Regex) && !string.IsNullOrWhiteSpace(value))
            {
                if (!Regex.IsMatch(value, cfg.Regex, RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(200)))
                    errors.Add($"{cfg.Label} does not match expected format ({cfg.Regex}).");
            }
        }

        return errors;
    }

    // ---- building ----------------------------------------------------------------------------

    private static CustomerSchema Build(string customerId, Type type)
    {
        var modelId = type.GetCustomAttribute<ExtractionModelAttribute>(inherit: true)?.ModelId
                      ?? "prebuilt-document";

        var groups = type.GetCustomAttributes<FormGroupAttribute>(inherit: true)
            .OrderBy(g => g.Order)
            .ToList();

        var fieldsByGroup = MappedProperties(type)
            .GroupBy(x => x.Config.Group, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Config.Order).ToList(), StringComparer.OrdinalIgnoreCase);

        var sections = new List<FormSectionDto>();
        foreach (var group in groups)
        {
            if (!fieldsByGroup.TryGetValue(group.Key, out var members) || members.Count == 0)
                continue; // render only groups this customer actually uses

            var fields = members.Select(m => ToFieldDef(m.Property, m.Config)).ToList();
            sections.Add(new FormSectionDto(group.Key, group.Title, "fields", fields, Columns: null));
        }

        var lineItemsAttr = type.GetCustomAttribute<FormLineItemsAttribute>(inherit: true);
        if (lineItemsAttr is not null)
        {
            sections.Add(new FormSectionDto(
                Key: "lines",
                Title: lineItemsAttr.Title,
                Type: "table",
                Fields: null,
                Columns:
                [
                    new FormColumnDef("sku", "SKU", "text", "Sku"),
                    new FormColumnDef("description", "Description", "text", "Description"),
                    new FormColumnDef("quantity", "Qty", "number", "Quantity"),
                    new FormColumnDef("unitPrice", "Unit Price", "number", "UnitPrice")
                ]));
        }

        var template = new FormTemplateDto(customerId, Version: 1, Name: type.Name, sections);

        var planFields = MappedProperties(type)
            .Where(x => !string.IsNullOrWhiteSpace(x.Config.ExtractionField))
            .OrderBy(x => x.Config.Order)
            .Select(x => new ExtractionFieldPlan(
                x.Config.ExtractionField!,
                x.Config.Label,
                x.Config.Type,
                x.Config.Localized,
                x.Config.Required))
            .ToList();

        var plan = new ExtractionPlan(customerId, modelId, planFields);

        return new CustomerSchema(customerId, type, template, plan);
    }

    private static string? LookupValue(PropertyInfo prop, FieldConfigAttribute cfg, IReadOnlyDictionary<string, string?> values)
    {
        if (cfg.ExtractionField is not null && values.TryGetValue(cfg.ExtractionField, out var v1))
            return v1;
        if (values.TryGetValue(Camel(prop.Name), out var v2))
            return v2;
        if (values.TryGetValue(prop.Name, out var v3))
            return v3;
        return null;
    }

    private static FormFieldDef ToFieldDef(PropertyInfo prop, FieldConfigAttribute cfg) => new(
        Key: Camel(prop.Name),
        Label: cfg.Label,
        Type: cfg.Type,
        Required: cfg.Required,
        ExtractionField: cfg.ExtractionField,
        AllowManual: true,
        Localized: cfg.Localized,
        Regex: cfg.Regex,
        Group: cfg.Group,
        Options: cfg.Options,
        ReadOnly: cfg.ReadOnly,
        Disabled: cfg.Disabled);

    private static IEnumerable<(PropertyInfo Property, FieldConfigAttribute Config)> MappedProperties(Type type)
        => type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Select(p => (Property: p, Config: p.GetCustomAttribute<FieldConfigAttribute>()!))
            .Where(x => x.Config is not null);

    private static string Camel(string name)
        => string.IsNullOrEmpty(name) || char.IsLower(name[0])
            ? name
            : char.ToLowerInvariant(name[0]) + name[1..];
}
