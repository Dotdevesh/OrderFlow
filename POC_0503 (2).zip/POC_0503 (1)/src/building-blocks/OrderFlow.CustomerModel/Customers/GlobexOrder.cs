namespace OrderFlow.CustomerModel.Customers;

/// <summary>Extended purchase-order entity for <c>globex</c> (all 6 PO groups + line items).</summary>
public sealed class GlobexOrder : PurchaseOrderBase
{
    [FieldConfig(Group = "header", Label = "PO Number", Order = 1, Required = true, ExtractionField = "PONumber", Regex = "^PO-\\d+$")]
    public string? PoNumber { get; set; }

    [FieldConfig(Group = "header", Label = "Order Date", Type = "date", Order = 2, Required = true, ExtractionField = "OrderDate")]
    public string? OrderDate { get; set; }

    [FieldConfig(Group = "header", Label = "Requested Delivery", Type = "date", Order = 3, ExtractionField = "RequestedDelivery")]
    public string? RequestedDelivery { get; set; }

    [FieldConfig(Group = "header", Label = "Currency", Type = "select", Order = 4, Required = true, Options = ["GBP", "USD", "EUR"], ExtractionField = "Currency")]
    public string? Currency { get; set; }

    [FieldConfig(Group = "header", Label = "Customer Reference", Order = 5, ExtractionField = "Reference")]
    public string? Reference { get; set; }

    [FieldConfig(Group = "soldTo", Label = "Sold-To Name", Order = 1, Required = true, Localized = true, ExtractionField = "SoldToName")]
    public string? SoldToName { get; set; }

    [FieldConfig(Group = "soldTo", Label = "Address line 1", Order = 2, Required = true, ExtractionField = "SoldToAddress1")]
    public string? SoldToAddress1 { get; set; }

    [FieldConfig(Group = "soldTo", Label = "City", Order = 3, Required = true, ExtractionField = "SoldToCity")]
    public string? SoldToCity { get; set; }

    [FieldConfig(Group = "soldTo", Label = "Country", Order = 4, Required = true, ExtractionField = "SoldToCountry")]
    public string? SoldToCountry { get; set; }

    [FieldConfig(Group = "shipTo", Label = "Ship-To Name", Order = 1, Required = true, Localized = true, ExtractionField = "ShipToName")]
    public string? ShipToName { get; set; }

    [FieldConfig(Group = "shipTo", Label = "Address line 1", Order = 2, Required = true, ExtractionField = "ShipToAddress1")]
    public string? ShipToAddress1 { get; set; }

    [FieldConfig(Group = "shipTo", Label = "City", Order = 3, Required = true, ExtractionField = "ShipToCity")]
    public string? ShipToCity { get; set; }

    [FieldConfig(Group = "shipTo", Label = "Postcode", Order = 4, Required = true, ExtractionField = "ShipToPostcode")]
    public string? ShipToPostcode { get; set; }

    [FieldConfig(Group = "billTo", Label = "Bill-To Name", Order = 1, Required = true, Localized = true, ExtractionField = "BillToName")]
    public string? BillToName { get; set; }

    [FieldConfig(Group = "billTo", Label = "VAT Number", Order = 2, ExtractionField = "BillToVat")]
    public string? BillToVat { get; set; }

    [FieldConfig(Group = "logistics", Label = "Incoterm", Type = "select", Order = 1, Required = true, Options = ["EXW", "FOB", "CIF", "DDP"], ExtractionField = "Incoterm")]
    public string? Incoterm { get; set; }

    [FieldConfig(Group = "logistics", Label = "Carrier", Order = 2, ExtractionField = "Carrier")]
    public string? Carrier { get; set; }

    [FieldConfig(Group = "totals", Label = "Subtotal", Type = "number", Order = 1, Required = true, ExtractionField = "Subtotal")]
    public string? Subtotal { get; set; }

    [FieldConfig(Group = "totals", Label = "Tax", Type = "number", Order = 2, ExtractionField = "Tax")]
    public string? Tax { get; set; }

    [FieldConfig(Group = "totals", Label = "Grand Total", Type = "number", Order = 3, Required = true, ExtractionField = "Total")]
    public string? Total { get; set; }
}
