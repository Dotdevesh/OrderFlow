namespace OrderFlow.CustomerModel.Customers;

/// <summary>
/// Customer entity for <c>first-national</c>. Uses all 5 master groups with a fuller property set.
/// </summary>
public sealed class FirstNationalTitleOrder : TitleInsuranceOrderBase
{
    [FieldConfig(Group = "order", Label = "File Number", Order = 1, Required = true, ExtractionField = "FileNumber", Regex = "^TI-\\d+$")]
    public string? FileNumber { get; set; }

    [FieldConfig(Group = "order", Label = "Order Date", Type = "date", Order = 2, Required = true, ExtractionField = "OrderDate")]
    public string? OrderDate { get; set; }

    [FieldConfig(Group = "order", Label = "Order Type", Type = "select", Order = 3, Options = ["Purchase", "Refinance", "Equity"], ExtractionField = "OrderType")]
    public string? OrderType { get; set; }

    [FieldConfig(Group = "order", Label = "Title Officer", Order = 4, ExtractionField = "TitleOfficer")]
    public string? TitleOfficer { get; set; }

    [FieldConfig(Group = "property", Label = "APN", Order = 1, Required = true, ExtractionField = "APN")]
    public string? Apn { get; set; }

    [FieldConfig(Group = "property", Label = "Property Address", Order = 2, Required = true, Localized = true, ExtractionField = "PropertyAddress")]
    public string? PropertyAddress { get; set; }

    [FieldConfig(Group = "property", Label = "City", Order = 3, ExtractionField = "PropertyCity")]
    public string? PropertyCity { get; set; }

    [FieldConfig(Group = "property", Label = "State", Order = 4, ExtractionField = "PropertyState")]
    public string? PropertyState { get; set; }

    [FieldConfig(Group = "property", Label = "ZIP", Order = 5, ExtractionField = "PropertyZip")]
    public string? PropertyZip { get; set; }

    [FieldConfig(Group = "property", Label = "County", Order = 6, ExtractionField = "PropertyCounty")]
    public string? PropertyCounty { get; set; }

    [FieldConfig(Group = "property", Label = "Legal Description", Type = "textarea", Order = 7, ExtractionField = "LegalDescription")]
    public string? LegalDescription { get; set; }

    [FieldConfig(Group = "buyer", Label = "Buyer Name", Order = 1, Required = true, Localized = true, ExtractionField = "BuyerName")]
    public string? BuyerName { get; set; }

    [FieldConfig(Group = "buyer", Label = "Vesting", Order = 2, ExtractionField = "BuyerVesting")]
    public string? BuyerVesting { get; set; }

    [FieldConfig(Group = "seller", Label = "Seller Name", Order = 1, Required = true, Localized = true, ExtractionField = "SellerName")]
    public string? SellerName { get; set; }

    [FieldConfig(Group = "seller", Label = "Vesting", Order = 2, ExtractionField = "SellerVesting")]
    public string? SellerVesting { get; set; }

    [FieldConfig(Group = "lender", Label = "Lender Name", Order = 1, Required = true, Localized = true, ExtractionField = "LenderName")]
    public string? LenderName { get; set; }

    [FieldConfig(Group = "lender", Label = "Loan Number", Order = 2, ExtractionField = "LoanNumber")]
    public string? LoanNumber { get; set; }

    [FieldConfig(Group = "lender", Label = "Loan Amount", Type = "number", Order = 3, Required = true, ExtractionField = "LoanAmount")]
    public string? LoanAmount { get; set; }

    [FieldConfig(Group = "lender", Label = "Policy Type", Type = "select", Order = 4, Options = ["ALTA Owner", "ALTA Loan", "Short-Form"], ExtractionField = "PolicyType")]
    public string? PolicyType { get; set; }

    [FieldConfig(Group = "lender", Label = "Coverage Amount", Type = "number", Order = 5, ExtractionField = "CoverageAmount")]
    public string? CoverageAmount { get; set; }

    [FieldConfig(Group = "lender", Label = "Premium", Type = "number", Order = 6, ExtractionField = "Premium")]
    public string? Premium { get; set; }
}
