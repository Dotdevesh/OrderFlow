namespace OrderFlow.CustomerModel.Customers;

/// <summary>Compact purchase-order entity for <c>acme</c>.</summary>
public sealed class AcmeOrder : PurchaseOrderBase
{
    [FieldConfig(Group = "header", Label = "PO Number", Order = 1, Required = true, ExtractionField = "PONumber", Regex = "^PO-\\d+$")]
    public string? PoNumber { get; set; }

    [FieldConfig(Group = "header", Label = "Order Date", Type = "date", Order = 2, Required = true, ExtractionField = "OrderDate")]
    public string? OrderDate { get; set; }

    [FieldConfig(Group = "shipTo", Label = "Ship-To Name", Order = 1, Required = true, Localized = true, ExtractionField = "ShipToName")]
    public string? ShipToName { get; set; }

    [FieldConfig(Group = "logistics", Label = "Incoterm", Type = "select", Order = 1, Options = ["EXW", "FOB", "CIF", "DDP"], ExtractionField = "Incoterm")]
    public string? Incoterm { get; set; }

    [FieldConfig(Group = "totals", Label = "Order Total", Type = "number", Order = 1, Required = true, ExtractionField = "Total")]
    public string? Total { get; set; }

    [FieldConfig(Group = "header", Label = "Notes", Type = "textarea", Order = 3)]
    public string? Notes { get; set; }
}
