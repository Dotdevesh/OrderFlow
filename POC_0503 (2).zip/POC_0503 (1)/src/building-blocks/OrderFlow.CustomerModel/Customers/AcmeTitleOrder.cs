namespace OrderFlow.CustomerModel.Customers;

/// <summary>
/// Customer entity for <c>acme-title</c>. Uses 3 of the 5 master groups. Each property carries its
/// own config (behaviour + Doc AI mapping). Doc AI values bind straight into these properties.
/// </summary>
public sealed class AcmeTitleOrder : TitleInsuranceOrderBase
{
    [FieldConfig(Group = "order", Label = "File Number", Order = 1, Required = true, ExtractionField = "FileNumber", Regex = "^TI-\\d+$")]
    public string? FileNumber { get; set; }

    [FieldConfig(Group = "order", Label = "Order Date", Type = "date", Order = 2, Required = true, ExtractionField = "OrderDate")]
    public string? OrderDate { get; set; }

    [FieldConfig(Group = "order", Label = "Order Type", Type = "select", Order = 3, ReadOnly = true, Options = ["Purchase", "Refinance", "Equity"], ExtractionField = "OrderType")]
    public string? OrderType { get; set; }

    [FieldConfig(Group = "order", Label = "Title Officer", Order = 4, Disabled = true, ExtractionField = "TitleOfficer")]
    public string? TitleOfficer { get; set; }

    [FieldConfig(Group = "property", Label = "APN", Order = 1, Required = true, ExtractionField = "APN")]
    public string? Apn { get; set; }

    [FieldConfig(Group = "property", Label = "Property Address", Order = 2, Localized = true, ExtractionField = "PropertyAddress")]
    public string? PropertyAddress { get; set; }

    [FieldConfig(Group = "property", Label = "City", Order = 3, ExtractionField = "PropertyCity")]
    public string? PropertyCity { get; set; }

    [FieldConfig(Group = "property", Label = "State", Order = 4, ExtractionField = "PropertyState")]
    public string? PropertyState { get; set; }

    [FieldConfig(Group = "property", Label = "ZIP", Order = 5, ExtractionField = "PropertyZip")]
    public string? PropertyZip { get; set; }

    [FieldConfig(Group = "lender", Label = "Lender Name", Order = 1, Required = true, Localized = true, ExtractionField = "LenderName")]
    public string? LenderName { get; set; }

    [FieldConfig(Group = "lender", Label = "Loan Amount", Type = "number", Order = 2, Required = true, ExtractionField = "LoanAmount")]
    public string? LoanAmount { get; set; }

    [FieldConfig(Group = "lender", Label = "Policy Type", Type = "select", Order = 3, Options = ["ALTA Owner", "ALTA Loan", "Short-Form"], ExtractionField = "PolicyType")]
    public string? PolicyType { get; set; }

    [FieldConfig(Group = "lender", Label = "Premium", Type = "number", Order = 4, ReadOnly = true, ExtractionField = "Premium")]
    public string? Premium { get; set; }
}
