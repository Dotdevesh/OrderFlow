namespace OrderFlow.CustomerModel.Customers;

/// <summary>Standard purchase-order entity for <c>initech</c> (and default/triage fallback).</summary>
public sealed class InitechOrder : PurchaseOrderBase
{
    [FieldConfig(Group = "header", Label = "PO Number", Order = 1, Required = true, ExtractionField = "PONumber", Regex = "^PO-\\d+$")]
    public string? PoNumber { get; set; }

    [FieldConfig(Group = "header", Label = "Order Date", Type = "date", Order = 2, Required = true, ExtractionField = "OrderDate")]
    public string? OrderDate { get; set; }

    [FieldConfig(Group = "shipTo", Label = "Ship-To Name", Order = 1, Required = true, Localized = true, ExtractionField = "ShipToName")]
    public string? ShipToName { get; set; }

    [FieldConfig(Group = "totals", Label = "Order Total", Type = "number", Order = 1, Required = true, ExtractionField = "Total")]
    public string? Total { get; set; }

    [FieldConfig(Group = "header", Label = "Expedite", Type = "checkbox", Order = 3, ExtractionField = "Expedite")]
    public string? Expedite { get; set; }
}
