namespace OrderFlow.CustomerModel;

/// <summary>
/// Declares a group (section) and its ordering on a customer entity class. Applied to the master
/// base class so all customer subclasses inherit the group catalog. Repeatable.
/// </summary>
[AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
public sealed class FormGroupAttribute(string key, string title, int order = 0) : Attribute
{
    public string Key { get; } = key;
    public string Title { get; } = title;
    public int Order { get; } = order;
}

/// <summary>
/// Specifies the Document Intelligence model id for a customer entity class (e.g.
/// <c>prebuilt-document</c> for title insurance or <c>prebuilt-invoice</c> for purchase orders).
/// Inherited from the master base unless overridden on a specific customer class.
/// </summary>
[AttributeUsage(AttributeTargets.Class, Inherited = true)]
public sealed class ExtractionModelAttribute(string modelId) : Attribute
{
    public string ModelId { get; } = modelId;
}

/// <summary>
/// Opts a customer entity class into a line-items table section in the rendered validation form
/// and extraction output (used by purchase-order customers, omitted for title insurance).
/// </summary>
[AttributeUsage(AttributeTargets.Class, Inherited = true)]
public sealed class FormLineItemsAttribute(string title = "Line items", int order = 99) : Attribute
{
    public string Title { get; } = title;
    public int Order { get; } = order;
}

/// <summary>
/// Declares how a customer entity property is configured: which group it belongs to, its UI type,
/// behaviour (required/readonly/disabled), and the Document Intelligence field it maps to. This
/// single declaration drives BOTH form rendering AND the extraction plan for that customer.
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class FieldConfigAttribute : Attribute
{
    public required string Group { get; init; }
    public required string Label { get; init; }
    public string Type { get; init; } = "text";          // text | number | date | select | textarea | checkbox
    public int Order { get; init; }
    public bool Required { get; init; }
    public bool ReadOnly { get; init; }
    public bool Disabled { get; init; }

    /// <summary>Name of the Document Intelligence field that feeds this property (also the OrderField name).</summary>
    public string? ExtractionField { get; init; }

    /// <summary>True when this entity appears in multiple places and needs candidate disambiguation.</summary>
    public bool Localized { get; init; }

    public string? Regex { get; init; }
    public string[]? Options { get; init; }
}
