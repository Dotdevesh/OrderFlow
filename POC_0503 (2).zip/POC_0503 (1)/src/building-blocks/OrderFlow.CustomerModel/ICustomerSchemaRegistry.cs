namespace OrderFlow.CustomerModel;

/// <summary>
/// Resolves a customer id to its code-first entity class and the schema derived from it
/// (render template + extraction plan). Also binds Document Intelligence values onto a typed entity
/// and validates submissions against the class attributes.
/// </summary>
public interface ICustomerSchemaRegistry
{
    /// <summary>True when a customer has a code-first entity class registered.</summary>
    bool Has(string customerId);

    /// <summary>The CLR entity type for a customer, or null when none is registered.</summary>
    Type? Resolve(string customerId);

    /// <summary>The full schema (template + extraction plan) for a customer, or null.</summary>
    CustomerSchema? Describe(string customerId);

    /// <summary>
    /// Creates a typed entity instance for the customer and binds the supplied extracted values
    /// (keyed by extraction-field name or property camelCase key) onto its mapped properties.
    /// </summary>
    object? Bind(string customerId, IReadOnlyDictionary<string, string?> values);

    /// <summary>
    /// Validates submitted field values (keyed by extraction-field name or property camelCase key)
    /// against the customer class's <see cref="FieldConfigAttribute"/> rules (Required, Regex).
    /// </summary>
    IReadOnlyList<string> Validate(string customerId, IReadOnlyDictionary<string, string?> values);
}
