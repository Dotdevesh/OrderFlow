using Microsoft.Extensions.DependencyInjection;
using OrderFlow.CustomerModel.Customers;

namespace OrderFlow.CustomerModel;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers the code-first customer schema registry for all supported customers.
    /// Add a new customer by writing a class deriving from <see cref="TitleInsuranceOrderBase"/>
    /// or <see cref="PurchaseOrderBase"/> and mapping its id here.
    /// </summary>
    public static IServiceCollection AddCustomerSchemas(this IServiceCollection services)
    {
        var map = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase)
        {
            ["acme-title"] = typeof(AcmeTitleOrder),
            ["first-national"] = typeof(FirstNationalTitleOrder),
            ["acme"] = typeof(AcmeOrder),
            ["globex"] = typeof(GlobexOrder),
            ["initech"] = typeof(InitechOrder),
            ["triage"] = typeof(InitechOrder),
        };

        services.AddSingleton<ICustomerSchemaRegistry>(_ => new ReflectionCustomerSchemaRegistry(map));
        return services;
    }
}
