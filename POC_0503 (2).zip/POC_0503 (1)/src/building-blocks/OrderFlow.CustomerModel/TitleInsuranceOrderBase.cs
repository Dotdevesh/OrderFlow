namespace OrderFlow.CustomerModel;

/// <summary>
/// Common marker base for all code-first customer order entities.
/// </summary>
public abstract class CustomerOrderBase
{
    /// <summary>The customer this entity instance belongs to (set during binding).</summary>
    public string? CustomerId { get; set; }
}

/// <summary>
/// MASTER class for title-insurance customers: declares the full set of <b>groups</b> and
/// the Document Intelligence model. Subclasses inherit the group catalog and declare only the
/// <b>mapped properties</b> they use.
/// </summary>
[ExtractionModel("prebuilt-document")]
[FormGroup("order", "Order / File", 1)]
[FormGroup("property", "Property", 2)]
[FormGroup("buyer", "Buyer / Borrower", 3)]
[FormGroup("seller", "Seller", 4)]
[FormGroup("lender", "Lender / Loan", 5)]
public abstract class TitleInsuranceOrderBase : CustomerOrderBase;

/// <summary>
/// MASTER class for purchase-order customers: declares PO groups, invoice model, and line items.
/// </summary>
[ExtractionModel("prebuilt-invoice")]
[FormGroup("header", "Order header", 1)]
[FormGroup("soldTo", "Sold-To party", 2)]
[FormGroup("shipTo", "Ship-To party", 3)]
[FormGroup("billTo", "Bill-To party", 4)]
[FormGroup("logistics", "Logistics", 5)]
[FormGroup("totals", "Totals", 6)]
[FormLineItems("Line items", 7)]
public abstract class PurchaseOrderBase : CustomerOrderBase;
