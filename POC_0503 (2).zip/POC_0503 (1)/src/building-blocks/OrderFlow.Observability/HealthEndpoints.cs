using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using OrderFlow.BuildingBlocks.Health;

namespace OrderFlow.Observability;

/// <summary>Maps the health contract every OrderFlow host exposes.</summary>
public static class HealthEndpoints
{
    /// <summary>
    /// Adds <c>/health/live</c> (process is up), <c>/health/ready</c> (dependencies answer), and
    /// <c>/health</c>, which stays an alias for liveness so existing probes keep working.
    /// </summary>
    public static IEndpointRouteBuilder MapOrderFlowHealthEndpoints(this IEndpointRouteBuilder endpoints, string serviceName)
    {
        endpoints.MapGet("/health/live", async (HealthCheckService health, CancellationToken ct) =>
        {
            var (payload, statusCode) = await OrderFlowHealthChecks.EvaluateAsync(health, serviceName, HealthTags.Live, ct);
            return Results.Json(payload, statusCode: statusCode);
        }).WithTags("Health").AllowAnonymous();

        endpoints.MapGet("/health/ready", async (HealthCheckService health, CancellationToken ct) =>
        {
            var (payload, statusCode) = await OrderFlowHealthChecks.EvaluateAsync(health, serviceName, HealthTags.Ready, ct);
            return Results.Json(payload, statusCode: statusCode);
        }).WithTags("Health").AllowAnonymous();

        endpoints.MapGet("/health", async (HealthCheckService health, CancellationToken ct) =>
        {
            var (payload, statusCode) = await OrderFlowHealthChecks.EvaluateAsync(health, serviceName, HealthTags.Live, ct);
            return Results.Json(payload, statusCode: statusCode);
        }).WithTags("Health").AllowAnonymous();

        return endpoints;
    }
}
