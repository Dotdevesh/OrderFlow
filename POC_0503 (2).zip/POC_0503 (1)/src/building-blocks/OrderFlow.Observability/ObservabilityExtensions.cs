using Azure.Monitor.OpenTelemetry.Exporter;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using OrderFlow.BuildingBlocks;

namespace OrderFlow.Observability;

/// <summary>
/// Single entry point for OrderFlow telemetry. Every service calls
/// <see cref="AddOrderFlowObservability{TBuilder}"/> with its own name and gets the same traces,
/// metrics, and structured logs, exported to Application Insights, an OTLP collector, the console,
/// or any combination the configuration asks for.
/// </summary>
public static class ObservabilityExtensions
{
    public static TBuilder AddOrderFlowObservability<TBuilder>(this TBuilder builder, string serviceName)
        where TBuilder : IHostApplicationBuilder
    {
        var options = ResolveOptions(builder, serviceName);
        builder.Services.AddSingleton(Options.Create(options));

        // Azure SDK clients emit spans only when this switch is on.
        AppContext.SetSwitch("Azure.Experimental.EnableActivitySource", true);

        builder.Services.AddSingleton<OrderFlowMetrics>();
        builder.Services.TryAddTransient<CorrelationIdPropagationHandler>();

        builder.Logging.AddOpenTelemetry(logging =>
        {
            logging.IncludeScopes = true;
            logging.IncludeFormattedMessage = true;
            logging.ParseStateValues = true;
        });

        builder.Services.AddOpenTelemetry()
            .ConfigureResource(resource => resource
                .AddService(
                    serviceName: options.ServiceName,
                    serviceVersion: options.ServiceVersion,
                    serviceInstanceId: System.Environment.MachineName)
                .AddAttributes([new KeyValuePair<string, object>("deployment.environment", options.Environment ?? "unknown")]))
            .WithTracing(tracing =>
            {
                tracing
                    .SetSampler(new ParentBasedSampler(new TraceIdRatioBasedSampler(options.TraceSamplingRatio)))
                    .AddSource(Telemetry.ActivitySourceName)
                    .AddSource("Azure.*")
                    .AddSource("Microsoft.Azure.Functions.Worker")
                    .AddSource("DurableTask.Core")
                    .AddAspNetCoreInstrumentation(o => o.RecordException = true)
                    .AddHttpClientInstrumentation(o => o.RecordException = true)
                    .AddSqlClientInstrumentation(o => o.RecordException = true);

                foreach (var source in options.AdditionalActivitySources)
                    tracing.AddSource(source);

                ApplyTraceExporters(tracing, options);
            })
            .WithMetrics(metrics =>
            {
                metrics
                    .AddMeter(Telemetry.MeterName)
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation();

                if (options.EnableRuntimeMetrics)
                    metrics.AddRuntimeInstrumentation();

                ApplyMetricExporters(metrics, options);
            })
            .WithLogging(logging => ApplyLogExporters(logging, options));

        return builder;
    }

    /// <summary>
    /// Puts correlation id handling in front of the pipeline so the id is in scope for authentication,
    /// authorization, and endpoint logs alike.
    /// </summary>
    public static IApplicationBuilder UseOrderFlowCorrelationId(this IApplicationBuilder app)
        => app.UseMiddleware<CorrelationIdMiddleware>();

    private static ObservabilityOptions ResolveOptions(IHostApplicationBuilder builder, string serviceName)
    {
        var options = new ObservabilityOptions();
        builder.Configuration.GetSection(ObservabilityOptions.Section).Bind(options);

        options.ServiceName = serviceName;
        options.Environment ??= builder.Environment.EnvironmentName;
        options.ServiceVersion ??= typeof(ObservabilityExtensions).Assembly.GetName().Version?.ToString();

        if (string.IsNullOrWhiteSpace(options.ApplicationInsightsConnectionString))
        {
            options.ApplicationInsightsConnectionString =
                builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"]
                ?? builder.Configuration["ApplicationInsights:ConnectionString"];
        }

        // With no backend configured anywhere, fall back to stdout rather than dropping telemetry silently.
        if (string.IsNullOrWhiteSpace(options.ApplicationInsightsConnectionString)
            && string.IsNullOrWhiteSpace(options.OtlpEndpoint))
        {
            options.EnableConsoleExporter = true;
        }

        return options;
    }

    private static void ApplyTraceExporters(TracerProviderBuilder tracing, ObservabilityOptions options)
    {
        if (!string.IsNullOrWhiteSpace(options.ApplicationInsightsConnectionString))
            tracing.AddAzureMonitorTraceExporter(o => o.ConnectionString = options.ApplicationInsightsConnectionString);

        if (!string.IsNullOrWhiteSpace(options.OtlpEndpoint))
            tracing.AddOtlpExporter(o => o.Endpoint = new Uri(options.OtlpEndpoint));

        if (options.EnableConsoleExporter)
            tracing.AddConsoleExporter();
    }

    private static void ApplyMetricExporters(MeterProviderBuilder metrics, ObservabilityOptions options)
    {
        if (!string.IsNullOrWhiteSpace(options.ApplicationInsightsConnectionString))
            metrics.AddAzureMonitorMetricExporter(o => o.ConnectionString = options.ApplicationInsightsConnectionString);

        if (!string.IsNullOrWhiteSpace(options.OtlpEndpoint))
            metrics.AddOtlpExporter(o => o.Endpoint = new Uri(options.OtlpEndpoint));
    }

    private static void ApplyLogExporters(LoggerProviderBuilder logging, ObservabilityOptions options)
    {
        if (!string.IsNullOrWhiteSpace(options.ApplicationInsightsConnectionString))
            logging.AddAzureMonitorLogExporter(o => o.ConnectionString = options.ApplicationInsightsConnectionString);

        if (!string.IsNullOrWhiteSpace(options.OtlpEndpoint))
            logging.AddOtlpExporter(o => o.Endpoint = new Uri(options.OtlpEndpoint));
    }
}
