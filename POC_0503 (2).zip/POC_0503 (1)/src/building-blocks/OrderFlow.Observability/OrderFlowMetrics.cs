using System.Diagnostics;
using System.Diagnostics.Metrics;
using OrderFlow.BuildingBlocks;

namespace OrderFlow.Observability;

/// <summary>The single <see cref="ActivitySource"/> OrderFlow code creates spans from.</summary>
public static class OrderFlowActivity
{
    public static readonly ActivitySource Source = new(Telemetry.ActivitySourceName);

    /// <summary>Starts a span already tagged with the correlation id in scope.</summary>
    public static Activity? Start(string name, ActivityKind kind = ActivityKind.Internal)
    {
        var activity = Source.StartActivity(name, kind);
        if (activity is not null && CorrelationContext.Current is { } correlationId)
        {
            activity.SetBaggage(CorrelationContext.BaggageKey, correlationId);
            activity.SetTag(CorrelationContext.LogPropertyName, correlationId);
        }
        return activity;
    }
}

/// <summary>
/// Business counters that answer the questions the dashboards ask: how many orders arrived, how many
/// breached SLA, how many notifications went out. Registered as a singleton by
/// <see cref="ObservabilityExtensions.AddOrderFlowObservability{TBuilder}"/>.
/// </summary>
public sealed class OrderFlowMetrics : IDisposable
{
    private readonly Meter _meter;

    public OrderFlowMetrics(IMeterFactory meterFactory)
    {
        _meter = meterFactory.Create(Telemetry.MeterName);

        OrdersReceived = _meter.CreateCounter<long>("orderflow.orders.received", "order", "Order emails accepted from Microsoft Graph.");
        OrdersFinalized = _meter.CreateCounter<long>("orderflow.orders.finalized", "order", "Orders finalized after human validation.");
        ValidationTasksCreated = _meter.CreateCounter<long>("orderflow.validation_tasks.created", "task", "Validation tasks routed to a human.");
        SlaBreaches = _meter.CreateCounter<long>("orderflow.sla.breaches", "breach", "SLA timers that fired before a human submitted.");
        NotificationsSent = _meter.CreateCounter<long>("orderflow.notifications.sent", "notification", "Notification emails accepted by the provider.");
        NotificationsFailed = _meter.CreateCounter<long>("orderflow.notifications.failed", "notification", "Notification emails the provider rejected.");
        ExtractionDuration = _meter.CreateHistogram<double>("orderflow.extraction.duration", "ms", "Document Intelligence extraction latency.");
    }

    public Counter<long> OrdersReceived { get; }
    public Counter<long> OrdersFinalized { get; }
    public Counter<long> ValidationTasksCreated { get; }
    public Counter<long> SlaBreaches { get; }
    public Counter<long> NotificationsSent { get; }
    public Counter<long> NotificationsFailed { get; }
    public Histogram<double> ExtractionDuration { get; }

    public void Dispose() => _meter.Dispose();
}
