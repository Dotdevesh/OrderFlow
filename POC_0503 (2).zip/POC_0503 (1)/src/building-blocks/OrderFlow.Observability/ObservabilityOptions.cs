namespace OrderFlow.Observability;

/// <summary>
/// One place to configure where every OrderFlow service sends traces, metrics, and logs. Bound from
/// the <c>Observability</c> configuration section; each service only supplies its own name.
/// </summary>
public sealed class ObservabilityOptions
{
    public const string Section = "Observability";

    /// <summary>Set by the calling service; appears as <c>service.name</c> on every signal.</summary>
    public string ServiceName { get; set; } = "orderflow-service";

    public string? ServiceVersion { get; set; }

    /// <summary>Logical deployment, e.g. <c>dev</c> or <c>prod</c>. Emitted as <c>deployment.environment</c>.</summary>
    public string? Environment { get; set; }

    /// <summary>
    /// Application Insights connection string. Falls back to the <c>APPLICATIONINSIGHTS_CONNECTION_STRING</c>
    /// environment variable. When empty, the Azure Monitor exporter is not registered.
    /// </summary>
    public string? ApplicationInsightsConnectionString { get; set; }

    /// <summary>OTLP collector endpoint, e.g. <c>http://otel-collector:4317</c>. Optional, and additive to Azure Monitor.</summary>
    public string? OtlpEndpoint { get; set; }

    /// <summary>Head sampling ratio between 0 and 1. 1 keeps every trace, which is the default for a POC.</summary>
    public double TraceSamplingRatio { get; set; } = 1.0;

    /// <summary>Writes signals to stdout. Useful in Docker Compose, where there is no Application Insights.</summary>
    public bool EnableConsoleExporter { get; set; }

    public bool EnableRuntimeMetrics { get; set; } = true;

    /// <summary>Extra <see cref="System.Diagnostics.ActivitySource"/> names to subscribe to.</summary>
    public IList<string> AdditionalActivitySources { get; set; } = [];
}
