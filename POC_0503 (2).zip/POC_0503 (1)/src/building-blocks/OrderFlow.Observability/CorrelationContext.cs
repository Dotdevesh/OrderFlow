using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using OrderFlow.BuildingBlocks;

namespace OrderFlow.Observability;

/// <summary>
/// Carries the OrderFlow correlation id across HTTP hops, Service Bus messages, and Durable activities.
/// The id rides on <see cref="Activity"/> baggage so it survives async flow and is attached to every
/// log record and span the service emits.
/// </summary>
public static class CorrelationContext
{
    public const string BaggageKey = "correlation.id";
    public const string LogPropertyName = "CorrelationId";

    private static readonly AsyncLocal<string?> Ambient = new();

    /// <summary>The correlation id in scope, or <see langword="null"/> outside a correlated operation.</summary>
    public static string? Current => Activity.Current?.GetBaggageItem(BaggageKey) ?? Ambient.Value;

    /// <summary>
    /// Adopts <paramref name="candidate"/> as the correlation id, keeps the one already in scope, or
    /// mints a new one. Always returns the id now in effect.
    /// </summary>
    public static string Ensure(string? candidate = null)
    {
        var id = !string.IsNullOrWhiteSpace(candidate)
            ? candidate!
            : Current ?? Guid.NewGuid().ToString("N");

        Activity.Current?.SetBaggage(BaggageKey, id);
        Activity.Current?.SetTag(LogPropertyName, id);
        Ambient.Value = id;
        return id;
    }
}

/// <summary>
/// Reads <c>x-correlation-id</c> off the request (or mints one), puts it on the ambient activity and
/// the log scope, and echoes it back so callers can quote it in a support ticket.
/// </summary>
public sealed class CorrelationIdMiddleware(RequestDelegate next, ILogger<CorrelationIdMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var incoming = context.Request.Headers[Telemetry.CorrelationIdHeader].FirstOrDefault();
        var correlationId = CorrelationContext.Ensure(incoming);

        context.Response.Headers[Telemetry.CorrelationIdHeader] = correlationId;

        using var scope = logger.BeginScope(new Dictionary<string, object>
        {
            [CorrelationContext.LogPropertyName] = correlationId
        });

        await next(context);
    }
}

/// <summary>Stamps outbound service-to-service calls with the correlation id currently in scope.</summary>
public sealed class CorrelationIdPropagationHandler : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        if (!request.Headers.Contains(Telemetry.CorrelationIdHeader) && CorrelationContext.Current is { } correlationId)
            request.Headers.TryAddWithoutValidation(Telemetry.CorrelationIdHeader, correlationId);

        return base.SendAsync(request, cancellationToken);
    }
}
