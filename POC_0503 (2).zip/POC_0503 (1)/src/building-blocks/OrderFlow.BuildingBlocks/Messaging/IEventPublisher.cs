using OrderFlow.Domain;

namespace OrderFlow.BuildingBlocks.Messaging;

/// <summary>Publishes integration events to the Service Bus topic with routing properties.</summary>
public interface IEventPublisher
{
    /// <param name="payload">The event object (serialized as JSON).</param>
    /// <param name="messageId">Used for duplicate detection (e.g. the Graph message id).</param>
    /// <param name="correlationId">End-to-end correlation id.</param>
    /// <param name="customerId">Customer the event belongs to.</param>
    /// <param name="priority">Routing priority (selects the subscription via a SQL filter).</param>
    /// <param name="sessionId">Optional Service Bus session id (e.g. customer id) for ordered processing.</param>
    Task PublishAsync<T>(
        T payload,
        string messageId,
        Guid correlationId,
        string customerId,
        Priority priority,
        string? sessionId = null,
        CancellationToken ct = default);
}
