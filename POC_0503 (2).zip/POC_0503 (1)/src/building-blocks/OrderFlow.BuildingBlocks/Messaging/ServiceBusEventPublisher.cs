using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Logging;
using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.BuildingBlocks.Messaging;

/// <summary>Service Bus implementation that stamps routing properties used by priority subscriptions.</summary>
public sealed class ServiceBusEventPublisher(
    ServiceBusClient client,
    ILogger<ServiceBusEventPublisher> logger) : IEventPublisher
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task PublishAsync<T>(
        T payload,
        string messageId,
        Guid correlationId,
        string customerId,
        Priority priority,
        string? sessionId = null,
        CancellationToken ct = default)
    {
        Guard.NotNull(payload);
        Guard.NotNullOrWhiteSpace(messageId);

        var sender = client.CreateSender(Topics.Orders);
        var message = new ServiceBusMessage(BinaryData.FromObjectAsJson(payload, JsonOptions))
        {
            MessageId = messageId,                 // enables duplicate detection
            CorrelationId = correlationId.ToString(),
            ContentType = "application/json",
            Subject = typeof(T).Name,
            SessionId = sessionId
        };
        message.ApplicationProperties[MessageProperties.Priority] = (int)priority;
        message.ApplicationProperties[MessageProperties.CustomerId] = customerId;
        message.ApplicationProperties[MessageProperties.CorrelationId] = correlationId.ToString();
        message.ApplicationProperties[MessageProperties.EventType] = typeof(T).Name;
        message.ApplicationProperties[MessageProperties.SchemaVersion] = "1.0";

        await sender.SendMessageAsync(message, ct);
        logger.LogInformation(
            "Published {EventType} msgId={MessageId} customer={CustomerId} priority={Priority} corr={CorrelationId}",
            typeof(T).Name, messageId, customerId, priority, correlationId);
    }
}
