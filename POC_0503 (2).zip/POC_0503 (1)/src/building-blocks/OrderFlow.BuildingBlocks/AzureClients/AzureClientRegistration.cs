using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using OrderFlow.BuildingBlocks.Storage;

namespace OrderFlow.BuildingBlocks.AzureClients;

/// <summary>
/// Registers Azure SDK clients so that every service resolves credentials the same way: an endpoint
/// plus a token credential when one is configured, otherwise a connection string or emulator.
/// </summary>
public static class AzureClientRegistration
{
    public static IServiceCollection AddOrderFlowAzureCredentials(this IServiceCollection services)
    {
        services.TryAddSingleton<IAzureCredentialFactory, AzureCredentialFactory>();
        return services;
    }

    /// <summary>
    /// Registers <see cref="BlobServiceClient"/> from <c>&lt;section&gt;:BlobEndpoint</c> with a token
    /// credential, falling back to <c>&lt;section&gt;:ConnectionString</c>, <c>ConnectionStrings:&lt;section&gt;</c>,
    /// and finally the Azurite development account.
    /// </summary>
    public static IServiceCollection AddOrderFlowBlobServiceClient(this IServiceCollection services, string section = "Storage")
    {
        services.AddOrderFlowAzureCredentials();
        services.TryAddSingleton(sp =>
        {
            var cfg = sp.GetRequiredService<IConfiguration>();
            var endpoint = cfg[$"{section}:BlobEndpoint"];
            var credential = sp.GetRequiredService<IAzureCredentialFactory>().Create(section);

            if (!string.IsNullOrWhiteSpace(endpoint) && credential is not null)
                return new BlobServiceClient(new Uri(endpoint), credential);

            return new BlobServiceClient(ResolveConnectionString(cfg, section) ?? "UseDevelopmentStorage=true");
        });
        return services;
    }

    /// <summary>Registers <see cref="BlobServiceClient"/> and the <see cref="IBlobDocumentStore"/> over it.</summary>
    public static IServiceCollection AddOrderFlowBlobDocumentStore(this IServiceCollection services, string section = "Storage")
    {
        services.AddOrderFlowBlobServiceClient(section);
        services.TryAddSingleton<IBlobDocumentStore>(sp => new BlobDocumentStore(
            sp.GetRequiredService<BlobServiceClient>(),
            sp.GetRequiredService<IConfiguration>()[$"{section}:Container"] ?? "order-documents",
            sp.GetRequiredService<ILogger<BlobDocumentStore>>()));
        return services;
    }

    /// <summary>
    /// Registers <see cref="ServiceBusClient"/> from <c>&lt;section&gt;:FullyQualifiedNamespace</c> with a
    /// token credential, or from a connection string. Returns <see langword="false"/> when neither is
    /// configured, so callers can leave the publisher unregistered rather than fail at startup.
    /// </summary>
    public static bool TryAddOrderFlowServiceBusClient(this IServiceCollection services, IConfiguration cfg, string section = "ServiceBus")
    {
        var fqns = cfg[$"{section}:FullyQualifiedNamespace"];
        var connectionString = ResolveConnectionString(cfg, section);

        if (string.IsNullOrWhiteSpace(fqns) && string.IsNullOrWhiteSpace(connectionString))
            return false;

        services.AddOrderFlowAzureCredentials();
        services.TryAddSingleton(sp =>
        {
            var credential = sp.GetRequiredService<IAzureCredentialFactory>().Create(section);
            return !string.IsNullOrWhiteSpace(fqns) && credential is not null
                ? new ServiceBusClient(fqns, credential)
                : new ServiceBusClient(connectionString);
        });
        return true;
    }

    /// <summary>Same as <see cref="TryAddOrderFlowServiceBusClient"/>, but falls back to the local emulator connection string.</summary>
    public static IServiceCollection AddOrderFlowServiceBusClient(this IServiceCollection services, IConfiguration cfg, string section = "ServiceBus")
    {
        services.AddOrderFlowAzureCredentials();
        services.TryAddSingleton(sp =>
        {
            var fqns = cfg[$"{section}:FullyQualifiedNamespace"];
            var credential = sp.GetRequiredService<IAzureCredentialFactory>().Create(section);
            return !string.IsNullOrWhiteSpace(fqns) && credential is not null
                ? new ServiceBusClient(fqns, credential)
                : new ServiceBusClient(ResolveConnectionString(cfg, section));
        });
        return services;
    }

    private static string? ResolveConnectionString(IConfiguration cfg, string section)
        => cfg[$"{section}:ConnectionString"]
           ?? cfg.GetConnectionString(section)
           ?? cfg[section];
}
