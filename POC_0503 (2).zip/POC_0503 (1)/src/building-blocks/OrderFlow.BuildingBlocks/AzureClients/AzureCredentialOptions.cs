namespace OrderFlow.BuildingBlocks.AzureClients;

/// <summary>How a service authenticates to an Azure data-plane resource.</summary>
public enum AzureCredentialMode
{
    /// <summary>Walk the <c>DefaultAzureCredential</c> chain: environment, workload identity, managed identity, Azure CLI, Visual Studio.</summary>
    Default = 0,

    /// <summary>Managed identity only. System-assigned, or user-assigned when <see cref="AzureCredentialOptions.ClientId"/> is set.</summary>
    ManagedIdentity,

    /// <summary>Entra workload identity federation, for federated credentials on AKS.</summary>
    WorkloadIdentity,

    /// <summary>Confidential client using tenant id, client id, and a client secret.</summary>
    ClientSecret,

    /// <summary>The signed-in Azure CLI user. Developer machines only.</summary>
    AzureCli,

    /// <summary>No token credential. The resource is reached with a connection string or a local emulator.</summary>
    ConnectionString
}

/// <summary>
/// Credential settings for one Azure resource. Bound from the global <c>Azure:Credential</c> section,
/// then overridden by the resource's own <c>&lt;Resource&gt;:Credential</c> section, so a service can use
/// its user-assigned identity for Service Bus while still reaching Blob storage through an emulator.
/// </summary>
public sealed class AzureCredentialOptions
{
    public const string Section = "Azure:Credential";

    public AzureCredentialMode Mode { get; set; } = AzureCredentialMode.Default;

    /// <summary>User-assigned managed identity client id, or the app registration client id for <see cref="AzureCredentialMode.ClientSecret"/>.</summary>
    public string? ClientId { get; set; }

    public string? TenantId { get; set; }

    /// <summary>Key Vault reference in Azure. Prefer a managed identity mode wherever the host supports one.</summary>
    public string? ClientSecret { get; set; }

    /// <summary>Sovereign or national cloud authority, e.g. <c>https://login.microsoftonline.us/</c>.</summary>
    public string? AuthorityHost { get; set; }

    public AzureCredentialOptions Clone() => (AzureCredentialOptions)MemberwiseClone();
}
