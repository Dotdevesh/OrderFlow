using System.Collections.Concurrent;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace OrderFlow.BuildingBlocks.AzureClients;

/// <summary>
/// Builds the <see cref="TokenCredential"/> a service uses for an Azure resource, from configuration
/// rather than from code, so the same build runs against a connection string locally, a user-assigned
/// managed identity in Azure, and a client secret in a hybrid environment.
/// </summary>
public interface IAzureCredentialFactory
{
    /// <summary>Reads <c>Azure:Credential</c>, then overlays <c>&lt;resourceSection&gt;:Credential</c>.</summary>
    AzureCredentialOptions Resolve(string? resourceSection = null);

    /// <summary>Returns <see langword="null"/> when the resolved mode is <see cref="AzureCredentialMode.ConnectionString"/>.</summary>
    TokenCredential? Create(string? resourceSection = null);

    TokenCredential? Create(AzureCredentialOptions options);

    /// <summary>Throws when the resource is configured for connection-string access but a token credential is required.</summary>
    TokenCredential CreateRequired(string? resourceSection = null);
}

public sealed class AzureCredentialFactory(
    IConfiguration configuration,
    ILogger<AzureCredentialFactory> logger) : IAzureCredentialFactory
{
    private readonly ConcurrentDictionary<string, TokenCredential?> _bySection = new(StringComparer.OrdinalIgnoreCase);

    public AzureCredentialOptions Resolve(string? resourceSection = null)
    {
        var options = new AzureCredentialOptions();
        Overlay(options, configuration.GetSection(AzureCredentialOptions.Section));

        if (!string.IsNullOrWhiteSpace(resourceSection))
            Overlay(options, configuration.GetSection($"{resourceSection}:Credential"));

        return options;
    }

    // Hand-rolled rather than IConfiguration.Bind because blank values must not overwrite what the
    // global section already supplied: shipped example settings leave every key present but empty,
    // and binding those would silently erase the tenant and client id an operator set globally.
    private static void Overlay(AzureCredentialOptions options, IConfigurationSection section)
    {
        if (!section.Exists())
            return;

        var mode = section["Mode"];
        if (!string.IsNullOrWhiteSpace(mode))
        {
            if (!Enum.TryParse<AzureCredentialMode>(mode, ignoreCase: true, out var parsed))
            {
                throw new InvalidOperationException(
                    $"'{section.Path}:Mode' is '{mode}'. Expected one of: {string.Join(", ", Enum.GetNames<AzureCredentialMode>())}.");
            }
            options.Mode = parsed;
        }

        options.ClientId = Prefer(section["ClientId"], options.ClientId);
        options.TenantId = Prefer(section["TenantId"], options.TenantId);
        options.ClientSecret = Prefer(section["ClientSecret"], options.ClientSecret);
        options.AuthorityHost = Prefer(section["AuthorityHost"], options.AuthorityHost);
    }

    private static string? Prefer(string? candidate, string? current)
        => string.IsNullOrWhiteSpace(candidate) ? current : candidate;

    public TokenCredential? Create(string? resourceSection = null)
        => _bySection.GetOrAdd(resourceSection ?? string.Empty, section => Create(Resolve(section)));

    public TokenCredential CreateRequired(string? resourceSection = null)
        => Create(resourceSection)
           ?? throw new InvalidOperationException(
               $"'{resourceSection ?? AzureCredentialOptions.Section}' is configured for {nameof(AzureCredentialMode.ConnectionString)} access, " +
               "but a token credential is required here. Set a credential mode that issues tokens.");

    public TokenCredential? Create(AzureCredentialOptions options)
    {
        var authorityHost = string.IsNullOrWhiteSpace(options.AuthorityHost) ? null : new Uri(options.AuthorityHost);

        switch (options.Mode)
        {
            case AzureCredentialMode.ConnectionString:
                return null;

            case AzureCredentialMode.ManagedIdentity:
                logger.LogInformation("Azure credential: managed identity ({Kind}).",
                    string.IsNullOrWhiteSpace(options.ClientId) ? "system-assigned" : $"user-assigned {options.ClientId}");
                return string.IsNullOrWhiteSpace(options.ClientId)
                    ? new ManagedIdentityCredential()
                    : new ManagedIdentityCredential(options.ClientId);

            case AzureCredentialMode.WorkloadIdentity:
                logger.LogInformation("Azure credential: workload identity federation.");
                return new WorkloadIdentityCredential(new WorkloadIdentityCredentialOptions
                {
                    ClientId = options.ClientId,
                    TenantId = options.TenantId,
                    AuthorityHost = authorityHost
                });

            case AzureCredentialMode.ClientSecret:
                if (string.IsNullOrWhiteSpace(options.TenantId)
                    || string.IsNullOrWhiteSpace(options.ClientId)
                    || string.IsNullOrWhiteSpace(options.ClientSecret))
                {
                    throw new InvalidOperationException(
                        $"{nameof(AzureCredentialMode.ClientSecret)} requires TenantId, ClientId, and ClientSecret.");
                }
                logger.LogInformation("Azure credential: client secret for app {ClientId}.", options.ClientId);
                return new ClientSecretCredential(options.TenantId, options.ClientId, options.ClientSecret,
                    new ClientSecretCredentialOptions { AuthorityHost = authorityHost });

            case AzureCredentialMode.AzureCli:
                logger.LogInformation("Azure credential: Azure CLI user.");
                return new AzureCliCredential(new AzureCliCredentialOptions { TenantId = options.TenantId });

            default:
                logger.LogInformation("Azure credential: DefaultAzureCredential chain.");
                return new DefaultAzureCredential(new DefaultAzureCredentialOptions
                {
                    ManagedIdentityClientId = options.ClientId,
                    TenantId = options.TenantId,
                    AuthorityHost = authorityHost
                });
        }
    }
}
