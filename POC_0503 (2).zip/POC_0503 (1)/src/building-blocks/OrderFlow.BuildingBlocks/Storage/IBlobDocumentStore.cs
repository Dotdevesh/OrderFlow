namespace OrderFlow.BuildingBlocks.Storage;

/// <summary>Stores and retrieves order documents in Blob Storage and issues short-lived read SAS URLs.</summary>
public interface IBlobDocumentStore
{
    /// <summary>Uploads a document to a deterministic path and returns that path (idempotent).</summary>
    Task<string> UploadAsync(string blobPath, Stream content, string contentType, CancellationToken ct = default);

    Task<Stream> OpenReadAsync(string blobPath, CancellationToken ct = default);

    /// <summary>Returns a short-lived, read-only, user-agnostic SAS URL for a stored document.</summary>
    Task<Uri> GetReadSasAsync(string blobPath, TimeSpan validFor, CancellationToken ct = default);
}
