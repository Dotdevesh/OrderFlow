using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using Microsoft.Extensions.Logging;

namespace OrderFlow.BuildingBlocks.Storage;

public sealed class BlobDocumentStore(
    BlobServiceClient serviceClient,
    string containerName,
    ILogger<BlobDocumentStore> logger) : IBlobDocumentStore
{
    private volatile bool _containerEnsured;
    private readonly SemaphoreSlim _ensureLock = new(1, 1);

    private BlobContainerClient Container => serviceClient.GetBlobContainerClient(containerName);

    public async Task<string> UploadAsync(string blobPath, Stream content, string contentType, CancellationToken ct = default)
    {
        Guard.NotNullOrWhiteSpace(blobPath);
        await EnsureContainerAsync(ct);

        var blob = Container.GetBlobClient(blobPath);
        await blob.UploadAsync(content, new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = contentType }
        }, ct);
        logger.LogInformation("Stored document {BlobPath} ({ContentType})", blobPath, contentType);
        return blobPath;
    }

    public async Task<Stream> OpenReadAsync(string blobPath, CancellationToken ct = default)
        => await Container.GetBlobClient(blobPath).OpenReadAsync(cancellationToken: ct);

    public async Task<Uri> GetReadSasAsync(string blobPath, TimeSpan validFor, CancellationToken ct = default)
    {
        var blob = Container.GetBlobClient(blobPath);
        var expiresOn = DateTimeOffset.UtcNow.Add(validFor);
        var builder = new BlobSasBuilder(BlobSasPermissions.Read, expiresOn)
        {
            BlobContainerName = containerName,
            BlobName = blobPath,
            Resource = "b"
        };

        // Account-key path (local dev / connection string): client can sign directly.
        if (blob.CanGenerateSasUri)
            return blob.GenerateSasUri(builder);

        // Managed Identity path: use a user-delegation key (no account key required).
        var delegationKey = await serviceClient.GetUserDelegationKeyAsync(
            DateTimeOffset.UtcNow.AddMinutes(-5), expiresOn, ct);

        var sas = builder.ToSasQueryParameters(delegationKey.Value, serviceClient.AccountName);
        return new BlobUriBuilder(blob.Uri) { Sas = sas }.ToUri();
    }

    private async Task EnsureContainerAsync(CancellationToken ct)
    {
        if (_containerEnsured) return;

        await _ensureLock.WaitAsync(ct);
        try
        {
            if (!_containerEnsured)
            {
                await Container.CreateIfNotExistsAsync(PublicAccessType.None, cancellationToken: ct);
                _containerEnsured = true;
            }
        }
        finally
        {
            _ensureLock.Release();
        }
    }
}
