using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.BuildingBlocks.Identity;

/// <summary>
/// Issues and validates short-lived HMAC-SHA256 JWTs minted by <c>OrderFlow.IdentityApi</c> for:
/// <list type="bullet">
///   <item>Windows Integrated Authentication (Negotiate/Kerberos) token exchange</item>
///   <item>Service-to-service (microservice intercommunication) tokens</item>
/// </list>
/// </summary>
public sealed class InternalTokenService
{
    private readonly string _issuer;
    private readonly SymmetricSecurityKey _signingKey;
    private readonly JsonWebTokenHandler _handler = new() { MapInboundClaims = false };

    public InternalTokenService(string signingKey, string issuer = "https://identity.orderflow.internal")
    {
        Guard.NotNullOrWhiteSpace(signingKey, nameof(signingKey));
        if (Encoding.UTF8.GetByteCount(signingKey) < 32)
            throw new ArgumentException("Internal JWT signing key must be at least 32 bytes.", nameof(signingKey));

        _issuer = issuer;
        _signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey));
    }

    public (string Token, DateTimeOffset ExpiresAtUtc) CreateUserToken(
        AuthenticatedPrincipalDto principal,
        string audience,
        TimeSpan lifetime)
    {
        var now = DateTimeOffset.UtcNow;
        var expires = now.Add(lifetime);

        var claims = new List<Claim>
        {
            new(OrderFlowIdentityConstants.ClaimObjectId, principal.UserId ?? string.Empty),
            new("sub", principal.UserId ?? string.Empty),
            new("name", principal.DisplayName ?? principal.Upn ?? principal.UserId ?? string.Empty),
            new(OrderFlowIdentityConstants.ClaimTokenKind, OrderFlowIdentityConstants.TokenKindUser),
            new(OrderFlowIdentityConstants.ClaimAdGroupVerified, principal.IsAuthorized ? "true" : "false"),
            new(OrderFlowIdentityConstants.ClaimDbRoleVerified, principal.Role is not null ? "true" : "false")
        };

        if (!string.IsNullOrWhiteSpace(principal.Upn))
            claims.Add(new Claim(OrderFlowIdentityConstants.ClaimUpn, principal.Upn));

        if (!string.IsNullOrWhiteSpace(principal.Email))
            claims.Add(new Claim("email", principal.Email));

        if (!string.IsNullOrWhiteSpace(principal.ManagerId))
            claims.Add(new Claim(OrderFlowIdentityConstants.ClaimManagerId, principal.ManagerId));

        if (principal.Role is { } role)
        {
            var roleName = role == UserRole.Manager
                ? OrderFlowIdentityConstants.RoleManager
                : OrderFlowIdentityConstants.RoleReportee;
            claims.Add(new Claim("roles", roleName));
            claims.Add(new Claim(ClaimTypes.Role, roleName));
        }

        foreach (var group in principal.Groups)
            claims.Add(new Claim(OrderFlowIdentityConstants.ClaimGroupId, group));

        var descriptor = new SecurityTokenDescriptor
        {
            Issuer = _issuer,
            Audience = audience,
            Subject = new ClaimsIdentity(claims),
            NotBefore = now.UtcDateTime,
            IssuedAt = now.UtcDateTime,
            Expires = expires.UtcDateTime,
            SigningCredentials = new SigningCredentials(_signingKey, SecurityAlgorithms.HmacSha256)
        };

        return (_handler.CreateToken(descriptor), expires);
    }

    public (string Token, DateTimeOffset ExpiresAtUtc) CreateServiceToken(
        string serviceName,
        string audience,
        IReadOnlyList<string> roles,
        TimeSpan lifetime)
    {
        var now = DateTimeOffset.UtcNow;
        var expires = now.Add(lifetime);

        var claims = new List<Claim>
        {
            new("sub", $"service:{serviceName}"),
            new(OrderFlowIdentityConstants.ClaimObjectId, $"service:{serviceName}"),
            new(OrderFlowIdentityConstants.ClaimTokenKind, OrderFlowIdentityConstants.TokenKindService),
            new(OrderFlowIdentityConstants.ClaimServiceName, serviceName)
        };

        foreach (var role in roles)
        {
            claims.Add(new Claim("roles", role));
            claims.Add(new Claim(ClaimTypes.Role, role));
        }

        var descriptor = new SecurityTokenDescriptor
        {
            Issuer = _issuer,
            Audience = audience,
            Subject = new ClaimsIdentity(claims),
            NotBefore = now.UtcDateTime,
            IssuedAt = now.UtcDateTime,
            Expires = expires.UtcDateTime,
            SigningCredentials = new SigningCredentials(_signingKey, SecurityAlgorithms.HmacSha256)
        };

        return (_handler.CreateToken(descriptor), expires);
    }

    public async Task<TokenValidationResult> ValidateAsync(string token, string? expectedAudience = null)
    {
        var parameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = _issuer,
            ValidateAudience = !string.IsNullOrWhiteSpace(expectedAudience),
            ValidAudience = expectedAudience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = _signingKey,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            RoleClaimType = "roles",
            NameClaimType = "name"
        };

        return await _handler.ValidateTokenAsync(token, parameters);
    }
}
