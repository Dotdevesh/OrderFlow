namespace OrderFlow.BuildingBlocks.Identity;

/// <summary>
/// Configuration shared by OrderFlow microservices for authenticating user requests and
/// app-to-app intercommunication through Microsoft Entra ID and <c>OrderFlow.IdentityApi</c>.
/// </summary>
public sealed class IdentityClientOptions
{
    public const string Section = "Identity";

    /// <summary>Base URL of <c>OrderFlow.IdentityApi</c> (e.g. <c>http://localhost:5085</c>).</summary>
    public string? BaseUrl { get; set; }

    /// <summary>Logical name of the calling microservice (e.g. OrderApi, Orchestrator, EmailIntake, IdentitySync).</summary>
    public string ServiceName { get; set; } = "unknown-service";

    /// <summary>Target audience URI/name expected when calling downstream internal APIs.</summary>
    public string TargetAudience { get; set; } = "api://orderflow-internal";

    /// <summary>
    /// Optional Microsoft Entra scope (e.g. <c>api://&lt;app-client-id&gt;/.default</c>) for acquiring
    /// Managed Identity or Client Credentials tokens for service-to-service calls.
    /// </summary>
    public string? EntraTargetScope { get; set; }

    /// <summary>Optional Entra tenant ID when using confidential client credentials instead of Managed Identity.</summary>
    public string? TenantId { get; set; }

    /// <summary>Optional Entra client ID (or user-assigned Managed Identity client ID).</summary>
    public string? ClientId { get; set; }

    /// <summary>Optional Entra client secret (Key Vault reference in Azure; prefer Managed Identity when hosted).</summary>
    public string? ClientSecret { get; set; }

    /// <summary>
    /// Shared secret used to mint short-lived service JWTs from <c>OrderFlow.IdentityApi</c> when
    /// Managed Identity tokens are not used (e.g., Docker Compose / hybrid).
    /// </summary>
    public string? ServiceSharedSecret { get; set; }

    /// <summary>Optional internal signing key if validating IdentityApi-issued tokens locally.</summary>
    public string? InternalJwtSigningKey { get; set; }

    /// <summary>Issuer expected on IdentityApi-minted Windows SSO and service tokens.</summary>
    public string InternalJwtIssuer { get; set; } = "https://identity.orderflow.internal";

    /// <summary>Optional legacy/dev header key (<c>X-Internal-ApiKey</c>) for local backward compatibility.</summary>
    public string? FallbackInternalApiKey { get; set; }

    /// <summary>Short TTL cache duration (in seconds) for user AD-group/role introspection results.</summary>
    public int IntrospectionCacheSeconds { get; set; } = 15;
}
