using System.Collections.Concurrent;
using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;

namespace OrderFlow.BuildingBlocks.Identity;

/// <summary>
/// Client abstraction used by OrderFlow microservices (e.g. <c>OrderFlow.OrderApi</c>) to
/// authenticate user requests (enforcing synced AD group + App Role membership in DB) and
/// validate service-to-service tokens via <c>OrderFlow.IdentityApi</c>.
/// </summary>
public interface IIdentityServiceClient
{
    Task<AuthenticatedPrincipalDto> IntrospectUserAsync(IntrospectUserRequest request, CancellationToken ct = default);
    Task<IntrospectServiceResponse> IntrospectServiceAsync(IntrospectServiceRequest request, CancellationToken ct = default);
    Task<IReadOnlyList<UserSummaryDto>> GetAuthorizedUsersAsync(CancellationToken ct = default);
    void InvalidateUserCache(string? userId = null);
}

public sealed class HttpIdentityServiceClient(
    HttpClient http,
    IOptions<IdentityClientOptions> options,
    ILogger<HttpIdentityServiceClient> logger) : IIdentityServiceClient
{
    private readonly IdentityClientOptions _options = options.Value;
    private readonly ConcurrentDictionary<string, (AuthenticatedPrincipalDto Value, DateTimeOffset ExpiresAtUtc)> _cache = new(StringComparer.OrdinalIgnoreCase);

    public async Task<AuthenticatedPrincipalDto> IntrospectUserAsync(IntrospectUserRequest request, CancellationToken ct = default)
    {
        var cacheKey = $"{request.ObjectId ?? "_"}|{request.Upn ?? "_"}|{request.WindowsAccountName ?? "_"}|{string.Join(',', request.TokenRoles ?? [])}|{string.Join(',', request.TokenGroups ?? [])}";
        var now = DateTimeOffset.UtcNow;

        if (_options.IntrospectionCacheSeconds > 0
            && _cache.TryGetValue(cacheKey, out var cached)
            && cached.ExpiresAtUtc > now)
        {
            return cached.Value;
        }

        using var response = await http.PostAsJsonAsync("/api/auth/introspect", request, ct);
        if (!response.IsSuccessStatusCode)
        {
            var err = await response.Content.ReadAsStringAsync(ct);
            logger.LogWarning("IdentityApi user introspection returned {Status}: {Body}", response.StatusCode, err);
            return new AuthenticatedPrincipalDto(
                IsAuthenticated: true,
                IsAuthorized: false,
                DenialCode: "identity_service_denied",
                DenialReason: $"Identity service rejected principal ({(int)response.StatusCode}).",
                UserId: request.ObjectId,
                Upn: request.Upn,
                Email: request.Upn,
                DisplayName: request.DisplayName,
                Role: null,
                ManagerId: null,
                Groups: [],
                AppRoles: [],
                AuthMethod: request.AuthMethod);
        }

        var result = (await response.Content.ReadFromJsonAsync<AuthenticatedPrincipalDto>(ct))!;
        if (_options.IntrospectionCacheSeconds > 0)
        {
            _cache[cacheKey] = (result, now.AddSeconds(_options.IntrospectionCacheSeconds));
        }

        return result;
    }

    public async Task<IntrospectServiceResponse> IntrospectServiceAsync(IntrospectServiceRequest request, CancellationToken ct = default)
    {
        using var response = await http.PostAsJsonAsync("/api/auth/introspect-service", request, ct);
        if (!response.IsSuccessStatusCode)
        {
            return new IntrospectServiceResponse(false, null, null, [], $"IdentityApi returned {(int)response.StatusCode}");
        }

        return (await response.Content.ReadFromJsonAsync<IntrospectServiceResponse>(ct))
               ?? new IntrospectServiceResponse(false, null, null, [], "Empty introspection response");
    }

    public async Task<IReadOnlyList<UserSummaryDto>> GetAuthorizedUsersAsync(CancellationToken ct = default)
    {
        var users = await http.GetFromJsonAsync<List<UserSummaryDto>>("/api/users", ct);
        return users ?? [];
    }

    public void InvalidateUserCache(string? userId = null)
    {
        if (string.IsNullOrWhiteSpace(userId))
        {
            _cache.Clear();
            return;
        }

        foreach (var key in _cache.Keys)
        {
            if (key.StartsWith($"{userId}|", StringComparison.OrdinalIgnoreCase))
                _cache.TryRemove(key, out _);
        }
    }
}
