using System.Net.Http.Headers;
using System.Net.Http.Json;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.Contracts;

namespace OrderFlow.BuildingBlocks.Identity;

/// <summary>
/// Outbound <see cref="DelegatingHandler"/> that authenticates microservice-to-microservice calls:
/// <list type="number">
///   <item>Acquires a Microsoft Entra ID token when <see cref="IdentityClientOptions.EntraTargetScope"/> is set, using whichever credential mode <c>Identity:Credential</c> selects.</item>
///   <item>Otherwise exchanges service credentials with <c>OrderFlow.IdentityApi</c> (<c>POST /api/auth/service-token</c>) when configured.</item>
///   <item>Optionally attaches <c>X-Internal-ApiKey</c> in local dev fallback mode.</item>
/// </list>
/// </summary>
public sealed class ServiceToServiceBearerHandler : DelegatingHandler
{
    private readonly IdentityClientOptions _options;
    private readonly ILogger<ServiceToServiceBearerHandler> _logger;
    private readonly HttpClient _tokenHttpClient;
    private readonly TokenCredential? _entraCredential;
    private readonly SemaphoreSlim _lock = new(1, 1);

    private string? _cachedToken;
    private DateTimeOffset _cachedExpiresAtUtc = DateTimeOffset.MinValue;

    public ServiceToServiceBearerHandler(
        IOptions<IdentityClientOptions> options,
        ILogger<ServiceToServiceBearerHandler> logger,
        HttpClient? tokenHttpClient = null,
        IAzureCredentialFactory? credentialFactory = null)
    {
        _options = options.Value;
        _logger = logger;
        _tokenHttpClient = tokenHttpClient ?? new HttpClient { Timeout = TimeSpan.FromSeconds(10) };

        if (!string.IsNullOrWhiteSpace(_options.EntraTargetScope))
            _entraCredential = BuildEntraCredential(credentialFactory);
    }

    /// <summary>
    /// Prefers the configured <c>Identity:Credential</c> mode. The flat <c>Identity:ClientId</c>,
    /// <c>TenantId</c>, and <c>ClientSecret</c> keys still apply when that section is absent.
    /// </summary>
    private TokenCredential? BuildEntraCredential(IAzureCredentialFactory? credentialFactory)
    {
        if (credentialFactory is null)
        {
            return string.IsNullOrWhiteSpace(_options.ClientId)
                ? new DefaultAzureCredential()
                : new DefaultAzureCredential(new DefaultAzureCredentialOptions { ManagedIdentityClientId = _options.ClientId });
        }

        var credentialOptions = credentialFactory.Resolve(IdentityClientOptions.Section);
        credentialOptions.ClientId ??= _options.ClientId;
        credentialOptions.TenantId ??= _options.TenantId;
        credentialOptions.ClientSecret ??= _options.ClientSecret;

        if (credentialOptions.Mode == AzureCredentialMode.Default && !string.IsNullOrWhiteSpace(credentialOptions.ClientSecret))
            credentialOptions.Mode = AzureCredentialMode.ClientSecret;

        return credentialFactory.Create(credentialOptions);
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        if (request.Headers.Authorization is null)
        {
            var token = await AcquireTokenAsync(cancellationToken);
            if (!string.IsNullOrWhiteSpace(token))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        if (!string.IsNullOrWhiteSpace(_options.FallbackInternalApiKey)
            && !request.Headers.Contains("X-Internal-ApiKey"))
        {
            request.Headers.TryAddWithoutValidation("X-Internal-ApiKey", _options.FallbackInternalApiKey);
        }

        return await base.SendAsync(request, cancellationToken);
    }

    private async Task<string?> AcquireTokenAsync(CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        if (!string.IsNullOrWhiteSpace(_cachedToken) && _cachedExpiresAtUtc > now.AddSeconds(60))
            return _cachedToken;

        await _lock.WaitAsync(ct);
        try
        {
            now = DateTimeOffset.UtcNow;
            if (!string.IsNullOrWhiteSpace(_cachedToken) && _cachedExpiresAtUtc > now.AddSeconds(60))
                return _cachedToken;

            // 1) Entra ID Managed Identity / Client Credentials flow
            if (_entraCredential is not null && !string.IsNullOrWhiteSpace(_options.EntraTargetScope))
            {
                var accessToken = await _entraCredential.GetTokenAsync(
                    new TokenRequestContext([_options.EntraTargetScope]), ct);
                _cachedToken = accessToken.Token;
                _cachedExpiresAtUtc = accessToken.ExpiresOn;
                return _cachedToken;
            }

            // 2) Identity microservice token exchange flow
            if (!string.IsNullOrWhiteSpace(_options.BaseUrl) && !string.IsNullOrWhiteSpace(_options.ServiceSharedSecret))
            {
                var endpoint = $"{_options.BaseUrl.TrimEnd('/')}/api/auth/service-token";
                var payload = new ServiceTokenRequest(
                    _options.ServiceName,
                    _options.TargetAudience,
                    _options.ServiceSharedSecret);

                using var res = await _tokenHttpClient.PostAsJsonAsync(endpoint, payload, ct);
                if (!res.IsSuccessStatusCode)
                {
                    var body = await res.Content.ReadAsStringAsync(ct);
                    _logger.LogError("Failed to acquire service token from IdentityApi ({Status}): {Body}", res.StatusCode, body);
                    res.EnsureSuccessStatusCode();
                }

                var minted = await res.Content.ReadFromJsonAsync<ServiceTokenResponse>(ct);
                if (minted is not null)
                {
                    _cachedToken = minted.AccessToken;
                    _cachedExpiresAtUtc = minted.ExpiresAtUtc;
                    return _cachedToken;
                }
            }

            return null;
        }
        finally
        {
            _lock.Release();
        }
    }
}
