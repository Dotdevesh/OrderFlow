namespace OrderFlow.BuildingBlocks;

/// <summary>A lightweight functional result for expected (non-exceptional) failures.</summary>
public readonly record struct Result
{
    public bool IsSuccess { get; }
    public string? Error { get; }
    public string? Code { get; }
    public bool IsFailure => !IsSuccess;

    private Result(bool success, string? error, string? code)
        => (IsSuccess, Error, Code) = (success, error, code);

    public static Result Success() => new(true, null, null);
    public static Result Failure(string error, string? code = null) => new(false, error, code);
}

public readonly record struct Result<T>
{
    public bool IsSuccess { get; }
    public T? Value { get; }
    public string? Error { get; }
    public string? Code { get; }
    public bool IsFailure => !IsSuccess;

    private Result(bool success, T? value, string? error, string? code)
        => (IsSuccess, Value, Error, Code) = (success, value, error, code);

    public static Result<T> Success(T value) => new(true, value, null, null);
    public static Result<T> Failure(string error, string? code = null) => new(false, default, error, code);

    public static implicit operator Result<T>(T value) => Success(value);
}
