using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;

namespace OrderFlow.BuildingBlocks.Health;

/// <summary>Tags that split liveness ("the process is up") from readiness ("dependencies answer").</summary>
public static class HealthTags
{
    public const string Live = "live";
    public const string Ready = "ready";
}

/// <summary>Confirms the documents container is reachable with the credential the service was given.</summary>
public sealed class BlobStorageHealthCheck(
    BlobServiceClient client,
    string containerName,
    ILogger<BlobStorageHealthCheck> logger) : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var container = client.GetBlobContainerClient(containerName);
            var exists = await container.ExistsAsync(cancellationToken);
            return exists.Value
                ? HealthCheckResult.Healthy($"Container '{containerName}' is reachable.")
                : HealthCheckResult.Degraded($"Container '{containerName}' does not exist yet.");
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Blob storage health check failed for container {Container}.", containerName);
            return HealthCheckResult.Unhealthy("Blob storage is not reachable.", ex);
        }
    }
}

/// <summary>
/// Confirms Service Bus accepts a sender on the orders topic. Creating an empty batch round-trips to
/// the namespace and validates send rights without publishing anything.
/// </summary>
public sealed class ServiceBusHealthCheck(
    ServiceBusClient client,
    string entityPath,
    ILogger<ServiceBusHealthCheck> logger) : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            await using var sender = client.CreateSender(entityPath);
            using var batch = await sender.CreateMessageBatchAsync(cancellationToken);
            return HealthCheckResult.Healthy($"Topic '{entityPath}' accepts publishes.");
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Service Bus health check failed for entity {Entity}.", entityPath);
            return HealthCheckResult.Unhealthy("Service Bus is not reachable.", ex);
        }
    }
}

/// <summary>Confirms a downstream OrderFlow service answers its own liveness endpoint.</summary>
public sealed class HttpDependencyHealthCheck(
    IHttpClientFactory httpClientFactory,
    string dependencyName,
    Uri probeUrl,
    ILogger<HttpDependencyHealthCheck> logger) : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            using var http = httpClientFactory.CreateClient(OrderFlowHealthChecks.ProbeClientName);
            using var response = await http.GetAsync(probeUrl, cancellationToken);

            return response.IsSuccessStatusCode
                ? HealthCheckResult.Healthy($"{dependencyName} answered {(int)response.StatusCode}.")
                : HealthCheckResult.Unhealthy($"{dependencyName} answered {(int)response.StatusCode}.");
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Health probe to {Dependency} at {Url} failed.", dependencyName, probeUrl);
            return HealthCheckResult.Unhealthy($"{dependencyName} is not reachable.", ex);
        }
    }
}
