using System.Text.Json.Serialization;
using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;

namespace OrderFlow.BuildingBlocks.Health;

/// <summary>Registration helpers so every OrderFlow service reports health in the same shape.</summary>
public static class OrderFlowHealthChecks
{
    /// <summary>Named <see cref="HttpClient"/> used for dependency probes; short timeout, no retry.</summary>
    public const string ProbeClientName = "orderflow-health-probe";

    public static IHealthChecksBuilder AddOrderFlowHealthChecks(this IServiceCollection services, string serviceName)
    {
        services.AddHttpClient(ProbeClientName, c => c.Timeout = TimeSpan.FromSeconds(5));

        return services.AddHealthChecks()
            .AddCheck(serviceName, () => HealthCheckResult.Healthy("Process is running."), tags: [HealthTags.Live]);
    }

    /// <summary>Adds the documents container as a readiness dependency.</summary>
    public static IHealthChecksBuilder AddBlobStorage(this IHealthChecksBuilder builder, string name = "blob-storage")
    {
        builder.Add(new HealthCheckRegistration(
            name,
            sp => new BlobStorageHealthCheck(
                sp.GetRequiredService<BlobServiceClient>(),
                sp.GetRequiredService<IConfiguration>()["Storage:Container"] ?? "order-documents",
                sp.GetRequiredService<ILogger<BlobStorageHealthCheck>>()),
            HealthStatus.Unhealthy,
            [HealthTags.Ready]));
        return builder;
    }

    /// <summary>Adds the orders topic as a readiness dependency.</summary>
    public static IHealthChecksBuilder AddServiceBus(this IHealthChecksBuilder builder, string name = "service-bus")
    {
        builder.Add(new HealthCheckRegistration(
            name,
            sp => new ServiceBusHealthCheck(
                sp.GetRequiredService<ServiceBusClient>(),
                sp.GetRequiredService<IConfiguration>()["ServiceBus:Topic"] ?? "orders",
                sp.GetRequiredService<ILogger<ServiceBusHealthCheck>>()),
            HealthStatus.Unhealthy,
            [HealthTags.Ready]));
        return builder;
    }

    /// <summary>Adds another OrderFlow service as a readiness dependency.</summary>
    public static IHealthChecksBuilder AddHttpDependency(
        this IHealthChecksBuilder builder,
        string name,
        string baseUrl,
        string path = "/health/live",
        HealthStatus failureStatus = HealthStatus.Degraded)
    {
        builder.Add(new HealthCheckRegistration(
            name,
            sp => new HttpDependencyHealthCheck(
                sp.GetRequiredService<IHttpClientFactory>(),
                name,
                new Uri(new Uri(baseUrl), path),
                sp.GetRequiredService<ILogger<HttpDependencyHealthCheck>>()),
            failureStatus,
            [HealthTags.Ready]));
        return builder;
    }

    /// <summary>
    /// Runs the checks carrying <paramref name="tag"/> and returns the body and status code to write.
    /// Hosts differ in how they return a response, so this stays free of any web framework: minimal
    /// APIs wrap it in <c>Results.Json</c>, HTTP-triggered functions in a <c>JsonResult</c>.
    /// </summary>
    public static async Task<(HealthResponse Payload, int StatusCode)> EvaluateAsync(
        HealthCheckService health,
        string serviceName,
        string? tag = null,
        CancellationToken ct = default)
    {
        var report = tag is null
            ? await health.CheckHealthAsync(ct)
            : await health.CheckHealthAsync(registration => registration.Tags.Contains(tag), ct);

        // Degraded still serves traffic, so only Unhealthy takes an instance out of rotation.
        var statusCode = report.Status == HealthStatus.Unhealthy ? 503 : 200;
        return (HealthResponse.From(serviceName, report), statusCode);
    }
}

/// <summary>
/// Wire shape of <c>/health/live</c> and <c>/health/ready</c>. The watchdog in
/// <c>OrderFlow.Notifications</c> and the APIM backend probes both parse this.
/// </summary>
public sealed record HealthResponse(
    [property: JsonPropertyName("status")] string Status,
    [property: JsonPropertyName("service")] string Service,
    [property: JsonPropertyName("totalDurationMs")] double TotalDurationMs,
    [property: JsonPropertyName("checks")] IReadOnlyList<HealthEntryResponse> Checks)
{
    public static HealthResponse From(string serviceName, HealthReport report) => new(
        report.Status.ToString(),
        serviceName,
        report.TotalDuration.TotalMilliseconds,
        report.Entries
            .Select(e => new HealthEntryResponse(e.Key, e.Value.Status.ToString(), e.Value.Description, e.Value.Duration.TotalMilliseconds))
            .ToList());
}

public sealed record HealthEntryResponse(
    [property: JsonPropertyName("name")] string Name,
    [property: JsonPropertyName("status")] string Status,
    [property: JsonPropertyName("description")] string? Description,
    [property: JsonPropertyName("durationMs")] double DurationMs);
