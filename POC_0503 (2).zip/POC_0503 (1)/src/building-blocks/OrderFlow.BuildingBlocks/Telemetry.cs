namespace OrderFlow.BuildingBlocks;

/// <summary>Shared names used for correlation across HTTP headers, Service Bus properties, and logs.</summary>
public static class Telemetry
{
    public const string CorrelationIdHeader = "x-correlation-id";
    public const string ActivitySourceName = "OrderFlow";
    public const string MeterName = "OrderFlow";

    /// <summary>Well-known business event names surfaced to Application Insights.</summary>
    public static class Events
    {
        public const string OrderReceived = "OrderReceived";
        public const string DocumentsStored = "DocumentsStored";
        public const string ExtractionCompleted = "ExtractionCompleted";
        public const string ValidationTaskCreated = "ValidationTaskCreated";
        public const string ValidationSubmitted = "ValidationSubmitted";
        public const string SlaBreached = "SlaBreached";
        public const string OrderFinalized = "OrderFinalized";
    }
}
