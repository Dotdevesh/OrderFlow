using OrderFlow.Domain;

namespace OrderFlow.Contracts;

/// <summary>Well-known claim types and role names shared across the OrderFlow microservice architecture.</summary>
public static class OrderFlowIdentityConstants
{
    public const string RoleManager = "Manager";
    public const string RoleReportee = "Reportee";
    public const string RoleInternalService = "InternalService";
    public const string RoleDirectorySync = "DirectorySync";

    public const string ClaimObjectId = "oid";
    public const string ClaimUpn = "preferred_username";
    public const string ClaimWindowsAccount = "orderflow:win_account";
    public const string ClaimAdGroupVerified = "orderflow:ad_group_verified";
    public const string ClaimDbRoleVerified = "orderflow:db_role_verified";
    public const string ClaimManagerId = "orderflow:manager_id";
    public const string ClaimTokenKind = "orderflow:token_kind";
    public const string ClaimServiceName = "orderflow:service_name";
    public const string ClaimGroupId = "groups";

    public const string TokenKindUser = "user";
    public const string TokenKindService = "service";
}

// ---------- User Authentication & Introspection (Services <-> IdentityApi) ----------

public sealed record IntrospectUserRequest(
    string? ObjectId,
    string? Upn,
    string? WindowsAccountName = null,
    string? DisplayName = null,
    IReadOnlyList<string>? TokenRoles = null,
    IReadOnlyList<string>? TokenGroups = null,
    string AuthMethod = "EntraJwt");

public sealed record AuthenticatedPrincipalDto(
    bool IsAuthenticated,
    bool IsAuthorized,
    string? DenialCode,
    string? DenialReason,
    string? UserId,
    string? Upn,
    string? Email,
    string? DisplayName,
    UserRole? Role,
    string? ManagerId,
    IReadOnlyList<string> Groups,
    IReadOnlyList<string> AppRoles,
    string AuthMethod);

public sealed record WindowsSsoExchangeResponse(
    bool Authenticated,
    bool Authorized,
    string? AccessToken,
    DateTimeOffset? ExpiresAtUtc,
    AuthenticatedPrincipalDto Principal);

// ---------- Service-to-Service Intercommunication (Microservices <-> IdentityApi) ----------

public sealed record ServiceTokenRequest(
    string ServiceName,
    string TargetAudience,
    string? ClientSecret = null);

public sealed record ServiceTokenResponse(
    string AccessToken,
    DateTimeOffset ExpiresAtUtc,
    string ServiceName,
    IReadOnlyList<string> Roles);

public sealed record IntrospectServiceRequest(
    string AccessToken,
    string? ExpectedAudience = null);

public sealed record IntrospectServiceResponse(
    bool IsValid,
    string? ServiceId,
    string? ServiceName,
    IReadOnlyList<string> Roles,
    string? DenialReason = null);

// ---------- Directory Sync (OrderFlow.IdentitySync Function -> OrderFlow.IdentityApi) ----------

public sealed record SyncedGroupConfigDto(
    string GroupId,
    string DisplayName,
    bool IsRequiredAccessGroup,
    UserRole? MappedRole = null,
    string? DeltaLink = null);

public sealed record SyncedUserDto(
    string ObjectId,
    string DisplayName,
    string? Upn,
    string? Email,
    string? WindowsAccountName = null,
    string? ManagerObjectId = null,
    bool AccountEnabled = true);

public sealed record SyncedGroupMembershipDto(
    string GroupId,
    IReadOnlyList<string> MemberUserIds,
    IReadOnlyList<string>? RemovedUserIds = null,
    bool IsFullSnapshot = true,
    string? DeltaLink = null);

public sealed record SyncedAppRoleAssignmentDto(
    string AssignmentId,
    string PrincipalId,
    string AppRoleId,
    string RoleName,
    DateTimeOffset? CreatedAtUtc = null);

public sealed record DirectorySyncBatchRequest(
    string SyncSource,
    bool IsFullAppRoleSnapshot,
    IReadOnlyList<SyncedGroupConfigDto> Groups,
    IReadOnlyList<SyncedUserDto> Users,
    IReadOnlyList<SyncedGroupMembershipDto> Memberships,
    IReadOnlyList<SyncedAppRoleAssignmentDto> AppRoleAssignments);

public sealed record DirectorySyncResultDto(
    int UsersUpserted,
    int UsersAuthorized,
    int UsersRevoked,
    int MembershipsUpdated,
    int AppRolesUpdated,
    DateTimeOffset SyncedAtUtc);

public sealed record DirectoryGroupStateDto(
    string GroupId,
    string DisplayName,
    bool IsRequiredAccessGroup,
    UserRole? MappedRole,
    string? DeltaLink,
    string? WebhookSubscriptionId,
    DateTimeOffset? WebhookExpiresAtUtc,
    DateTimeOffset? LastSyncedAtUtc);

public sealed record UpdateWebhookSubscriptionRequest(
    string GroupId,
    string SubscriptionId,
    DateTimeOffset ExpiresAtUtc);
