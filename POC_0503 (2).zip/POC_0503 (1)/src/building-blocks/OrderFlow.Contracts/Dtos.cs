using OrderFlow.Domain;

namespace OrderFlow.Contracts;

// ---------- Internal (orchestrator -> Order API) ----------

public sealed record CreateOrderRequest(
    Guid CorrelationId,
    string CustomerId,
    Priority Priority,
    string OrchestrationInstanceId,
    string? SenderAddress,
    string? Subject,
    DateTimeOffset ReceivedAtUtc,
    IReadOnlyList<StoredDocumentDto> Documents,
    string? GraphMessageId = null);

public sealed record StoredDocumentDto(
    DocumentKind Kind, string FileName, string BlobPath, string ContentType, long SizeBytes);

/// <summary>SLA and escalation interval are resolved server-side from the customer profile.</summary>
public sealed record CreateOrderResponse(Guid OrderId, DateTimeOffset SlaDueAtUtc, int EscalationIntervalMinutes);

public sealed record CreateValidationTaskRequest(
    Guid OrderId,
    string OrchestrationInstanceId,
    IReadOnlyList<ExtractedFieldDto> Fields,
    IReadOnlyList<ExtractedLineDto> Lines,
    double MinConfidence,
    string? ModelId = null);

public sealed record ExtractedFieldDto(
    string Name, string? Value, double Confidence, string? BoundingRegionJson,
    IReadOnlyList<FieldCandidateDto>? Candidates = null);

public sealed record ExtractedLineDto(string? Sku, string? Description, decimal Quantity, decimal UnitPrice, double Confidence);

public sealed record EscalateOrderRequest(Guid OrderId, DateTimeOffset NewSlaDueAtUtc, int Attempt);

public sealed record FinalizeOrderRequest(Guid OrderId, string ValidatedByUserId, bool Approved, string? Note);

// ---------- Intake Ledger (resilience / no-order-loss) ----------

public sealed record RecordIntakeRequest(
    string GraphMessageId,
    string Mailbox,
    string? CustomerId,
    Priority Priority,
    Guid CorrelationId = default);

public sealed record UpdateIntakeStatusRequest(
    string GraphMessageId,
    IntakeStatus Status,
    string? FailureReason = null);

// ---------- Action Center (Order API -> SPA) ----------

public sealed record TaskSummaryDto(
    Guid TaskId,
    Guid OrderId,
    string CustomerId,
    Priority Priority,
    Domain.TaskStatus Status,
    AssignmentKind AssignmentKind,
    string? AssignedToUserId,
    string? Subject,
    double MinConfidence,
    DateTimeOffset SlaDueAtUtc,
    int SecondsRemaining);

public sealed record TaskDetailDto(
    TaskSummaryDto Summary,
    IReadOnlyList<FieldDto> Fields,
    IReadOnlyList<LineDto> Lines,
    IReadOnlyList<DocumentRefDto> Documents,
    object? BoundEntity = null);

public sealed record UserSummaryDto(string Id, string DisplayName, string? Email, UserRole Role, string? ManagerId);

public sealed record FieldDto(
    Guid Id, string Name, string? ExtractedValue, string? ValidatedValue, double Confidence,
    string? BoundingRegionJson, IReadOnlyList<FieldCandidateDto>? Candidates = null);

public sealed record LineDto(Guid Id, string? Sku, string? Description, decimal Quantity, decimal UnitPrice, double Confidence, bool IsCorrected);

public sealed record DocumentRefDto(Guid Id, string FileName, DocumentKind Kind, string ContentType);

// Requests from the SPA
public sealed record AssignRequest(string TargetUserId);
public sealed record SubmitValidationRequest(
    bool Approved,
    IReadOnlyList<ValidatedField> Fields,
    IReadOnlyList<ValidatedLine> Lines,
    string? Note);
