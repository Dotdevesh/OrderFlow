namespace OrderFlow.Contracts;

/// <summary>What happened, which decides the template and the default recipient list.</summary>
public enum NotificationKind
{
    SlaBreached,
    OrderFinalized,
    OrderFailed,
    ValidationTaskAssigned,
    DeadLetterDetected,
    ServiceUnhealthy,
    ServiceRecovered
}

public enum NotificationSeverity
{
    Information,
    Warning,
    Critical
}

/// <summary>
/// Published to the <c>orders</c> topic and consumed by <c>OrderFlow.Notifications</c>, which renders
/// and sends the email. Producers describe the event; they do not decide formatting or addressing.
/// </summary>
/// <param name="NotificationId">Also the Service Bus <c>MessageId</c>, so duplicate detection suppresses repeat sends.</param>
/// <param name="Recipients">Explicit recipients. Empty means "use the configured default list for this kind".</param>
/// <param name="Facts">Ordered label/value pairs rendered as a detail table in the email body.</param>
public sealed record NotificationRequested(
    Guid NotificationId,
    NotificationKind Kind,
    NotificationSeverity Severity,
    string Subject,
    string Summary,
    IReadOnlyList<string> Recipients,
    IReadOnlyList<NotificationFact> Facts,
    Guid? CorrelationId = null,
    string? CustomerId = null,
    Guid? OrderId = null,
    string? ActionUrl = null,
    DateTimeOffset? RaisedAtUtc = null)
{
    public const string SchemaVersion = "1.0";
}

public sealed record NotificationFact(string Label, string Value);
