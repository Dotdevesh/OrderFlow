using OrderFlow.Domain;

namespace OrderFlow.Contracts;

/// <summary>Published by Email Intake when a new order email is detected. Starts an orchestration.</summary>
public sealed record OrderReceived(
    Guid CorrelationId,
    string GraphMessageId,
    string MailboxAddress,
    string CustomerId,
    Priority Priority,
    string? SenderAddress,
    string? Subject,
    DateTimeOffset ReceivedAtUtc)
{
    public const string SchemaVersion = "1.0";
}

/// <summary>Published after Document Intelligence extraction completes (for analytics / downstream).</summary>
public sealed record OrderExtracted(
    Guid CorrelationId,
    Guid OrderId,
    int DocumentCount,
    double MinConfidence,
    DateTimeOffset ExtractedAtUtc);

/// <summary>
/// Raised as a Durable external event ("ValidationCompleted") by the Order API when a human submits.
/// Resumes the suspended orchestration.
/// </summary>
public sealed record ValidationCompletedPayload(
    Guid OrderId,
    string ValidatedByUserId,
    bool Approved,
    IReadOnlyList<ValidatedField> Fields,
    IReadOnlyList<ValidatedLine> Lines,
    string? Note);

public sealed record ValidatedField(string Name, string? Value);

public sealed record ValidatedLine(Guid? Id, string? Sku, string? Description, decimal Quantity, decimal UnitPrice);

/// <summary>Published when an order is finalized (handoff to downstream ERP).</summary>
public sealed record OrderFinalized(Guid OrderId, string CustomerId, DateTimeOffset FinalizedAtUtc);
