namespace OrderFlow.Contracts;

// ---------- Customers ----------

public sealed record CustomerDto(
    string CustomerId,
    string DisplayName,
    int Tier,
    int Priority,
    int SlaMinutes);

// ---------- Configurable form template ----------

public sealed record FormTemplateDto(
    string CustomerId,
    int Version,
    string Name,
    IReadOnlyList<FormSectionDto> Sections);

public sealed record FormSectionDto(
    string Key,
    string Title,
    string Type,                               // "fields" | "table"
    IReadOnlyList<FormFieldDef>? Fields,
    IReadOnlyList<FormColumnDef>? Columns);

public sealed record FormFieldDef(
    string Key,
    string Label,
    string Type,                               // text | number | date | select | textarea | checkbox
    bool Required,
    string? ExtractionField,
    bool AllowManual,
    bool Localized,
    string? Regex,
    string? Group,
    IReadOnlyList<string>? Options,
    bool ReadOnly = false,
    bool Disabled = false);

public sealed record FormColumnDef(
    string Key,
    string Label,
    string Type,
    string? ExtractionField);

// ---------- Field candidates (localization / disambiguation) ----------

public sealed record FieldCandidateDto(
    string? Value,
    double Confidence,
    string? Label,
    string? BoundingRegionJson);
