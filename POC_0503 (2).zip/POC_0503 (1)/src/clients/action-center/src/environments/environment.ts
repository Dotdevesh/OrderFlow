export const environment = {
  production: false,
  // Order API base URL (BFF).
  apiBaseUrl: 'http://localhost:5080',
  // Dedicated Identity microservice base URL (Entra/Windows SSO + AD Group & App Role verification).
  identityApiBaseUrl: 'http://localhost:5085',
  // SignalR hub.
  hubUrl: 'http://localhost:5080/hubs/tasks',
  // Microsoft Entra ID + Windows Credential Seamless SSO configuration.
  // Set enabled: true in Azure/Domain environments (automatically disables devAuth).
  entra: {
    enabled: false,
    tenantId: '',
    clientId: '',
    redirectUri: 'http://localhost:4200',
    apiScopes: ['api://orderflow-orderapi/Orders.Validate'],
    // Automatically sign in using logged-in Windows credentials:
    // 1) MSAL ssoSilent() (Entra Seamless SSO / Windows PRT / Kerberos)
    // 2) Windows Integrated Authentication (Negotiate) against IdentityApi (/api/auth/windows-sso)
    enableWindowsSso: true,
    domainHint: '',
  },
  // Local dev: impersonate a user without Entra when entra.enabled is false.
  devAuth: {
    enabled: true,
    userId: 'mgr-1',
    role: 'Manager' as 'Manager' | 'Reportee',
    name: 'Morgan (Manager)',
  },
};
