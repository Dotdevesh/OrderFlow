import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'inbox' },
  {
    path: 'access-denied',
    loadComponent: () =>
      import('./features/access-denied/access-denied.component').then((m) => m.AccessDeniedComponent),
  },
  {
    path: 'select-customer',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/customer-select/customer-select.component').then((m) => m.CustomerSelectComponent),
  },
  {
    path: 'inbox',
    canActivate: [authGuard],
    loadComponent: () => import('./features/inbox/inbox.component').then((m) => m.InboxComponent),
  },
  {
    path: 'tasks/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/validation/validation-workspace.component').then((m) => m.ValidationWorkspaceComponent),
  },
  { path: '**', redirectTo: 'inbox' },
];
