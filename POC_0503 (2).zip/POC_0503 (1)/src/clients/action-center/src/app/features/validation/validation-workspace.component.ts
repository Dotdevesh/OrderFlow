import { Component, OnInit, TemplateRef, ViewChild, computed, inject, signal } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { MatButtonModule } from '@angular/material/button';
import { Session } from '../../core/session';
import { TaskService } from '../../core/task.service';
import {
  FieldCandidate, FieldDto, FormFieldDef, FormTemplate, LineDto, SubmitValidation, TaskDetail,
  TaskStatusCode, UserSummary,
} from '../../core/models';
import {
  AppAlertComponent,
  AppCheckboxComponent,
  AppDialogService,
  AppSelectComponent,
  AppTextareaComponent,
  AppTextboxComponent,
  AppToastService,
  UiOption,
} from '../../shared/ui';

@Component({
  selector: 'app-validation-workspace',
  standalone: true,
  imports: [
    FormsModule,
    DecimalPipe,
    MatButtonModule,
    AppTextboxComponent,
    AppTextareaComponent,
    AppSelectComponent,
    AppCheckboxComponent,
    AppAlertComponent,
  ],
  styles: [`
    .workspace { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; height: calc(100vh - 150px); }
    .pane { display: flex; flex-direction: column; min-height: 0; }
    .pane h3 { margin: 0 0 8px; font-size: 15px; color: var(--muted); }
    .doc-tabs { display: flex; gap: 6px; margin-bottom: 8px; flex-wrap: wrap; }
    iframe { flex: 1; width: 100%; border: 1px solid var(--line); border-radius: 8px; background: #fff; }
    .form { overflow: auto; padding: 14px; }
    .section { margin-bottom: 18px; }
    .section > h4 { margin: 0 0 12px; font-size: 14px; border-bottom: 1px solid var(--line); padding-bottom: 6px; }
    .field-row { display: grid; grid-template-columns: 1fr 54px; gap: 10px; align-items: start; margin-bottom: 12px; }
    .conf { font-size: 12px; text-align: right; padding-top: 16px; }
    .cand { grid-column: 1 / 2; margin-top: 6px; }
    .lines table { width: 100%; border-collapse: collapse; margin-top: 6px; }
    .lines th, .lines td { border-bottom: 1px solid var(--line); padding: 6px; font-size: 13px; }
    .lines input { width: 100%; border: 1px solid var(--line); border-radius: 6px; padding: 5px; }
    .bar { display: flex; gap: 10px; margin-top: 16px; align-items: center; position: sticky; bottom: 0;
      background: #fff; padding: 10px 0 4px; border-top: 1px solid var(--line); }
    .toolbar { display: flex; gap: 10px; align-items: center; margin-bottom: 12px; flex-wrap: wrap; }
  `],
  template: `
    @if (detail(); as d) {
      <div class="toolbar">
        <button mat-stroked-button type="button" (click)="back()">← Inbox</button>
        <strong>{{ d.summary.customerId }}</strong> · {{ d.summary.subject }}
        <span class="badge p{{ d.summary.priority }}">P{{ d.summary.priority }}</span>
        @if (template(); as t) { <span style="color:var(--muted)">· {{ t.name }} (v{{ t.version }})</span> }
        <span style="flex:1"></span>
        @if (session.isManager() && !isClosed(d)) {
          <button mat-stroked-button type="button" (click)="openDelegatePopup(d)">Delegate</button>
        }
      </div>

      <ng-template #delegatePopupTpl>
        <div style="padding-top:6px;">
          <of-select
            label="Delegate to team member"
            placeholder="Search user..."
            [searchable]="true"
            [options]="userOptions()"
            [value]="delegateTarget()"
            (selectionChanged)="delegateTarget.set($any($event) || '')"
          />
        </div>
      </ng-template>

      <div class="workspace">
        <!-- LEFT: PDF viewer -->
        <section class="pane">
          <h3>Source document</h3>
          <div class="doc-tabs">
            @for (doc of d.documents; track doc.id) {
              <button mat-stroked-button type="button" (click)="viewDoc(d.summary.orderId, doc.id)">{{ doc.fileName }}</button>
            }
          </div>
          <iframe [src]="pdfUrl()"></iframe>
        </section>

        <!-- RIGHT: dynamic form built from the customer's entity class using reusable Material wrappers -->
        <section class="pane card form">
          @if (isClosed(d)) {
            <div style="margin-bottom:12px;">
              <of-alert severity="info" title="Completed task" message="This validation task is already closed and shown in read-only mode." />
            </div>
          } @else if (d.summary.minConfidence < 0.8) {
            <div style="margin-bottom:12px;">
              <of-alert
                severity="warning"
                title="Low extraction confidence"
                message="One or more fields scored below 80%. Please verify highlighted fields against the source PDF."
                [dismissible]="true"
              />
            </div>
          }

          @if (message()) {
            <div style="margin-bottom:12px;">
              <of-alert severity="error" [message]="message()!" [dismissible]="true" (dismissed)="message.set(null)" />
            </div>
          }

          @if (template(); as t) {
            @for (sec of t.sections; track sec.key) {
              <div class="section">
                <h4>{{ sec.title }}</h4>

                @if (sec.type === 'table') {
                  <div class="lines">
                    <table>
                      <thead>
                        <tr>
                          @for (col of sec.columns ?? []; track col.key) { <th>{{ col.label }}</th> }
                          <th>Conf</th>
                        </tr>
                      </thead>
                      <tbody>
                        @for (l of lines(); track l.id) {
                          <tr>
                            <td><input [readonly]="isClosed(d)" [(ngModel)]="l.sku" /></td>
                            <td><input [readonly]="isClosed(d)" [(ngModel)]="l.description" /></td>
                            <td><input [readonly]="isClosed(d)" type="number" [(ngModel)]="l.quantity" /></td>
                            <td><input [readonly]="isClosed(d)" type="number" [(ngModel)]="l.unitPrice" /></td>
                            <td [class.sla-warn]="l.confidence < 0.8">{{ (l.confidence * 100) | number:'1.0-0' }}%</td>
                          </tr>
                        }
                      </tbody>
                    </table>
                  </div>
                } @else {
                  @for (f of sec.fields ?? []; track f.key) {
                    <div class="field-row">
                      <div>
                        @switch (f.type) {
                          @case ('select') {
                            <of-select
                              [label]="f.label"
                              [options]="selectOptions(f)"
                              [allowEmpty]="!f.required"
                              [required]="f.required"
                              [disabled]="isClosed(d) || !!f.disabled || !!f.readOnly"
                              [errorMessage]="fieldError(f)"
                              [value]="values()[f.key] || null"
                              (selectionChanged)="set(f.key, $any($event) ?? '')"
                            />
                          }
                          @case ('textarea') {
                            <of-textarea
                              [label]="f.label"
                              [required]="f.required"
                              [readonly]="isClosed(d) || !!f.readOnly"
                              [disabled]="!!f.disabled"
                              [errorMessage]="fieldError(f)"
                              [value]="values()[f.key]"
                              (valueChanged)="set(f.key, $event)"
                            />
                          }
                          @case ('checkbox') {
                            <of-checkbox
                              [label]="f.label"
                              [required]="f.required"
                              [disabled]="isClosed(d) || !!f.disabled || !!f.readOnly"
                              [errorMessage]="fieldError(f)"
                              [checked]="values()[f.key] === 'true'"
                              (checkedChange)="set(f.key, $event ? 'true' : 'false')"
                            />
                          }
                          @default {
                            <of-textbox
                              [label]="f.label"
                              [type]="f.type === 'number' ? 'number' : (f.type === 'date' ? 'date' : 'text')"
                              [required]="f.required"
                              [readonly]="isClosed(d) || !!f.readOnly"
                              [disabled]="!!f.disabled"
                              [clearable]="!f.readOnly && !f.disabled && !isClosed(d)"
                              [errorMessage]="fieldError(f)"
                              [value]="values()[f.key]"
                              (valueChanged)="set(f.key, $event)"
                            />
                          }
                        }

                        @if (f.localized && candidates(f).length && !isClosed(d)) {
                          <div class="cand">
                            <of-select
                              label="Locate extracted candidate"
                              placeholder="— choose the right one —"
                              [options]="candidateOptions(f)"
                              [allowEmpty]="true"
                              (selectionChanged)="pickCandidateValue(f.key, $any($event))"
                            />
                          </div>
                        }
                      </div>

                      <span class="conf" [class.sla-warn]="low(f)">{{ confPercent(f) }}</span>
                    </div>
                  }
                }
              </div>
            }

            @if (!isClosed(d)) {
              <div class="bar">
                <button mat-flat-button color="primary" type="button" [disabled]="submitting()" (click)="submit(d, true)">
                  Approve &amp; Submit
                </button>
                <button mat-stroked-button color="warn" type="button" [disabled]="submitting()" (click)="submit(d, false)">
                  Reject
                </button>
              </div>
            }
          } @else {
            <p>Loading form…</p>
          }
        </section>
      </div>
    } @else {
      <p>Loading…</p>
    }
  `,
})
export class ValidationWorkspaceComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly svc = inject(TaskService);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly toast = inject(AppToastService);
  private readonly dialogs = inject(AppDialogService);
  readonly session = inject(Session);

  readonly detail = signal<TaskDetail | null>(null);
  readonly template = signal<FormTemplate | null>(null);
  readonly lines = signal<LineDto[]>([]);
  readonly users = signal<UserSummary[]>([]);
  readonly delegateTarget = signal('');
  readonly pdfUrl = signal<SafeResourceUrl | null>(null);
  readonly submitting = signal(false);
  readonly message = signal<string | null>(null);
  readonly showErrors = signal(false);
  readonly values = signal<Record<string, string>>({});

  readonly userOptions = computed<UiOption<string>[]>(() =>
    this.users().map((u) => ({ label: u.displayName, value: u.id })),
  );

  private byExtraction = new Map<string, FieldDto>();

  @ViewChild('delegatePopupTpl', { static: true }) delegatePopupTpl!: TemplateRef<{ $implicit: unknown; close: (r?: unknown) => void }>;

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.svc.getUsers().subscribe({ next: (u) => this.users.set(u), error: () => {} });

    this.svc.getDetail(id).subscribe((d) => {
      this.detail.set(d);
      this.lines.set(d.lines.map((l) => ({ ...l })));
      this.byExtraction = new Map(d.fields.map((f) => [f.name, f]));
      if (d.documents.length) this.viewDoc(d.summary.orderId, d.documents[0].id);

      if (d.summary.status !== TaskStatusCode.Completed && d.summary.status !== TaskStatusCode.Cancelled) {
        this.svc.open(id).subscribe({ error: () => {} });
      }

      this.svc.getFormTemplate(d.summary.customerId).subscribe((t) => {
        this.template.set(t);
        this.prefill(t, d.boundEntity ?? null);
      });
    });
  }

  private prefill(t: FormTemplate, boundEntity: Record<string, string | null> | null): void {
    const next: Record<string, string> = {};
    for (const sec of t.sections) {
      if (sec.type === 'table') continue;
      for (const f of sec.fields ?? []) {
        const ext = f.extractionField ? this.byExtraction.get(f.extractionField) : undefined;
        const boundVal = boundEntity ? boundEntity[f.key] : undefined;
        next[f.key] = ext?.validatedValue ?? ext?.extractedValue ?? boundVal ?? '';
      }
    }
    this.values.set(next);
  }

  set(key: string, value: string): void {
    this.values.update((cur) => ({ ...cur, [key]: value }));
  }

  selectOptions(f: FormFieldDef): UiOption<string>[] {
    return (f.options ?? []).map((opt) => ({ label: opt, value: opt }));
  }

  candidateOptions(f: FormFieldDef): UiOption<string>[] {
    return this.candidates(f)
      .filter((c) => Boolean(c.value))
      .map((c) => ({
        label: `${c.label ?? 'Candidate'}: ${c.value} (${Math.round(c.confidence * 100)}%)`,
        value: c.value!,
      }));
  }

  pickCandidateValue(key: string, value: string | null): void {
    if (value) this.set(key, value);
  }

  candidates(f: FormFieldDef): FieldCandidate[] {
    const ext = f.extractionField ? this.byExtraction.get(f.extractionField) : undefined;
    return ext?.candidates ?? [];
  }

  low(f: FormFieldDef): boolean {
    const ext = f.extractionField ? this.byExtraction.get(f.extractionField) : undefined;
    return ext ? ext.confidence < 0.8 : false;
  }

  confPercent(f: FormFieldDef): string {
    const ext = f.extractionField ? this.byExtraction.get(f.extractionField) : undefined;
    return ext ? `${Math.round(ext.confidence * 100)}%` : '—';
  }

  fieldError(f: FormFieldDef): string | null {
    if (!this.showErrors() || f.disabled || f.readOnly) return null;
    const val = (this.values()[f.key] ?? '').trim();
    if (f.required && !val) return `${f.label} is required.`;
    if (f.regex && val) {
      try {
        if (!new RegExp(f.regex).test(val)) return `Expected format: ${f.regex}`;
      } catch {
        /* ignore invalid regex */
      }
    }
    return null;
  }

  isClosed(d: TaskDetail): boolean {
    return d.summary.status === TaskStatusCode.Completed || d.summary.status === TaskStatusCode.Cancelled;
  }

  viewDoc(orderId: string, docId: string): void {
    this.svc.getDocumentSas(orderId, docId).subscribe((r) => {
      this.pdfUrl.set(this.sanitizer.bypassSecurityTrustResourceUrl(r.url));
    });
  }

  async submit(d: TaskDetail, approved: boolean): Promise<void> {
    const t = this.template();
    if (!t) return;

    if (approved) {
      this.showErrors.set(true);
      const hasErrors = t.sections.some((sec) =>
        (sec.fields ?? []).some((f) => this.fieldError(f) !== null),
      );
      if (hasErrors) {
        this.message.set('Please fix the highlighted fields before approving.');
        return;
      }
    } else {
      const confirmed = await this.dialogs.confirmAsync({
        title: 'Reject Order?',
        message: 'Are you sure you want to reject this order? This will finalize the workflow as rejected.',
        confirmText: 'Reject Order',
        cancelText: 'Cancel',
        severity: 'danger',
      });
      if (!confirmed) return;
    }

    this.submitting.set(true);
    this.message.set(null);

    const curValues = this.values();
    const fields: { name: string; value: string | null }[] = [];
    for (const sec of t.sections) {
      if (sec.type === 'table') continue;
      for (const f of sec.fields ?? []) {
        fields.push({ name: f.extractionField ?? f.key, value: curValues[f.key] ?? null });
      }
    }

    const body: SubmitValidation = {
      approved,
      fields,
      lines: this.lines().map((l) => ({
        id: l.id, sku: l.sku ?? null, description: l.description ?? null,
        quantity: Number(l.quantity), unitPrice: Number(l.unitPrice),
      })),
      note: null,
    };

    this.svc.submit(d.summary.taskId, body).subscribe({
      next: () => {
        this.toast.success(approved ? 'Validation approved and submitted.' : 'Order rejected.');
        this.router.navigate(['/inbox']);
      },
      error: (e) => {
        this.submitting.set(false);
        const msg = e?.error?.error ?? 'Submit failed (it may have been changed by someone else).';
        this.message.set(msg);
        this.toast.error(msg);
      },
    });
  }

  openDelegatePopup(d: TaskDetail): void {
    this.delegateTarget.set(d.summary.assignedToUserId ?? 'rep-2');
    const ref = this.dialogs.openPopup({
      title: 'Delegate Task',
      subtitle: `${d.summary.customerId} · ${d.summary.subject ?? ''}`,
      size: 'sm',
      template: this.delegatePopupTpl,
      confirmText: 'Delegate',
      cancelText: 'Cancel',
    });

    ref.afterClosed().subscribe((confirmed) => {
      const target = this.delegateTarget();
      if (!confirmed || !target) return;
      this.svc.delegate(d.summary.taskId, target).subscribe({
        next: () => {
          this.toast.success(`Delegated task to ${target}.`);
          this.router.navigate(['/inbox']);
        },
        error: (err) => this.toast.error(err?.error?.error ?? 'Delegation failed.'),
      });
    });
  }

  back(): void {
    this.router.navigate(['/inbox']);
  }
}
