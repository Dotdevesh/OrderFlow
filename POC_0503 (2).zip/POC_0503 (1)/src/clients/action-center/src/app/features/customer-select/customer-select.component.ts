import { Component, OnInit, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from '../../core/task.service';
import { CustomerContext } from '../../core/customer-context';
import { Customer, PriorityLabel } from '../../core/models';

@Component({
  selector: 'app-customer-select',
  standalone: true,
  styles: [`
    .wrap { max-width: 720px; margin: 40px auto; }
    h2 { margin: 0 0 6px; }
    p.sub { color: var(--muted); margin: 0 0 20px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 14px; }
    .cust { padding: 16px; cursor: pointer; transition: box-shadow .15s, transform .15s; }
    .cust:hover { box-shadow: 0 6px 18px rgba(0,0,0,.08); transform: translateY(-2px); }
    .cust h3 { margin: 0 0 8px; }
    .meta { display: flex; gap: 8px; align-items: center; color: var(--muted); font-size: 13px; }
    .tier { font-weight: 600; }
  `],
  template: `
    <div class="wrap">
      <h2>Select a customer</h2>
      <p class="sub">Choose the customer you want to work on. The inbox and forms will be scoped to them.</p>
      <div class="grid">
        @for (c of customers(); track c.customerId) {
          <div class="card cust" (click)="choose(c)">
            <h3>{{ c.displayName }}</h3>
            <div class="meta">
              <span class="badge p{{ c.priority }}">{{ priorityLabel(c.priority) }}</span>
              <span class="tier">SLA {{ c.slaMinutes }}m</span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class CustomerSelectComponent implements OnInit {
  private readonly svc = inject(TaskService);
  private readonly ctx = inject(CustomerContext);
  private readonly router = inject(Router);

  readonly customers = signal<Customer[]>([]);

  ngOnInit(): void {
    this.svc.getCustomers().subscribe((c) => this.customers.set(c));
  }

  choose(c: Customer): void {
    this.ctx.select(c);
    this.router.navigate(['/inbox']);
  }

  priorityLabel(p: number): string {
    return PriorityLabel[p as 0 | 1 | 2];
  }
}
