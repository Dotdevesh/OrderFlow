import {
  Component,
  OnDestroy,
  OnInit,
  TemplateRef,
  ViewChild,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { Session } from '../../core/session';
import { TaskService } from '../../core/task.service';
import { RealtimeService } from '../../core/realtime.service';
import { CustomerContext } from '../../core/customer-context';
import { InboxScope, PriorityLabel, TaskStatusCode, TaskSummary, UserSummary } from '../../core/models';
import {
  AppDataTableComponent,
  AppDialogService,
  AppSelectComponent,
  AppToastService,
  SearchFormFieldDef,
  TableColumnDef,
  UiOption,
} from '../../shared/ui';

interface StatusTab {
  label: string;
  value: number | null;
}

@Component({
  selector: 'app-inbox',
  standalone: true,
  imports: [
    DecimalPipe,
    MatButtonModule,
    AppDataTableComponent,
    AppSelectComponent,
  ],
  styles: [`
    .tabs { display: flex; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; align-items: center; }
    .tabs .btn.active { background: #0f172a; color: #fff; border-color: #0f172a; }
    .subtabs { display: flex; gap: 6px; margin-bottom: 14px; flex-wrap: wrap; }
    .subtabs .btn { padding: 5px 10px; font-size: 13px; }
    .subtabs .btn.active { background: var(--primary); color: #fff; border-color: var(--primary); }
    .row-actions { display: flex; gap: 6px; align-items: center; }
    .scope-label { color: var(--muted); font-size: 13px; margin-left: auto; align-self: center; }
  `],
  template: `
    <div class="tabs">
      <button class="btn" [class.active]="scope() === 'mine'" (click)="setScope('mine')">My Tasks</button>
      <button class="btn" [class.active]="scope() === 'pool'" (click)="setScope('pool')">Pending Pool</button>
      @if (session.isManager()) {
        <button class="btn" [class.active]="scope() === 'team'" (click)="setScope('team')">Team</button>
      }
      <span class="scope-label">Customer: <strong>{{ customerName() }}</strong></span>
      <button class="btn" (click)="reload()">Refresh</button>
    </div>

    <div class="subtabs">
      @for (s of statusTabs; track s.label) {
        <button class="btn" [class.active]="status() === s.value" (click)="setStatus(s.value)">{{ s.label }}</button>
      }
    </div>

    <ng-template #priorityTpl let-row>
      <span class="badge p{{ row.priority }}">{{ priorityLabel(row) }}</span>
    </ng-template>

    <ng-template #assigneeTpl let-row>
      {{ displayUser(row.assignedToUserId) }}
    </ng-template>

    <ng-template #confTpl let-row>
      <span [class.sla-warn]="row.minConfidence < 0.8">{{ (row.minConfidence * 100) | number:'1.0-0' }}%</span>
    </ng-template>

    <ng-template #slaTpl let-row>
      <span [class]="slaClass(row)">{{ countdown(row) }}</span>
    </ng-template>

    <ng-template #statusTpl let-row>
      {{ statusName(row.status) }}
    </ng-template>

    <ng-template #actionsTpl let-row>
      <div class="row-actions" (click)="$event.stopPropagation()">
        <button mat-flat-button color="primary" type="button" (click)="open(row)">Open</button>
        @if (canClaim(row)) {
          <button mat-stroked-button type="button" (click)="claim(row, $event)">Claim</button>
        }
        @if (session.isManager() && isOpen(row)) {
          <button mat-stroked-button type="button" (click)="openAssignPopup(row, $event)">
            {{ row.status === pendingCode ? 'Assign' : 'Delegate' }}
          </button>
        }
      </div>
    </ng-template>

    <ng-template #assignTpl let-data>
      <div style="padding-top:6px;">
        <of-select
          label="Team member"
          placeholder="Search user..."
          [searchable]="true"
          [options]="userOptions()"
          [value]="selectedAssignee()"
          (selectionChanged)="selectedAssignee.set($any($event) || '')"
        />
      </div>
    </ng-template>

    <of-data-table
      [data]="tasks()"
      [columns]="columns()"
      [showPagination]="true"
      [pageSize]="10"
      [pageSizeOptions]="[5, 10, 25, 50]"
      [sortable]="true"
      [showColumnFilters]="true"
      [showSearchForm]="true"
      searchLabel="Search tasks"
      searchPlaceholder="Subject, customer, assignee..."
      [searchFields]="searchFields"
      emptyMessage="No tasks in this view."
      (rowClick)="open($event)"
    />
  `,
})
export class InboxComponent implements OnInit, OnDestroy {
  private readonly svc = inject(TaskService);
  private readonly router = inject(Router);
  private readonly realtime = inject(RealtimeService);
  private readonly ctx = inject(CustomerContext);
  private readonly toast = inject(AppToastService);
  private readonly dialogs = inject(AppDialogService);
  readonly session = inject(Session);

  readonly pendingCode = TaskStatusCode.Pending;
  readonly scope = signal<InboxScope>('mine');
  readonly status = signal<number | null>(null);
  readonly tasks = signal<TaskSummary[]>([]);
  readonly users = signal<UserSummary[]>([]);
  readonly selectedAssignee = signal<string>('rep-1');
  private readonly now = signal(Date.now());
  private timerId?: ReturnType<typeof setInterval>;

  readonly userOptions = computed<UiOption<string>[]>(() =>
    this.users().map((u) => ({ label: u.displayName, value: u.id })),
  );

  readonly columns = signal<TableColumnDef<TaskSummary>[]>([]);

  readonly searchFields: SearchFormFieldDef[] = [
    {
      key: 'priority',
      label: 'Priority',
      type: 'select',
      options: [
        { label: 'High', value: 'High' },
        { label: 'Standard', value: 'Standard' },
        { label: 'Low', value: 'Low' },
      ],
    },
    {
      key: 'status',
      label: 'Status',
      type: 'select',
      options: [
        { label: 'Pending', value: 'Pending' },
        { label: 'Assigned', value: 'Assigned' },
        { label: 'InProgress', value: 'InProgress' },
        { label: 'Completed', value: 'Completed' },
        { label: 'Escalated', value: 'Escalated' },
      ],
    },
  ];

  readonly statusTabs: StatusTab[] = [
    { label: 'All', value: null },
    { label: 'Pending', value: TaskStatusCode.Pending },
    { label: 'Assigned', value: TaskStatusCode.Assigned },
    { label: 'In Progress', value: TaskStatusCode.InProgress },
    { label: 'Completed', value: TaskStatusCode.Completed },
    { label: 'Escalated', value: TaskStatusCode.Escalated },
  ];

  @ViewChild('priorityTpl', { static: true }) priorityTpl!: TemplateRef<{ $implicit: TaskSummary; row: TaskSummary; value: unknown }>;
  @ViewChild('assigneeTpl', { static: true }) assigneeTpl!: TemplateRef<{ $implicit: TaskSummary; row: TaskSummary; value: unknown }>;
  @ViewChild('confTpl', { static: true }) confTpl!: TemplateRef<{ $implicit: TaskSummary; row: TaskSummary; value: unknown }>;
  @ViewChild('slaTpl', { static: true }) slaTpl!: TemplateRef<{ $implicit: TaskSummary; row: TaskSummary; value: unknown }>;
  @ViewChild('statusTpl', { static: true }) statusTpl!: TemplateRef<{ $implicit: TaskSummary; row: TaskSummary; value: unknown }>;
  @ViewChild('actionsTpl', { static: true }) actionsTpl!: TemplateRef<{ $implicit: TaskSummary; row: TaskSummary; value: unknown }>;
  @ViewChild('assignTpl', { static: true }) assignTpl!: TemplateRef<{ $implicit: TaskSummary; close: (r?: unknown) => void }>;

  constructor() {
    effect(() => {
      const evt = this.realtime.lastEvent();
      if (evt && this.ctx.selected()) this.reload();
    });
    effect(() => {
      this.session.userId();
      if (!this.session.isManager() && this.scope() === 'team') {
        this.scope.set('mine');
      }
      if (this.ctx.selected()) this.reload();
    });
  }

  async ngOnInit(): Promise<void> {
    if (!this.ctx.selected()) {
      this.router.navigate(['/select-customer']);
      return;
    }

    this.columns.set([
      { key: 'priority', header: 'Priority', sortable: true, filterable: true, accessor: (r) => this.priorityLabel(r), cellTemplate: this.priorityTpl },
      { key: 'customerId', header: 'Customer', sortable: true, filterable: true },
      { key: 'subject', header: 'Subject', sortable: true, filterable: true, accessor: (r) => r.subject || '—' },
      { key: 'assignedToUserId', header: 'Assigned To', sortable: true, filterable: true, accessor: (r) => this.displayUser(r.assignedToUserId), cellTemplate: this.assigneeTpl },
      { key: 'minConfidence', header: 'Confidence', sortable: true, filterable: false, align: 'right', cellTemplate: this.confTpl },
      { key: 'slaDueAtUtc', header: 'SLA', sortable: true, filterable: false, cellTemplate: this.slaTpl },
      { key: 'status', header: 'Status', sortable: true, filterable: true, accessor: (r) => this.statusName(r.status), cellTemplate: this.statusTpl },
      { key: 'actions', header: '', sortable: false, filterable: false, cellTemplate: this.actionsTpl },
    ]);

    this.timerId = setInterval(() => this.now.set(Date.now()), 1000);
    this.svc.getUsers().subscribe({ next: (u) => this.users.set(u), error: () => {} });
    this.reload();
    try {
      await this.realtime.connect(this.session.teamScopeId());
    } catch {
      /* hub optional in dev */
    }
  }

  ngOnDestroy(): void {
    if (this.timerId) clearInterval(this.timerId);
  }

  customerName(): string {
    return this.ctx.selected()?.displayName ?? '—';
  }

  setScope(s: InboxScope): void {
    this.scope.set(s);
    this.reload();
  }

  setStatus(v: number | null): void {
    this.status.set(v);
    this.reload();
  }

  reload(): void {
    const customerId = this.ctx.selected()?.customerId ?? null;
    this.svc.getInbox(this.scope(), customerId, this.status()).subscribe((t) => this.tasks.set(t));
  }

  open(t: TaskSummary): void {
    this.router.navigate(['/tasks', t.taskId]);
  }

  claim(t: TaskSummary, e: Event): void {
    e.stopPropagation();
    this.svc.claim(t.taskId).subscribe({
      next: () => {
        this.toast.success('Task claimed.');
        this.reload();
      },
      error: (err) => this.toast.error(err?.error?.error ?? 'Could not claim task.'),
    });
  }

  openAssignPopup(t: TaskSummary, e: Event): void {
    e.stopPropagation();
    this.selectedAssignee.set(t.assignedToUserId ?? 'rep-1');
    const isAssign = t.status === TaskStatusCode.Pending;
    const ref = this.dialogs.openPopup({
      title: isAssign ? 'Assign Task' : 'Delegate Task',
      subtitle: t.subject ?? t.customerId,
      size: 'sm',
      template: this.assignTpl,
      data: t,
      confirmText: isAssign ? 'Assign' : 'Delegate',
      cancelText: 'Cancel',
    });

    ref.afterClosed().subscribe((confirmed) => {
      const target = this.selectedAssignee();
      if (!confirmed || !target) return;
      const op = isAssign ? this.svc.assign(t.taskId, target) : this.svc.delegate(t.taskId, target);
      op.subscribe({
        next: () => {
          this.toast.success(`${isAssign ? 'Assigned' : 'Delegated'} to ${this.displayUser(target)}.`);
          this.reload();
        },
        error: (err) => this.toast.error(err?.error?.error ?? 'Operation failed.'),
      });
    });
  }

  canClaim(t: TaskSummary): boolean {
    return t.status === TaskStatusCode.Pending;
  }

  isOpen(t: TaskSummary): boolean {
    return t.status !== TaskStatusCode.Completed && t.status !== TaskStatusCode.Cancelled;
  }

  displayUser(userId?: string | null): string {
    if (!userId) return 'Unassigned';
    return this.users().find((u) => u.id === userId)?.displayName ?? userId;
  }

  priorityLabel(t: TaskSummary): string {
    return PriorityLabel[t.priority];
  }

  statusName(status: number): string {
    return ['Pending', 'Assigned', 'Claimed', 'InProgress', 'Completed', 'Escalated', 'Cancelled'][status] ?? '—';
  }

  countdown(t: TaskSummary): string {
    const ms = new Date(t.slaDueAtUtc).getTime() - this.now();
    if (ms <= 0) return 'BREACHED';
    const m = Math.floor(ms / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    return `${m}m ${s}s`;
  }

  slaClass(t: TaskSummary): string {
    const ms = new Date(t.slaDueAtUtc).getTime() - this.now();
    if (ms <= 0) return 'sla-breach';
    if (ms < 5 * 60000) return 'sla-warn';
    return 'sla-ok';
  }
}
