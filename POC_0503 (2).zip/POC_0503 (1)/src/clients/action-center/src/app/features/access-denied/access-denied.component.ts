import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../core/auth.service';
import { Session } from '../../core/session';

@Component({
  selector: 'app-access-denied',
  standalone: true,
  imports: [MatButtonModule],
  styles: [`
    .wrap { max-width: 640px; margin: 56px auto; padding: 28px; }
    h2 { margin: 0 0 10px; color: #991b1b; }
    .subtitle { color: var(--muted); margin: 0 0 18px; line-height: 1.5; }
    .meta { background: #f8fafc; border: 1px solid var(--line); border-radius: 8px; padding: 14px; font-size: 13px; margin-bottom: 20px; }
    .meta div { margin-bottom: 6px; }
    .meta div:last-child { margin-bottom: 0; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; }
  `],
  template: `
    <section class="card wrap">
      <h2>Access Restricted — AD Group &amp; Role Required</h2>
      <p class="subtitle">
        To access the OrderFlow Action Center, your Windows / Microsoft Entra ID account must be
        both a member of an authorized <strong>Active Directory Security Group</strong> and assigned
        an OrderFlow <strong>Role</strong> (<code>Manager</code> or <code>Reportee</code>) synced in the Identity database.
      </p>

      <div class="meta">
        <div><strong>Signed-in identity:</strong> {{ session.upn() || session.name() || 'Not signed in' }}</div>
        <div><strong>Authentication method:</strong> {{ session.authMethod() }}</div>
        @if (session.denialCode()) {
          <div><strong>Status code:</strong> <code>{{ session.denialCode() }}</code></div>
        }
        @if (session.denialReason()) {
          <div><strong>Details:</strong> {{ session.denialReason() }}</div>
        }
      </div>

      <div class="actions">
        <button mat-flat-button color="primary" type="button" [disabled]="checking()" (click)="retryWindowsSso()">
          Sign in with Windows Credentials
        </button>
        <button mat-stroked-button type="button" [disabled]="checking()" (click)="retryEntra()">
          Sign in with Microsoft Entra ID
        </button>
        @if (session.isAuthenticated()) {
          <button mat-stroked-button type="button" [disabled]="checking()" (click)="recheckAccess()">
            Re-check AD Group &amp; Role
          </button>
          <button mat-stroked-button color="warn" type="button" (click)="logout()">
            Sign out
          </button>
        }
      </div>
    </section>
  `,
})
export class AccessDeniedComponent {
  readonly session = inject(Session);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  readonly checking = signal(false);

  async retryWindowsSso(): Promise<void> {
    this.checking.set(true);
    try {
      await this.auth.tryWindowsNegotiateSso();
      if (this.session.isAuthorized()) {
        await this.router.navigate(['/inbox']);
      }
    } finally {
      this.checking.set(false);
    }
  }

  async retryEntra(): Promise<void> {
    await this.auth.loginWithEntraRedirect();
  }

  async recheckAccess(): Promise<void> {
    this.checking.set(true);
    try {
      await this.auth.verifyPrincipalWithIdentityService();
      if (this.session.isAuthorized()) {
        await this.router.navigate(['/inbox']);
      }
    } finally {
      this.checking.set(false);
    }
  }

  async logout(): Promise<void> {
    await this.auth.logout();
  }
}
