import {
  Component,
  computed,
  forwardRef,
  input,
  linkedSignal,
  model,
  output,
  signal,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { UiFieldAppearance, UiOption } from '../ui-types';

/**
 * Reusable Material dropdown supporting:
 * - Single select (`multiple = false`)
 * - Multiselect (`multiple = true`)
 * - Searchable single & multiselect (`searchable = true`)
 * Uses `linkedSignal` to keep search query and valid selections in sync with reactive options.
 */
@Component({
  selector: 'of-select',
  standalone: true,
  imports: [MatFormFieldModule, MatSelectModule, MatIconModule, MatButtonModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AppSelectComponent),
      multi: true,
    },
  ],
  styles: [`
    :host { display: block; width: 100%; }
    .of-field { width: 100%; }
    .search-header {
      position: sticky; top: 0; z-index: 2; background: #fff;
      padding: 8px 10px; border-bottom: 1px solid var(--line, #e2e6ec);
      display: flex; flex-direction: column; gap: 6px;
    }
    .search-box {
      display: flex; align-items: center; gap: 6px;
      border: 1px solid var(--line, #e2e6ec); border-radius: 6px; padding: 4px 8px;
    }
    .search-box input {
      border: none; outline: none; width: 100%; font-size: 13px; background: transparent;
    }
    .search-box mat-icon { width: 18px; height: 18px; font-size: 18px; color: var(--muted, #6b7686); }
    .bulk-actions {
      display: flex; justify-content: space-between; align-items: center; font-size: 12px;
    }
    .bulk-btn {
      background: none; border: none; color: var(--primary, #2563eb); cursor: pointer;
      padding: 2px 4px; font-size: 12px; font-weight: 500;
    }
    .bulk-btn:disabled { opacity: 0.45; cursor: not-allowed; }
    .no-match { padding: 12px 16px; color: var(--muted, #6b7686); font-size: 13px; }
  `],
  template: `
    <mat-form-field [appearance]="appearance()" class="of-field" subscriptSizing="dynamic">
      @if (label()) {
        <mat-label>{{ label() }}</mat-label>
      }

      <mat-select
        [value]="internalValue()"
        [multiple]="multiple()"
        [placeholder]="placeholder()"
        [disabled]="isDisabled()"
        [required]="required()"
        (selectionChange)="onSelectChange($event)"
        (openedChange)="onOpenedChange($event)"
      >
        <mat-select-trigger>{{ triggerText() }}</mat-select-trigger>

        @if (searchable() || (multiple() && showSelectAll())) {
          <div class="search-header" (click)="$event.stopPropagation()" (keydown)="$event.stopPropagation()">
            @if (searchable()) {
              <div class="search-box">
                <mat-icon svgIcon="ui-search" />
                <input
                  type="text"
                  [value]="searchQuery()"
                  [placeholder]="searchPlaceholder()"
                  (input)="onSearchInput($event)"
                />
                @if (searchQuery()) {
                  <button
                    type="button"
                    class="bulk-btn"
                    aria-label="Clear search"
                    (click)="searchQuery.set('')"
                  >
                    Clear
                  </button>
                }
              </div>
            }
            @if (multiple() && showSelectAll()) {
              <div class="bulk-actions">
                <span>{{ selectedArray().length }} selected</span>
                <span>
                  <button type="button" class="bulk-btn" (click)="selectAllVisible()">
                    Select all{{ searchQuery() ? ' matching' : '' }}
                  </button>
                  <button type="button" class="bulk-btn" [disabled]="selectedArray().length === 0" (click)="clearAll()">
                    Clear
                  </button>
                </span>
              </div>
            }
          </div>
        }

        @if (!multiple() && allowEmpty()) {
          <mat-option [value]="null">{{ emptyLabel() }}</mat-option>
        }

        @for (opt of filteredOptions(); track opt.value) {
          <mat-option [value]="opt.value" [disabled]="!!opt.disabled">
            {{ opt.label }}
          </mat-option>
        }

        @if (filteredOptions().length === 0) {
          <div class="no-match">No matching options</div>
        }
      </mat-select>

      @if (hint() && !errorMessage()) {
        <mat-hint>{{ hint() }}</mat-hint>
      }
      @if (errorMessage()) {
        <mat-error>{{ errorMessage() }}</mat-error>
      }
    </mat-form-field>
  `,
})
export class AppSelectComponent<T = string> implements ControlValueAccessor {
  readonly label = input<string>('');
  readonly placeholder = input<string>('Select...');
  readonly options = input<readonly UiOption<T>[]>([]);
  readonly multiple = input<boolean>(false);
  readonly searchable = input<boolean>(false);
  readonly searchPlaceholder = input<string>('Search options...');
  readonly showSelectAll = input<boolean>(true);
  readonly allowEmpty = input<boolean>(false);
  readonly emptyLabel = input<string>('— None —');
  readonly appearance = input<UiFieldAppearance>('outline');
  readonly hint = input<string>('');
  readonly errorMessage = input<string | null>(null);
  readonly disabled = input<boolean>(false);
  readonly required = input<boolean>(false);

  /** Two-way bindable signal: `T | null` when single, `T[]` when multiple. */
  readonly value = model<T | T[] | null>(null);
  readonly selectionChanged = output<T | T[] | null>();

  /** Linked search query that automatically clears when options list is replaced or panel closes. */
  readonly searchQuery = linkedSignal({
    source: this.options,
    computation: () => '',
  });

  /**
   * Linked internal value synced with `value` and pruned whenever `options` changes
   * so stale/removed option values never remain selected.
   */
  readonly internalValue = linkedSignal<
    { val: T | T[] | null; opts: readonly UiOption<T>[]; multi: boolean },
    T | T[] | null
  >({
    source: () => ({ val: this.value(), opts: this.options(), multi: this.multiple() }),
    computation: (src) => {
      const validSet = new Set(src.opts.map((o) => o.value));
      if (src.multi) {
        const arr = Array.isArray(src.val) ? src.val : src.val !== null ? [src.val] : [];
        return arr.filter((v) => validSet.has(v));
      }
      if (src.val === null || src.val === undefined || Array.isArray(src.val)) return null;
      return validSet.has(src.val) ? src.val : null;
    },
  });

  readonly filteredOptions = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const opts = this.options();
    if (!q) return opts;
    return opts.filter((o) => o.label.toLowerCase().includes(q));
  });

  readonly selectedArray = computed<T[]>(() => {
    const cur = this.internalValue();
    if (Array.isArray(cur)) return cur;
    return cur !== null && cur !== undefined ? [cur] : [];
  });

  readonly triggerText = computed(() => {
    const opts = this.options();
    const labelMap = new Map(opts.map((o) => [o.value, o.label]));
    if (this.multiple()) {
      const selected = this.selectedArray();
      if (selected.length === 0) return '';
      if (selected.length <= 2) {
        return selected.map((v) => labelMap.get(v) ?? String(v)).join(', ');
      }
      const first = labelMap.get(selected[0]) ?? String(selected[0]);
      return `${first} (+${selected.length - 1} more)`;
    }
    const single = this.internalValue();
    if (single === null || single === undefined || Array.isArray(single)) return '';
    return labelMap.get(single) ?? String(single);
  });

  private readonly cvaDisabled = signal(false);
  readonly isDisabled = computed(() => this.disabled() || this.cvaDisabled());

  private onChange: (v: T | T[] | null) => void = () => {};
  onTouched: () => void = () => {};

  onOpenedChange(opened: boolean): void {
    if (!opened) {
      this.searchQuery.set('');
      this.onTouched();
    }
  }

  onSearchInput(event: Event): void {
    this.searchQuery.set((event.target as HTMLInputElement).value);
  }

  onSelectChange(event: MatSelectChange): void {
    if (!this.multiple()) {
      this.commit(event.value as T | null);
      return;
    }
    // mat-select only reports values of rendered options, so selections hidden by the search filter must be carried over.
    const visible = new Set(this.filteredOptions().map((o) => o.value));
    const hiddenSelected = this.selectedArray().filter((v) => !visible.has(v));
    const visibleSelected = (event.value as T[] | null) ?? [];
    const next = new Set([...hiddenSelected, ...visibleSelected]);
    this.commit(this.options().map((o) => o.value).filter((v) => next.has(v)));
  }

  selectAllVisible(): void {
    if (!this.multiple()) return;
    const enabledVisible = this.filteredOptions()
      .filter((o) => !o.disabled)
      .map((o) => o.value);
    const merged = Array.from(new Set([...this.selectedArray(), ...enabledVisible]));
    this.commit(merged);
  }

  clearAll(): void {
    this.commit(this.multiple() ? [] : null);
  }

  private commit(next: T | T[] | null): void {
    this.internalValue.set(next);
    this.value.set(next);
    this.onChange(next);
    this.selectionChanged.emit(next);
  }

  writeValue(val: T | T[] | null): void {
    this.value.set(val ?? (this.multiple() ? [] : null));
    this.internalValue.set(this.value());
  }

  registerOnChange(fn: (v: T | T[] | null) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.cvaDisabled.set(isDisabled);
  }
}
