import {
  Component,
  computed,
  forwardRef,
  input,
  linkedSignal,
  model,
  output,
  signal,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { UiFieldAppearance } from '../ui-types';

@Component({
  selector: 'of-textbox',
  standalone: true,
  imports: [MatFormFieldModule, MatInputModule, MatIconModule, MatButtonModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AppTextboxComponent),
      multi: true,
    },
  ],
  styles: [`
    :host { display: block; width: 100%; }
    .of-field { width: 100%; }
  `],
  template: `
    <mat-form-field [appearance]="appearance()" class="of-field" subscriptSizing="dynamic">
      @if (label()) {
        <mat-label>{{ label() }}</mat-label>
      }

      @if (prefixSvgIcon()) {
        <mat-icon matPrefix [svgIcon]="prefixSvgIcon()!" />
      } @else if (prefixIcon()) {
        <mat-icon matPrefix>{{ prefixIcon() }}</mat-icon>
      }

      <input
        matInput
        [type]="resolvedType()"
        [value]="draftValue()"
        [placeholder]="placeholder()"
        [readonly]="readonly()"
        [disabled]="isDisabled()"
        [required]="required()"
        [attr.maxlength]="maxLength()"
        (input)="onInput($event)"
        (blur)="onTouched()"
      />

      @if (type() === 'password') {
        <button
          mat-icon-button
          matSuffix
          type="button"
          [attr.aria-label]="hidePassword() ? 'Show password' : 'Hide password'"
          (click)="hidePassword.set(!hidePassword())"
        >
          <mat-icon [svgIcon]="hidePassword() ? 'ui-visibility' : 'ui-visibility-off'" />
        </button>
      } @else if (clearable() && draftValue() && !readonly() && !isDisabled()) {
        <button
          mat-icon-button
          matSuffix
          type="button"
          aria-label="Clear value"
          (click)="clear()"
        >
          <mat-icon svgIcon="ui-close" />
        </button>
      } @else if (suffixSvgIcon()) {
        <mat-icon matSuffix [svgIcon]="suffixSvgIcon()!" />
      } @else if (suffixIcon()) {
        <mat-icon matSuffix>{{ suffixIcon() }}</mat-icon>
      }

      @if (hint() && !errorMessage()) {
        <mat-hint>{{ hint() }}</mat-hint>
      }
      @if (errorMessage()) {
        <mat-error>{{ errorMessage() }}</mat-error>
      }
    </mat-form-field>
  `,
})
export class AppTextboxComponent implements ControlValueAccessor {
  readonly label = input<string>('');
  readonly placeholder = input<string>('');
  readonly type = input<'text' | 'number' | 'email' | 'password' | 'date' | 'tel' | 'url'>('text');
  readonly appearance = input<UiFieldAppearance>('outline');
  readonly hint = input<string>('');
  readonly errorMessage = input<string | null>(null);
  readonly prefixIcon = input<string>('');
  readonly suffixIcon = input<string>('');
  readonly prefixSvgIcon = input<string>('');
  readonly suffixSvgIcon = input<string>('');
  readonly clearable = input<boolean>(false);
  readonly readonly = input<boolean>(false);
  readonly disabled = input<boolean>(false);
  readonly required = input<boolean>(false);
  readonly maxLength = input<number | null>(null);

  readonly value = model<string>('');
  readonly valueChanged = output<string>();

  /** Linked working signal synced to `value` so input edits remain reactive and resettable. */
  readonly draftValue = linkedSignal(() => this.value() ?? '');
  readonly hidePassword = signal(true);

  private readonly cvaDisabled = signal(false);
  readonly isDisabled = computed(() => this.disabled() || this.cvaDisabled());

  readonly resolvedType = computed(() =>
    this.type() === 'password' ? (this.hidePassword() ? 'password' : 'text') : this.type(),
  );

  private onChange: (v: string) => void = () => {};
  onTouched: () => void = () => {};

  onInput(event: Event): void {
    const next = (event.target as HTMLInputElement).value;
    this.commit(next);
  }

  clear(): void {
    this.commit('');
  }

  private commit(next: string): void {
    this.draftValue.set(next);
    this.value.set(next);
    this.onChange(next);
    this.valueChanged.emit(next);
  }

  writeValue(val: string | null): void {
    const normalized = val ?? '';
    this.draftValue.set(normalized);
    this.value.set(normalized);
  }

  registerOnChange(fn: (v: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.cvaDisabled.set(isDisabled);
  }
}
