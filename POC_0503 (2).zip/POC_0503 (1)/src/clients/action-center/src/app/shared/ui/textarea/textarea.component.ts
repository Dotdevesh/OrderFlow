import {
  Component,
  computed,
  forwardRef,
  input,
  linkedSignal,
  model,
  output,
  signal,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { UiFieldAppearance } from '../ui-types';

@Component({
  selector: 'of-textarea',
  standalone: true,
  imports: [MatFormFieldModule, MatInputModule, TextFieldModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AppTextareaComponent),
      multi: true,
    },
  ],
  styles: [`
    :host { display: block; width: 100%; }
    .of-field { width: 100%; }
  `],
  template: `
    <mat-form-field [appearance]="appearance()" class="of-field" subscriptSizing="dynamic">
      @if (label()) {
        <mat-label>{{ label() }}</mat-label>
      }

      <textarea
        matInput
        [rows]="rows()"
        [cdkTextareaAutosize]="autosize()"
        [cdkAutosizeMinRows]="minRows()"
        [cdkAutosizeMaxRows]="maxRows()"
        [value]="draftValue()"
        [placeholder]="placeholder()"
        [readonly]="readonly()"
        [disabled]="isDisabled()"
        [required]="required()"
        [attr.maxlength]="maxLength()"
        (input)="onInput($event)"
        (blur)="onTouched()"
      ></textarea>

      @if (hint() && !errorMessage()) {
        <mat-hint>{{ hint() }}</mat-hint>
      }
      @if (maxLength(); as max) {
        <mat-hint align="end">{{ charCount() }} / {{ max }}</mat-hint>
      }
      @if (errorMessage()) {
        <mat-error>{{ errorMessage() }}</mat-error>
      }
    </mat-form-field>
  `,
})
export class AppTextareaComponent implements ControlValueAccessor {
  readonly label = input<string>('');
  readonly placeholder = input<string>('');
  readonly appearance = input<UiFieldAppearance>('outline');
  readonly rows = input<number>(3);
  readonly autosize = input<boolean>(true);
  readonly minRows = input<number>(2);
  readonly maxRows = input<number>(8);
  readonly hint = input<string>('');
  readonly errorMessage = input<string | null>(null);
  readonly readonly = input<boolean>(false);
  readonly disabled = input<boolean>(false);
  readonly required = input<boolean>(false);
  readonly maxLength = input<number | null>(null);

  readonly value = model<string>('');
  readonly valueChanged = output<string>();

  readonly draftValue = linkedSignal(() => this.value() ?? '');
  readonly charCount = computed(() => this.draftValue().length);

  private readonly cvaDisabled = signal(false);
  readonly isDisabled = computed(() => this.disabled() || this.cvaDisabled());

  private onChange: (v: string) => void = () => {};
  onTouched: () => void = () => {};

  onInput(event: Event): void {
    const next = (event.target as HTMLTextAreaElement).value;
    this.draftValue.set(next);
    this.value.set(next);
    this.onChange(next);
    this.valueChanged.emit(next);
  }

  writeValue(val: string | null): void {
    const normalized = val ?? '';
    this.draftValue.set(normalized);
    this.value.set(normalized);
  }

  registerOnChange(fn: (v: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.cvaDisabled.set(isDisabled);
  }
}
