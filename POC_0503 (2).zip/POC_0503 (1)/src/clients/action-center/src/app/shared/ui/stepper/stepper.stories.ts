import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { AppStepComponent, AppStepperComponent } from './stepper.component';

const meta: Meta<AppStepperComponent> = {
  title: 'UI Wrappers/Navigation/Stepper',
  component: AppStepperComponent,
  tags: ['autodocs'],
  decorators: [moduleMetadata({ imports: [AppStepComponent] })],
  argTypes: {
    orientation: { control: 'select', options: ['horizontal', 'vertical'] },
    finished: { action: 'finished' },
  },
  args: {
    selectedIndex: 0,
    linear: true,
    orientation: 'horizontal',
    showNavigation: true,
    nextLabel: 'Next',
    backLabel: 'Back',
    finishLabel: 'Submit validation',
  },
  render: (args) => ({
    props: args,
    template: `
      <of-stepper
        [(selectedIndex)]="selectedIndex"
        [linear]="linear"
        [orientation]="orientation"
        [showNavigation]="showNavigation"
        [nextLabel]="nextLabel"
        [backLabel]="backLabel"
        [finishLabel]="finishLabel"
        (finished)="finished()"
      >
        <of-step label="Review document">Compare the PDF with the extracted entities.</of-step>
        <of-step label="Validate fields">Correct low-confidence fields (below 80%).</of-step>
        <of-step label="Attachments" [optional]="true">Add any supporting files.</of-step>
        <of-step label="Submit">Submitting resumes the Durable orchestration.</of-step>
      </of-stepper>
    `,
  }),
};

export default meta;
type Story = StoryObj<AppStepperComponent>;

export const Linear: Story = {};

export const Vertical: Story = { args: { orientation: 'vertical' } };

export const FreeNavigation: Story = { args: { linear: false } };

export const BlockedAndErrorSteps: Story = {
  render: (args) => ({
    props: args,
    template: `
      <of-stepper [linear]="true" [selectedIndex]="1" [finishLabel]="finishLabel" (finished)="finished()">
        <of-step label="Review document">Reviewed.</of-step>
        <of-step
          label="Validate fields"
          [completed]="false"
          [hasError]="true"
          errorMessage="2 required fields missing"
        >
          File Number and Property Address are required before you can continue.
        </of-step>
        <of-step label="Submit">Locked until the previous step is complete.</of-step>
      </of-stepper>
    `,
  }),
};
