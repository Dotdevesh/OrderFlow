import { Injectable, Type, computed, inject, signal } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { Observable, firstValueFrom, map } from 'rxjs';
import { AppConfirmDialogComponent } from './confirm-dialog.component';
import { AppPopupComponent } from './popup.component';
import { ConfirmDialogData, PopupDialogData, PopupSize } from '../ui-types';

const WIDTH_BY_SIZE: Record<PopupSize, string> = {
  sm: '400px',
  md: '560px',
  lg: '780px',
  xl: '980px',
};

@Injectable({ providedIn: 'root' })
export class AppDialogService {
  private readonly dialog = inject(MatDialog);
  private readonly _openCount = signal(0);

  readonly openCount = this._openCount.asReadonly();
  readonly hasOpenDialog = computed(() => this._openCount() > 0);

  confirm(data: ConfirmDialogData, config?: MatDialogConfig): Observable<boolean> {
    const ref = this.dialog.open(AppConfirmDialogComponent, {
      width: '420px',
      maxWidth: '94vw',
      data,
      ...config,
    });
    this.trackRef(ref);
    return ref.afterClosed().pipe(map((result) => Boolean(result)));
  }

  confirmAsync(data: ConfirmDialogData, config?: MatDialogConfig): Promise<boolean> {
    return firstValueFrom(this.confirm(data, config));
  }

  openPopup<TData = unknown, TResult = unknown>(
    data: PopupDialogData<TData>,
    config?: MatDialogConfig,
  ): MatDialogRef<AppPopupComponent, TResult> {
    const width = WIDTH_BY_SIZE[data.size ?? 'md'];
    const ref = this.dialog.open<AppPopupComponent, PopupDialogData<TData>, TResult>(AppPopupComponent, {
      width,
      maxWidth: '95vw',
      data,
      ...config,
    });
    this.trackRef(ref);
    return ref;
  }

  openComponent<TComp, TData = unknown, TResult = unknown>(
    component: Type<TComp>,
    data?: TData,
    size: PopupSize = 'md',
    config?: MatDialogConfig<TData>,
  ): MatDialogRef<TComp, TResult> {
    const ref = this.dialog.open<TComp, TData, TResult>(component, {
      width: WIDTH_BY_SIZE[size],
      maxWidth: '95vw',
      data,
      ...config,
    });
    this.trackRef(ref);
    return ref;
  }

  private trackRef<T, R>(ref: MatDialogRef<T, R>): void {
    this._openCount.update((c) => c + 1);
    ref.afterClosed().subscribe(() => {
      this._openCount.update((c) => Math.max(0, c - 1));
    });
  }
}
