import { Component, computed, inject, linkedSignal, signal } from '@angular/core';
import { JsonPipe } from '@angular/common';
import type { Meta, StoryObj } from '@storybook/angular';
import { MatButtonModule } from '@angular/material/button';
import {
  AppAlertComponent,
  AppCheckboxComponent,
  AppDialogService,
  AppRadioGroupComponent,
  AppSelectComponent,
  AppTextareaComponent,
  AppToastService,
  AppTextboxComponent,
  UiOption,
} from './index';

@Component({
  selector: 'of-form-showcase',
  standalone: true,
  imports: [
    JsonPipe,
    MatButtonModule,
    AppTextboxComponent,
    AppTextareaComponent,
    AppCheckboxComponent,
    AppRadioGroupComponent,
    AppSelectComponent,
    AppAlertComponent,
  ],
  styles: [`
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
    .panel { background: #fff; border: 1px solid #e2e6ec; border-radius: 10px; padding: 18px; }
    pre { background: #0f172a; color: #e2e8f0; padding: 12px; border-radius: 8px; font-size: 12px; overflow: auto; }
  `],
  template: `
    <div style="display:flex; flex-direction:column; gap:16px;">
      <of-alert
        severity="info"
        title="Signal + linkedSignal Demo"
        message="Changing the Customer Domain dynamically swaps the available Policy options; linkedSignal automatically prunes invalid selections."
        [dismissible]="true"
      />

      <div class="panel">
        <div class="grid">
          <of-textbox
            label="File Number"
            placeholder="TI-10045"
            [clearable]="true"
            [required]="true"
            [(value)]="fileNumber"
          />

          <of-radio-group
            label="Customer Domain"
            [options]="domainOptions"
            [(value)]="domain"
          />

          <of-select
            label="Policy Type (Single)"
            [options]="availablePolicies()"
            [(value)]="policyType"
          />

          <of-select
            label="Required Checks (Search + Multi-select)"
            [options]="checkOptions"
            [multiple]="true"
            [searchable]="true"
            [(value)]="selectedChecks"
          />
        </div>

        <div style="margin-top:14px;">
          <of-textarea
            label="Underwriting Notes"
            [maxLength]="300"
            [(value)]="notes"
          />
        </div>

        <div style="margin-top:12px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
          <of-checkbox label="Expedite processing" [(checked)]="expedite" />

          <div style="display:flex; gap:8px;">
            <button mat-stroked-button type="button" (click)="reset()">Reset</button>
            <button mat-flat-button color="primary" type="button" (click)="submit()">Validate &amp; Submit</button>
          </div>
        </div>
      </div>

      <pre>{{ snapshot() | json }}</pre>
    </div>
  `,
})
class FormShowcaseComponent {
  private readonly toast = inject(AppToastService);
  private readonly dialogs = inject(AppDialogService);

  readonly fileNumber = signal('TI-10045');
  readonly domain = signal<'title' | 'po'>('title');
  readonly notes = signal('Property verified against county tax roll.');
  readonly expedite = signal(true);
  readonly selectedChecks = signal<string[]>(['apn', 'vesting']);

  readonly domainOptions: UiOption<'title' | 'po'>[] = [
    { label: 'Title Insurance', value: 'title' },
    { label: 'Purchase Order', value: 'po' },
  ];

  readonly availablePolicies = computed<UiOption<string>[]>(() =>
    this.domain() === 'title'
      ? [
          { label: 'ALTA Owner', value: 'alta-owner' },
          { label: 'ALTA Loan', value: 'alta-loan' },
          { label: 'Short-Form', value: 'short-form' },
        ]
      : [
          { label: 'Standard PO', value: 'standard-po' },
          { label: 'Blanket PO', value: 'blanket-po' },
        ],
  );

  /** Linked signal resets policyType whenever the domain changes so stale options never linger. */
  readonly policyType = linkedSignal<UiOption<string>[], string>({
    source: this.availablePolicies,
    computation: (opts) => opts[0]?.value ?? '',
  });

  readonly checkOptions: UiOption<string>[] = [
    { label: 'APN Verification', value: 'apn' },
    { label: 'Vesting Match', value: 'vesting' },
    { label: 'Tax Lien Search', value: 'tax-lien' },
    { label: 'Payoff Demand', value: 'payoff' },
    { label: 'Flood Certification', value: 'flood' },
  ];

  readonly snapshot = computed(() => ({
    fileNumber: this.fileNumber(),
    domain: this.domain(),
    policyType: this.policyType(),
    selectedChecks: this.selectedChecks(),
    expedite: this.expedite(),
    notes: this.notes(),
  }));

  reset(): void {
    this.fileNumber.set('');
    this.notes.set('');
    this.expedite.set(false);
    this.selectedChecks.set([]);
    this.toast.info('Form reset.');
  }

  async submit(): Promise<void> {
    const ok = await this.dialogs.confirmAsync({
      title: 'Submit Showcase Form?',
      message: `Submit ${this.fileNumber() || '(empty)'} with ${this.selectedChecks().length} selected check(s)?`,
      confirmText: 'Submit',
      severity: 'info',
    });
    if (ok) {
      this.toast.success('Submitted via Material + Signals!');
    }
  }
}

const meta: Meta<FormShowcaseComponent> = {
  title: 'UI Wrappers/Patterns/All Controls + LinkedSignal Showcase',
  component: FormShowcaseComponent,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<FormShowcaseComponent>;

export const InteractiveShowcase: Story = {};
