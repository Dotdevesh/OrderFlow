import { Component, input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { UiBadgeTone } from '../ui-types';

/** Compact status pill, e.g. task status, priority or SLA state. */
@Component({
  selector: 'of-badge',
  standalone: true,
  imports: [MatIconModule],
  styles: [`
    :host { display: inline-flex; }
    .of-badge {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 2px 8px; border-radius: 999px; border: 1px solid transparent;
      font-size: 12px; font-weight: 600; line-height: 18px; white-space: nowrap;
    }
    .of-badge.sm { padding: 0 6px; font-size: 11px; line-height: 16px; }
    .dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
    .icon { width: 14px; height: 14px; font-size: 14px; }

    .soft.neutral { background: #f1f5f9; color: #334155; }
    .soft.primary { background: #eff6ff; color: #1d4ed8; }
    .soft.info    { background: #ecfeff; color: #0e7490; }
    .soft.success { background: #f0fdf4; color: #166534; }
    .soft.warning { background: #fffbeb; color: #92400e; }
    .soft.error   { background: #fef2f2; color: #991b1b; }

    .solid { color: #fff; }
    .solid.neutral { background: #475569; }
    .solid.primary { background: #2563eb; }
    .solid.info    { background: #0891b2; }
    .solid.success { background: #16a34a; }
    .solid.warning { background: #d97706; }
    .solid.error   { background: #dc2626; }

    .outline { background: #fff; }
    .outline.neutral { border-color: #cbd5e1; color: #334155; }
    .outline.primary { border-color: #93c5fd; color: #1d4ed8; }
    .outline.info    { border-color: #67e8f9; color: #0e7490; }
    .outline.success { border-color: #86efac; color: #166534; }
    .outline.warning { border-color: #fcd34d; color: #92400e; }
    .outline.error   { border-color: #fca5a5; color: #991b1b; }
  `],
  template: `
    <span class="of-badge" [class]="[tone(), variant(), size()]">
      @if (dot()) {
        <span class="dot" aria-hidden="true"></span>
      }
      @if (icon()) {
        <mat-icon class="icon" [svgIcon]="icon()" />
      }
      @if (label()) {
        {{ label() }}
      } @else {
        <ng-content />
      }
    </span>
  `,
})
export class AppBadgeComponent {
  readonly label = input<string>('');
  readonly tone = input<UiBadgeTone>('neutral');
  readonly variant = input<'soft' | 'solid' | 'outline'>('soft');
  readonly size = input<'sm' | 'md'>('md');
  readonly dot = input<boolean>(false);
  readonly icon = input<string>('');
}
