import {
  Component,
  computed,
  forwardRef,
  input,
  linkedSignal,
  model,
  output,
  signal,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatRadioChange, MatRadioModule } from '@angular/material/radio';
import { UiOption } from '../ui-types';

@Component({
  selector: 'of-radio-group',
  standalone: true,
  imports: [MatRadioModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AppRadioGroupComponent),
      multi: true,
    },
  ],
  styles: [`
    :host { display: flex; flex-direction: column; gap: 6px; }
    .group-label { font-size: 13px; font-weight: 500; color: var(--text, #1f2733); }
    .req { color: #dc2626; }
    .radio-list { display: flex; gap: 14px; flex-wrap: wrap; }
    .radio-list.vertical { flex-direction: column; gap: 8px; }
    .hint { font-size: 12px; color: var(--muted, #6b7686); }
    .err { font-size: 12px; color: #dc2626; }
  `],
  template: `
    @if (label()) {
      <label class="group-label">
        {{ label() }} @if (required()) { <span class="req">*</span> }
      </label>
    }
    <mat-radio-group
      class="radio-list"
      [class.vertical]="orientation() === 'vertical'"
      [value]="selectedValue()"
      [disabled]="isDisabled()"
      [color]="color()"
      (change)="onSelectionChange($event)"
    >
      @for (opt of options(); track opt.value) {
        <mat-radio-button [value]="opt.value" [disabled]="!!opt.disabled || isDisabled()">
          {{ opt.label }}
        </mat-radio-button>
      }
    </mat-radio-group>
    @if (hint() && !errorMessage()) {
      <span class="hint">{{ hint() }}</span>
    }
    @if (errorMessage()) {
      <span class="err">{{ errorMessage() }}</span>
    }
  `,
})
export class AppRadioGroupComponent<T = string> implements ControlValueAccessor {
  readonly label = input<string>('');
  readonly options = input<readonly UiOption<T>[]>([]);
  readonly orientation = input<'horizontal' | 'vertical'>('horizontal');
  readonly color = input<'primary' | 'accent' | 'warn'>('primary');
  readonly disabled = input<boolean>(false);
  readonly required = input<boolean>(false);
  readonly hint = input<string>('');
  readonly errorMessage = input<string | null>(null);

  readonly value = model<T | null>(null);
  readonly valueChanged = output<T | null>();

  /**
   * Linked signal keeps `selectedValue` synced with `value` and clears it automatically
   * if `options` changes such that the previously chosen value no longer exists.
   */
  readonly selectedValue = linkedSignal<{ val: T | null; opts: readonly UiOption<T>[] }, T | null>({
    source: () => ({ val: this.value(), opts: this.options() }),
    computation: (src) => {
      if (src.val === null || src.val === undefined) return null;
      return src.opts.some((o) => o.value === src.val) ? src.val : null;
    },
  });

  private readonly cvaDisabled = signal(false);
  readonly isDisabled = computed(() => this.disabled() || this.cvaDisabled());

  private onChange: (v: T | null) => void = () => {};
  onTouched: () => void = () => {};

  onSelectionChange(event: MatRadioChange): void {
    const next = event.value as T;
    this.selectedValue.set(next);
    this.value.set(next);
    this.onChange(next);
    this.valueChanged.emit(next);
    this.onTouched();
  }

  writeValue(val: T | null): void {
    this.value.set(val ?? null);
    this.selectedValue.set(val ?? null);
  }

  registerOnChange(fn: (v: T | null) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.cvaDisabled.set(isDisabled);
  }
}
