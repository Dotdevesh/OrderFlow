import {
  Component,
  TemplateRef,
  contentChildren,
  input,
  model,
  output,
  viewChild,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { STEPPER_GLOBAL_OPTIONS, StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

/** A single step declared inside `<of-stepper>`. */
@Component({
  selector: 'of-step',
  standalone: true,
  template: `<ng-template><ng-content /></ng-template>`,
})
export class AppStepComponent {
  readonly label = input.required<string>();
  /** `null` treats the step as complete once reached; `false` blocks moving past it in a linear stepper. */
  readonly completed = input<boolean | null>(null);
  readonly optional = input<boolean>(false);
  readonly editable = input<boolean>(true);
  readonly hasError = input<boolean>(false);
  readonly errorMessage = input<string>('');

  readonly content = viewChild.required(TemplateRef);
}

/**
 * Reusable Material stepper with built-in Back / Next / Finish buttons.
 * `<of-stepper linear (finished)="submit()"><of-step label="Review">...</of-step></of-stepper>`
 */
@Component({
  selector: 'of-stepper',
  standalone: true,
  imports: [NgTemplateOutlet, MatStepperModule, MatButtonModule, MatIconModule],
  providers: [{ provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true } }],
  styles: [`
    :host { display: block; }
    .step-body { padding: 8px 0 4px; }
    .step-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px; }
    .step-icon { width: 16px; height: 16px; font-size: 16px; }
  `],
  template: `
    <mat-stepper
      [linear]="linear()"
      [orientation]="orientation()"
      [selectedIndex]="selectedIndex()"
      (selectionChange)="onSelectionChange($event)"
    >
      <ng-template matStepperIcon="edit"><mat-icon class="step-icon" svgIcon="ui-edit" /></ng-template>
      <ng-template matStepperIcon="done"><mat-icon class="step-icon" svgIcon="ui-check" /></ng-template>
      <ng-template matStepperIcon="error"><mat-icon class="step-icon" svgIcon="ui-warning" /></ng-template>

      @for (step of steps(); track $index; let i = $index, first = $first, last = $last) {
        <mat-step
          [label]="step.label()"
          [completed]="step.completed() ?? i <= selectedIndex()"
          [optional]="step.optional()"
          [editable]="step.editable()"
          [hasError]="step.hasError()"
          [errorMessage]="step.errorMessage()"
        >
          <div class="step-body">
            <ng-container [ngTemplateOutlet]="step.content()" />
          </div>
          @if (showNavigation()) {
            <div class="step-actions">
              @if (!first) {
                <button mat-stroked-button type="button" matStepperPrevious>{{ backLabel() }}</button>
              }
              @if (last) {
                <button mat-flat-button type="button" [disabled]="step.completed() === false" (click)="finished.emit()">
                  {{ finishLabel() }}
                </button>
              } @else {
                <button mat-flat-button type="button" matStepperNext>{{ nextLabel() }}</button>
              }
            </div>
          }
        </mat-step>
      }
    </mat-stepper>
  `,
})
export class AppStepperComponent {
  readonly selectedIndex = model<number>(0);
  readonly linear = input<boolean>(false);
  readonly orientation = input<'horizontal' | 'vertical'>('horizontal');
  readonly showNavigation = input<boolean>(true);
  readonly nextLabel = input<string>('Next');
  readonly backLabel = input<string>('Back');
  readonly finishLabel = input<string>('Finish');
  readonly finished = output<void>();

  readonly steps = contentChildren(AppStepComponent);

  onSelectionChange(event: StepperSelectionEvent): void {
    this.selectedIndex.set(event.selectedIndex);
  }
}
