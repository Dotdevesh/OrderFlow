import { Component, TemplateRef, inject, input, linkedSignal, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { PopupDialogData } from '../ui-types';

/**
 * Generic popup wrapper around Material Dialog.
 * Can be used in two ways:
 * 1) Programmatically via `AppDialogService.openPopup({ title, template, data, ... })`
 * 2) Declaratively inside any MatDialog component: `<of-popup [title]="..." (confirmed)="...">...</of-popup>`
 */
@Component({
  selector: 'of-popup',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule, MatProgressBarModule],
  styles: [`
    .popup-header {
      display: flex; align-items: flex-start; justify-content: space-between; gap: 12px;
      padding: 16px 20px 12px; border-bottom: 1px solid var(--line, #e2e6ec);
    }
    .popup-title { margin: 0; font-size: 18px; font-weight: 600; color: var(--text, #1f2733); }
    .popup-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--muted, #6b7686); }
    .popup-body { padding: 16px 20px; max-height: 68vh; overflow: auto; }
    .popup-footer {
      display: flex; justify-content: flex-end; gap: 8px;
      padding: 12px 20px; border-top: 1px solid var(--line, #e2e6ec);
    }
  `],
  template: `
    <div class="popup-header">
      <div>
        <h2 class="popup-title">{{ resolvedTitle() }}</h2>
        @if (resolvedSubtitle()) {
          <p class="popup-subtitle">{{ resolvedSubtitle() }}</p>
        }
      </div>
      <button mat-icon-button type="button" aria-label="Close popup" (click)="close()">
        <mat-icon svgIcon="ui-close" />
      </button>
    </div>

    @if (loading()) {
      <mat-progress-bar mode="indeterminate" />
    }

    <div class="popup-body">
      @if (dialogData?.template; as tpl) {
        <ng-container
          [ngTemplateOutlet]="tpl"
          [ngTemplateOutletContext]="{ $implicit: dialogData?.data, close: closeBound }"
        />
      } @else {
        <ng-content />
      }
    </div>

    @if (resolvedShowFooter()) {
      <div class="popup-footer">
        <ng-content select="[popup-actions]" />
        @if (showDefaultActions()) {
          <button mat-button type="button" [disabled]="loading()" (click)="close()">
            {{ resolvedCancelText() }}
          </button>
          <button mat-flat-button color="primary" type="button" [disabled]="loading() || confirmDisabled()" (click)="confirm()">
            {{ resolvedConfirmText() }}
          </button>
        }
      </div>
    }
  `,
})
export class AppPopupComponent {
  readonly dialogData = inject<PopupDialogData | null>(MAT_DIALOG_DATA, { optional: true });
  private readonly dialogRef = inject(MatDialogRef<AppPopupComponent>, { optional: true });

  readonly title = input<string>('');
  readonly subtitle = input<string>('');
  readonly loading = input<boolean>(false);
  readonly confirmDisabled = input<boolean>(false);
  readonly showFooter = input<boolean>(true);
  readonly showDefaultActions = input<boolean>(true);
  readonly confirmText = input<string>('Save');
  readonly cancelText = input<string>('Cancel');

  readonly closed = output<unknown>();
  readonly confirmed = output<void>();

  readonly resolvedTitle = linkedSignal(() => this.title() || this.dialogData?.title || '');
  readonly resolvedSubtitle = linkedSignal(() => this.subtitle() || this.dialogData?.subtitle || '');
  readonly resolvedShowFooter = linkedSignal(() => this.dialogData?.showFooter ?? this.showFooter());
  readonly resolvedConfirmText = linkedSignal(() => this.dialogData?.confirmText || this.confirmText());
  readonly resolvedCancelText = linkedSignal(() => this.dialogData?.cancelText || this.cancelText());

  readonly closeBound = (result?: unknown) => this.close(result);

  close(result?: unknown): void {
    this.closed.emit(result);
    this.dialogRef?.close(result);
  }

  confirm(): void {
    this.confirmed.emit();
    if (this.dialogData?.template) {
      this.dialogRef?.close(true);
    }
  }
}
