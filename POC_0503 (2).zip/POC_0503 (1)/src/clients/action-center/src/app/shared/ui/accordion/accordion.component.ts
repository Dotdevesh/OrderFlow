import {
  Component,
  TemplateRef,
  contentChildren,
  input,
  output,
  viewChild,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { MatAccordion, MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { UiPanelToggle } from '../ui-types';

/** A single collapsible panel declared inside `<of-accordion>`. */
@Component({
  selector: 'of-accordion-panel',
  standalone: true,
  template: `<ng-template><ng-content /></ng-template>`,
})
export class AppAccordionPanelComponent {
  readonly title = input.required<string>();
  readonly description = input<string>('');
  /** Registered svg icon name shown before the title. */
  readonly icon = input<string>('');
  readonly expanded = input<boolean>(false);
  readonly disabled = input<boolean>(false);

  readonly content = viewChild.required(TemplateRef);
}

/**
 * Reusable Material accordion (expansion panels).
 * `<of-accordion multi><of-accordion-panel title="Parties">...</of-accordion-panel></of-accordion>`
 */
@Component({
  selector: 'of-accordion',
  standalone: true,
  imports: [NgTemplateOutlet, MatExpansionModule, MatButtonModule, MatIconModule],
  styles: [`
    :host { display: block; }
    .bulk-actions { display: flex; justify-content: flex-end; gap: 4px; margin-bottom: 8px; }
    .panel-title { display: inline-flex; align-items: center; gap: 8px; }
    .panel-icon { width: 18px; height: 18px; font-size: 18px; color: var(--muted, #6b7686); }
  `],
  template: `
    @if (multi() && showBulkActions()) {
      <div class="bulk-actions">
        <button mat-button type="button" (click)="expandAll()">Expand all</button>
        <button mat-button type="button" (click)="collapseAll()">Collapse all</button>
      </div>
    }
    <mat-accordion
      [multi]="multi()"
      [displayMode]="displayMode()"
      [togglePosition]="togglePosition()"
      [hideToggle]="hideToggle()"
    >
      @for (panel of panels(); track $index; let i = $index) {
        <mat-expansion-panel
          [expanded]="panel.expanded()"
          [disabled]="panel.disabled()"
          (opened)="panelToggled.emit({ index: i, expanded: true })"
          (closed)="panelToggled.emit({ index: i, expanded: false })"
        >
          <mat-expansion-panel-header>
            <mat-panel-title>
              <span class="panel-title">
                @if (panel.icon()) {
                  <mat-icon class="panel-icon" [svgIcon]="panel.icon()" />
                }
                {{ panel.title() }}
              </span>
            </mat-panel-title>
            @if (panel.description()) {
              <mat-panel-description>{{ panel.description() }}</mat-panel-description>
            }
          </mat-expansion-panel-header>
          <ng-container [ngTemplateOutlet]="panel.content()" />
        </mat-expansion-panel>
      }
    </mat-accordion>
  `,
})
export class AppAccordionComponent {
  /** Allow several panels open at once. */
  readonly multi = input<boolean>(false);
  /** Show "Expand all / Collapse all" (only when `multi`). */
  readonly showBulkActions = input<boolean>(true);
  readonly displayMode = input<'default' | 'flat'>('default');
  readonly togglePosition = input<'before' | 'after'>('after');
  readonly hideToggle = input<boolean>(false);
  readonly panelToggled = output<UiPanelToggle>();

  readonly panels = contentChildren(AppAccordionPanelComponent);
  private readonly accordion = viewChild.required(MatAccordion);

  expandAll(): void {
    this.accordion().openAll();
  }

  collapseAll(): void {
    this.accordion().closeAll();
  }
}
