import { Component, computed, input } from '@angular/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

/**
 * Reusable progress indicator. Leave `value` as `null` for an indeterminate (loading) state,
 * or pass 0–100 for determinate progress.
 */
@Component({
  selector: 'of-progress',
  standalone: true,
  imports: [MatProgressBarModule, MatProgressSpinnerModule],
  styles: [`
    :host { display: block; }
    .bar-wrap { display: flex; flex-direction: column; gap: 6px; }
    .bar-head { display: flex; justify-content: space-between; font-size: 12px; color: var(--muted, #6b7686); }
    .spinner-wrap { display: inline-flex; align-items: center; gap: 10px; font-size: 13px; color: var(--muted, #6b7686); }
  `],
  template: `
    @if (type() === 'bar') {
      <div class="bar-wrap">
        @if (label() || showValue()) {
          <div class="bar-head">
            <span>{{ label() }}</span>
            @if (showValue() && !indeterminate()) {
              <span>{{ clamped() }}%</span>
            }
          </div>
        }
        <mat-progress-bar
          [mode]="indeterminate() ? 'indeterminate' : 'determinate'"
          [value]="clamped()"
          [attr.aria-label]="label() || 'Progress'"
        />
      </div>
    } @else {
      <div class="spinner-wrap">
        <mat-progress-spinner
          [mode]="indeterminate() ? 'indeterminate' : 'determinate'"
          [value]="clamped()"
          [diameter]="diameter()"
          [strokeWidth]="diameter() / 10"
          [attr.aria-label]="label() || 'Progress'"
        />
        @if (label()) {
          <span>{{ label() }}@if (showValue() && !indeterminate()) { ({{ clamped() }}%) }</span>
        }
      </div>
    }
  `,
})
export class AppProgressComponent {
  readonly type = input<'bar' | 'spinner'>('bar');
  readonly value = input<number | null>(null);
  readonly label = input<string>('');
  readonly showValue = input<boolean>(true);
  readonly diameter = input<number>(32);

  readonly indeterminate = computed(() => this.value() === null);
  readonly clamped = computed(() => Math.min(100, Math.max(0, Math.round(this.value() ?? 0))));
}
