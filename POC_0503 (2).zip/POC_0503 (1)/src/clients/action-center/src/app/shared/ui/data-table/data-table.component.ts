import {
  Component,
  computed,
  effect,
  input,
  linkedSignal,
  output,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule, Sort } from '@angular/material/sort';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { AppTextboxComponent } from '../textbox/textbox.component';
import { AppSelectComponent } from '../select/select.component';
import {
  SearchFormFieldDef,
  TableColumnDef,
  TableStateSnapshot,
} from '../ui-types';

/**
 * Reusable Material Data Table wrapper supporting:
 * - Basic table display with custom cell templates
 * - Pagination (`showPagination`) with signal-driven page index
 * - Column sorting (`sortable`)
 * - Per-column inline filters (`showColumnFilters` + `column.filterable`)
 * - Top Search Form above the table/filters (`showSearchForm` + `searchFields`)
 * - Optional multi-row selection (`selectable`)
 * Uses `linkedSignal` so page index, filter maps, and selections stay consistent automatically.
 */
@Component({
  selector: 'of-data-table',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    AppTextboxComponent,
    AppSelectComponent,
  ],
  styles: [`
    :host { display: block; width: 100%; }
    .table-shell {
      background: var(--panel, #fff);
      border: 1px solid var(--line, #e2e6ec);
      border-radius: 10px;
      overflow: hidden;
    }
    .search-form-bar {
      padding: 14px 16px;
      border-bottom: 1px solid var(--line, #e2e6ec);
      background: #f8fafc;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .search-form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 10px;
      align-items: center;
    }
    .search-form-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
    }
    .result-meta {
      font-size: 12px;
      color: var(--muted, #6b7686);
    }
    .table-scroll {
      width: 100%;
      overflow-x: auto;
    }
    table {
      width: 100%;
    }
    .filter-row th {
      background: #f8fafc;
      padding: 6px 10px;
      border-bottom: 1px solid var(--line, #e2e6ec);
    }
    .col-filter-input {
      width: 100%;
      min-width: 90px;
      padding: 5px 8px;
      border: 1px solid var(--line, #e2e6ec);
      border-radius: 6px;
      font-size: 12px;
      background: #fff;
      outline: none;
    }
    .col-filter-input:focus {
      border-color: var(--primary, #2563eb);
    }
    tr.data-row {
      cursor: pointer;
    }
    tr.data-row:hover td {
      background: #f8fafc;
    }
    .empty-state {
      padding: 36px 16px;
      text-align: center;
      color: var(--muted, #6b7686);
      font-size: 14px;
    }
    .align-center { text-align: center; }
    .align-right  { text-align: right; }
  `],
  template: `
    <div class="table-shell">
      @if (showSearchForm()) {
        <form class="search-form-bar" (submit)="$event.preventDefault()">
          <div class="search-form-grid">
            <of-textbox
              [label]="searchLabel()"
              [placeholder]="searchPlaceholder()"
              prefixSvgIcon="ui-search"
              [clearable]="true"
              [value]="globalSearch()"
              (valueChanged)="onGlobalSearch($event)"
            />

            @for (sf of searchFields(); track sf.key) {
              @if (sf.type === 'select') {
                <of-select
                  [label]="sf.label"
                  [placeholder]="sf.placeholder || 'All'"
                  [options]="sf.options || []"
                  [allowEmpty]="true"
                  emptyLabel="All"
                  [value]="searchFormValues()[sf.key] || null"
                  (selectionChanged)="setSearchFormField(sf.key, $any($event))"
                />
              } @else {
                <of-textbox
                  [label]="sf.label"
                  [placeholder]="sf.placeholder || ''"
                  [clearable]="true"
                  [value]="searchFormValues()[sf.key] || ''"
                  (valueChanged)="setSearchFormField(sf.key, $event)"
                />
              }
            }
          </div>

          <div class="search-form-actions">
            <span class="result-meta">
              Showing {{ pagedData().length }} of {{ sortedData().length }} filtered ({{ data().length }} total)
            </span>
            <div style="display:flex; gap:8px; align-items:center;">
              <ng-content select="[table-toolbar-actions]" />
              @if (hasActiveFilters()) {
                <button mat-stroked-button type="button" (click)="resetAllFilters()">
                  <mat-icon svgIcon="ui-close" />
                  Clear filters
                </button>
              }
            </div>
          </div>
        </form>
      }

      @if (loading()) {
        <mat-progress-bar mode="indeterminate" />
      }

      <div class="table-scroll">
        <table
          mat-table
          [dataSource]="pagedData()"
          matSort
          [matSortDisabled]="!sortable()"
          [matSortActive]="sortState().active"
          [matSortDirection]="sortState().direction"
          (matSortChange)="onSortChange($event)"
        >
          @if (selectable()) {
            <ng-container matColumnDef="__select">
              <th mat-header-cell *matHeaderCellDef style="width: 48px;">
                <mat-checkbox
                  [checked]="allPageSelected()"
                  [indeterminate]="somePageSelected()"
                  (change)="toggleAllOnPage()"
                />
              </th>
              <td mat-cell *matCellDef="let row" (click)="$event.stopPropagation()">
                <mat-checkbox
                  [checked]="isSelected(row)"
                  (change)="toggleRow(row)"
                />
              </td>
            </ng-container>

            <ng-container matColumnDef="__select__filter">
              <th mat-header-cell *matHeaderCellDef></th>
            </ng-container>
          }

          @for (col of columns(); track col.key) {
            <ng-container [matColumnDef]="col.key">
              <th
                mat-header-cell
                *matHeaderCellDef
                [mat-sort-header]="col.key"
                [disabled]="!sortable() || col.sortable === false"
                [style.width]="col.width || null"
                [class.align-center]="col.align === 'center'"
                [class.align-right]="col.align === 'right'"
              >
                {{ col.header }}
              </th>
              <td
                mat-cell
                *matCellDef="let row"
                [class.align-center]="col.align === 'center'"
                [class.align-right]="col.align === 'right'"
              >
                @if (col.cellTemplate) {
                  <ng-container
                    [ngTemplateOutlet]="col.cellTemplate"
                    [ngTemplateOutletContext]="{ $implicit: row, row: row, value: cellValue(row, col) }"
                  />
                } @else {
                  {{ formatValue(cellValue(row, col)) }}
                }
              </td>
            </ng-container>

            <ng-container [matColumnDef]="col.key + '__filter'">
              <th mat-header-cell *matHeaderCellDef>
                @if (col.filterable !== false) {
                  <input
                    class="col-filter-input"
                    type="text"
                    [value]="columnFilters()[col.key] || ''"
                    [placeholder]="col.filterPlaceholder || ('Filter ' + col.header + '...')"
                    (input)="setColumnFilter(col.key, $event)"
                  />
                }
              </th>
            </ng-container>
          }

          <tr mat-header-row *matHeaderRowDef="displayedColumns(); sticky: stickyHeader()"></tr>
          @if (showColumnFilters()) {
            <tr mat-header-row *matHeaderRowDef="filterColumns()" class="filter-row"></tr>
          }
          <tr
            mat-row
            *matRowDef="let row; columns: displayedColumns()"
            class="data-row"
            (click)="rowClick.emit(row)"
          ></tr>
        </table>

        @if (!loading() && pagedData().length === 0) {
          <div class="empty-state">{{ emptyMessage() }}</div>
        }
      </div>

      @if (showPagination()) {
        <mat-paginator
          [length]="sortedData().length"
          [pageIndex]="pageIndex()"
          [pageSize]="currentPageSize()"
          [pageSizeOptions]="pageSizeOptions()"
          showFirstLastButtons
          (page)="onPage($event)"
        />
      }
    </div>
  `,
})
export class AppDataTableComponent<T = Record<string, unknown>> {
  readonly data = input.required<readonly T[]>();
  readonly columns = input.required<readonly TableColumnDef<T>[]>();

  readonly showPagination = input<boolean>(true);
  readonly pageSize = input<number>(10);
  readonly pageSizeOptions = input<readonly number[]>([5, 10, 25, 50]);
  readonly sortable = input<boolean>(true);
  readonly showColumnFilters = input<boolean>(false);
  readonly showSearchForm = input<boolean>(false);
  readonly searchLabel = input<string>('Search');
  readonly searchPlaceholder = input<string>('Search across all columns...');
  readonly searchFields = input<readonly SearchFormFieldDef[]>([]);
  readonly stickyHeader = input<boolean>(false);
  readonly selectable = input<boolean>(false);
  readonly loading = input<boolean>(false);
  readonly emptyMessage = input<string>('No matching records found.');

  readonly rowClick = output<T>();
  readonly selectionChange = output<readonly T[]>();
  readonly stateChange = output<TableStateSnapshot>();

  readonly globalSearch = signal<string>('');
  readonly sortState = signal<{ active: string; direction: 'asc' | 'desc' | '' }>({
    active: '',
    direction: '',
  });

  /** Linked to `searchFields`: preserves values for existing keys and drops stale keys. */
  readonly searchFormValues = linkedSignal<readonly SearchFormFieldDef[], Record<string, string>>({
    source: this.searchFields,
    computation: (fields, prev) => {
      const next: Record<string, string> = {};
      const prior = prev?.value ?? {};
      for (const f of fields) {
        next[f.key] = prior[f.key] ?? '';
      }
      return next;
    },
  });

  /** Linked to `columns`: keeps column filter keys synced with active columns. */
  readonly columnFilters = linkedSignal<readonly TableColumnDef<T>[], Record<string, string>>({
    source: this.columns,
    computation: (cols, prev) => {
      const next: Record<string, string> = {};
      const prior = prev?.value ?? {};
      for (const c of cols) {
        next[c.key] = prior[c.key] ?? '';
      }
      return next;
    },
  });

  /** Linked to `pageSize` input while allowing paginator interactions to update it. */
  readonly currentPageSize = linkedSignal(() => this.pageSize());

  readonly displayedColumns = computed(() => {
    const keys = this.columns().map((c) => c.key);
    return this.selectable() ? ['__select', ...keys] : keys;
  });

  readonly filterColumns = computed(() => {
    const keys = this.columns().map((c) => `${c.key}__filter`);
    return this.selectable() ? ['__select__filter', ...keys] : keys;
  });

  readonly hasActiveFilters = computed(() => {
    if (this.globalSearch().trim()) return true;
    if (Object.values(this.searchFormValues()).some((v) => v.trim() !== '')) return true;
    if (Object.values(this.columnFilters()).some((v) => v.trim() !== '')) return true;
    return false;
  });

  readonly filteredData = computed(() => {
    const rows = this.data();
    const cols = this.columns();
    const g = this.globalSearch().trim().toLowerCase();
    const formVals = this.searchFormValues();
    const colVals = this.columnFilters();

    return rows.filter((row) => {
      // 1) Top search form global term
      if (g) {
        const hit = cols.some((c) =>
          this.formatValue(this.cellValue(row, c)).toLowerCase().includes(g),
        );
        if (!hit) return false;
      }

      // 2) Top search form structured fields
      for (const [key, filterVal] of Object.entries(formVals)) {
        const needle = (filterVal ?? '').trim().toLowerCase();
        if (!needle) continue;
        const col = cols.find((c) => c.key === key);
        const raw = col
          ? this.cellValue(row, col)
          : (row as Record<string, unknown>)[key];
        if (!this.formatValue(raw).toLowerCase().includes(needle)) return false;
      }

      // 3) Per-column inline filters
      for (const col of cols) {
        const needle = (colVals[col.key] ?? '').trim().toLowerCase();
        if (!needle) continue;
        const val = this.formatValue(this.cellValue(row, col)).toLowerCase();
        if (!val.includes(needle)) return false;
      }

      return true;
    });
  });

  readonly sortedData = computed(() => {
    const rows = [...this.filteredData()];
    const { active, direction } = this.sortState();
    if (!active || !direction) return rows;

    const col = this.columns().find((c) => c.key === active);
    if (!col) return rows;

    const factor = direction === 'asc' ? 1 : -1;
    return rows.sort((a, b) => compareValues(this.cellValue(a, col), this.cellValue(b, col)) * factor);
  });

  /**
   * Linked pageIndex: clamps or resets to page 0 whenever `sortedData().length` or `currentPageSize()`
   * changes (for example when a user types a filter or search term).
   */
  readonly pageIndex = linkedSignal<{ len: number; size: number }, number>({
    source: () => ({ len: this.sortedData().length, size: this.currentPageSize() }),
    computation: (src, prev) => {
      const current = prev?.value ?? 0;
      if (src.len === 0) return 0;
      const maxPage = Math.max(0, Math.ceil(src.len / Math.max(1, src.size)) - 1);
      return current > maxPage ? 0 : current;
    },
  });

  readonly pagedData = computed(() => {
    const rows = this.sortedData();
    if (!this.showPagination()) return rows;
    const size = Math.max(1, this.currentPageSize());
    const start = this.pageIndex() * size;
    return rows.slice(start, start + size);
  });

  /** Linked selection state: keeps only rows still present in `data()`. */
  readonly selectedRows = linkedSignal<readonly T[], T[]>({
    source: this.data,
    computation: (rows, prev) => {
      const set = new Set(rows);
      return (prev?.value ?? []).filter((r) => set.has(r));
    },
  });

  readonly allPageSelected = computed(() => {
    const page = this.pagedData();
    const sel = new Set(this.selectedRows());
    return page.length > 0 && page.every((r) => sel.has(r));
  });

  readonly somePageSelected = computed(() => {
    const page = this.pagedData();
    const sel = new Set(this.selectedRows());
    const count = page.filter((r) => sel.has(r)).length;
    return count > 0 && count < page.length;
  });

  constructor() {
    effect(() => {
      this.stateChange.emit({
        globalSearch: this.globalSearch(),
        searchForm: this.searchFormValues(),
        columnFilters: this.columnFilters(),
        sortActive: this.sortState().active,
        sortDirection: this.sortState().direction,
        pageIndex: this.pageIndex(),
        pageSize: this.currentPageSize(),
        totalFiltered: this.sortedData().length,
      });
    });
  }

  cellValue(row: T, col: TableColumnDef<T>): unknown {
    return col.accessor ? col.accessor(row) : (row as Record<string, unknown>)[col.key];
  }

  formatValue(val: unknown): string {
    if (val === null || val === undefined) return '';
    if (val instanceof Date) return val.toISOString();
    return String(val);
  }

  onGlobalSearch(val: string): void {
    this.globalSearch.set(val);
    this.pageIndex.set(0);
  }

  setSearchFormField(key: string, val: string | null): void {
    this.searchFormValues.update((cur) => ({ ...cur, [key]: val ?? '' }));
    this.pageIndex.set(0);
  }

  setColumnFilter(key: string, event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.columnFilters.update((cur) => ({ ...cur, [key]: val }));
    this.pageIndex.set(0);
  }

  resetAllFilters(): void {
    this.globalSearch.set('');
    this.searchFormValues.update((cur) =>
      Object.fromEntries(Object.keys(cur).map((k) => [k, ''])),
    );
    this.columnFilters.update((cur) =>
      Object.fromEntries(Object.keys(cur).map((k) => [k, ''])),
    );
    this.pageIndex.set(0);
  }

  onSortChange(sort: Sort): void {
    this.sortState.set({ active: sort.active, direction: sort.direction });
  }

  onPage(event: PageEvent): void {
    this.currentPageSize.set(event.pageSize);
    this.pageIndex.set(event.pageIndex);
  }

  isSelected(row: T): boolean {
    return this.selectedRows().includes(row);
  }

  toggleRow(row: T): void {
    this.selectedRows.update((cur) =>
      cur.includes(row) ? cur.filter((r) => r !== row) : [...cur, row],
    );
    this.selectionChange.emit(this.selectedRows());
  }

  toggleAllOnPage(): void {
    const page = this.pagedData();
    const allSelected = this.allPageSelected();
    this.selectedRows.update((cur) => {
      if (allSelected) {
        const pageSet = new Set(page);
        return cur.filter((r) => !pageSet.has(r));
      }
      const next = new Set(cur);
      for (const r of page) next.add(r);
      return Array.from(next);
    });
    this.selectionChange.emit(this.selectedRows());
  }
}

function compareValues(a: unknown, b: unknown): number {
  if (a === b) return 0;
  if (a === null || a === undefined) return -1;
  if (b === null || b === undefined) return 1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}
