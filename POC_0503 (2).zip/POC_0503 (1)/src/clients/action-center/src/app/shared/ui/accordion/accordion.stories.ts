import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { AppAccordionComponent, AppAccordionPanelComponent } from './accordion.component';

const meta: Meta<AppAccordionComponent> = {
  title: 'UI Wrappers/Data Display/Accordion',
  component: AppAccordionComponent,
  tags: ['autodocs'],
  decorators: [moduleMetadata({ imports: [AppAccordionPanelComponent] })],
  argTypes: {
    displayMode: { control: 'select', options: ['default', 'flat'] },
    togglePosition: { control: 'select', options: ['before', 'after'] },
    panelToggled: { action: 'panelToggled' },
  },
  args: {
    multi: false,
    showBulkActions: true,
    displayMode: 'default',
    togglePosition: 'after',
    hideToggle: false,
  },
  render: (args) => ({
    props: args,
    template: `
      <of-accordion
        [multi]="multi"
        [showBulkActions]="showBulkActions"
        [displayMode]="displayMode"
        [togglePosition]="togglePosition"
        [hideToggle]="hideToggle"
        (panelToggled)="panelToggled($event)"
      >
        <of-accordion-panel title="Order details" description="TI-10045 · High priority" icon="ui-info" [expanded]="true">
          Received 08:42 from orders&#64;acmetitle.com. SLA due 09:42.
        </of-accordion-panel>
        <of-accordion-panel title="Parties" description="Buyer, seller, lender" icon="ui-group">
          Buyer: Jane Smith · Seller: John Doe · Lender: First National Bank
        </of-accordion-panel>
        <of-accordion-panel title="Extraction confidence" description="2 fields below 80%" icon="ui-warning">
          Property Address (72%), Closing Date (68%).
        </of-accordion-panel>
        <of-accordion-panel title="Audit history" description="Not available" [disabled]="true">
          Disabled panel.
        </of-accordion-panel>
      </of-accordion>
    `,
  }),
};

export default meta;
type Story = StoryObj<AppAccordionComponent>;

export const SingleOpen: Story = {};

export const MultipleOpen: Story = { args: { multi: true } };

export const Flat: Story = { args: { displayMode: 'flat', togglePosition: 'before' } };
