import { Component, computed, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ConfirmDialogData } from '../ui-types';

@Component({
  selector: 'of-confirm-dialog',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule],
  styles: [`
    .hdr { display: flex; align-items: center; gap: 10px; }
    .hdr mat-icon.info    { color: #2563eb; }
    .hdr mat-icon.warning { color: #d97706; }
    .hdr mat-icon.danger  { color: #dc2626; }
    .msg { margin: 8px 0 0; color: var(--text, #1f2733); line-height: 1.5; font-size: 14px; }
  `],
  template: `
    <h2 mat-dialog-title class="hdr">
      <mat-icon [class]="severity()" [svgIcon]="iconName()" />
      <span>{{ data.title }}</span>
    </h2>
    <mat-dialog-content>
      <p class="msg">{{ data.message }}</p>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" (click)="close(false)">
        {{ data.cancelText || 'Cancel' }}
      </button>
      <button
        mat-flat-button
        type="button"
        [color]="severity() === 'danger' ? 'warn' : 'primary'"
        (click)="close(true)"
      >
        {{ data.confirmText || 'Confirm' }}
      </button>
    </mat-dialog-actions>
  `,
})
export class AppConfirmDialogComponent {
  readonly data = inject<ConfirmDialogData>(MAT_DIALOG_DATA);
  private readonly ref = inject(MatDialogRef<AppConfirmDialogComponent, boolean>);

  readonly severity = computed(() => this.data.severity ?? 'info');
  readonly iconName = computed(() => {
    switch (this.severity()) {
      case 'danger':
        return 'ui-error';
      case 'warning':
        return 'ui-warning';
      default:
        return 'ui-help';
    }
  });

  close(confirmed: boolean): void {
    this.ref.close(confirmed);
  }
}
