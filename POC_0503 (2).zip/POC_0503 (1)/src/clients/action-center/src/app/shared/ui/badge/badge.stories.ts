import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { AppBadgeComponent } from './badge.component';

const meta: Meta<AppBadgeComponent> = {
  title: 'UI Wrappers/Data Display/Status Badge',
  component: AppBadgeComponent,
  tags: ['autodocs'],
  argTypes: {
    tone: { control: 'select', options: ['neutral', 'primary', 'info', 'success', 'warning', 'error'] },
    variant: { control: 'select', options: ['soft', 'solid', 'outline'] },
    size: { control: 'select', options: ['sm', 'md'] },
  },
  args: { label: 'In review', tone: 'primary', variant: 'soft', size: 'md', dot: true, icon: '' },
};

export default meta;
type Story = StoryObj<AppBadgeComponent>;

export const Playground: Story = {};

export const TaskStatuses: Story = {
  decorators: [moduleMetadata({ imports: [AppBadgeComponent] })],
  render: () => ({
    template: `
      <div style="display:flex; flex-direction:column; gap:12px;">
        @for (variant of ['soft', 'solid', 'outline']; track variant) {
          <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
            <of-badge label="Pending" tone="neutral" [variant]="variant" [dot]="true" />
            <of-badge label="Assigned" tone="primary" [variant]="variant" [dot]="true" />
            <of-badge label="In review" tone="info" [variant]="variant" [dot]="true" />
            <of-badge label="Approved" tone="success" [variant]="variant" icon="ui-check" />
            <of-badge label="SLA at risk" tone="warning" [variant]="variant" icon="ui-warning" />
            <of-badge label="Escalated" tone="error" [variant]="variant" icon="ui-error" />
          </div>
        }
      </div>
    `,
  }),
};

export const Priorities: Story = {
  decorators: [moduleMetadata({ imports: [AppBadgeComponent] })],
  render: () => ({
    template: `
      <div style="display:flex; gap:8px;">
        <of-badge label="High" tone="error" variant="solid" size="sm" />
        <of-badge label="Standard" tone="primary" variant="outline" size="sm" />
        <of-badge label="Low" tone="neutral" size="sm" />
      </div>
    `,
  }),
};
