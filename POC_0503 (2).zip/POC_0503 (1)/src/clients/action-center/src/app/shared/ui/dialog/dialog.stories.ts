import { Component, TemplateRef, ViewChild, inject, signal } from '@angular/core';
import type { Meta, StoryObj } from '@storybook/angular';
import { MatButtonModule } from '@angular/material/button';
import { AppDialogService } from './dialog.service';
import { AppTextboxComponent } from '../textbox/textbox.component';
import { AppSelectComponent } from '../select/select.component';
import { AppTextareaComponent } from '../textarea/textarea.component';
import { AppToastService } from '../toast/toast.service';
import { PopupSize } from '../ui-types';

@Component({
  selector: 'of-dialog-playground',
  standalone: true,
  imports: [MatButtonModule, AppTextboxComponent, AppSelectComponent, AppTextareaComponent],
  template: `
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:14px;">
      <button mat-flat-button color="primary" (click)="askConfirm('info')">
        Info Confirmation
      </button>
      <button mat-stroked-button (click)="askConfirm('warning')">
        Warning Confirmation
      </button>
      <button mat-flat-button color="warn" (click)="askConfirm('danger')">
        Danger Confirmation
      </button>
      <button mat-stroked-button (click)="openGenericPopup('sm')">
        Generic Popup (SM)
      </button>
      <button mat-stroked-button (click)="openGenericPopup('md')">
        Generic Popup (MD)
      </button>
      <button mat-stroked-button (click)="openGenericPopup('lg')">
        Generic Popup (LG)
      </button>
    </div>

    <div style="font-size:13px; color:#6b7686;">
      Open dialogs signal: <strong>{{ dialogs.openCount() }}</strong> ·
      Last outcome: <strong>{{ lastOutcome() }}</strong>
    </div>

    <ng-template #delegateTpl let-data let-close="close">
      <div style="display:flex; flex-direction:column; gap:14px; padding-top:4px;">
        <of-textbox label="Order Reference" [value]="data.orderRef" [readonly]="true" />
        <of-select
          label="Assignee"
          [searchable]="true"
          [options]="teamOptions"
          [value]="assignee()"
          (selectionChanged)="assignee.set($any($event) || '')"
        />
        <of-textarea
          label="Handover Note"
          placeholder="Optional instructions for assignee..."
          [value]="note()"
          (valueChanged)="note.set($event)"
        />
      </div>
    </ng-template>
  `,
})
class DialogPlaygroundComponent {
  readonly dialogs = inject(AppDialogService);
  private readonly toast = inject(AppToastService);

  @ViewChild('delegateTpl', { static: true }) delegateTpl!: TemplateRef<{ $implicit: { orderRef: string }; close: (r?: unknown) => void }>;

  readonly lastOutcome = signal('none yet');
  readonly assignee = signal('rep-1');
  readonly note = signal('');

  readonly teamOptions = [
    { label: 'Morgan (Manager)', value: 'mgr-1' },
    { label: 'Riley (Reportee)', value: 'rep-1' },
    { label: 'Jordan (Reportee)', value: 'rep-2' },
  ];

  async askConfirm(severity: 'info' | 'warning' | 'danger'): Promise<void> {
    const ok = await this.dialogs.confirmAsync({
      title: severity === 'danger' ? 'Reject Order TI-10045?' : 'Confirm Validation Submission',
      message:
        severity === 'danger'
          ? 'This will reject the order and notify downstream systems. This cannot be undone.'
          : 'Submitting will resume the Durable Orchestrator and finalize this order.',
      confirmText: severity === 'danger' ? 'Yes, Reject' : 'Proceed',
      cancelText: 'Cancel',
      severity,
    });
    this.lastOutcome.set(ok ? `Confirmed (${severity})` : `Cancelled (${severity})`);
    if (ok) this.toast.success(`Confirmed (${severity})`);
  }

  openGenericPopup(size: PopupSize): void {
    const ref = this.dialogs.openPopup({
      title: 'Delegate Validation Task',
      subtitle: `Popup size: ${size.toUpperCase()} · Powered by AppPopupComponent`,
      size,
      template: this.delegateTpl,
      data: { orderRef: 'TI-10045 (Acme Title)' },
      confirmText: 'Delegate Task',
      cancelText: 'Close',
    });

    ref.afterClosed().subscribe((res) => {
      if (res) {
        const msg = `Delegated to ${this.assignee()} (${this.note() || 'no note'})`;
        this.lastOutcome.set(msg);
        this.toast.success(msg);
      } else {
        this.lastOutcome.set('Popup closed without saving');
      }
    });
  }
}

const meta: Meta<DialogPlaygroundComponent> = {
  title: 'UI Wrappers/Overlays/Confirmation Dialog & Generic Popup',
  component: DialogPlaygroundComponent,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<DialogPlaygroundComponent>;

export const InteractivePlayground: Story = {};
