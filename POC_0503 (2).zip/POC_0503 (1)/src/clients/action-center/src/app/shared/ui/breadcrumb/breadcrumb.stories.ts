import { provideRouter } from '@angular/router';
import { applicationConfig, type Meta, type StoryObj } from '@storybook/angular';
import { AppBreadcrumbComponent } from './breadcrumb.component';
import { BreadcrumbItem } from '../ui-types';

const trail: BreadcrumbItem[] = [
  { label: 'Home', link: '/', icon: 'ui-home' },
  { label: 'Customers', link: '/customers' },
  { label: 'Acme Title', link: ['/customers', 'acme-title'] },
  { label: 'Inbox', link: ['/customers', 'acme-title', 'inbox'] },
  { label: 'Task TI-10045' },
];

const meta: Meta<AppBreadcrumbComponent> = {
  title: 'UI Wrappers/Navigation/Breadcrumb',
  component: AppBreadcrumbComponent,
  tags: ['autodocs'],
  decorators: [applicationConfig({ providers: [provideRouter([])] })],
  argTypes: {
    itemClicked: { action: 'itemClicked' },
  },
  args: { items: trail, maxVisible: 0, separatorIcon: 'ui-chevron-right' },
};

export default meta;
type Story = StoryObj<AppBreadcrumbComponent>;

export const Default: Story = {};

export const Collapsed: Story = {
  args: { maxVisible: 3 },
};

export const ClickHandlersInsteadOfLinks: Story = {
  args: {
    items: [
      { label: 'Action Center', icon: 'ui-home' },
      { label: 'Validation' },
      { label: 'Archived', disabled: true },
      { label: 'Order 7781' },
    ],
  },
};
