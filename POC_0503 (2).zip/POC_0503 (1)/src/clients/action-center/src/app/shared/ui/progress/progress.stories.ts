import type { Meta, StoryObj } from '@storybook/angular';
import { AppProgressComponent } from './progress.component';

const meta: Meta<AppProgressComponent> = {
  title: 'UI Wrappers/Feedback/Progress',
  component: AppProgressComponent,
  tags: ['autodocs'],
  argTypes: {
    type: { control: 'select', options: ['bar', 'spinner'] },
    value: { control: { type: 'range', min: 0, max: 100, step: 1 } },
  },
  args: { type: 'bar', value: 64, label: 'Extracting entities', showValue: true, diameter: 32 },
};

export default meta;
type Story = StoryObj<AppProgressComponent>;

export const DeterminateBar: Story = {};

export const IndeterminateBar: Story = { args: { value: null, label: 'Loading tasks…' } };

export const DeterminateSpinner: Story = { args: { type: 'spinner', value: 40, label: 'Uploading PDF' } };

export const LoadingSpinner: Story = { args: { type: 'spinner', value: null, label: 'Resuming orchestration…' } };
