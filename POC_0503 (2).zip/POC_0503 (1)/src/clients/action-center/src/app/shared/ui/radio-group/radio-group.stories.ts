import type { Meta, StoryObj } from '@storybook/angular';
import { AppRadioGroupComponent } from './radio-group.component';

const meta: Meta<AppRadioGroupComponent<string>> = {
  title: 'UI Wrappers/Form Controls/Radio Group',
  component: AppRadioGroupComponent,
  tags: ['autodocs'],
  argTypes: {
    orientation: { control: 'radio', options: ['horizontal', 'vertical'] },
    color: { control: 'select', options: ['primary', 'accent', 'warn'] },
    valueChanged: { action: 'valueChanged' },
  },
};

export default meta;
type Story = StoryObj<AppRadioGroupComponent<string>>;

const POLICY_OPTIONS = [
  { label: 'ALTA Owner', value: 'alta-owner' },
  { label: 'ALTA Loan', value: 'alta-loan' },
  { label: 'Short-Form', value: 'short-form' },
  { label: 'Commercial (Unavailable)', value: 'commercial', disabled: true },
];

export const Horizontal: Story = {
  args: {
    label: 'Policy Type',
    options: POLICY_OPTIONS,
    value: 'alta-owner',
    orientation: 'horizontal',
    required: true,
  },
};

export const Vertical: Story = {
  args: {
    label: 'Validation Decision',
    options: [
      { label: 'Approve & Finalize Order', value: 'approve' },
      { label: 'Hold for Missing Docs', value: 'hold' },
      { label: 'Reject Order', value: 'reject' },
    ],
    value: 'approve',
    orientation: 'vertical',
  },
};

export const WithError: Story = {
  args: {
    label: 'Priority Override',
    options: [
      { label: 'High', value: 'high' },
      { label: 'Standard', value: 'standard' },
      { label: 'Low', value: 'low' },
    ],
    value: null,
    required: true,
    errorMessage: 'Please choose a priority.',
  },
};
