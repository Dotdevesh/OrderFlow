import { Injectable, computed, inject, signal } from '@angular/core';
import { MatSnackBar, MatSnackBarRef } from '@angular/material/snack-bar';
import { AppToastComponent } from './toast.component';
import { ToastConfig } from '../ui-types';

export interface ToastLogEntry extends ToastConfig {
  id: number;
  shownAt: Date;
}

@Injectable({ providedIn: 'root' })
export class AppToastService {
  private readonly snackBar = inject(MatSnackBar);
  private nextId = 1;

  private readonly _history = signal<ToastLogEntry[]>([]);
  private readonly _activeRef = signal<MatSnackBarRef<AppToastComponent> | null>(null);

  readonly history = this._history.asReadonly();
  readonly hasActiveToast = computed(() => this._activeRef() !== null);

  show(config: ToastConfig): MatSnackBarRef<AppToastComponent> {
    const severity = config.severity ?? 'info';
    const duration = config.durationMs ?? (severity === 'error' ? 6000 : 3500);

    const ref = this.snackBar.openFromComponent(AppToastComponent, {
      data: { ...config, severity },
      duration,
      horizontalPosition: 'right',
      verticalPosition: 'top',
      panelClass: ['of-snackbar', `of-snackbar-${severity}`],
    });

    this._activeRef.set(ref);
    this._history.update((items) => [
      { ...config, severity, id: this.nextId++, shownAt: new Date() },
      ...items.slice(0, 19),
    ]);

    ref.afterDismissed().subscribe(() => {
      if (this._activeRef() === ref) {
        this._activeRef.set(null);
      }
    });

    return ref;
  }

  success(message: string, title = 'Success', durationMs?: number): MatSnackBarRef<AppToastComponent> {
    return this.show({ title, message, severity: 'success', durationMs });
  }

  info(message: string, title = 'Info', durationMs?: number): MatSnackBarRef<AppToastComponent> {
    return this.show({ title, message, severity: 'info', durationMs });
  }

  warning(message: string, title = 'Warning', durationMs?: number): MatSnackBarRef<AppToastComponent> {
    return this.show({ title, message, severity: 'warning', durationMs });
  }

  error(message: string, title = 'Error', durationMs?: number): MatSnackBarRef<AppToastComponent> {
    return this.show({ title, message, severity: 'error', durationMs });
  }

  dismissAll(): void {
    this.snackBar.dismiss();
    this._activeRef.set(null);
  }
}
