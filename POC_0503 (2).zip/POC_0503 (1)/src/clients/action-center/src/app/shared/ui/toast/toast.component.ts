import { Component, computed, inject } from '@angular/core';
import { MAT_SNACK_BAR_DATA, MatSnackBarRef } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { ToastConfig } from '../ui-types';

@Component({
  selector: 'of-toast',
  standalone: true,
  imports: [MatIconModule, MatButtonModule],
  styles: [`
    .of-toast {
      display: flex; align-items: flex-start; gap: 10px;
      min-width: 280px; max-width: 440px; padding: 4px 2px;
      color: #f8fafc;
    }
    .icon { flex-shrink: 0; margin-top: 2px; }
    .icon.success { color: #4ade80; }
    .icon.info    { color: #60a5fa; }
    .icon.warning { color: #fbbf24; }
    .icon.error   { color: #f87171; }
    .text { flex: 1; min-width: 0; }
    .title { font-weight: 600; font-size: 14px; margin-bottom: 2px; }
    .msg { font-size: 13px; color: #e2e8f0; word-break: break-word; }
    .actions { display: flex; align-items: center; gap: 4px; margin-left: 4px; }
  `],
  template: `
    <div class="of-toast" role="status">
      <mat-icon class="icon" [class]="severity()" [svgIcon]="iconName()" />
      <div class="text">
        @if (data.title) {
          <div class="title">{{ data.title }}</div>
        }
        <div class="msg">{{ data.message }}</div>
      </div>
      <div class="actions">
        @if (data.actionLabel) {
          <button mat-button color="accent" type="button" (click)="triggerAction()">
            {{ data.actionLabel }}
          </button>
        }
        <button mat-icon-button type="button" aria-label="Close toast" (click)="close()">
          <mat-icon svgIcon="ui-close" />
        </button>
      </div>
    </div>
  `,
})
export class AppToastComponent {
  readonly data = inject<ToastConfig>(MAT_SNACK_BAR_DATA);
  private readonly ref = inject(MatSnackBarRef<AppToastComponent>);

  readonly severity = computed(() => this.data.severity ?? 'info');
  readonly iconName = computed(() => {
    switch (this.severity()) {
      case 'success':
        return 'ui-check-circle';
      case 'warning':
        return 'ui-warning';
      case 'error':
        return 'ui-error';
      default:
        return 'ui-info';
    }
  });

  triggerAction(): void {
    this.data.onAction?.();
    this.ref.dismissWithAction();
  }

  close(): void {
    this.ref.dismiss();
  }
}
