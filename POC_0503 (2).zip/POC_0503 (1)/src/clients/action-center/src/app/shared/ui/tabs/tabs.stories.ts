import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { AppTabComponent, AppTabsComponent } from './tabs.component';

const meta: Meta<AppTabsComponent> = {
  title: 'UI Wrappers/Navigation/Tabs',
  component: AppTabsComponent,
  tags: ['autodocs'],
  decorators: [moduleMetadata({ imports: [AppTabComponent] })],
  argTypes: {
    align: { control: 'select', options: ['start', 'center', 'end'] },
    tabChanged: { action: 'tabChanged' },
  },
  args: { selectedIndex: 0, stretch: false, align: 'start', animationDuration: '200ms' },
  render: (args) => ({
    props: args,
    template: `
      <of-tabs
        [(selectedIndex)]="selectedIndex"
        [stretch]="stretch"
        [align]="align"
        [animationDuration]="animationDuration"
        (tabChanged)="tabChanged($event)"
      >
        <of-tab label="My Inbox" icon="ui-inbox" [badge]="4">
          4 validation tasks assigned to you. The nearest SLA is due in 18 minutes.
        </of-tab>
        <of-tab label="Pending Pool" [badge]="12">
          12 unclaimed tasks are waiting. Claim one to start validating.
        </of-tab>
        <of-tab label="Team" icon="ui-group">
          Managers can assign and delegate tasks to reportees here.
        </of-tab>
        <of-tab label="Completed">Recently submitted validations.</of-tab>
        <of-tab label="Archived" [disabled]="true">Disabled tab.</of-tab>
      </of-tabs>
    `,
  }),
};

export default meta;
type Story = StoryObj<AppTabsComponent>;

export const Default: Story = {};

export const Stretched: Story = { args: { stretch: true } };

export const Centered: Story = { args: { align: 'center' } };

export const StartOnSecondTab: Story = { args: { selectedIndex: 1 } };
