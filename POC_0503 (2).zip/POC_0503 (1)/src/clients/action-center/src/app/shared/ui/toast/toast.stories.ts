import { Component, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import type { Meta, StoryObj } from '@storybook/angular';
import { MatButtonModule } from '@angular/material/button';
import { AppToastService } from './toast.service';

@Component({
  selector: 'of-toast-playground',
  standalone: true,
  imports: [MatButtonModule, DatePipe],
  template: `
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:16px;">
      <button mat-flat-button color="primary" (click)="toast.success('Order TI-10045 approved and finalized.')">
        Success Toast
      </button>
      <button mat-stroked-button (click)="toast.info('New high-priority task arrived in pool.')">
        Info Toast
      </button>
      <button mat-stroked-button (click)="toast.warning('SLA expires in 3 minutes.')">
        Warning Toast
      </button>
      <button mat-flat-button color="warn" (click)="toast.error('Failed to connect to Order API.')">
        Error Toast
      </button>
      <button mat-stroked-button (click)="showWithAction()">
        Toast with Action
      </button>
      <button mat-button (click)="toast.dismissAll()">
        Dismiss All
      </button>
    </div>

    <div style="font-size:13px; color:#6b7686;">
      <strong>Signal state:</strong> active={{ toast.hasActiveToast() }} · recent history ({{ toast.history().length }})
      <ul>
        @for (item of toast.history(); track item.id) {
          <li>[{{ item.severity }}] {{ item.title }}: {{ item.message }} ({{ item.shownAt | date:'mediumTime' }})</li>
        }
      </ul>
    </div>
  `,
})
class ToastPlaygroundComponent {
  readonly toast = inject(AppToastService);

  showWithAction(): void {
    this.toast.show({
      title: 'Task Delegated',
      message: 'Assigned TI-10045 to Riley (Reportee).',
      severity: 'info',
      actionLabel: 'Undo',
      onAction: () => this.toast.success('Delegation reverted.', 'Undone'),
    });
  }
}

const meta: Meta<ToastPlaygroundComponent> = {
  title: 'UI Wrappers/Feedback/Toast',
  component: ToastPlaygroundComponent,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<ToastPlaygroundComponent>;

export const InteractivePlayground: Story = {};
