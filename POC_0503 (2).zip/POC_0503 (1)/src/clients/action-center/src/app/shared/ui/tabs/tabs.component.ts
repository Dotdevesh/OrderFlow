import {
  Component,
  TemplateRef,
  contentChildren,
  input,
  model,
  output,
  viewChild,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { UiTabChange } from '../ui-types';

/** A single tab declared inside `<of-tabs>`. Its content is rendered by the parent tab group. */
@Component({
  selector: 'of-tab',
  standalone: true,
  template: `<ng-template><ng-content /></ng-template>`,
})
export class AppTabComponent {
  readonly label = input.required<string>();
  /** Registered svg icon name shown before the label. */
  readonly icon = input<string>('');
  /** Count or short text shown as a pill after the label (e.g. pending task count). */
  readonly badge = input<string | number | null>(null);
  readonly disabled = input<boolean>(false);

  readonly content = viewChild.required(TemplateRef);
}

/**
 * Reusable Material tab group. Declare tabs as children:
 * `<of-tabs [(selectedIndex)]="i"><of-tab label="Inbox" [badge]="3">...</of-tab></of-tabs>`
 */
@Component({
  selector: 'of-tabs',
  standalone: true,
  imports: [NgTemplateOutlet, MatTabsModule, MatIconModule],
  styles: [`
    :host { display: block; }
    .tab-label { display: inline-flex; align-items: center; gap: 6px; }
    .tab-icon { width: 18px; height: 18px; font-size: 18px; }
    .tab-badge {
      min-width: 20px; height: 20px; padding: 0 6px; border-radius: 10px;
      background: var(--primary, #2563eb); color: #fff;
      font-size: 11px; font-weight: 600; line-height: 20px; text-align: center;
    }
    .tab-body { padding: 16px 2px; }
  `],
  template: `
    <mat-tab-group
      [selectedIndex]="selectedIndex()"
      (selectedIndexChange)="onIndexChange($event)"
      [mat-stretch-tabs]="stretch()"
      [mat-align-tabs]="align()"
      [animationDuration]="animationDuration()"
      [preserveContent]="true"
      [dynamicHeight]="true"
    >
      @for (tab of tabs(); track $index) {
        <mat-tab [disabled]="tab.disabled()">
          <ng-template mat-tab-label>
            <span class="tab-label">
              @if (tab.icon()) {
                <mat-icon class="tab-icon" [svgIcon]="tab.icon()" />
              }
              <span>{{ tab.label() }}</span>
              @if (tab.badge() !== null && tab.badge() !== '') {
                <span class="tab-badge">{{ tab.badge() }}</span>
              }
            </span>
          </ng-template>
          <div class="tab-body">
            <ng-container [ngTemplateOutlet]="tab.content()" />
          </div>
        </mat-tab>
      }
    </mat-tab-group>
  `,
})
export class AppTabsComponent {
  readonly selectedIndex = model<number>(0);
  readonly stretch = input<boolean>(false);
  readonly align = input<'start' | 'center' | 'end'>('start');
  readonly animationDuration = input<string>('200ms');
  readonly tabChanged = output<UiTabChange>();

  readonly tabs = contentChildren(AppTabComponent);

  onIndexChange(index: number): void {
    this.selectedIndex.set(index);
    this.tabChanged.emit({ index, label: this.tabs()[index]?.label() ?? '' });
  }
}
