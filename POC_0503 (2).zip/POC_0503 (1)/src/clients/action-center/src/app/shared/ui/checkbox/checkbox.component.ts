import {
  Component,
  computed,
  forwardRef,
  input,
  linkedSignal,
  model,
  output,
  signal,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatCheckboxChange, MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'of-checkbox',
  standalone: true,
  imports: [MatCheckboxModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AppCheckboxComponent),
      multi: true,
    },
  ],
  styles: [`
    :host { display: inline-flex; flex-direction: column; gap: 4px; }
    .hint { font-size: 12px; color: var(--muted, #6b7686); margin-left: 32px; }
    .err { font-size: 12px; color: #dc2626; margin-left: 32px; }
  `],
  template: `
    <mat-checkbox
      [checked]="internalChecked()"
      [indeterminate]="internalIndeterminate()"
      [disabled]="isDisabled()"
      [required]="required()"
      [labelPosition]="labelPosition()"
      [color]="color()"
      (change)="onToggle($event)"
      (blur)="onTouched()"
    >
      {{ label() }}
    </mat-checkbox>
    @if (hint() && !errorMessage()) {
      <span class="hint">{{ hint() }}</span>
    }
    @if (errorMessage()) {
      <span class="err">{{ errorMessage() }}</span>
    }
  `,
})
export class AppCheckboxComponent implements ControlValueAccessor {
  readonly label = input<string>('');
  readonly labelPosition = input<'before' | 'after'>('after');
  readonly color = input<'primary' | 'accent' | 'warn'>('primary');
  readonly disabled = input<boolean>(false);
  readonly required = input<boolean>(false);
  readonly hint = input<string>('');
  readonly errorMessage = input<string | null>(null);

  readonly checked = model<boolean>(false);
  readonly indeterminate = model<boolean>(false);
  readonly checkedChange = output<boolean>();

  readonly internalChecked = linkedSignal(() => Boolean(this.checked()));
  readonly internalIndeterminate = linkedSignal(() => Boolean(this.indeterminate()));

  private readonly cvaDisabled = signal(false);
  readonly isDisabled = computed(() => this.disabled() || this.cvaDisabled());

  private onChange: (v: boolean) => void = () => {};
  onTouched: () => void = () => {};

  onToggle(event: MatCheckboxChange): void {
    const next = event.checked;
    this.internalChecked.set(next);
    this.internalIndeterminate.set(false);
    this.checked.set(next);
    this.indeterminate.set(false);
    this.onChange(next);
    this.checkedChange.emit(next);
  }

  writeValue(val: boolean | null): void {
    const normalized = Boolean(val);
    this.internalChecked.set(normalized);
    this.checked.set(normalized);
  }

  registerOnChange(fn: (v: boolean) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.cvaDisabled.set(isDisabled);
  }
}
