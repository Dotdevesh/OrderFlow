import type { Meta, StoryObj } from '@storybook/angular';
import { AppTextboxComponent } from './textbox.component';

const meta: Meta<AppTextboxComponent> = {
  title: 'UI Wrappers/Form Controls/Textbox',
  component: AppTextboxComponent,
  tags: ['autodocs'],
  argTypes: {
    type: { control: 'select', options: ['text', 'number', 'email', 'password', 'date', 'tel', 'url'] },
    appearance: { control: 'radio', options: ['outline', 'fill'] },
    valueChanged: { action: 'valueChanged' },
  },
};

export default meta;
type Story = StoryObj<AppTextboxComponent>;

export const Default: Story = {
  args: {
    label: 'File Number',
    placeholder: 'e.g. TI-10045',
    hint: 'Must match ^TI-\\d+$',
    clearable: true,
    required: true,
    value: 'TI-10045',
  },
};

export const WithSearchIcon: Story = {
  args: {
    label: 'Search Orders',
    placeholder: 'Type PO or File #...',
    prefixSvgIcon: 'ui-search',
    clearable: true,
    value: '',
  },
};

export const PasswordWithToggle: Story = {
  args: {
    label: 'API Secret',
    type: 'password',
    value: 'super-secret-token',
  },
};

export const ErrorState: Story = {
  args: {
    label: 'Loan Amount',
    type: 'number',
    value: '',
    required: true,
    errorMessage: 'Loan Amount is required.',
  },
};

export const ReadOnlyAndDisabled: Story = {
  args: {
    label: 'Customer Reference (ReadOnly)',
    value: 'ACME-2026-001',
    readonly: true,
  },
};
