import type { Meta, StoryObj } from '@storybook/angular';
import { AppAlertComponent } from './alert.component';

const meta: Meta<AppAlertComponent> = {
  title: 'UI Wrappers/Feedback/Alert',
  component: AppAlertComponent,
  tags: ['autodocs'],
  argTypes: {
    severity: { control: 'select', options: ['info', 'success', 'warning', 'error'] },
    dismissed: { action: 'dismissed' },
  },
};

export default meta;
type Story = StoryObj<AppAlertComponent>;

export const Info: Story = {
  args: {
    severity: 'info',
    title: 'Human-in-the-loop required',
    message: 'Review extracted entities against the PDF on the left before submitting.',
    dismissible: false,
  },
};

export const Success: Story = {
  args: {
    severity: 'success',
    title: 'Validation submitted',
    message: 'Order TI-10045 was approved and Durable Orchestrator has resumed.',
    dismissible: true,
  },
};

export const Warning: Story = {
  args: {
    severity: 'warning',
    title: 'Low confidence detected (72%)',
    message: 'Property Address appeared in multiple places. Use the candidate picker to confirm.',
    dismissible: true,
  },
};

export const Error: Story = {
  args: {
    severity: 'error',
    title: 'Validation failed',
    message: 'File Number must match ^TI-\\d+$ before approval.',
    dismissible: true,
  },
};
