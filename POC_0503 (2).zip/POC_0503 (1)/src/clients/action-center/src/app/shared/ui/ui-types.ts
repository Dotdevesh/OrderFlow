import { TemplateRef } from '@angular/core';

export type UiSeverity = 'info' | 'success' | 'warning' | 'error';

export type UiFieldAppearance = 'outline' | 'fill';

export type UiBadgeTone = UiSeverity | 'neutral' | 'primary';

export interface BreadcrumbItem {
  label: string;
  /** Router link (string path or commands array). Items without a link emit `itemClicked` instead. */
  link?: string | readonly unknown[];
  /** Registered svg icon name, e.g. `ui-home`. */
  icon?: string;
  disabled?: boolean;
}

export interface UiTabChange {
  index: number;
  label: string;
}

export interface UiPanelToggle {
  index: number;
  expanded: boolean;
}

export interface UiOption<T = string> {
  label: string;
  value: T;
  disabled?: boolean;
  hint?: string;
}

export interface TableColumnDef<T = Record<string, unknown>> {
  key: string;
  header: string;
  sortable?: boolean;
  filterable?: boolean;
  filterPlaceholder?: string;
  width?: string;
  align?: 'left' | 'center' | 'right';
  /** Extracts the display/filter/sort value when it differs from `row[key]`. */
  accessor?: (row: T) => unknown;
  /** Optional custom cell template receiving `{ $implicit: row, row, value }`. */
  cellTemplate?: TemplateRef<{ $implicit: T; row: T; value: unknown }>;
}

export interface SearchFormFieldDef {
  key: string;
  label: string;
  type?: 'text' | 'select';
  placeholder?: string;
  options?: readonly UiOption<string>[];
}

export interface TableStateSnapshot {
  globalSearch: string;
  searchForm: Record<string, string>;
  columnFilters: Record<string, string>;
  sortActive: string;
  sortDirection: 'asc' | 'desc' | '';
  pageIndex: number;
  pageSize: number;
  totalFiltered: number;
}

export interface ToastConfig {
  title?: string;
  message: string;
  severity?: UiSeverity;
  durationMs?: number;
  actionLabel?: string;
  onAction?: () => void;
}

export interface ConfirmDialogData {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  severity?: 'info' | 'warning' | 'danger';
}

export type PopupSize = 'sm' | 'md' | 'lg' | 'xl';

export interface PopupDialogData<TData = unknown> {
  title: string;
  subtitle?: string;
  size?: PopupSize;
  template?: TemplateRef<{ $implicit: TData; close: (result?: unknown) => void }>;
  data?: TData;
  confirmText?: string;
  cancelText?: string;
  showFooter?: boolean;
}
