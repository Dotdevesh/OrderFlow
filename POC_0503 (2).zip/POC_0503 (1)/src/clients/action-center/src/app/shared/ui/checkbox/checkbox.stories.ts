import type { Meta, StoryObj } from '@storybook/angular';
import { AppCheckboxComponent } from './checkbox.component';

const meta: Meta<AppCheckboxComponent> = {
  title: 'UI Wrappers/Form Controls/Checkbox',
  component: AppCheckboxComponent,
  tags: ['autodocs'],
  argTypes: {
    color: { control: 'select', options: ['primary', 'accent', 'warn'] },
    labelPosition: { control: 'radio', options: ['after', 'before'] },
    checkedChange: { action: 'checkedChange' },
  },
};

export default meta;
type Story = StoryObj<AppCheckboxComponent>;

export const Default: Story = {
  args: {
    label: 'Expedite title commitment processing',
    checked: false,
    hint: 'Routes order to high-priority SLA queue',
  },
};

export const Checked: Story = {
  args: {
    label: 'I confirm extracted values match the source PDF',
    checked: true,
  },
};

export const Indeterminate: Story = {
  args: {
    label: 'Select all line items (partial)',
    checked: false,
    indeterminate: true,
  },
};

export const WithError: Story = {
  args: {
    label: 'Accept compliance attestation',
    required: true,
    checked: false,
    errorMessage: 'You must accept before submitting.',
  },
};
