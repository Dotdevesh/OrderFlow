import type { Meta, StoryObj } from '@storybook/angular';
import { AppTextareaComponent } from './textarea.component';

const meta: Meta<AppTextareaComponent> = {
  title: 'UI Wrappers/Form Controls/Textarea',
  component: AppTextareaComponent,
  tags: ['autodocs'],
  argTypes: {
    appearance: { control: 'radio', options: ['outline', 'fill'] },
    valueChanged: { action: 'valueChanged' },
  },
};

export default meta;
type Story = StoryObj<AppTextareaComponent>;

export const Default: Story = {
  args: {
    label: 'Legal Description',
    placeholder: 'Enter lot, block, subdivision...',
    rows: 3,
    autosize: true,
    maxLength: 500,
    hint: 'Auto-grows up to 8 rows',
    value: 'Lot 14, Block 2, Evergreen Terrace Subdivision, Sangamon County, IL.',
  },
};

export const WithValidationError: Story = {
  args: {
    label: 'Reviewer Notes',
    required: true,
    value: '',
    errorMessage: 'Rejection reason is required when rejecting an order.',
  },
};
