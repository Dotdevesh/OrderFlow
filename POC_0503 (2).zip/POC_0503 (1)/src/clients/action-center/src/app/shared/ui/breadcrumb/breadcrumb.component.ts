import { Component, computed, input, linkedSignal, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { BreadcrumbItem } from '../ui-types';

/**
 * Reusable breadcrumb trail. The last item is the current page. Items with `link` navigate via
 * the router; items without one emit `itemClicked`. Long trails collapse to
 * `first … last (maxVisible - 1)` until the ellipsis is clicked.
 */
@Component({
  selector: 'of-breadcrumb',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  styles: [`
    :host { display: block; }
    ol {
      display: flex; flex-wrap: wrap; align-items: center; gap: 4px;
      list-style: none; margin: 0; padding: 0; font-size: 13px;
    }
    li { display: inline-flex; align-items: center; gap: 4px; min-width: 0; }
    .crumb {
      display: inline-flex; align-items: center; gap: 4px; max-width: 220px;
      padding: 2px 6px; border-radius: 4px; border: none; background: none;
      color: var(--primary, #2563eb); text-decoration: none; cursor: pointer;
      font: inherit; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .crumb:hover:not(:disabled) { background: #eff6ff; text-decoration: underline; }
    .crumb:disabled { color: var(--muted, #6b7686); cursor: not-allowed; }
    .current { color: #111827; font-weight: 600; cursor: default; }
    .current:hover { background: none; text-decoration: none; }
    .crumb-icon { width: 16px; height: 16px; font-size: 16px; flex-shrink: 0; }
    .sep { width: 16px; height: 16px; font-size: 16px; color: var(--muted, #6b7686); }
  `],
  template: `
    <nav [attr.aria-label]="ariaLabel()">
      <ol>
        @for (item of visibleItems(); track $index; let last = $last) {
          <li>
            @if (item === ellipsis) {
              <button type="button" class="crumb" aria-label="Show full path" (click)="expanded.set(true)">…</button>
            } @else if (last) {
              <span class="crumb current" aria-current="page">
                @if (item.icon) { <mat-icon class="crumb-icon" [svgIcon]="item.icon" /> }
                {{ item.label }}
              </span>
            } @else if (item.link && !item.disabled) {
              <a class="crumb" [routerLink]="item.link" (click)="itemClicked.emit(item)">
                @if (item.icon) { <mat-icon class="crumb-icon" [svgIcon]="item.icon" /> }
                {{ item.label }}
              </a>
            } @else {
              <button type="button" class="crumb" [disabled]="!!item.disabled" (click)="itemClicked.emit(item)">
                @if (item.icon) { <mat-icon class="crumb-icon" [svgIcon]="item.icon" /> }
                {{ item.label }}
              </button>
            }
            @if (!last) {
              <mat-icon class="sep" [svgIcon]="separatorIcon()" aria-hidden="true" />
            }
          </li>
        }
      </ol>
    </nav>
  `,
})
export class AppBreadcrumbComponent {
  readonly items = input<readonly BreadcrumbItem[]>([]);
  /** Collapse the middle of the trail when it has more items than this. `0` disables collapsing. */
  readonly maxVisible = input<number>(0);
  readonly separatorIcon = input<string>('ui-chevron-right');
  readonly ariaLabel = input<string>('Breadcrumb');
  readonly itemClicked = output<BreadcrumbItem>();

  protected readonly ellipsis: BreadcrumbItem = { label: '…' };

  /** Re-collapses whenever a new trail is supplied. */
  readonly expanded = linkedSignal({ source: this.items, computation: () => false });

  readonly visibleItems = computed<readonly BreadcrumbItem[]>(() => {
    const all = this.items();
    const max = this.maxVisible();
    if (this.expanded() || max < 2 || all.length <= max) return all;
    return [all[0], this.ellipsis, ...all.slice(all.length - (max - 1))];
  });
}
