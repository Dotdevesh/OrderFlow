import type { Meta, StoryObj } from '@storybook/angular';
import { AppSelectComponent } from './select.component';

const meta: Meta<AppSelectComponent<string>> = {
  title: 'UI Wrappers/Form Controls/Dropdown (Select)',
  component: AppSelectComponent,
  tags: ['autodocs'],
  argTypes: {
    appearance: { control: 'radio', options: ['outline', 'fill'] },
    selectionChanged: { action: 'selectionChanged' },
  },
};

export default meta;
type Story = StoryObj<AppSelectComponent<string>>;

const CUSTOMER_OPTIONS = [
  { label: 'Acme Title (Platinum)', value: 'acme-title' },
  { label: 'First National Title (Gold)', value: 'first-national' },
  { label: 'Acme Corp (Platinum)', value: 'acme' },
  { label: 'Globex Corp (Gold)', value: 'globex' },
  { label: 'Initech (Silver)', value: 'initech' },
  { label: 'Triage Pool (Disabled)', value: 'triage', disabled: true },
];

export const SingleDropdown: Story = {
  args: {
    label: 'Order Type',
    placeholder: 'Choose order type',
    options: [
      { label: 'Purchase', value: 'Purchase' },
      { label: 'Refinance', value: 'Refinance' },
      { label: 'Equity', value: 'Equity' },
    ],
    multiple: false,
    searchable: false,
    value: 'Purchase',
  },
};

export const MultiSelectDropdown: Story = {
  args: {
    label: 'Assigned Customers',
    placeholder: 'Select one or more customers',
    options: CUSTOMER_OPTIONS,
    multiple: true,
    searchable: false,
    showSelectAll: true,
    value: ['acme-title', 'first-national'],
  },
};

export const SearchableMultiSelectDropdown: Story = {
  args: {
    label: 'Filter Customers (Search + Multi-select)',
    placeholder: 'Search & select customers...',
    searchPlaceholder: 'Type customer name...',
    options: CUSTOMER_OPTIONS,
    multiple: true,
    searchable: true,
    showSelectAll: true,
    value: ['acme-title'],
    hint: 'Supports live search, Select all matching, and Clear',
  },
};

export const SearchableSingleDropdown: Story = {
  args: {
    label: 'Delegate To User',
    placeholder: 'Search team member...',
    options: [
      { label: 'Morgan (Manager)', value: 'mgr-1' },
      { label: 'Riley (Reportee)', value: 'rep-1' },
      { label: 'Jordan (Reportee)', value: 'rep-2' },
      { label: 'Taylor (Reportee)', value: 'rep-3' },
    ],
    multiple: false,
    searchable: true,
    allowEmpty: true,
    value: 'rep-1',
  },
};
