import { Component, OnInit, TemplateRef, ViewChild, inject, input, signal } from '@angular/core';
import type { Meta, StoryObj } from '@storybook/angular';
import { AppDataTableComponent } from './data-table.component';
import { AppToastService } from '../toast/toast.service';
import { SearchFormFieldDef, TableColumnDef } from '../ui-types';

interface SampleOrderRow {
  fileNumber: string;
  customer: string;
  priority: 'High' | 'Standard' | 'Low';
  status: 'Pending' | 'Assigned' | 'InProgress' | 'Completed' | 'Escalated';
  confidence: number;
  assignee: string;
  slaRemaining: string;
}

const SAMPLE_ROWS: SampleOrderRow[] = [
  { fileNumber: 'TI-10045', customer: 'Acme Title', priority: 'High', status: 'Pending', confidence: 92, assignee: 'Unassigned', slaRemaining: '14m' },
  { fileNumber: 'TI-10046', customer: 'First National', priority: 'Standard', status: 'Assigned', confidence: 74, assignee: 'Riley', slaRemaining: '52m' },
  { fileNumber: 'PO-10047', customer: 'Acme Corp', priority: 'High', status: 'InProgress', confidence: 96, assignee: 'Morgan', slaRemaining: '9m' },
  { fileNumber: 'PO-20890', customer: 'Globex', priority: 'Standard', status: 'Completed', confidence: 88, assignee: 'Jordan', slaRemaining: 'Done' },
  { fileNumber: 'PO-30112', customer: 'Initech', priority: 'Low', status: 'Pending', confidence: 68, assignee: 'Unassigned', slaRemaining: '3h 40m' },
  { fileNumber: 'TI-10048', customer: 'Acme Title', priority: 'High', status: 'Escalated', confidence: 71, assignee: 'Morgan', slaRemaining: 'BREACHED' },
  { fileNumber: 'TI-10049', customer: 'First National', priority: 'Standard', status: 'Pending', confidence: 95, assignee: 'Unassigned', slaRemaining: '1h 12m' },
  { fileNumber: 'PO-10050', customer: 'Acme Corp', priority: 'High', status: 'Completed', confidence: 99, assignee: 'Riley', slaRemaining: 'Done' },
  { fileNumber: 'TI-10051', customer: 'Acme Title', priority: 'High', status: 'Assigned', confidence: 83, assignee: 'Jordan', slaRemaining: '18m' },
  { fileNumber: 'PO-20891', customer: 'Globex', priority: 'Standard', status: 'InProgress', confidence: 79, assignee: 'Riley', slaRemaining: '41m' },
  { fileNumber: 'PO-30113', customer: 'Initech', priority: 'Low', status: 'Completed', confidence: 91, assignee: 'Jordan', slaRemaining: 'Done' },
  { fileNumber: 'TI-10052', customer: 'First National', priority: 'Standard', status: 'Pending', confidence: 85, assignee: 'Unassigned', slaRemaining: '1h 25m' },
];

@Component({
  selector: 'of-table-playground',
  standalone: true,
  imports: [AppDataTableComponent],
  template: `
    <ng-template #priorityTpl let-value="value">
      <span
        style="padding:2px 8px; border-radius:10px; font-size:12px; color:#fff; font-weight:600;"
        [style.background]="value === 'High' ? '#dc2626' : (value === 'Standard' ? '#d97706' : '#16a34a')"
      >
        {{ value }}
      </span>
    </ng-template>

    <ng-template #confTpl let-value="value">
      <span [style.color]="value < 80 ? '#dc2626' : '#166534'" [style.font-weight]="value < 80 ? '600' : '400'">
        {{ value }}%
      </span>
    </ng-template>

    <of-data-table
      [data]="rows()"
      [columns]="columns()"
      [showPagination]="showPagination()"
      [pageSize]="pageSize()"
      [pageSizeOptions]="[5, 10, 25]"
      [sortable]="sortable()"
      [showColumnFilters]="showColumnFilters()"
      [showSearchForm]="showSearchForm()"
      [searchFields]="showSearchForm() ? searchFields : []"
      [selectable]="selectable()"
      (rowClick)="onRowClick($event)"
      (selectionChange)="onSelectionChange($event)"
    />
  `,
})
class TablePlaygroundComponent implements OnInit {
  private readonly toast = inject(AppToastService);

  readonly showPagination = input(true);
  readonly pageSize = input(5);
  readonly sortable = input(true);
  readonly showColumnFilters = input(true);
  readonly showSearchForm = input(true);
  readonly selectable = input(true);

  readonly rows = signal(SAMPLE_ROWS);
  readonly columns = signal<TableColumnDef<SampleOrderRow>[]>([
    { key: 'fileNumber', header: 'Order / File #', sortable: true, filterable: true },
    { key: 'customer', header: 'Customer', sortable: true, filterable: true },
    { key: 'priority', header: 'Priority', sortable: true, filterable: true },
    { key: 'status', header: 'Status', sortable: true, filterable: true },
    { key: 'confidence', header: 'Confidence', sortable: true, filterable: true, align: 'right' },
    { key: 'assignee', header: 'Assigned To', sortable: true, filterable: true },
    { key: 'slaRemaining', header: 'SLA', sortable: true, filterable: false },
  ]);

  readonly searchFields: SearchFormFieldDef[] = [
    {
      key: 'priority',
      label: 'Priority',
      type: 'select',
      options: [
        { label: 'High', value: 'High' },
        { label: 'Standard', value: 'Standard' },
        { label: 'Low', value: 'Low' },
      ],
    },
    {
      key: 'status',
      label: 'Status',
      type: 'select',
      options: [
        { label: 'Pending', value: 'Pending' },
        { label: 'Assigned', value: 'Assigned' },
        { label: 'InProgress', value: 'InProgress' },
        { label: 'Completed', value: 'Completed' },
        { label: 'Escalated', value: 'Escalated' },
      ],
    },
    {
      key: 'customer',
      label: 'Customer',
      type: 'text',
      placeholder: 'e.g. Acme',
    },
  ];

  @ViewChild('priorityTpl', { static: true }) priorityTpl!: TemplateRef<{ $implicit: SampleOrderRow; row: SampleOrderRow; value: unknown }>;
  @ViewChild('confTpl', { static: true }) confTpl!: TemplateRef<{ $implicit: SampleOrderRow; row: SampleOrderRow; value: unknown }>;

  ngOnInit(): void {
    this.columns.update((cols) =>
      cols.map((c) => {
        if (c.key === 'priority') return { ...c, cellTemplate: this.priorityTpl };
        if (c.key === 'confidence') return { ...c, cellTemplate: this.confTpl };
        return c;
      }),
    );
  }

  onRowClick(row: SampleOrderRow): void {
    this.toast.info(`Clicked ${row.fileNumber} (${row.customer})`);
  }

  onSelectionChange(rows: readonly SampleOrderRow[]): void {
    if (rows.length) {
      this.toast.info(`${rows.length} row(s) selected`);
    }
  }
}

const meta: Meta<TablePlaygroundComponent> = {
  title: 'UI Wrappers/Data Display/Data Table',
  component: TablePlaygroundComponent,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<TablePlaygroundComponent>;

export const FullEnterpriseTable: Story = {
  args: {
    showSearchForm: true,
    showColumnFilters: true,
    sortable: true,
    showPagination: true,
    pageSize: 5,
    selectable: true,
  },
};

export const BasicTable: Story = {
  args: {
    showSearchForm: false,
    showColumnFilters: false,
    sortable: false,
    showPagination: false,
    selectable: false,
  },
};

export const TableWithPagination: Story = {
  args: {
    showSearchForm: false,
    showColumnFilters: false,
    sortable: true,
    showPagination: true,
    pageSize: 5,
    selectable: false,
  },
};

export const SortingAndColumnFilters: Story = {
  args: {
    showSearchForm: false,
    showColumnFilters: true,
    sortable: true,
    showPagination: true,
    pageSize: 5,
    selectable: false,
  },
};
