import {
  Component,
  computed,
  input,
  linkedSignal,
  model,
  output,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { UiSeverity } from '../ui-types';

@Component({
  selector: 'of-alert',
  standalone: true,
  imports: [MatIconModule, MatButtonModule],
  styles: [`
    .of-alert {
      display: flex; align-items: flex-start; gap: 12px;
      padding: 12px 14px; border-radius: 8px; border: 1px solid;
      font-size: 14px; line-height: 1.45;
    }
    .of-alert.info    { background: #eff6ff; border-color: #bfdbfe; color: #1e40af; }
    .of-alert.success { background: #f0fdf4; border-color: #bbf7d0; color: #166534; }
    .of-alert.warning { background: #fffbeb; border-color: #fde68a; color: #92400e; }
    .of-alert.error   { background: #fef2f2; border-color: #fecaca; color: #991b1b; }
    .icon { flex-shrink: 0; margin-top: 1px; }
    .body { flex: 1; min-width: 0; }
    .title { font-weight: 600; margin-bottom: 2px; }
    .actions { display: flex; gap: 8px; align-items: center; margin-top: 8px; }
    .actions:empty { display: none; }
    .close-btn { margin: -6px -6px 0 0; }
  `],
  template: `
    @if (isVisible()) {
      <div class="of-alert" [class]="severity()" role="alert">
        <mat-icon class="icon" [svgIcon]="iconName()" />
        <div class="body">
          @if (title()) {
            <div class="title">{{ title() }}</div>
          }
          <div class="message">
            @if (message()) {
              {{ message() }}
            } @else {
              <ng-content />
            }
          </div>
          <div class="actions">
            <ng-content select="[alert-actions]" />
          </div>
        </div>
        @if (dismissible()) {
          <button
            mat-icon-button
            type="button"
            class="close-btn"
            aria-label="Dismiss alert"
            (click)="dismiss()"
          >
            <mat-icon svgIcon="ui-close" />
          </button>
        }
      </div>
    }
  `,
})
export class AppAlertComponent {
  readonly severity = input<UiSeverity>('info');
  readonly title = input<string>('');
  readonly message = input<string>('');
  readonly dismissible = input<boolean>(false);

  /** External visibility model. */
  readonly visible = model<boolean>(true);
  readonly dismissed = output<void>();

  /**
   * Linked signal re-opens the alert automatically when `message` or `severity` changes
   * (unless `visible` is explicitly false for the new payload).
   */
  readonly isVisible = linkedSignal({
    source: () => ({ msg: this.message(), sev: this.severity(), vis: this.visible() }),
    computation: (src) => src.vis,
  });

  readonly iconName = computed(() => {
    switch (this.severity()) {
      case 'success':
        return 'ui-check-circle';
      case 'warning':
        return 'ui-warning';
      case 'error':
        return 'ui-error';
      default:
        return 'ui-info';
    }
  });

  dismiss(): void {
    this.isVisible.set(false);
    this.visible.set(false);
    this.dismissed.emit();
  }
}
