import { Injectable, inject, signal } from '@angular/core';
import {
  AccountInfo,
  BrowserCacheLocation,
  InteractionRequiredAuthError,
  PublicClientApplication,
} from '@azure/msal-browser';
import { environment } from '../../environments/environment';
import { AuthenticatedPrincipal, Session } from './session';

interface WindowsSsoExchangeDto {
  authenticated: boolean;
  authorized: boolean;
  accessToken?: string | null;
  expiresAtUtc?: string | null;
  principal: AuthenticatedPrincipal;
}

/**
 * Orchestrates user login and AD Group + App Role verification via OrderFlow.IdentityApi:
 * 1. Microsoft Entra ID Seamless SSO (MSAL `ssoSilent` using Windows PRT / Kerberos credentials)
 * 2. Windows Integrated Authentication (`Negotiate` / Kerberos) fallback on `IdentityApi` (`/api/auth/windows-sso`)
 * 3. Interactive Microsoft Entra ID OAuth 2.0 Authorization Code + PKCE redirect fallback
 * 4. Database-backed AD Security Group + Role gate (`GET /api/auth/me` on `IdentityApi`)
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly session = inject(Session);
  private msal?: PublicClientApplication;
  private initPromise?: Promise<void>;

  private windowsBearerToken: string | null = null;
  private windowsTokenExpiresAtMs = 0;

  readonly initialized = signal(false);
  readonly busy = signal(false);

  initialize(): Promise<void> {
    if (!this.initPromise) {
      this.initPromise = this.doInitialize();
    }
    return this.initPromise;
  }

  private async doInitialize(): Promise<void> {
    this.busy.set(true);
    try {
      // Local offline dev mode
      if (!environment.entra.enabled && environment.devAuth.enabled) {
        this.session.isAuthenticated.set(true);
        this.session.isAuthorized.set(true);
        return;
      }

      // 1) Initialize MSAL Browser if Entra clientId + tenantId are configured
      if (environment.entra.clientId && environment.entra.tenantId) {
        this.msal = new PublicClientApplication({
          auth: {
            clientId: environment.entra.clientId,
            authority: `https://login.microsoftonline.com/${environment.entra.tenantId}`,
            redirectUri: environment.entra.redirectUri || window.location.origin,
          },
          cache: {
            cacheLocation: BrowserCacheLocation.SessionStorage,
          },
        });
        await this.msal.initialize();

        // Handle returning OAuth2 PKCE redirect
        const redirectResult = await this.msal.handleRedirectPromise();
        if (redirectResult?.account) {
          this.msal.setActiveAccount(redirectResult.account);
        }

        const existingAccount = this.getActiveMsalAccount();
        if (existingAccount) {
          await this.verifyPrincipalWithIdentityService();
          return;
        }
      }

      // 2) Automatic Windows Credentials Login (Seamless SSO -> Windows Negotiate fallback)
      if (environment.entra.enableWindowsSso) {
        const silentMsalOk = await this.tryEntraWindowsSeamlessSso();
        if (silentMsalOk) {
          await this.verifyPrincipalWithIdentityService();
          return;
        }

        const negotiateOk = await this.tryWindowsNegotiateSso();
        if (negotiateOk) {
          return;
        }
      }

      // 3) Interactive Entra redirect if silent Windows SSO was unavailable
      if (this.msal) {
        await this.loginWithEntraRedirect();
      }
    } finally {
      this.busy.set(false);
      this.initialized.set(true);
    }
  }

  /**
   * Attempts silent SSO with Microsoft Entra ID using the signed-in Windows OS user's
   * Primary Refresh Token (PRT) / Seamless SSO Kerberos ticket (zero password prompt).
   */
  private async tryEntraWindowsSeamlessSso(): Promise<boolean> {
    if (!this.msal) return false;
    try {
      const result = await this.msal.ssoSilent({
        scopes: environment.entra.apiScopes,
        domainHint: environment.entra.domainHint || undefined,
      });
      if (result.account) {
        this.msal.setActiveAccount(result.account);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  /**
   * Attempts Integrated Windows Authentication (Negotiate: Kerberos/NTLM) against
   * `OrderFlow.IdentityApi` (`GET /api/auth/windows-sso`) using browser Windows credentials.
   */
  async tryWindowsNegotiateSso(): Promise<boolean> {
    try {
      const res = await fetch(`${environment.identityApiBaseUrl}/api/auth/windows-sso`, {
        method: 'GET',
        credentials: 'include',
        headers: { Accept: 'application/json' },
      });

      if (res.status === 401) {
        return false;
      }

      const data = (await res.json()) as WindowsSsoExchangeDto;
      if (data?.principal) {
        this.session.applyPrincipal(data.principal);
      }

      if (res.ok && data.authorized && data.accessToken) {
        this.windowsBearerToken = data.accessToken;
        this.windowsTokenExpiresAtMs = data.expiresAtUtc
          ? new Date(data.expiresAtUtc).getTime()
          : Date.now() + 55 * 60 * 1000;
        return true;
      }

      // User authenticated via Windows credentials, but failed AD Group or Role check (403)
      return data?.authenticated === true;
    } catch {
      return false;
    }
  }

  /**
   * Calls `GET /api/auth/me` on `OrderFlow.IdentityApi` to confirm the user is active in SQL,
   * belongs to the required AD Security Group, and holds an assigned App Role / Group Role.
   */
  async verifyPrincipalWithIdentityService(): Promise<void> {
    const token = await this.getAccessToken();
    if (!token) return;

    try {
      const res = await fetch(`${environment.identityApiBaseUrl}/api/auth/me`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      });

      if (res.status === 401) {
        this.session.isAuthenticated.set(false);
        this.session.isAuthorized.set(false);
        return;
      }

      const principal = (await res.json()) as AuthenticatedPrincipal;
      this.session.applyPrincipal(principal);
    } catch {
      this.session.applyPrincipal({
        isAuthenticated: true,
        isAuthorized: false,
        denialCode: 'identity_service_unreachable',
        denialReason: 'Unable to reach OrderFlow Identity microservice to verify AD group and role membership.',
        groups: [],
        appRoles: [],
        authMethod: 'EntraJwt',
      });
    }
  }

  async getAccessToken(): Promise<string | null> {
    if (!environment.entra.enabled && environment.devAuth.enabled) {
      return null;
    }

    // 1) Active Windows Negotiate exchanged JWT
    if (this.windowsBearerToken && this.windowsTokenExpiresAtMs > Date.now() + 30_000) {
      return this.windowsBearerToken;
    }

    // 2) MSAL Entra ID access token
    if (this.msal) {
      const account = this.getActiveMsalAccount();
      if (account) {
        try {
          const tokenRes = await this.msal.acquireTokenSilent({
            account,
            scopes: environment.entra.apiScopes,
          });
          return tokenRes.accessToken;
        } catch (err) {
          if (err instanceof InteractionRequiredAuthError) {
            await this.msal.acquireTokenRedirect({
              account,
              scopes: environment.entra.apiScopes,
            });
          }
        }
      }
    }

    // 3) Re-attempt Windows Negotiate renewal if expired
    if (environment.entra.enableWindowsSso && await this.tryWindowsNegotiateSso()) {
      return this.windowsBearerToken;
    }

    return null;
  }

  async loginWithEntraRedirect(): Promise<void> {
    if (!this.msal) return;
    await this.msal.loginRedirect({
      scopes: environment.entra.apiScopes,
      domainHint: environment.entra.domainHint || undefined,
    });
  }

  async logout(): Promise<void> {
    this.windowsBearerToken = null;
    this.windowsTokenExpiresAtMs = 0;
    this.session.isAuthenticated.set(false);
    this.session.isAuthorized.set(false);

    if (this.msal && this.getActiveMsalAccount()) {
      await this.msal.logoutRedirect();
    }
  }

  private getActiveMsalAccount(): AccountInfo | null {
    if (!this.msal) return null;
    const active = this.msal.getActiveAccount();
    if (active) return active;
    const all = this.msal.getAllAccounts();
    if (all.length > 0) {
      this.msal.setActiveAccount(all[0]);
      return all[0];
    }
    return null;
  }
}
