import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { from, switchMap } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
import { Session } from './session';

/**
 * Attaches Microsoft Entra ID / Windows SSO Bearer tokens to outbound API calls
 * (`OrderFlow.OrderApi` and `OrderFlow.IdentityApi`).
 * Falls back to `X-Debug-*` headers only in local offline dev (`devAuth.enabled && !entra.enabled`).
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const isBackendApi =
    req.url.startsWith(environment.apiBaseUrl) ||
    req.url.startsWith(environment.identityApiBaseUrl);

  if (!isBackendApi) {
    return next(req);
  }

  if (!environment.entra.enabled && environment.devAuth.enabled) {
    const session = inject(Session);
    const devRole = session.role() ?? 'Reportee';
    return next(
      req.clone({
        setHeaders: {
          'X-Debug-UserId': session.userId(),
          'X-Debug-Role': devRole,
          'X-Debug-Name': session.name(),
        },
      }),
    );
  }

  const auth = inject(AuthService);
  return from(auth.getAccessToken()).pipe(
    switchMap((token) => {
      if (!token) {
        return next(req);
      }
      return next(
        req.clone({
          setHeaders: {
            Authorization: `Bearer ${token}`,
          },
        }),
      );
    }),
  );
};
