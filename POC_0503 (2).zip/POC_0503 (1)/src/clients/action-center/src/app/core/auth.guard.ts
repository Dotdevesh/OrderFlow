import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
import { Session } from './session';

/**
 * Enforces that the user is authenticated (via Entra Seamless SSO / Windows credentials) AND
 * verified by `OrderFlow.IdentityApi` as belonging to both an authorized AD Security Group
 * and an OrderFlow Role (`Manager` or `Reportee`).
 */
export const authGuard: CanActivateFn = async () => {
  if (!environment.entra.enabled && environment.devAuth.enabled) {
    return true;
  }

  const auth = inject(AuthService);
  const session = inject(Session);
  const router = inject(Router);

  await auth.initialize();

  if (!session.isAuthenticated() || !session.isAuthorized()) {
    return router.createUrlTree(['/access-denied']);
  }

  return true;
};
