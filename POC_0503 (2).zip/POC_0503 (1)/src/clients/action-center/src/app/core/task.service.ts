import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Customer, FormTemplate, InboxScope, SubmitValidation, TaskDetail, TaskSummary, UserSummary } from './models';

@Injectable({ providedIn: 'root' })
export class TaskService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiBaseUrl;

  getCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(`${this.base}/api/customers`);
  }

  getUsers(): Observable<UserSummary[]> {
    return this.http.get<UserSummary[]>(`${this.base}/api/users`);
  }

  getFormTemplate(customerId: string): Observable<FormTemplate> {
    return this.http.get<FormTemplate>(`${this.base}/api/customers/${customerId}/form-template`);
  }

  getInbox(scope: InboxScope, customerId?: string | null, status?: number | null): Observable<TaskSummary[]> {
    let params: Record<string, string> = { scope };
    if (customerId) params = { ...params, customerId };
    if (status !== null && status !== undefined) params = { ...params, status: String(status) };
    return this.http.get<TaskSummary[]>(`${this.base}/api/tasks`, { params });
  }

  getDetail(taskId: string): Observable<TaskDetail> {
    return this.http.get<TaskDetail>(`${this.base}/api/tasks/${taskId}`);
  }

  open(taskId: string): Observable<void> {
    return this.http.post<void>(`${this.base}/api/tasks/${taskId}/open`, {});
  }

  claim(taskId: string): Observable<void> {
    return this.http.post<void>(`${this.base}/api/tasks/${taskId}/claim`, {});
  }

  assign(taskId: string, targetUserId: string): Observable<void> {
    return this.http.post<void>(`${this.base}/api/tasks/${taskId}/assign`, { targetUserId });
  }

  delegate(taskId: string, targetUserId: string): Observable<void> {
    return this.http.post<void>(`${this.base}/api/tasks/${taskId}/delegate`, { targetUserId });
  }

  submit(taskId: string, body: SubmitValidation): Observable<void> {
    return this.http.post<void>(`${this.base}/api/tasks/${taskId}/submit`, body);
  }

  getDocumentSas(orderId: string, docId: string): Observable<{ url: string; fileName: string; contentType: string }> {
    return this.http.get<{ url: string; fileName: string; contentType: string }>(
      `${this.base}/api/documents/${orderId}/${docId}/sas`,
    );
  }
}
