import { HttpInterceptorFn } from '@angular/common/http';
import { authInterceptor } from './auth.interceptor';

/** Backwards-compatible alias forwarding to `authInterceptor`. */
export const devAuthInterceptor: HttpInterceptorFn = authInterceptor;
