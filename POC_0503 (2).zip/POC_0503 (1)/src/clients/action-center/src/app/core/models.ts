export type Priority = 0 | 1 | 2; // High, Standard, Low
export const PriorityLabel: Record<Priority, string> = { 0: 'High', 1: 'Standard', 2: 'Low' };

export type TaskStatusName =
  | 'Pending' | 'Assigned' | 'Claimed' | 'InProgress' | 'Completed' | 'Escalated' | 'Cancelled';

export interface TaskSummary {
  taskId: string;
  orderId: string;
  customerId: string;
  priority: Priority;
  status: number;
  assignmentKind: number;
  assignedToUserId?: string | null;
  subject?: string | null;
  minConfidence: number;
  slaDueAtUtc: string;
  secondsRemaining: number;
}

export interface FieldCandidate {
  value?: string | null;
  confidence: number;
  label?: string | null;
  boundingRegionJson?: string | null;
}

export interface FieldDto {
  id: string;
  name: string;
  extractedValue?: string | null;
  validatedValue?: string | null;
  confidence: number;
  boundingRegionJson?: string | null;
  candidates?: FieldCandidate[] | null;
}

export interface LineDto {
  id: string;
  sku?: string | null;
  description?: string | null;
  quantity: number;
  unitPrice: number;
  confidence: number;
  isCorrected: boolean;
}

export interface DocumentRef {
  id: string;
  fileName: string;
  kind: number;
  contentType: string;
}

export interface TaskDetail {
  summary: TaskSummary;
  fields: FieldDto[];
  lines: LineDto[];
  documents: DocumentRef[];
  boundEntity?: Record<string, string | null> | null;
}

export interface SubmitValidation {
  approved: boolean;
  fields: { name: string; value: string | null }[];
  lines: { id: string | null; sku: string | null; description: string | null; quantity: number; unitPrice: number }[];
  note?: string | null;
}

export type InboxScope = 'mine' | 'pool' | 'team';

export interface UserSummary {
  id: string;
  displayName: string;
  email: string;
  role: number; // 0=Reportee, 1=Manager
  managerId?: string | null;
}

export interface Customer {
  customerId: string;
  displayName: string;
  tier: number;
  priority: Priority;
  slaMinutes: number;
}

// ----- Configurable form template -----
export interface FormFieldDef {
  key: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea' | 'checkbox';
  required: boolean;
  extractionField?: string | null;
  allowManual: boolean;
  localized: boolean;
  regex?: string | null;
  group?: string | null;
  options?: string[] | null;
  readOnly?: boolean;
  disabled?: boolean;
}

export interface FormColumnDef {
  key: string;
  label: string;
  type: string;
  extractionField?: string | null;
}

export interface FormSection {
  key: string;
  title: string;
  type: 'fields' | 'table';
  fields?: FormFieldDef[] | null;
  columns?: FormColumnDef[] | null;
}

export interface FormTemplate {
  customerId: string;
  version: number;
  name: string;
  sections: FormSection[];
}

// Status codes aligned with the server TaskStatus enum.
export const TaskStatusCode = {
  Pending: 0,
  Assigned: 1,
  Claimed: 2,
  InProgress: 3,
  Completed: 4,
  Escalated: 5,
  Cancelled: 6,
} as const;
