import { Injectable, inject, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
import { Session } from './session';

/** Wraps the SignalR connection to the Tasks hub for realtime inbox + SLA updates. */
@Injectable({ providedIn: 'root' })
export class RealtimeService {
  private readonly session = inject(Session);
  private readonly auth = inject(AuthService);
  private connection?: signalR.HubConnection;
  private joinedTeamId?: string;
  readonly lastEvent = signal<{ type: string; payload: unknown } | null>(null);

  async connect(teamManagerId: string): Promise<void> {
    if (this.connection && this.joinedTeamId === teamManagerId) return;
    if (this.connection) {
      await this.connection.stop();
      this.connection = undefined;
    }

    const useDevHeaders = !environment.entra.enabled && environment.devAuth.enabled;

    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(environment.hubUrl, {
        accessTokenFactory: useDevHeaders
          ? undefined
          : async () => (await this.auth.getAccessToken()) ?? '',
        headers: useDevHeaders
          ? {
              'X-Debug-UserId': this.session.userId(),
              'X-Debug-Role': this.session.role() ?? 'Reportee',
            }
          : undefined,
      })
      .withAutomaticReconnect()
      .build();

    this.connection.on('taskCreated', (p) => this.lastEvent.set({ type: 'taskCreated', payload: p }));
    this.connection.on('taskChanged', (p) => this.lastEvent.set({ type: 'taskChanged', payload: p }));

    await this.connection.start();
    await this.connection.invoke('JoinTeam', teamManagerId);
    this.joinedTeamId = teamManagerId;
  }
}
