import { Injectable, signal } from '@angular/core';
import { Customer } from './models';

const STORAGE_KEY = 'orderflow.selectedCustomer';

/**
 * Holds the customer the validator is currently working on. On login the user selects a customer;
 * every inbox/query is then scoped to it. Persisted so a refresh keeps the context.
 */
@Injectable({ providedIn: 'root' })
export class CustomerContext {
  readonly selected = signal<Customer | null>(this.restore());

  select(customer: Customer): void {
    this.selected.set(customer);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(customer));
  }

  clear(): void {
    this.selected.set(null);
    localStorage.removeItem(STORAGE_KEY);
  }

  private restore(): Customer | null {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Customer) : null;
  }
}
