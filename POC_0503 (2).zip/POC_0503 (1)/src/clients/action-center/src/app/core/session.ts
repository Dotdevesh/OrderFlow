import { Injectable, computed, signal } from '@angular/core';
import { environment } from '../../environments/environment';

export interface DevPersona {
  userId: string;
  role: 'Manager' | 'Reportee';
  name: string;
  managerId?: string | null;
}

export interface AuthenticatedPrincipal {
  isAuthenticated: boolean;
  isAuthorized: boolean;
  denialCode?: string | null;
  denialReason?: string | null;
  userId?: string | null;
  upn?: string | null;
  email?: string | null;
  displayName?: string | null;
  role?: number | 'Manager' | 'Reportee' | null; // 0=Reportee, 1=Manager
  managerId?: string | null;
  groups: string[];
  appRoles: string[];
  authMethod: string;
}

/**
 * Current user/session populated from Microsoft Entra ID (MSAL Seamless SSO),
 * Windows Integrated Auth (Negotiate via IdentityApi), or local Dev persona.
 * Strictly reflects AD Security Group + Azure App Registration Role verification from IdentityApi.
 */
@Injectable({ providedIn: 'root' })
export class Session {
  readonly userId = signal(environment.devAuth.userId);
  readonly role = signal<'Manager' | 'Reportee' | null>(
    environment.entra.enabled ? null : environment.devAuth.role,
  );
  readonly name = signal(environment.devAuth.name);
  readonly upn = signal<string | null>(null);
  readonly managerId = signal<string | null>(null);
  readonly groups = signal<string[]>([]);
  readonly appRoles = signal<string[]>([]);
  readonly authMethod = signal<string>(environment.entra.enabled ? 'Pending' : 'Dev');
  readonly isAuthenticated = signal<boolean>(!environment.entra.enabled && environment.devAuth.enabled);
  readonly isAuthorized = signal<boolean>(!environment.entra.enabled && environment.devAuth.enabled);
  readonly denialCode = signal<string | null>(null);
  readonly denialReason = signal<string | null>(null);

  readonly teamScopeId = computed(() =>
    this.isManager() ? this.userId() : (this.managerId() || 'mgr-1'),
  );

  readonly devPersonas: DevPersona[] = [
    { userId: 'mgr-1', role: 'Manager', name: 'Morgan (Manager)', managerId: null },
    { userId: 'rep-1', role: 'Reportee', name: 'Riley (Reportee)', managerId: 'mgr-1' },
    { userId: 'rep-2', role: 'Reportee', name: 'Jordan (Reportee)', managerId: 'mgr-1' },
  ];

  isManager(): boolean {
    return this.role() === 'Manager';
  }

  applyPrincipal(p: AuthenticatedPrincipal): void {
    this.isAuthenticated.set(p.isAuthenticated);
    this.isAuthorized.set(p.isAuthorized);
    this.denialCode.set(p.denialCode ?? null);
    this.denialReason.set(p.denialReason ?? null);
    this.authMethod.set(p.authMethod);
    this.groups.set(p.groups ?? []);
    this.appRoles.set(p.appRoles ?? []);

    if (p.userId) this.userId.set(p.userId);
    if (p.displayName) this.name.set(p.displayName);
    this.upn.set(p.upn ?? p.email ?? null);
    this.managerId.set(p.managerId ?? null);

    if (p.role === 1 || p.role === 'Manager') {
      this.role.set('Manager');
    } else if (p.role === 0 || p.role === 'Reportee') {
      this.role.set('Reportee');
    } else {
      this.role.set(null);
    }
  }

  switchPersona(userId: string): void {
    const found = this.devPersonas.find((p) => p.userId === userId);
    if (!found) return;
    this.userId.set(found.userId);
    this.role.set(found.role);
    this.name.set(found.name);
    this.managerId.set(found.managerId ?? null);
    this.isAuthenticated.set(true);
    this.isAuthorized.set(true);
    this.denialCode.set(null);
    this.denialReason.set(null);
  }
}
