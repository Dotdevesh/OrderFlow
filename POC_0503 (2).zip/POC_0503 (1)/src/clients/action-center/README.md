# Action Center (Angular 20)

Human-in-the-loop UI for OrderFlow. Validators (Manager / Reportee) review Document-Intelligence
extractions next to the source PDF and submit, which **resumes** the Durable orchestration.

## Run

```bash
npm install
npm start           # http://localhost:4200  (proxies to Order API at http://localhost:5080)
```

## Features

- **Inbox** with scopes: *My Tasks*, *Pending Pool*, and *Team* (managers only).
- Live **SLA countdown** per task, priority badges, low-confidence highlighting.
- **Validation workspace**: PDF (left) + editable entity form & line items (right).
- **Manager**: assign, delegate. **Reportee**: claim pending, validate, submit.
- Realtime task updates via **SignalR**.

## Auth

- **Local dev**: `environment.devAuth` injects `X-Debug-UserId` / `X-Debug-Role` headers consumed
  by the API's `DevAuthenticationHandler`. Flip `role` to `Reportee` to test that flow.
- **Production**: replace the dev interceptor with MSAL (Entra ID) and a Bearer-token interceptor.

> Configure API/hub URLs in `src/environments/environment.ts`.
