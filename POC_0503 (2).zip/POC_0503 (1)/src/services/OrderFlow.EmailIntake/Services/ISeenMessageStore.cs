using System.Collections.Concurrent;

namespace OrderFlow.EmailIntake.Services;

/// <summary>De-duplicates Graph notifications by message id. Production impl uses Azure Table with TTL.</summary>
public interface ISeenMessageStore
{
    /// <summary>Returns true if this message id was not seen before (and records it).</summary>
    Task<bool> TryMarkSeenAsync(string mailbox, string messageId, CancellationToken ct = default);
}

public sealed class InMemorySeenMessageStore : ISeenMessageStore
{
    private readonly ConcurrentDictionary<string, DateTimeOffset> _seen = new();

    public Task<bool> TryMarkSeenAsync(string mailbox, string messageId, CancellationToken ct = default)
    {
        var key = $"{mailbox}|{messageId}";
        var added = _seen.TryAdd(key, DateTimeOffset.UtcNow);
        return Task.FromResult(added);
    }
}
