using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.EmailIntake.Services;

/// <summary>
/// Records inbound messages in the Order API's Intake Ledger (Received -> Published) and queries
/// stale entries so no email is ever silently lost if Service Bus or an orchestrator fails downstream.
/// </summary>
public interface IIntakeLedgerClient
{
    Task RecordReceivedAsync(RecordIntakeRequest request, CancellationToken ct = default);
    Task MarkPublishedAsync(string graphMessageId, CancellationToken ct = default);
    Task<IReadOnlyList<IntakeLedgerEntry>> GetStaleAsync(int olderThanMinutes = 5, CancellationToken ct = default);
}

public sealed class HttpIntakeLedgerClient(
    HttpClient http,
    IConfiguration cfg,
    ILogger<HttpIntakeLedgerClient> logger) : IIntakeLedgerClient
{
    private bool Enabled => !string.IsNullOrWhiteSpace(cfg["OrderApi:BaseUrl"]);

    public async Task RecordReceivedAsync(RecordIntakeRequest request, CancellationToken ct = default)
    {
        if (!Enabled) return;
        try
        {
            using var res = await http.PostAsJsonAsync("/internal/intake", request, ct);
            res.EnsureSuccessStatusCode();
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not record intake ledger entry for {MessageId}; continuing Service Bus publish.", request.GraphMessageId);
        }
    }

    public async Task MarkPublishedAsync(string graphMessageId, CancellationToken ct = default)
    {
        if (!Enabled) return;
        try
        {
            using var res = await http.PostAsJsonAsync("/internal/intake/status",
                new UpdateIntakeStatusRequest(graphMessageId, IntakeStatus.Published), ct);
            res.EnsureSuccessStatusCode();
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not mark intake ledger entry Published for {MessageId}.", graphMessageId);
        }
    }

    public async Task<IReadOnlyList<IntakeLedgerEntry>> GetStaleAsync(int olderThanMinutes = 5, CancellationToken ct = default)
    {
        if (!Enabled) return [];
        try
        {
            var entries = await http.GetFromJsonAsync<List<IntakeLedgerEntry>>(
                $"/internal/intake/stale?olderThanMinutes={olderThanMinutes}", ct);
            return entries ?? [];
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not query stale intake ledger entries.");
            return [];
        }
    }
}
