using Microsoft.Extensions.Configuration;
using OrderFlow.Domain;

namespace OrderFlow.EmailIntake.Services;

public sealed record ResolvedCustomer(string CustomerId, Priority Priority);

/// <summary>Resolves the owning customer and processing priority from an inbound email's sender.</summary>
public interface ICustomerResolver
{
    ResolvedCustomer Resolve(string? senderAddress);
}

/// <summary>
/// Maps sender domains to customers/tiers. Reads optional overrides from configuration
/// (<c>Customers:DomainMap</c>) on top of built-in defaults so onboarding needs no code change.
/// </summary>
public sealed class CustomerResolver(IConfiguration cfg) : ICustomerResolver
{
    private static readonly Dictionary<string, (string Id, Priority Priority)> DefaultDomainMap = new(StringComparer.OrdinalIgnoreCase)
    {
        ["acmetitle.com"] = ("acme-title", Priority.High),
        ["fntitle.com"] = ("first-national", Priority.Standard),
        ["acme.com"] = ("acme", Priority.High),
        ["globex.com"] = ("globex", Priority.Standard),
        ["initech.com"] = ("initech", Priority.Low)
    };

    public ResolvedCustomer Resolve(string? senderAddress)
    {
        var domain = senderAddress?.Split('@').LastOrDefault()?.Trim();
        if (!string.IsNullOrEmpty(domain))
        {
            // Check config override first: Customers:DomainMap:<domain> = "<customerId>:<High|Standard|Low>"
            var overrideVal = cfg[$"Customers:DomainMap:{domain}"];
            if (!string.IsNullOrWhiteSpace(overrideVal))
            {
                var parts = overrideVal.Split(':', 2, StringSplitOptions.TrimEntries);
                var p = parts.Length == 2 && Enum.TryParse<Priority>(parts[1], ignoreCase: true, out var parsed)
                    ? parsed
                    : Priority.Standard;
                return new ResolvedCustomer(parts[0], p);
            }

            if (DefaultDomainMap.TryGetValue(domain, out var hit))
                return new ResolvedCustomer(hit.Id, hit.Priority);
        }

        // Unknown sender -> triage queue at lowest priority.
        return new ResolvedCustomer("triage", Priority.Low);
    }
}
