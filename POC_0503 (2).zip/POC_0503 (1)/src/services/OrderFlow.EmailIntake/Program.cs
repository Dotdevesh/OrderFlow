using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.BuildingBlocks.Health;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.EmailIntake.Services;
using OrderFlow.Observability;

var builder = FunctionsApplication.CreateBuilder(args);
builder.ConfigureFunctionsWebApplication();

var cfg = builder.Configuration;

// Traces, metrics, and logs through one OpenTelemetry pipeline.
builder.AddOrderFlowObservability("EmailIntake");

// Service Bus: endpoint plus a token credential, or a connection string, whichever is configured.
builder.Services.AddOrderFlowServiceBusClient(cfg);

// Service-to-service authentication via Entra Managed Identity / IdentityApi service token.
builder.Services.Configure<IdentityClientOptions>(opts =>
{
    cfg.GetSection(IdentityClientOptions.Section).Bind(opts);
    opts.ServiceName = "EmailIntake";
    if (string.IsNullOrWhiteSpace(opts.FallbackInternalApiKey))
        opts.FallbackInternalApiKey = cfg["OrderApi:InternalApiKey"];
});
builder.Services.AddTransient<ServiceToServiceBearerHandler>();

builder.Services.AddHttpClient<IIntakeLedgerClient, HttpIntakeLedgerClient>(c =>
{
    c.BaseAddress = new Uri(cfg["OrderApi:BaseUrl"] ?? "http://localhost:5080");
    c.Timeout = TimeSpan.FromSeconds(3); // keep Graph webhook fast
})
.AddHttpMessageHandler<ServiceToServiceBearerHandler>()
.AddHttpMessageHandler<CorrelationIdPropagationHandler>();

builder.Services.AddSingleton<IEventPublisher, ServiceBusEventPublisher>();
builder.Services.AddSingleton<ICustomerResolver, CustomerResolver>();
builder.Services.AddSingleton<ISeenMessageStore, InMemorySeenMessageStore>();

var health = builder.Services.AddOrderFlowHealthChecks("EmailIntake");
health.AddServiceBus();
if (!string.IsNullOrWhiteSpace(cfg["OrderApi:BaseUrl"]))
    health.AddHttpDependency("order-api", cfg["OrderApi:BaseUrl"]!);

builder.Build().Run();
