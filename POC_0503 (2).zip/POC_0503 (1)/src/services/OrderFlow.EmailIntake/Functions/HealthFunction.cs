using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using OrderFlow.BuildingBlocks.Health;

namespace OrderFlow.EmailIntake.Functions;

/// <summary>
/// Health contract for this Function app. The HTTP route prefix makes these
/// <c>/api/health/live</c> and <c>/api/health/ready</c>.
/// </summary>
public sealed class HealthFunction(HealthCheckService health)
{
    private const string ServiceName = "EmailIntake";

    [Function("HealthLive")]
    public async Task<IActionResult> Live(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "health/live")] HttpRequest req,
        CancellationToken ct)
    {
        var (payload, statusCode) = await OrderFlowHealthChecks.EvaluateAsync(health, ServiceName, HealthTags.Live, ct);
        return new JsonResult(payload) { StatusCode = statusCode };
    }

    [Function("HealthReady")]
    public async Task<IActionResult> Ready(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "health/ready")] HttpRequest req,
        CancellationToken ct)
    {
        var (payload, statusCode) = await OrderFlowHealthChecks.EvaluateAsync(health, ServiceName, HealthTags.Ready, ct);
        return new JsonResult(payload) { StatusCode = statusCode };
    }
}
