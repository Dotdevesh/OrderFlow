using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.Contracts;
using OrderFlow.EmailIntake.Services;

namespace OrderFlow.EmailIntake.Functions;

/// <summary>
/// Renews Microsoft Graph mail subscriptions before they expire and runs stale-intake
/// reconciliation: any message stuck in Received/Published past the threshold is safely
/// re-published (Service Bus dedup + Orchestrator deterministic instance id make this idempotent).
/// </summary>
public sealed class SubscriptionRenewalFunction(
    IIntakeLedgerClient ledger,
    IEventPublisher publisher,
    ILogger<SubscriptionRenewalFunction> logger)
{
    [Function("SubscriptionRenewal")]
    public async Task Run([TimerTrigger("0 */30 * * * *")] TimerInfo timer, CancellationToken ct)
    {
        logger.LogInformation("Subscription renewal & reconciliation tick at {Now}; next due {Next}",
            DateTimeOffset.UtcNow, timer.ScheduleStatus?.Next);

        var stale = await ledger.GetStaleAsync(olderThanMinutes: 5, ct);
        if (stale.Count == 0) return;

        logger.LogWarning("Reconciling {Count} stale intake ledger entries", stale.Count);
        foreach (var entry in stale)
        {
            var customerId = entry.CustomerId ?? "triage";
            var corrId = entry.CorrelationId == Guid.Empty ? Guid.NewGuid() : entry.CorrelationId;
            var evt = new OrderReceived(
                corrId,
                entry.GraphMessageId,
                entry.Mailbox,
                customerId,
                entry.Priority,
                SenderAddress: null,
                Subject: "[Reconciled] Inbound order",
                entry.ReceivedAtUtc);

            await publisher.PublishAsync(
                evt, entry.GraphMessageId, corrId, customerId, entry.Priority,
                sessionId: customerId, ct);
            await ledger.MarkPublishedAsync(entry.GraphMessageId, ct);
        }
    }
}
