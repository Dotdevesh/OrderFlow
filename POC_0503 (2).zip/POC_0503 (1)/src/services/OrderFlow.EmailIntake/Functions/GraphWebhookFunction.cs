using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrderFlow.Contracts;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.EmailIntake.Services;

namespace OrderFlow.EmailIntake.Functions;

/// <summary>
/// Receives Microsoft Graph change notifications for new mail. Handles the subscription validation
/// handshake, verifies clientState, de-dupes, resolves customer+priority, and publishes
/// <see cref="OrderReceived"/> to Service Bus. Kept fast to satisfy Graph's ack window.
/// </summary>
public sealed class GraphWebhookFunction(
    IEventPublisher publisher,
    ICustomerResolver resolver,
    ISeenMessageStore seen,
    IIntakeLedgerClient ledger,
    IConfiguration cfg,
    ILogger<GraphWebhookFunction> logger)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    [Function("GraphWebhook")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "graph/webhook")] HttpRequest req,
        CancellationToken ct)
    {
        // 1) Subscription validation handshake — echo the token as text/plain.
        if (req.Query.TryGetValue("validationToken", out var token))
        {
            logger.LogInformation("Graph subscription validation handshake");
            return new ContentResult { Content = token!, ContentType = "text/plain", StatusCode = StatusCodes.Status200OK };
        }

        using var reader = new StreamReader(req.Body);
        var body = await reader.ReadToEndAsync(ct);
        var notifications = JsonSerializer.Deserialize<ChangeNotificationCollection>(body, Json);
        if (notifications?.Value is null || notifications.Value.Count == 0)
            return new OkResult();

        var expectedClientState = cfg["Graph:ClientState"];
        var mailbox = cfg["Graph:Mailboxes"]?.Split(',').FirstOrDefault()?.Trim() ?? "orders@contoso.com";

        foreach (var n in notifications.Value)
        {
            // 2) Anti-spoofing: verify the clientState we set when creating the subscription.
            if (!string.IsNullOrEmpty(expectedClientState) && n.ClientState != expectedClientState)
            {
                logger.LogWarning("Rejected notification with invalid clientState");
                continue;
            }

            var messageId = n.ResourceData?.Id;
            if (string.IsNullOrEmpty(messageId)) continue;

            // 3) De-dup.
            if (!await seen.TryMarkSeenAsync(mailbox, messageId, ct))
            {
                logger.LogInformation("Duplicate notification for message {MessageId} ignored", messageId);
                continue;
            }

            // 4) Resolve customer + priority. Sender is enriched later by FetchEmail; use hint if present.
            var sender = n.ResourceData?.SenderAddress;
            var resolved = resolver.Resolve(sender);
            var correlationId = Guid.NewGuid();

            // 5) Durability: record Received in the intake ledger before publishing.
            await ledger.RecordReceivedAsync(
                new RecordIntakeRequest(messageId, mailbox, resolved.CustomerId, resolved.Priority, correlationId), ct);

            var evt = new OrderReceived(
                correlationId, messageId, mailbox, resolved.CustomerId, resolved.Priority,
                sender, n.ResourceData?.Subject, DateTimeOffset.UtcNow);

            // 6) Publish (dedup by Graph message id; routed by priority property; session per customer).
            await publisher.PublishAsync(evt, messageId, correlationId, resolved.CustomerId,
                resolved.Priority, sessionId: resolved.CustomerId, ct);
            await ledger.MarkPublishedAsync(messageId, ct);

            logger.LogInformation("Published OrderReceived corr={Corr} customer={Customer} priority={Priority}",
                correlationId, resolved.CustomerId, resolved.Priority);
        }

        // 6) Ack fast.
        return new AcceptedResult();
    }
}

// Minimal notification contracts (subset of the Graph change notification schema).
public sealed class ChangeNotificationCollection
{
    public List<ChangeNotification>? Value { get; set; }
}

public sealed class ChangeNotification
{
    public string? SubscriptionId { get; set; }
    public string? ClientState { get; set; }
    public string? ChangeType { get; set; }
    public string? Resource { get; set; }
    public ResourceData? ResourceData { get; set; }
}

public sealed class ResourceData
{
    public string? Id { get; set; }
    public string? Subject { get; set; }
    public string? SenderAddress { get; set; }
}
