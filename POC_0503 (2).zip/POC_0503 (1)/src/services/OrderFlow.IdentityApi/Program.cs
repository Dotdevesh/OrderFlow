using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.BuildingBlocks.Health;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.Contracts;
using OrderFlow.IdentityApi.Data;
using OrderFlow.IdentityApi.Services;
using OrderFlow.Observability;

namespace OrderFlow.IdentityApi;

/// <summary>Entry point and <c>WebApplicationFactory&lt;IdentityApiMarker&gt;</c> anchor for <c>OrderFlow.IdentityApi</c>.</summary>
public sealed class IdentityApiMarker
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        var cfg = builder.Configuration;

        // ---------- Telemetry: traces, metrics, and logs through one OpenTelemetry pipeline ----------
        builder.AddOrderFlowObservability("IdentityApi");
        builder.Services.AddOrderFlowAzureCredentials();

        // ---------- Persistence (isolated 'identity' schema in OrderFlow SQL DB) ----------
        builder.Services.AddDbContext<IdentityDbContext>(o =>
            o.UseSqlServer(cfg.GetConnectionString("Sql")
                ?? "Server=(localdb)\\mssqllocaldb;Database=OrderFlow;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=true",
                sql => sql.EnableRetryOnFailure(maxRetryCount: 6, maxRetryDelay: TimeSpan.FromSeconds(10), errorNumbersToAdd: null)));

        builder.Services.AddOptions<IdentityServiceOptions>()
            .Configure<IConfiguration>((opts, config) => config.GetSection(IdentityServiceOptions.Section).Bind(opts));

        builder.Services.AddSingleton(sp =>
        {
            var opts = sp.GetRequiredService<IOptions<IdentityServiceOptions>>().Value;
            return new InternalTokenService(opts.JwtSigningKey, opts.Issuer);
        });
        builder.Services.AddScoped<IIdentityDirectoryService, IdentityDirectoryService>();

        // ---------- Authentication: Entra JWT + Internal JWT + Windows Negotiate SSO (+ Dev locally) ----------
        var entraAuthority = cfg["Entra:Authority"];

        var authBuilder = builder.Services.AddAuthentication(options =>
        {
            options.DefaultScheme = "SmartIdentityScheme";
            options.DefaultChallengeScheme = "SmartIdentityScheme";
        })
        .AddPolicyScheme("SmartIdentityScheme", "Routes Entra JWT, Internal JWT, or Local Dev Auth", options =>
        {
            options.ForwardDefaultSelector = ctx =>
            {
                var liveCfg = ctx.RequestServices.GetRequiredService<IConfiguration>();
                var liveEnv = ctx.RequestServices.GetRequiredService<IHostEnvironment>();
                var liveOpts = ctx.RequestServices.GetRequiredService<IOptions<IdentityServiceOptions>>().Value;
                var liveEntraAuthority = liveCfg["Entra:Authority"];

                var authHeader = ctx.Request.Headers.Authorization.FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                {
                    var rawToken = authHeader["Bearer ".Length..].Trim();
                    var handler = new Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler();
                    if (handler.CanReadToken(rawToken))
                    {
                        var jwt = handler.ReadJsonWebToken(rawToken);
                        if (string.Equals(jwt.Issuer, liveOpts.Issuer, StringComparison.OrdinalIgnoreCase))
                            return "InternalJwt";
                    }
                    if (!string.IsNullOrWhiteSpace(liveEntraAuthority))
                        return JwtBearerDefaults.AuthenticationScheme;

                    return "InternalJwt";
                }

                if (liveEnv.IsDevelopment()
                    && string.IsNullOrWhiteSpace(liveEntraAuthority)
                    && string.IsNullOrWhiteSpace(liveOpts.ServiceSharedSecret))
                {
                    return "DevIdentity";
                }

                return !string.IsNullOrWhiteSpace(liveEntraAuthority) ? JwtBearerDefaults.AuthenticationScheme : "InternalJwt";
            };
        })
        .AddJwtBearer("InternalJwt");

        if (cfg.GetValue("IdentityService:EnableWindowsNegotiate", true))
        {
            authBuilder.AddNegotiate(); // Windows Integrated Authentication (Kerberos / NTLM domain credentials)
        }

        builder.Services.AddOptions<JwtBearerOptions>("InternalJwt")
            .Configure<IOptions<IdentityServiceOptions>>((options, idOpts) =>
            {
                var settings = idOpts.Value;
                options.MapInboundClaims = false;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = settings.Issuer,
                    ValidateAudience = false,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(settings.JwtSigningKey)),
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(1),
                    RoleClaimType = "roles",
                    NameClaimType = "name"
                };
            });

        if (!string.IsNullOrWhiteSpace(entraAuthority))
        {
            authBuilder.AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
            {
                options.Authority = entraAuthority;
                options.Audience = cfg["Entra:Audience"];
                options.MapInboundClaims = false;
                options.TokenValidationParameters.RoleClaimType = "roles";
                options.TokenValidationParameters.NameClaimType = "name";
            });
        }
        else if (builder.Environment.IsDevelopment())
        {
            authBuilder.AddScheme<AuthenticationSchemeOptions, DevIdentityAuthHandler>("DevIdentity", _ => { });
        }
        else
        {
            throw new InvalidOperationException("Entra:Authority is required outside Development.");
        }

        builder.Services.AddAuthorizationBuilder()
            .AddPolicy("InternalService", p => p.RequireAssertion(ctx =>
            {
                var http = ctx.Resource as HttpContext;
                var liveCfg = http?.RequestServices.GetService<IConfiguration>();
                var liveEnv = http?.RequestServices.GetService<IHostEnvironment>();
                var sharedSecret = liveCfg?["IdentityService:ServiceSharedSecret"];
                var apiKey = liveCfg?["InternalAuth:ApiKey"];
                var liveEntra = liveCfg?["Entra:Authority"];

                if (http is not null && !string.IsNullOrWhiteSpace(apiKey)
                    && http.Request.Headers.TryGetValue("X-Internal-ApiKey", out var header)
                    && string.Equals(header.FirstOrDefault(), apiKey, StringComparison.Ordinal))
                {
                    return true;
                }

                if (ctx.User.Identity?.IsAuthenticated == true
                    && (ctx.User.IsInRole(OrderFlowIdentityConstants.RoleInternalService)
                        || ctx.User.IsInRole(OrderFlowIdentityConstants.RoleDirectorySync)))
                {
                    return true;
                }

                return liveEnv?.IsDevelopment() == true
                       && string.IsNullOrWhiteSpace(sharedSecret)
                       && string.IsNullOrWhiteSpace(apiKey)
                       && string.IsNullOrWhiteSpace(liveEntra);
            }));

        builder.Services.AddProblemDetails();
        builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
            .WithOrigins(cfg.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:4200"])
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials()));

        builder.Services.AddOrderFlowHealthChecks("IdentityApi")
            .AddDbContextCheck<IdentityDbContext>("sql", tags: [HealthTags.Ready]);

        var app = builder.Build();

        if (!app.Environment.IsDevelopment())
            app.UseExceptionHandler();
        app.UseOrderFlowCorrelationId();
        app.UseCors();
        app.UseAuthentication();
        app.UseAuthorization();

        app.MapOrderFlowHealthEndpoints("IdentityApi");

        // ---------- 1) User Authentication & Current Principal (/api/auth/me) ----------
        app.MapGet("/api/auth/me", async (
            ClaimsPrincipal principal,
            IIdentityDirectoryService directory,
            CancellationToken ct) =>
        {
            if (principal.Identity?.IsAuthenticated != true)
                return Results.Unauthorized();

            var req = ExtractIntrospectionRequest(principal, "EntraOrInternalJwt");
            var evaluated = await directory.EvaluateUserAsync(req, ct);
            return evaluated.IsAuthorized
                ? Results.Ok(evaluated)
                : Results.Json(evaluated, statusCode: StatusCodes.Status403Forbidden);
        }).RequireAuthorization().WithTags("Auth");

        // ---------- 2) Windows Credentials SSO Login (/api/auth/windows-sso) ----------
        app.MapGet("/api/auth/windows-sso", async (
            HttpContext http,
            IAuthenticationSchemeProvider schemes,
            IIdentityDirectoryService directory,
            InternalTokenService tokens,
            IOptions<IdentityServiceOptions> opts,
            IHostEnvironment env,
            IConfiguration liveCfg,
            CancellationToken ct) =>
        {
            string? windowsIdentityName = null;
            string? oid = null;
            string? upn = null;

            if (env.IsDevelopment() && http.Request.Headers.TryGetValue("X-Debug-WindowsUser", out var debugWin))
            {
                windowsIdentityName = debugWin.FirstOrDefault();
            }
            else
            {
                var hasNegotiate = await schemes.GetSchemeAsync(NegotiateDefaults.AuthenticationScheme) is not null;
                var authResult = hasNegotiate
                    ? await http.AuthenticateAsync(NegotiateDefaults.AuthenticationScheme)
                    : AuthenticateResult.NoResult();

                if (authResult.Succeeded && authResult.Principal?.Identity?.IsAuthenticated == true)
                {
                    windowsIdentityName = authResult.Principal.Identity.Name;
                    upn = authResult.Principal.FindFirstValue(ClaimTypes.Upn)
                          ?? (windowsIdentityName?.Contains('@') == true ? windowsIdentityName : null);
                    oid = authResult.Principal.FindFirstValue(OrderFlowIdentityConstants.ClaimObjectId);
                }
                else if (env.IsDevelopment() && string.IsNullOrWhiteSpace(liveCfg["Entra:Authority"]))
                {
                    var devId = http.Request.Headers["X-Debug-UserId"].FirstOrDefault() ?? "mgr-1";
                    oid = devId;
                    windowsIdentityName = devId == "mgr-1" ? "CONTOSO\\morgan" : $"CONTOSO\\{devId}";
                }
                else if (hasNegotiate)
                {
                    await http.ChallengeAsync(NegotiateDefaults.AuthenticationScheme);
                    return Results.Empty;
                }
                else
                {
                    return Results.Unauthorized();
                }
            }

            var principalDto = await directory.EvaluateUserAsync(
                new IntrospectUserRequest(
                    ObjectId: oid,
                    Upn: upn,
                    WindowsAccountName: windowsIdentityName,
                    DisplayName: windowsIdentityName,
                    AuthMethod: "WindowsNegotiate"),
                ct);

            if (!principalDto.IsAuthorized)
            {
                return Results.Json(
                    new WindowsSsoExchangeResponse(true, false, null, null, principalDto),
                    statusCode: StatusCodes.Status403Forbidden);
            }

            var (jwt, expiresAt) = tokens.CreateUserToken(
                principalDto,
                opts.Value.UserTokenAudience,
                TimeSpan.FromMinutes(opts.Value.UserTokenLifetimeMinutes));

            return Results.Ok(new WindowsSsoExchangeResponse(true, true, jwt, expiresAt, principalDto));
        }).WithTags("Auth");

        // ---------- 3) Microservice User Introspection (/api/auth/introspect) ----------
        app.MapPost("/api/auth/introspect", async (
            IntrospectUserRequest req,
            IIdentityDirectoryService directory,
            CancellationToken ct) =>
        {
            var evaluated = await directory.EvaluateUserAsync(req, ct);
            return Results.Ok(evaluated);
        }).RequireAuthorization("InternalService").WithTags("InternalAuth");

        // ---------- 4) Service-to-Service Token Issuance & Introspection ----------
        app.MapPost("/api/auth/service-token", (
            ServiceTokenRequest req,
            ClaimsPrincipal caller,
            InternalTokenService tokens,
            IOptions<IdentityServiceOptions> opts) =>
        {
            var settings = opts.Value;

            var secretValid = !string.IsNullOrWhiteSpace(settings.ServiceSharedSecret)
                              && string.Equals(req.ClientSecret, settings.ServiceSharedSecret, StringComparison.Ordinal);
            var entraAppValid = caller.Identity?.IsAuthenticated == true
                                && (caller.IsInRole(OrderFlowIdentityConstants.RoleInternalService)
                                    || caller.IsInRole(OrderFlowIdentityConstants.RoleDirectorySync));

            if (!secretValid && !entraAppValid)
                return Results.Unauthorized();

            if (!settings.AllowedServices.Contains(req.ServiceName, StringComparer.OrdinalIgnoreCase))
                return Results.Json(new { error = $"Service '{req.ServiceName}' is not registered." }, statusCode: StatusCodes.Status403Forbidden);

            var roles = new List<string> { OrderFlowIdentityConstants.RoleInternalService };
            if (string.Equals(req.ServiceName, "IdentitySync", StringComparison.OrdinalIgnoreCase))
                roles.Add(OrderFlowIdentityConstants.RoleDirectorySync);

            var (jwt, expiresAt) = tokens.CreateServiceToken(
                req.ServiceName,
                string.IsNullOrWhiteSpace(req.TargetAudience) ? "api://orderflow-internal" : req.TargetAudience,
                roles,
                TimeSpan.FromMinutes(settings.ServiceTokenLifetimeMinutes));

            return Results.Ok(new ServiceTokenResponse(jwt, expiresAt, req.ServiceName, roles));
        }).WithTags("ServiceAuth");

        app.MapPost("/api/auth/introspect-service", async (
            IntrospectServiceRequest req,
            InternalTokenService tokens) =>
        {
            if (string.IsNullOrWhiteSpace(req.AccessToken))
                return Results.Ok(new IntrospectServiceResponse(false, null, null, [], "Missing token"));

            var validation = await tokens.ValidateAsync(req.AccessToken, req.ExpectedAudience);
            if (!validation.IsValid || validation.ClaimsIdentity is null)
            {
                return Results.Ok(new IntrospectServiceResponse(
                    false, null, null, [], validation.Exception?.Message ?? "Invalid service token"));
            }

            var identity = validation.ClaimsIdentity;
            var kind = identity.FindFirst(OrderFlowIdentityConstants.ClaimTokenKind)?.Value;
            if (!string.Equals(kind, OrderFlowIdentityConstants.TokenKindService, StringComparison.Ordinal))
                return Results.Ok(new IntrospectServiceResponse(false, null, null, [], "Token is not a service token"));

            var serviceName = identity.FindFirst(OrderFlowIdentityConstants.ClaimServiceName)?.Value;
            var sub = identity.FindFirst("sub")?.Value;
            var roles = identity.FindAll("roles").Select(c => c.Value).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            return Results.Ok(new IntrospectServiceResponse(true, sub, serviceName, roles));
        }).WithTags("ServiceAuth");

        // ---------- 5) Directory & Sync Endpoints ----------
        app.MapGet("/api/users", async (IIdentityDirectoryService directory, CancellationToken ct) =>
            Results.Ok(await directory.GetAuthorizedUsersAsync(ct)))
            .RequireAuthorization()
            .WithTags("Directory");

        var syncGroup = app.MapGroup("/internal/sync")
            .RequireAuthorization("InternalService")
            .WithTags("DirectorySync");

        syncGroup.MapPost("/directory", async (
            DirectorySyncBatchRequest batch,
            IIdentityDirectoryService directory,
            CancellationToken ct) =>
        {
            var result = await directory.ApplyDirectorySyncAsync(batch, ct);
            return Results.Ok(result);
        });

        syncGroup.MapGet("/groups", async (IIdentityDirectoryService directory, CancellationToken ct) =>
            Results.Ok(await directory.GetGroupStatesAsync(ct)));

        syncGroup.MapPost("/subscriptions", async (
            UpdateWebhookSubscriptionRequest req,
            IIdentityDirectoryService directory,
            CancellationToken ct) =>
        {
            await directory.UpdateWebhookSubscriptionAsync(req, ct);
            return Results.Ok();
        });

        using (var scope = app.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<IdentityDbContext>();
            try
            {
                IdentityDbInitializer.EnsureInitializedAsync(db, seedDevUsers: app.Environment.IsDevelopment())
                    .GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                app.Logger.LogWarning(ex, "Identity DB initialization skipped (SQL not reachable at startup).");
            }
        }

        app.Run();
    }

    private static IntrospectUserRequest ExtractIntrospectionRequest(ClaimsPrincipal principal, string authMethod)
    {
        var oid = principal.FindFirstValue(OrderFlowIdentityConstants.ClaimObjectId)
                  ?? principal.FindFirstValue("http://schemas.microsoft.com/identity/claims/objectidentifier")
                  ?? principal.FindFirstValue(ClaimTypes.NameIdentifier)
                  ?? principal.FindFirstValue("sub");

        var upn = principal.FindFirstValue(OrderFlowIdentityConstants.ClaimUpn)
                  ?? principal.FindFirstValue(ClaimTypes.Upn)
                  ?? principal.FindFirstValue("upn")
                  ?? principal.FindFirstValue("email")
                  ?? principal.FindFirstValue(ClaimTypes.Email);

        var name = principal.FindFirstValue("name") ?? principal.Identity?.Name;
        var win = principal.FindFirstValue(OrderFlowIdentityConstants.ClaimWindowsAccount);

        var roles = principal.FindAll("roles").Select(c => c.Value)
            .Concat(principal.FindAll(ClaimTypes.Role).Select(c => c.Value))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var groups = principal.FindAll(OrderFlowIdentityConstants.ClaimGroupId).Select(c => c.Value)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        return new IntrospectUserRequest(oid, upn, win, name, roles, groups, authMethod);
    }
}

public sealed class DevIdentityAuthHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var userId = Request.Headers["X-Debug-UserId"].FirstOrDefault() ?? "mgr-1";
        var role = Request.Headers["X-Debug-Role"].FirstOrDefault() ?? OrderFlowIdentityConstants.RoleManager;
        var name = Request.Headers["X-Debug-Name"].FirstOrDefault() ?? userId;

        var claims = new List<Claim>
        {
            new(OrderFlowIdentityConstants.ClaimObjectId, userId),
            new(ClaimTypes.NameIdentifier, userId),
            new("name", name),
            new("roles", role),
            new(ClaimTypes.Role, role)
        };

        var identity = new ClaimsIdentity(claims, Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme.Name)));
    }
}
