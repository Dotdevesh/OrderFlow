using Microsoft.EntityFrameworkCore;
using OrderFlow.Domain;
using OrderFlow.IdentityApi.Entities;

namespace OrderFlow.IdentityApi.Data;

/// <summary>
/// Isolated EF Core DbContext for <c>OrderFlow.IdentityApi</c>.
/// Stores authoritative AD Group, App Role, and User sync tables in the <c>identity</c> schema
/// and projects authorized validators into <c>dbo.Users</c> (<see cref="AppUser"/>).
/// </summary>
public sealed class IdentityDbContext(DbContextOptions<IdentityDbContext> options) : DbContext(options)
{
    public DbSet<DirectoryUser> DirectoryUsers => Set<DirectoryUser>();
    public DbSet<DirectoryGroup> DirectoryGroups => Set<DirectoryGroup>();
    public DbSet<UserGroupMembership> UserGroupMemberships => Set<UserGroupMembership>();
    public DbSet<UserAppRoleAssignment> UserAppRoleAssignments => Set<UserAppRoleAssignment>();
    public DbSet<DirectorySyncAudit> SyncAudits => Set<DirectorySyncAudit>();

    /// <summary>Shared validator projection read by <c>OrderFlow.OrderApi</c> for team/inbox queries.</summary>
    public DbSet<AppUser> AppUsers => Set<AppUser>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.HasDefaultSchema("identity");

        b.Entity<DirectoryUser>(e =>
        {
            e.ToTable("DirectoryUsers", "identity");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasMaxLength(128);
            e.Property(x => x.DisplayName).HasMaxLength(256).IsRequired();
            e.Property(x => x.Upn).HasMaxLength(256);
            e.Property(x => x.Email).HasMaxLength(256);
            e.Property(x => x.WindowsAccountName).HasMaxLength(256);
            e.Property(x => x.ManagerId).HasMaxLength(128);
            e.Property(x => x.EffectiveRole).HasConversion<int?>();
            e.Ignore(x => x.IsAuthorized);
            e.HasIndex(x => x.Upn);
            e.HasIndex(x => x.WindowsAccountName);
            e.HasIndex(x => x.ManagerId);
            e.HasMany(x => x.GroupMemberships).WithOne().HasForeignKey(m => m.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.AppRoleAssignments).WithOne().HasForeignKey(r => r.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<DirectoryGroup>(e =>
        {
            e.ToTable("DirectoryGroups", "identity");
            e.HasKey(x => x.GroupId);
            e.Property(x => x.GroupId).HasMaxLength(128);
            e.Property(x => x.DisplayName).HasMaxLength(256).IsRequired();
            e.Property(x => x.MappedRole).HasConversion<int?>();
            e.Property(x => x.DeltaLink).HasMaxLength(2048);
            e.Property(x => x.WebhookSubscriptionId).HasMaxLength(256);
        });

        b.Entity<UserGroupMembership>(e =>
        {
            e.ToTable("UserGroupMemberships", "identity");
            e.HasKey(x => new { x.UserId, x.GroupId });
            e.Property(x => x.UserId).HasMaxLength(128);
            e.Property(x => x.GroupId).HasMaxLength(128);
            e.HasIndex(x => x.GroupId);
        });

        b.Entity<UserAppRoleAssignment>(e =>
        {
            e.ToTable("UserAppRoleAssignments", "identity");
            e.HasKey(x => x.AssignmentId);
            e.Property(x => x.AssignmentId).HasMaxLength(128);
            e.Property(x => x.UserId).HasMaxLength(128).IsRequired();
            e.Property(x => x.AppRoleId).HasMaxLength(128).IsRequired();
            e.Property(x => x.RoleName).HasMaxLength(128).IsRequired();
            e.HasIndex(x => x.UserId);
        });

        b.Entity<DirectorySyncAudit>(e =>
        {
            e.ToTable("DirectorySyncAudits", "identity");
            e.HasKey(x => x.Id);
            e.Property(x => x.Source).HasMaxLength(128).IsRequired();
            e.HasIndex(x => x.OccurredAtUtc);
        });

        b.Entity<AppUser>(e =>
        {
            e.ToTable("Users", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasMaxLength(128);
            e.Property(x => x.DisplayName).HasMaxLength(256).IsRequired();
            e.Property(x => x.Email).HasMaxLength(256);
            e.Property(x => x.Upn).HasMaxLength(256);
            e.Property(x => x.WindowsAccountName).HasMaxLength(256);
            e.Property(x => x.Role).HasConversion<int>();
            e.Property(x => x.ManagerId).HasMaxLength(128);
            e.Ignore(x => x.IsManager);
            e.HasIndex(x => x.ManagerId);
        });
    }
}
