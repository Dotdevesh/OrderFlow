using Microsoft.EntityFrameworkCore;
using OrderFlow.Domain;
using OrderFlow.IdentityApi.Entities;

namespace OrderFlow.IdentityApi.Data;

/// <summary>
/// Idempotently creates the <c>identity</c> schema and tables inside the shared OrderFlow SQL database
/// (even when <c>OrderFlowDbContext.EnsureCreatedAsync</c> already created <c>dbo.*</c> tables)
/// and seeds default AD groups + App Roles in Development.
/// </summary>
public static class IdentityDbInitializer
{
    private const string SqlServerBootstrapScript = """
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'identity')
            EXEC(N'CREATE SCHEMA [identity]');

        IF OBJECT_ID(N'[dbo].[Users]', N'U') IS NULL
        BEGIN
            CREATE TABLE [dbo].[Users] (
                [Id] nvarchar(128) NOT NULL CONSTRAINT [PK_Users] PRIMARY KEY,
                [DisplayName] nvarchar(256) NOT NULL,
                [Email] nvarchar(256) NULL,
                [Upn] nvarchar(256) NULL,
                [WindowsAccountName] nvarchar(256) NULL,
                [Role] int NOT NULL,
                [ManagerId] nvarchar(128) NULL,
                [IsActive] bit NOT NULL DEFAULT 1,
                [IsInAuthorizedGroup] bit NOT NULL DEFAULT 1,
                [LastSyncedAtUtc] datetimeoffset NULL
            );
            CREATE INDEX [IX_Users_ManagerId] ON [dbo].[Users] ([ManagerId]);
        END
        ELSE
        BEGIN
            IF COL_LENGTH('dbo.Users', 'Upn') IS NULL
                ALTER TABLE [dbo].[Users] ADD [Upn] nvarchar(256) NULL;
            IF COL_LENGTH('dbo.Users', 'WindowsAccountName') IS NULL
                ALTER TABLE [dbo].[Users] ADD [WindowsAccountName] nvarchar(256) NULL;
            IF COL_LENGTH('dbo.Users', 'IsActive') IS NULL
                ALTER TABLE [dbo].[Users] ADD [IsActive] bit NOT NULL DEFAULT 1;
            IF COL_LENGTH('dbo.Users', 'IsInAuthorizedGroup') IS NULL
                ALTER TABLE [dbo].[Users] ADD [IsInAuthorizedGroup] bit NOT NULL DEFAULT 1;
            IF COL_LENGTH('dbo.Users', 'LastSyncedAtUtc') IS NULL
                ALTER TABLE [dbo].[Users] ADD [LastSyncedAtUtc] datetimeoffset NULL;
        END;

        IF OBJECT_ID(N'[identity].[DirectoryUsers]', N'U') IS NULL
        BEGIN
            CREATE TABLE [identity].[DirectoryUsers] (
                [Id] nvarchar(128) NOT NULL CONSTRAINT [PK_DirectoryUsers] PRIMARY KEY,
                [DisplayName] nvarchar(256) NOT NULL,
                [Upn] nvarchar(256) NULL,
                [Email] nvarchar(256) NULL,
                [WindowsAccountName] nvarchar(256) NULL,
                [ManagerId] nvarchar(128) NULL,
                [AccountEnabled] bit NOT NULL,
                [IsInAuthorizedGroup] bit NOT NULL,
                [EffectiveRole] int NULL,
                [LastSyncedAtUtc] datetimeoffset NOT NULL
            );
            CREATE INDEX [IX_DirectoryUsers_Upn] ON [identity].[DirectoryUsers] ([Upn]);
            CREATE INDEX [IX_DirectoryUsers_WindowsAccountName] ON [identity].[DirectoryUsers] ([WindowsAccountName]);
            CREATE INDEX [IX_DirectoryUsers_ManagerId] ON [identity].[DirectoryUsers] ([ManagerId]);
        END;

        IF OBJECT_ID(N'[identity].[DirectoryGroups]', N'U') IS NULL
        BEGIN
            CREATE TABLE [identity].[DirectoryGroups] (
                [GroupId] nvarchar(128) NOT NULL CONSTRAINT [PK_DirectoryGroups] PRIMARY KEY,
                [DisplayName] nvarchar(256) NOT NULL,
                [IsRequiredAccessGroup] bit NOT NULL,
                [MappedRole] int NULL,
                [DeltaLink] nvarchar(2048) NULL,
                [WebhookSubscriptionId] nvarchar(256) NULL,
                [WebhookExpiresAtUtc] datetimeoffset NULL,
                [LastSyncedAtUtc] datetimeoffset NULL
            );
        END;

        IF OBJECT_ID(N'[identity].[UserGroupMemberships]', N'U') IS NULL
        BEGIN
            CREATE TABLE [identity].[UserGroupMemberships] (
                [UserId] nvarchar(128) NOT NULL,
                [GroupId] nvarchar(128) NOT NULL,
                [SyncedAtUtc] datetimeoffset NOT NULL,
                CONSTRAINT [PK_UserGroupMemberships] PRIMARY KEY ([UserId], [GroupId]),
                CONSTRAINT [FK_UserGroupMemberships_DirectoryUsers] FOREIGN KEY ([UserId]) REFERENCES [identity].[DirectoryUsers]([Id]) ON DELETE CASCADE
            );
            CREATE INDEX [IX_UserGroupMemberships_GroupId] ON [identity].[UserGroupMemberships] ([GroupId]);
        END;

        IF OBJECT_ID(N'[identity].[UserAppRoleAssignments]', N'U') IS NULL
        BEGIN
            CREATE TABLE [identity].[UserAppRoleAssignments] (
                [AssignmentId] nvarchar(128) NOT NULL CONSTRAINT [PK_UserAppRoleAssignments] PRIMARY KEY,
                [UserId] nvarchar(128) NOT NULL,
                [AppRoleId] nvarchar(128) NOT NULL,
                [RoleName] nvarchar(128) NOT NULL,
                [AssignedAtUtc] datetimeoffset NOT NULL,
                CONSTRAINT [FK_UserAppRoleAssignments_DirectoryUsers] FOREIGN KEY ([UserId]) REFERENCES [identity].[DirectoryUsers]([Id]) ON DELETE CASCADE
            );
            CREATE INDEX [IX_UserAppRoleAssignments_UserId] ON [identity].[UserAppRoleAssignments] ([UserId]);
        END;

        IF OBJECT_ID(N'[identity].[DirectorySyncAudits]', N'U') IS NULL
        BEGIN
            CREATE TABLE [identity].[DirectorySyncAudits] (
                [Id] uniqueidentifier NOT NULL CONSTRAINT [PK_DirectorySyncAudits] PRIMARY KEY,
                [Source] nvarchar(128) NOT NULL,
                [UsersUpserted] int NOT NULL,
                [UsersAuthorized] int NOT NULL,
                [UsersRevoked] int NOT NULL,
                [OccurredAtUtc] datetimeoffset NOT NULL
            );
            CREATE INDEX [IX_DirectorySyncAudits_OccurredAtUtc] ON [identity].[DirectorySyncAudits] ([OccurredAtUtc]);
        END;
        """;

    public static async Task EnsureInitializedAsync(
        IdentityDbContext db,
        bool seedDevUsers,
        CancellationToken ct = default)
    {
        if (db.Database.IsRelational())
        {
            await db.Database.EnsureCreatedAsync(ct);
            await db.Database.ExecuteSqlRawAsync(SqlServerBootstrapScript, ct);
        }
        else
        {
            await db.Database.EnsureCreatedAsync(ct);
        }

        if (!seedDevUsers || await db.DirectoryUsers.AnyAsync(ct))
            return;

        var now = DateTimeOffset.UtcNow;

        db.DirectoryGroups.AddRange(
            new DirectoryGroup
            {
                GroupId = "grp-orderflow-access",
                DisplayName = "SG-OrderFlow-ActionCenter-Users",
                IsRequiredAccessGroup = true,
                MappedRole = null,
                LastSyncedAtUtc = now
            },
            new DirectoryGroup
            {
                GroupId = "grp-orderflow-managers",
                DisplayName = "SG-OrderFlow-Managers",
                IsRequiredAccessGroup = true,
                MappedRole = UserRole.Manager,
                LastSyncedAtUtc = now
            },
            new DirectoryGroup
            {
                GroupId = "grp-orderflow-reportees",
                DisplayName = "SG-OrderFlow-Reportees",
                IsRequiredAccessGroup = true,
                MappedRole = UserRole.Reportee,
                LastSyncedAtUtc = now
            });

        db.DirectoryUsers.AddRange(
            new DirectoryUser
            {
                Id = "mgr-1",
                DisplayName = "Morgan (Manager)",
                Upn = "morgan@contoso.com",
                Email = "morgan@contoso.com",
                WindowsAccountName = "CONTOSO\\morgan",
                AccountEnabled = true,
                IsInAuthorizedGroup = true,
                EffectiveRole = UserRole.Manager,
                LastSyncedAtUtc = now
            },
            new DirectoryUser
            {
                Id = "rep-1",
                DisplayName = "Riley (Reportee)",
                Upn = "riley@contoso.com",
                Email = "riley@contoso.com",
                WindowsAccountName = "CONTOSO\\riley",
                ManagerId = "mgr-1",
                AccountEnabled = true,
                IsInAuthorizedGroup = true,
                EffectiveRole = UserRole.Reportee,
                LastSyncedAtUtc = now
            },
            new DirectoryUser
            {
                Id = "rep-2",
                DisplayName = "Jordan (Reportee)",
                Upn = "jordan@contoso.com",
                Email = "jordan@contoso.com",
                WindowsAccountName = "CONTOSO\\jordan",
                ManagerId = "mgr-1",
                AccountEnabled = true,
                IsInAuthorizedGroup = true,
                EffectiveRole = UserRole.Reportee,
                LastSyncedAtUtc = now
            });

        db.UserGroupMemberships.AddRange(
            new UserGroupMembership { UserId = "mgr-1", GroupId = "grp-orderflow-access", SyncedAtUtc = now },
            new UserGroupMembership { UserId = "mgr-1", GroupId = "grp-orderflow-managers", SyncedAtUtc = now },
            new UserGroupMembership { UserId = "rep-1", GroupId = "grp-orderflow-access", SyncedAtUtc = now },
            new UserGroupMembership { UserId = "rep-1", GroupId = "grp-orderflow-reportees", SyncedAtUtc = now },
            new UserGroupMembership { UserId = "rep-2", GroupId = "grp-orderflow-access", SyncedAtUtc = now },
            new UserGroupMembership { UserId = "rep-2", GroupId = "grp-orderflow-reportees", SyncedAtUtc = now });

        db.UserAppRoleAssignments.AddRange(
            new UserAppRoleAssignment { AssignmentId = "seed-role-mgr-1", UserId = "mgr-1", AppRoleId = "approle-manager", RoleName = "Manager", AssignedAtUtc = now },
            new UserAppRoleAssignment { AssignmentId = "seed-role-rep-1", UserId = "rep-1", AppRoleId = "approle-reportee", RoleName = "Reportee", AssignedAtUtc = now },
            new UserAppRoleAssignment { AssignmentId = "seed-role-rep-2", UserId = "rep-2", AppRoleId = "approle-reportee", RoleName = "Reportee", AssignedAtUtc = now });

        if (!await db.AppUsers.AnyAsync(ct))
        {
            db.AppUsers.AddRange(
                new AppUser { Id = "mgr-1", DisplayName = "Morgan (Manager)", Email = "morgan@contoso.com", Upn = "morgan@contoso.com", WindowsAccountName = "CONTOSO\\morgan", Role = UserRole.Manager, IsActive = true, IsInAuthorizedGroup = true, LastSyncedAtUtc = now },
                new AppUser { Id = "rep-1", DisplayName = "Riley (Reportee)", Email = "riley@contoso.com", Upn = "riley@contoso.com", WindowsAccountName = "CONTOSO\\riley", Role = UserRole.Reportee, ManagerId = "mgr-1", IsActive = true, IsInAuthorizedGroup = true, LastSyncedAtUtc = now },
                new AppUser { Id = "rep-2", DisplayName = "Jordan (Reportee)", Email = "jordan@contoso.com", Upn = "jordan@contoso.com", WindowsAccountName = "CONTOSO\\jordan", Role = UserRole.Reportee, ManagerId = "mgr-1", IsActive = true, IsInAuthorizedGroup = true, LastSyncedAtUtc = now });
        }

        await db.SaveChangesAsync(ct);
    }
}
