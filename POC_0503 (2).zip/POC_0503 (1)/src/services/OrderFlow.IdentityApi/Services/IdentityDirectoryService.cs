using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.IdentityApi.Data;
using OrderFlow.IdentityApi.Entities;

namespace OrderFlow.IdentityApi.Services;

public interface IIdentityDirectoryService
{
    Task<AuthenticatedPrincipalDto> EvaluateUserAsync(IntrospectUserRequest request, CancellationToken ct = default);
    Task<DirectorySyncResultDto> ApplyDirectorySyncAsync(DirectorySyncBatchRequest batch, CancellationToken ct = default);
    Task<IReadOnlyList<UserSummaryDto>> GetAuthorizedUsersAsync(CancellationToken ct = default);
    Task<IReadOnlyList<DirectoryGroupStateDto>> GetGroupStatesAsync(CancellationToken ct = default);
    Task UpdateWebhookSubscriptionAsync(UpdateWebhookSubscriptionRequest request, CancellationToken ct = default);
}

/// <summary>
/// Evaluates user AD Group &amp; App Role authorization against the synced SQL database and
/// processes incremental/full directory updates from <c>OrderFlow.IdentitySync</c>.
/// </summary>
public sealed class IdentityDirectoryService(
    IdentityDbContext db,
    IOptions<IdentityServiceOptions> options,
    ILogger<IdentityDirectoryService> logger) : IIdentityDirectoryService
{
    private readonly IdentityServiceOptions _opts = options.Value;

    public async Task<AuthenticatedPrincipalDto> EvaluateUserAsync(IntrospectUserRequest req, CancellationToken ct = default)
    {
        DirectoryUser? user = null;

        if (!string.IsNullOrWhiteSpace(req.ObjectId))
        {
            user = await db.DirectoryUsers
                .AsNoTracking()
                .Include(u => u.GroupMemberships)
                .Include(u => u.AppRoleAssignments)
                .FirstOrDefaultAsync(u => u.Id == req.ObjectId, ct);
        }

        if (user is null && !string.IsNullOrWhiteSpace(req.Upn))
        {
            var normalizedUpn = req.Upn.Trim();
            user = await db.DirectoryUsers
                .AsNoTracking()
                .Include(u => u.GroupMemberships)
                .Include(u => u.AppRoleAssignments)
                .FirstOrDefaultAsync(u =>
                    (u.Upn != null && u.Upn == normalizedUpn) ||
                    (u.Email != null && u.Email == normalizedUpn), ct);
        }

        if (user is null && !string.IsNullOrWhiteSpace(req.WindowsAccountName))
        {
            var win = req.WindowsAccountName.Trim();
            var shortUser = win.Contains('\\') ? win.Split('\\').Last() : win;
            user = await db.DirectoryUsers
                .AsNoTracking()
                .Include(u => u.GroupMemberships)
                .Include(u => u.AppRoleAssignments)
                .FirstOrDefaultAsync(u =>
                    (u.WindowsAccountName != null && u.WindowsAccountName == win) ||
                    (u.Upn != null && u.Upn.StartsWith(shortUser + "@")), ct);
        }

        if (user is null)
        {
            return new AuthenticatedPrincipalDto(
                IsAuthenticated: true,
                IsAuthorized: false,
                DenialCode: "user_not_synced",
                DenialReason: "User is not provisioned in the OrderFlow Identity database (AD group/role sync required).",
                UserId: req.ObjectId,
                Upn: req.Upn,
                Email: req.Upn,
                DisplayName: req.DisplayName ?? req.WindowsAccountName ?? req.Upn,
                Role: null,
                ManagerId: null,
                Groups: [],
                AppRoles: [],
                AuthMethod: req.AuthMethod);
        }

        if (!user.AccountEnabled)
        {
            return BuildDenied(user, "account_disabled", "Entra ID user account is disabled.", req.AuthMethod);
        }

        var groupIds = user.GroupMemberships.Select(m => m.GroupId).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var userGroups = await db.DirectoryGroups.AsNoTracking()
            .Where(g => groupIds.Contains(g.GroupId))
            .ToListAsync(ct);

        var appRoles = user.AppRoleAssignments
            .Select(r => r.RoleName)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var hasRequiredAdGroup = EvaluateAdGroupMembership(userGroups);
        if (!hasRequiredAdGroup)
        {
            return new AuthenticatedPrincipalDto(
                IsAuthenticated: true,
                IsAuthorized: false,
                DenialCode: "missing_ad_group",
                DenialReason: "Logged-in user is not a member of any authorized Entra/AD security group.",
                UserId: user.Id,
                Upn: user.Upn,
                Email: user.Email,
                DisplayName: user.DisplayName,
                Role: null,
                ManagerId: user.ManagerId,
                Groups: groupIds,
                AppRoles: appRoles,
                AuthMethod: req.AuthMethod);
        }

        var resolvedRole = ResolveEffectiveRole(appRoles, userGroups);
        if (resolvedRole is null)
        {
            return new AuthenticatedPrincipalDto(
                IsAuthenticated: true,
                IsAuthorized: false,
                DenialCode: "missing_role",
                DenialReason: "Logged-in user does not hold an assigned OrderFlow role (Manager or Reportee) in Azure App Registration or AD Group.",
                UserId: user.Id,
                Upn: user.Upn,
                Email: user.Email,
                DisplayName: user.DisplayName,
                Role: null,
                ManagerId: user.ManagerId,
                Groups: groupIds,
                AppRoles: appRoles,
                AuthMethod: req.AuthMethod);
        }

        return new AuthenticatedPrincipalDto(
            IsAuthenticated: true,
            IsAuthorized: true,
            DenialCode: null,
            DenialReason: null,
            UserId: user.Id,
            Upn: user.Upn,
            Email: user.Email,
            DisplayName: user.DisplayName,
            Role: resolvedRole,
            ManagerId: user.ManagerId,
            Groups: groupIds,
            AppRoles: appRoles,
            AuthMethod: req.AuthMethod);
    }

    public async Task<DirectorySyncResultDto> ApplyDirectorySyncAsync(DirectorySyncBatchRequest batch, CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var membershipsChanged = 0;
        var appRolesChanged = 0;

        // 1) Upsert watched AD groups
        var existingGroups = await db.DirectoryGroups.ToDictionaryAsync(g => g.GroupId, StringComparer.OrdinalIgnoreCase, ct);
        foreach (var g in batch.Groups)
        {
            if (!existingGroups.TryGetValue(g.GroupId, out var entity))
            {
                entity = new DirectoryGroup
                {
                    GroupId = g.GroupId,
                    DisplayName = g.DisplayName,
                    IsRequiredAccessGroup = g.IsRequiredAccessGroup,
                    MappedRole = g.MappedRole,
                    DeltaLink = g.DeltaLink,
                    LastSyncedAtUtc = now
                };
                db.DirectoryGroups.Add(entity);
                existingGroups[g.GroupId] = entity;
            }
            else
            {
                entity.DisplayName = g.DisplayName;
                entity.IsRequiredAccessGroup = g.IsRequiredAccessGroup;
                entity.MappedRole = g.MappedRole;
                if (!string.IsNullOrWhiteSpace(g.DeltaLink))
                    entity.DeltaLink = g.DeltaLink;
                entity.LastSyncedAtUtc = now;
            }
        }

        // 2) Upsert users discovered in groups or app role assignments
        var existingUsers = await db.DirectoryUsers
            .Include(u => u.GroupMemberships)
            .Include(u => u.AppRoleAssignments)
            .ToDictionaryAsync(u => u.Id, StringComparer.OrdinalIgnoreCase, ct);

        foreach (var u in batch.Users)
        {
            if (!existingUsers.TryGetValue(u.ObjectId, out var userEntity))
            {
                userEntity = new DirectoryUser
                {
                    Id = u.ObjectId,
                    DisplayName = u.DisplayName,
                    Upn = u.Upn,
                    Email = u.Email ?? u.Upn,
                    WindowsAccountName = u.WindowsAccountName,
                    ManagerId = u.ManagerObjectId,
                    AccountEnabled = u.AccountEnabled,
                    LastSyncedAtUtc = now
                };
                db.DirectoryUsers.Add(userEntity);
                existingUsers[u.ObjectId] = userEntity;
            }
            else
            {
                userEntity.DisplayName = u.DisplayName;
                userEntity.Upn = u.Upn ?? userEntity.Upn;
                userEntity.Email = u.Email ?? u.Upn ?? userEntity.Email;
                if (!string.IsNullOrWhiteSpace(u.WindowsAccountName))
                    userEntity.WindowsAccountName = u.WindowsAccountName;
                userEntity.ManagerId = u.ManagerObjectId;
                userEntity.AccountEnabled = u.AccountEnabled;
                userEntity.LastSyncedAtUtc = now;
            }
        }

        // 3) Apply AD Group membership snapshots or Graph delta changes
        foreach (var m in batch.Memberships)
        {
            if (existingGroups.TryGetValue(m.GroupId, out var grp))
            {
                if (!string.IsNullOrWhiteSpace(m.DeltaLink))
                    grp.DeltaLink = m.DeltaLink;
                grp.LastSyncedAtUtc = now;
            }

            var currentMembers = await db.UserGroupMemberships
                .Where(x => x.GroupId == m.GroupId)
                .ToListAsync(ct);

            var incomingSet = new HashSet<string>(m.MemberUserIds, StringComparer.OrdinalIgnoreCase);

            if (m.IsFullSnapshot)
            {
                var toRemove = currentMembers.Where(c => !incomingSet.Contains(c.UserId)).ToList();
                if (toRemove.Count > 0)
                {
                    db.UserGroupMemberships.RemoveRange(toRemove);
                    foreach (var rem in toRemove)
                    {
                        if (existingUsers.TryGetValue(rem.UserId, out var u))
                            u.GroupMemberships.RemoveAll(gm => string.Equals(gm.GroupId, m.GroupId, StringComparison.OrdinalIgnoreCase));
                    }
                    membershipsChanged += toRemove.Count;
                }
            }
            else if (m.RemovedUserIds is { Count: > 0 })
            {
                var removedSet = new HashSet<string>(m.RemovedUserIds, StringComparer.OrdinalIgnoreCase);
                var toRemove = currentMembers.Where(c => removedSet.Contains(c.UserId)).ToList();
                if (toRemove.Count > 0)
                {
                    db.UserGroupMemberships.RemoveRange(toRemove);
                    foreach (var rem in toRemove)
                    {
                        if (existingUsers.TryGetValue(rem.UserId, out var u))
                            u.GroupMemberships.RemoveAll(gm => string.Equals(gm.GroupId, m.GroupId, StringComparison.OrdinalIgnoreCase));
                    }
                    membershipsChanged += toRemove.Count;
                }
            }

            var currentUserSet = new HashSet<string>(currentMembers.Select(c => c.UserId), StringComparer.OrdinalIgnoreCase);
            foreach (var userId in incomingSet)
            {
                if (!existingUsers.ContainsKey(userId) || currentUserSet.Contains(userId))
                    continue;

                var added = new UserGroupMembership { UserId = userId, GroupId = m.GroupId, SyncedAtUtc = now };
                db.UserGroupMemberships.Add(added);
                existingUsers[userId].GroupMemberships.Add(added);
                membershipsChanged++;
            }
        }

        // 4) Apply Azure App Registration App Role assignments
        var existingRoleAssignments = await db.UserAppRoleAssignments.ToListAsync(ct);
        if (batch.IsFullAppRoleSnapshot)
        {
            var incomingIds = new HashSet<string>(batch.AppRoleAssignments.Select(a => a.AssignmentId), StringComparer.OrdinalIgnoreCase);
            var staleRoles = existingRoleAssignments.Where(r => !incomingIds.Contains(r.AssignmentId)).ToList();
            if (staleRoles.Count > 0)
            {
                db.UserAppRoleAssignments.RemoveRange(staleRoles);
                foreach (var sr in staleRoles)
                {
                    if (existingUsers.TryGetValue(sr.UserId, out var u))
                        u.AppRoleAssignments.RemoveAll(a => string.Equals(a.AssignmentId, sr.AssignmentId, StringComparison.OrdinalIgnoreCase));
                }
                appRolesChanged += staleRoles.Count;
            }
        }

        var existingRoleMap = existingRoleAssignments.ToDictionary(r => r.AssignmentId, StringComparer.OrdinalIgnoreCase);
        foreach (var assignment in batch.AppRoleAssignments)
        {
            if (!existingUsers.TryGetValue(assignment.PrincipalId, out var userEntity))
                continue;

            if (!existingRoleMap.TryGetValue(assignment.AssignmentId, out var roleEntity))
            {
                roleEntity = new UserAppRoleAssignment
                {
                    AssignmentId = assignment.AssignmentId,
                    UserId = assignment.PrincipalId,
                    AppRoleId = assignment.AppRoleId,
                    RoleName = assignment.RoleName,
                    AssignedAtUtc = assignment.CreatedAtUtc ?? now
                };
                db.UserAppRoleAssignments.Add(roleEntity);
                userEntity.AppRoleAssignments.Add(roleEntity);
                existingRoleMap[assignment.AssignmentId] = roleEntity;
                appRolesChanged++;
            }
            else if (!string.Equals(roleEntity.RoleName, assignment.RoleName, StringComparison.OrdinalIgnoreCase))
            {
                roleEntity.RoleName = assignment.RoleName;
                roleEntity.AppRoleId = assignment.AppRoleId;
                appRolesChanged++;
            }
        }

        // 5) Recompute effective AD-group + App-Role authorization for every user & sync dbo.Users projection
        var appUsers = await db.AppUsers.ToDictionaryAsync(u => u.Id, StringComparer.OrdinalIgnoreCase, ct);
        var authorizedCount = 0;
        var revokedCount = 0;

        foreach (var user in existingUsers.Values)
        {
            var wasAuthorized = user.IsAuthorized;
            var memberGroups = user.GroupMemberships
                .Select(gm => existingGroups.TryGetValue(gm.GroupId, out var g) ? g : null)
                .Where(g => g is not null)
                .Cast<DirectoryGroup>()
                .ToList();

            var roleNames = user.AppRoleAssignments
                .Select(a => a.RoleName)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            user.IsInAuthorizedGroup = EvaluateAdGroupMembership(memberGroups);
            user.EffectiveRole = ResolveEffectiveRole(roleNames, memberGroups);
            user.LastSyncedAtUtc = now;

            if (user.IsAuthorized)
                authorizedCount++;
            else if (wasAuthorized)
                revokedCount++;

            if (appUsers.TryGetValue(user.Id, out var appUser))
            {
                appUser.DisplayName = user.DisplayName;
                appUser.Email = user.Email;
                appUser.Upn = user.Upn;
                appUser.WindowsAccountName = user.WindowsAccountName;
                appUser.ManagerId = user.ManagerId;
                appUser.IsInAuthorizedGroup = user.IsInAuthorizedGroup;
                appUser.IsActive = user.IsAuthorized;
                if (user.EffectiveRole is { } effRole)
                    appUser.Role = effRole;
                appUser.LastSyncedAtUtc = now;
            }
            else if (user.IsAuthorized && user.EffectiveRole is { } newRole)
            {
                var createdAppUser = new AppUser
                {
                    Id = user.Id,
                    DisplayName = user.DisplayName,
                    Email = user.Email,
                    Upn = user.Upn,
                    WindowsAccountName = user.WindowsAccountName,
                    ManagerId = user.ManagerId,
                    Role = newRole,
                    IsActive = true,
                    IsInAuthorizedGroup = true,
                    LastSyncedAtUtc = now
                };
                db.AppUsers.Add(createdAppUser);
                appUsers[user.Id] = createdAppUser;
            }
        }

        db.SyncAudits.Add(new DirectorySyncAudit
        {
            Source = batch.SyncSource,
            UsersUpserted = batch.Users.Count,
            UsersAuthorized = authorizedCount,
            UsersRevoked = revokedCount,
            OccurredAtUtc = now
        });

        await db.SaveChangesAsync(ct);

        logger.LogInformation(
            "Directory sync ({Source}) completed: {Upserted} upserted, {Authorized} authorized, {Revoked} revoked, {Memberships} group deltas, {Roles} app-role deltas.",
            batch.SyncSource, batch.Users.Count, authorizedCount, revokedCount, membershipsChanged, appRolesChanged);

        return new DirectorySyncResultDto(
            batch.Users.Count,
            authorizedCount,
            revokedCount,
            membershipsChanged,
            appRolesChanged,
            now);
    }

    public async Task<IReadOnlyList<UserSummaryDto>> GetAuthorizedUsersAsync(CancellationToken ct = default)
    {
        var users = await db.DirectoryUsers.AsNoTracking()
            .Where(u => u.AccountEnabled && u.IsInAuthorizedGroup && u.EffectiveRole != null)
            .OrderBy(u => u.EffectiveRole)
            .ThenBy(u => u.DisplayName)
            .Select(u => new UserSummaryDto(u.Id, u.DisplayName, u.Email ?? u.Upn, u.EffectiveRole!.Value, u.ManagerId))
            .ToListAsync(ct);

        return users;
    }

    public async Task<IReadOnlyList<DirectoryGroupStateDto>> GetGroupStatesAsync(CancellationToken ct = default)
    {
        return await db.DirectoryGroups.AsNoTracking()
            .OrderBy(g => g.DisplayName)
            .Select(g => new DirectoryGroupStateDto(
                g.GroupId,
                g.DisplayName,
                g.IsRequiredAccessGroup,
                g.MappedRole,
                g.DeltaLink,
                g.WebhookSubscriptionId,
                g.WebhookExpiresAtUtc,
                g.LastSyncedAtUtc))
            .ToListAsync(ct);
    }

    public async Task UpdateWebhookSubscriptionAsync(UpdateWebhookSubscriptionRequest request, CancellationToken ct = default)
    {
        var group = await db.DirectoryGroups.FirstOrDefaultAsync(g => g.GroupId == request.GroupId, ct);
        if (group is null) return;

        group.WebhookSubscriptionId = request.SubscriptionId;
        group.WebhookExpiresAtUtc = request.ExpiresAtUtc;
        await db.SaveChangesAsync(ct);
    }

    private bool EvaluateAdGroupMembership(IReadOnlyCollection<DirectoryGroup> memberGroups)
    {
        if (memberGroups.Count == 0)
            return false;

        if (_opts.RequiredAccessGroupIds.Count > 0)
        {
            return memberGroups.Any(g =>
                _opts.RequiredAccessGroupIds.Contains(g.GroupId, StringComparer.OrdinalIgnoreCase));
        }

        return memberGroups.Any(g => g.IsRequiredAccessGroup);
    }

    private UserRole? ResolveEffectiveRole(
        IReadOnlyCollection<string> appRoleNames,
        IReadOnlyCollection<DirectoryGroup> memberGroups)
    {
        UserRole? fromAppRoles = null;
        if (appRoleNames.Contains(OrderFlowIdentityConstants.RoleManager, StringComparer.OrdinalIgnoreCase))
            fromAppRoles = UserRole.Manager;
        else if (appRoleNames.Contains(OrderFlowIdentityConstants.RoleReportee, StringComparer.OrdinalIgnoreCase))
            fromAppRoles = UserRole.Reportee;

        if (_opts.RequireExplicitAppRoleAssignment)
            return fromAppRoles;

        UserRole? fromGroups = null;
        if (memberGroups.Any(g => g.MappedRole == UserRole.Manager))
            fromGroups = UserRole.Manager;
        else if (memberGroups.Any(g => g.MappedRole == UserRole.Reportee))
            fromGroups = UserRole.Reportee;

        // Manager takes precedence if granted in either Azure App Registration App Roles or AD Group role mapping.
        if (fromAppRoles == UserRole.Manager || fromGroups == UserRole.Manager)
            return UserRole.Manager;
        if (fromAppRoles == UserRole.Reportee || fromGroups == UserRole.Reportee)
            return UserRole.Reportee;

        return null;
    }

    private static AuthenticatedPrincipalDto BuildDenied(DirectoryUser u, string code, string reason, string authMethod) =>
        new(
            IsAuthenticated: true,
            IsAuthorized: false,
            DenialCode: code,
            DenialReason: reason,
            UserId: u.Id,
            Upn: u.Upn,
            Email: u.Email,
            DisplayName: u.DisplayName,
            Role: null,
            ManagerId: u.ManagerId,
            Groups: u.GroupMemberships.Select(g => g.GroupId).ToList(),
            AppRoles: u.AppRoleAssignments.Select(r => r.RoleName).ToList(),
            AuthMethod: authMethod);
}
