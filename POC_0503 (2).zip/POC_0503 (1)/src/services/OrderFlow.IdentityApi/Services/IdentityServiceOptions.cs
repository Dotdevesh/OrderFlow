namespace OrderFlow.IdentityApi.Services;

public sealed class IdentityServiceOptions
{
    public const string Section = "IdentityService";

    /// <summary>
    /// Signing key used by <c>OrderFlow.IdentityApi</c> to mint Windows SSO tokens and S2S tokens.
    /// Store in Azure Key Vault in non-dev environments.
    /// </summary>
    public string JwtSigningKey { get; set; } = "orderflow-local-dev-signing-key-minimum-32-bytes!";

    /// <summary>Token issuer URI placed in IdentityApi-minted JWTs.</summary>
    public string Issuer { get; set; } = "https://identity.orderflow.internal";

    /// <summary>Default audience for user SSO tokens consumed by OrderApi.</summary>
    public string UserTokenAudience { get; set; } = "api://orderflow-orderapi";

    /// <summary>Lifetime in minutes for Windows SSO exchanged tokens.</summary>
    public int UserTokenLifetimeMinutes { get; set; } = 60;

    /// <summary>Lifetime in minutes for service-to-service tokens.</summary>
    public int ServiceTokenLifetimeMinutes { get; set; } = 30;

    /// <summary>Shared secret validating non-Managed-Identity S2S token exchange requests (Key Vault in Azure).</summary>
    public string? ServiceSharedSecret { get; set; }

    /// <summary>
    /// Registered internal services allowed to exchange credentials for <c>InternalService</c> / <c>DirectorySync</c> tokens.
    /// </summary>
    public List<string> AllowedServices { get; set; } =
    [
        "OrderApi",
        "Orchestrator",
        "EmailIntake",
        "IdentitySync"
    ];

    /// <summary>
    /// Optional explicit list of Entra Security Group Object IDs required for user login.
    /// When empty, any <c>DirectoryGroup</c> row with <c>IsRequiredAccessGroup = true</c> satisfies the AD group check.
    /// </summary>
    public List<string> RequiredAccessGroupIds { get; set; } = [];

    /// <summary>
    /// When true, a user must hold BOTH a synced AD Group membership AND an explicit Azure App Registration
    /// App Role assignment (<c>UserAppRoleAssignment</c>). When false (default), the role can come from either
    /// an Azure App Registration App Role OR a role-mapped AD Security Group, while AD Group membership is ALWAYS mandatory.
    /// </summary>
    public bool RequireExplicitAppRoleAssignment { get; set; } = false;
}
