using OrderFlow.Domain;

namespace OrderFlow.IdentityApi.Entities;

/// <summary>Authoritative Entra / Active Directory user record synced into the <c>identity</c> schema.</summary>
public sealed class DirectoryUser
{
    /// <summary>Microsoft Entra Object ID (<c>oid</c>).</summary>
    public required string Id { get; init; }
    public required string DisplayName { get; set; }
    public string? Upn { get; set; }
    public string? Email { get; set; }

    /// <summary>On-premises / hybrid Windows account name (e.g. <c>CONTOSO\morgan</c> or sAMAccountName).</summary>
    public string? WindowsAccountName { get; set; }

    /// <summary>Manager's Entra Object ID synced from Microsoft Graph (<c>/users/{id}/manager</c>).</summary>
    public string? ManagerId { get; set; }

    /// <summary>Entra <c>accountEnabled</c> flag.</summary>
    public bool AccountEnabled { get; set; } = true;

    /// <summary>Computed on sync: true when user belongs to at least one required AD security group.</summary>
    public bool IsInAuthorizedGroup { get; set; }

    /// <summary>Computed on sync from Azure App Registration App Roles + AD Group role mappings. Null when unassigned.</summary>
    public UserRole? EffectiveRole { get; set; }

    /// <summary>True only when <see cref="AccountEnabled"/>, <see cref="IsInAuthorizedGroup"/>, and <see cref="EffectiveRole"/> are all satisfied.</summary>
    public bool IsAuthorized => AccountEnabled && IsInAuthorizedGroup && EffectiveRole is not null;

    public DateTimeOffset LastSyncedAtUtc { get; set; } = DateTimeOffset.UtcNow;

    public List<UserGroupMembership> GroupMemberships { get; set; } = [];
    public List<UserAppRoleAssignment> AppRoleAssignments { get; set; } = [];
}

/// <summary>Tracked Entra ID / AD Security Group synced via Microsoft Graph webhook &amp; delta queries.</summary>
public sealed class DirectoryGroup
{
    /// <summary>Microsoft Entra Group Object ID.</summary>
    public required string GroupId { get; init; }
    public required string DisplayName { get; set; }

    /// <summary>When true, membership in this group satisfies the mandatory AD group access gate.</summary>
    public bool IsRequiredAccessGroup { get; set; } = true;

    /// <summary>Optional role granted by membership in this AD group (in addition to or combined with App Registration roles).</summary>
    public UserRole? MappedRole { get; set; }

    /// <summary>Microsoft Graph <c>/groups/{id}/members/delta</c> continuation link.</summary>
    public string? DeltaLink { get; set; }

    /// <summary>Active Microsoft Graph change-notification subscription ID for this group.</summary>
    public string? WebhookSubscriptionId { get; set; }
    public DateTimeOffset? WebhookExpiresAtUtc { get; set; }
    public DateTimeOffset? LastSyncedAtUtc { get; set; }
}

/// <summary>Many-to-many join between <see cref="DirectoryUser"/> and <see cref="DirectoryGroup"/>.</summary>
public sealed class UserGroupMembership
{
    public required string UserId { get; init; }
    public required string GroupId { get; init; }
    public DateTimeOffset SyncedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

/// <summary>Azure App Registration role assignment (<c>servicePrincipals/{id}/appRoleAssignedTo</c>).</summary>
public sealed class UserAppRoleAssignment
{
    /// <summary>Graph <c>appRoleAssignment.id</c>.</summary>
    public required string AssignmentId { get; init; }
    public required string UserId { get; init; }
    public required string AppRoleId { get; set; }

    /// <summary>Role value configured in Azure App Registration (e.g. <c>Manager</c>, <c>Reportee</c>).</summary>
    public required string RoleName { get; set; }
    public DateTimeOffset AssignedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

/// <summary>Audit trail of directory synchronization runs triggered by Graph webhooks or timers.</summary>
public sealed class DirectorySyncAudit
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public required string Source { get; init; }
    public int UsersUpserted { get; init; }
    public int UsersAuthorized { get; init; }
    public int UsersRevoked { get; init; }
    public DateTimeOffset OccurredAtUtc { get; init; } = DateTimeOffset.UtcNow;
}
