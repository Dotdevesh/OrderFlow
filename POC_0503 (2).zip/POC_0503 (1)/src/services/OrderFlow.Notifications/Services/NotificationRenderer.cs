using System.Net;
using System.Text;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;

namespace OrderFlow.Notifications.Services;

public interface INotificationRenderer
{
    NotificationEmail Render(NotificationRequested notification, IReadOnlyList<string> recipients);
}

/// <summary>
/// Turns a <see cref="NotificationRequested"/> into subject, HTML, and plain text. Producers supply
/// the facts; wording, severity colour, and the Action Center link are decided here so every email
/// looks the same regardless of which service raised it.
/// </summary>
public sealed class NotificationRenderer(IOptions<NotificationOptions> options) : INotificationRenderer
{
    private readonly NotificationOptions _options = options.Value;

    public NotificationEmail Render(NotificationRequested notification, IReadOnlyList<string> recipients)
    {
        var subject = $"{_options.SubjectPrefix} {SeverityPrefix(notification.Severity)}{notification.Subject}".Trim();
        var facts = BuildFacts(notification);
        var actionUrl = ResolveActionUrl(notification);

        return new NotificationEmail(recipients, subject, RenderHtml(notification, facts, actionUrl), RenderText(notification, facts, actionUrl));
    }

    private static string SeverityPrefix(NotificationSeverity severity) => severity switch
    {
        NotificationSeverity.Critical => "CRITICAL: ",
        NotificationSeverity.Warning => "Warning: ",
        _ => string.Empty
    };

    private static string SeverityColour(NotificationSeverity severity) => severity switch
    {
        NotificationSeverity.Critical => "#b3261e",
        NotificationSeverity.Warning => "#b26a00",
        _ => "#1a73e8"
    };

    private static List<NotificationFact> BuildFacts(NotificationRequested notification)
    {
        var facts = new List<NotificationFact>();

        if (notification.OrderId is { } orderId)
            facts.Add(new NotificationFact("Order", orderId.ToString()));
        if (!string.IsNullOrWhiteSpace(notification.CustomerId))
            facts.Add(new NotificationFact("Customer", notification.CustomerId));
        if (notification.CorrelationId is { } correlationId)
            facts.Add(new NotificationFact("Correlation id", correlationId.ToString()));

        facts.AddRange(notification.Facts);
        facts.Add(new NotificationFact("Raised at (UTC)",
            (notification.RaisedAtUtc ?? DateTimeOffset.UtcNow).UtcDateTime.ToString("yyyy-MM-dd HH:mm:ss")));

        return facts;
    }

    private string? ResolveActionUrl(NotificationRequested notification)
    {
        if (!string.IsNullOrWhiteSpace(notification.ActionUrl))
            return notification.ActionUrl;

        if (string.IsNullOrWhiteSpace(_options.ActionCenterBaseUrl) || notification.OrderId is not { } orderId)
            return null;

        return $"{_options.ActionCenterBaseUrl.TrimEnd('/')}/validation/{orderId}";
    }

    private static string RenderHtml(NotificationRequested notification, List<NotificationFact> facts, string? actionUrl)
    {
        var html = new StringBuilder();
        html.Append("<html><body style=\"font-family:Segoe UI,Arial,sans-serif;color:#202124;\">");
        html.Append($"<p style=\"border-left:4px solid {SeverityColour(notification.Severity)};padding-left:12px;font-size:16px;\">");
        html.Append(WebUtility.HtmlEncode(notification.Summary));
        html.Append("</p><table cellpadding=\"6\" cellspacing=\"0\" style=\"border-collapse:collapse;font-size:14px;\">");

        foreach (var fact in facts)
        {
            html.Append("<tr><td style=\"border:1px solid #dadce0;background:#f8f9fa;\"><strong>");
            html.Append(WebUtility.HtmlEncode(fact.Label));
            html.Append("</strong></td><td style=\"border:1px solid #dadce0;\">");
            html.Append(WebUtility.HtmlEncode(fact.Value));
            html.Append("</td></tr>");
        }

        html.Append("</table>");

        if (!string.IsNullOrWhiteSpace(actionUrl))
        {
            html.Append($"<p style=\"margin-top:20px;\"><a href=\"{WebUtility.HtmlEncode(actionUrl)}\" ");
            html.Append("style=\"background:#1a73e8;color:#fff;padding:10px 18px;border-radius:4px;text-decoration:none;\">");
            html.Append("Open in Action Center</a></p>");
        }

        html.Append("<p style=\"color:#5f6368;font-size:12px;margin-top:24px;\">Sent by OrderFlow. Do not reply to this message.</p>");
        html.Append("</body></html>");
        return html.ToString();
    }

    private static string RenderText(NotificationRequested notification, List<NotificationFact> facts, string? actionUrl)
    {
        var text = new StringBuilder();
        text.AppendLine(notification.Summary).AppendLine();

        foreach (var fact in facts)
            text.AppendLine($"{fact.Label}: {fact.Value}");

        if (!string.IsNullOrWhiteSpace(actionUrl))
            text.AppendLine().AppendLine($"Open in Action Center: {actionUrl}");

        text.AppendLine().Append("Sent by OrderFlow. Do not reply to this message.");
        return text.ToString();
    }
}
