using OrderFlow.Contracts;

namespace OrderFlow.Notifications.Services;

/// <summary>Addressing and provider settings for outbound notification email.</summary>
public sealed class NotificationOptions
{
    public const string Section = "Notifications";

    /// <summary>Turns sending off while leaving the pipeline wired, for a dry run in a new environment.</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Azure Communication Services endpoint, e.g. <c>https://acs-orderflow-dev.communication.azure.com</c>.
    /// Used with the credential from <c>Notifications:Credential</c>, so a managed identity works here.
    /// </summary>
    public string? AcsEndpoint { get; set; }

    /// <summary>Connection string alternative to <see cref="AcsEndpoint"/>, for environments without a managed identity.</summary>
    public string? AcsConnectionString { get; set; }

    /// <summary>Verified ACS sender, e.g. <c>DoNotReply@&lt;guid&gt;.azurecomm.net</c> or a custom domain.</summary>
    public string? SenderAddress { get; set; }

    /// <summary>Used when an event carries no explicit recipients and its kind has no specific list.</summary>
    public IList<string> DefaultRecipients { get; set; } = [];

    /// <summary>Per-kind overrides, keyed by <see cref="NotificationKind"/> name, e.g. <c>"SlaBreached": ["ops@contoso.com"]</c>.</summary>
    public IDictionary<string, List<string>> RecipientsByKind { get; set; } = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

    /// <summary>Recipients for infrastructure events: service down, service recovered, dead letters.</summary>
    public IList<string> OperationsRecipients { get; set; } = [];

    /// <summary>Base URL used to build the "open the task" link in order emails.</summary>
    public string? ActionCenterBaseUrl { get; set; }

    /// <summary>Prefixed to every subject line, e.g. <c>[OrderFlow dev]</c>.</summary>
    public string SubjectPrefix { get; set; } = "[OrderFlow]";

    /// <summary>
    /// Resolves the audience for one notification: explicit recipients win, then the per-kind list,
    /// then the operations list for infrastructure events, then the default list.
    /// </summary>
    public IReadOnlyList<string> ResolveRecipients(NotificationRequested notification)
    {
        if (notification.Recipients.Count > 0)
            return notification.Recipients;

        if (RecipientsByKind.TryGetValue(notification.Kind.ToString(), out var byKind) && byKind.Count > 0)
            return byKind;

        var isInfrastructure = notification.Kind
            is NotificationKind.ServiceUnhealthy
            or NotificationKind.ServiceRecovered
            or NotificationKind.DeadLetterDetected;

        if (isInfrastructure && OperationsRecipients.Count > 0)
            return [.. OperationsRecipients];

        return [.. DefaultRecipients];
    }
}
