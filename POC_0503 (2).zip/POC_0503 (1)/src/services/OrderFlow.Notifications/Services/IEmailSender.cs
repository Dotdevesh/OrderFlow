using Azure;
using Azure.Communication.Email;
using Azure.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OrderFlow.BuildingBlocks.AzureClients;

namespace OrderFlow.Notifications.Services;

/// <summary>A rendered notification, ready to hand to a provider.</summary>
public sealed record NotificationEmail(
    IReadOnlyList<string> To,
    string Subject,
    string HtmlBody,
    string PlainTextBody);

public sealed record EmailSendOutcome(bool Delivered, string? ProviderMessageId = null, string? Error = null)
{
    public static EmailSendOutcome Sent(string? id) => new(true, id);
    public static EmailSendOutcome Failed(string error) => new(false, Error: error);
    public static readonly EmailSendOutcome Skipped = new(true, Error: "Sending is disabled or there were no recipients.");
}

public interface IEmailSender
{
    Task<EmailSendOutcome> SendAsync(NotificationEmail email, CancellationToken ct = default);
}

/// <summary>
/// Sends through Azure Communication Services Email. Authenticates with the credential selected by
/// <c>Notifications:Credential</c> when an endpoint is configured, or with a connection string.
/// </summary>
public sealed class AcsEmailSender : IEmailSender
{
    private readonly EmailClient _client;
    private readonly NotificationOptions _options;
    private readonly ILogger<AcsEmailSender> _logger;

    public AcsEmailSender(
        IOptions<NotificationOptions> options,
        IAzureCredentialFactory credentials,
        ILogger<AcsEmailSender> logger)
    {
        _options = options.Value;
        _logger = logger;

        if (string.IsNullOrWhiteSpace(_options.SenderAddress))
            throw new InvalidOperationException($"{NotificationOptions.Section}:SenderAddress is required to send email.");

        if (!string.IsNullOrWhiteSpace(_options.AcsEndpoint))
        {
            TokenCredential credential = credentials.CreateRequired(NotificationOptions.Section);
            _client = new EmailClient(new Uri(_options.AcsEndpoint), credential);
        }
        else if (!string.IsNullOrWhiteSpace(_options.AcsConnectionString))
        {
            _client = new EmailClient(_options.AcsConnectionString);
        }
        else
        {
            throw new InvalidOperationException(
                $"Configure {NotificationOptions.Section}:AcsEndpoint or {NotificationOptions.Section}:AcsConnectionString.");
        }
    }

    public async Task<EmailSendOutcome> SendAsync(NotificationEmail email, CancellationToken ct = default)
    {
        if (email.To.Count == 0)
            return EmailSendOutcome.Skipped;

        var message = new EmailMessage(
            _options.SenderAddress,
            new EmailRecipients(email.To.Select(address => new EmailAddress(address)).ToList()),
            new EmailContent(email.Subject)
            {
                Html = email.HtmlBody,
                PlainText = email.PlainTextBody
            });

        try
        {
            // WaitUntil.Started: the Service Bus message is the unit of retry, so do not hold the
            // consumer open for the provider's delivery poll.
            var operation = await _client.SendAsync(WaitUntil.Started, message, ct);
            _logger.LogInformation("Queued notification email {OperationId} to {RecipientCount} recipient(s).",
                operation.Id, email.To.Count);
            return EmailSendOutcome.Sent(operation.Id);
        }
        catch (RequestFailedException ex)
        {
            _logger.LogError(ex, "Azure Communication Services rejected the notification email.");
            return EmailSendOutcome.Failed(ex.Message);
        }
    }
}

/// <summary>
/// Writes the rendered email to the log instead of sending it. Used when no provider is configured,
/// which is the normal state in Docker Compose and in tests.
/// </summary>
public sealed class LoggingEmailSender(ILogger<LoggingEmailSender> logger) : IEmailSender
{
    public Task<EmailSendOutcome> SendAsync(NotificationEmail email, CancellationToken ct = default)
    {
        logger.LogInformation(
            "Notification email (not sent, no provider configured)\nTo: {Recipients}\nSubject: {Subject}\n{Body}",
            string.Join(", ", email.To), email.Subject, email.PlainTextBody);

        return Task.FromResult(EmailSendOutcome.Sent("local-no-op"));
    }
}
