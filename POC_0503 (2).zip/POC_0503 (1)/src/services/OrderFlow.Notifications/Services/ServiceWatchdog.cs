using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace OrderFlow.Notifications.Services;

public sealed class WatchdogOptions
{
    public const string Section = "Watchdog";

    public bool Enabled { get; set; } = true;

    public int TimeoutSeconds { get; set; } = 10;

    /// <summary>Consecutive failed probes before a service is declared down. Absorbs a single restart or cold start.</summary>
    public int FailureThreshold { get; set; } = 2;

    public IList<WatchedService> Services { get; set; } = [];
}

public sealed class WatchedService
{
    public string Name { get; set; } = string.Empty;
    public string BaseUrl { get; set; } = string.Empty;
    public string Path { get; set; } = "/health/ready";
}

public sealed record ServiceProbeResult(string Name, bool IsHealthy, int? StatusCode, string? Detail, TimeSpan Duration);

public interface IServiceHealthProbe
{
    Task<ServiceProbeResult> ProbeAsync(WatchedService service, TimeSpan timeout, CancellationToken ct = default);
}

public sealed class HttpServiceHealthProbe(IHttpClientFactory httpClientFactory, ILogger<HttpServiceHealthProbe> logger) : IServiceHealthProbe
{
    public const string HttpClientName = "watchdog";

    public async Task<ServiceProbeResult> ProbeAsync(WatchedService service, TimeSpan timeout, CancellationToken ct = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var url = new Uri(new Uri(service.BaseUrl), service.Path);

        using var timeoutSource = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeoutSource.CancelAfter(timeout);

        try
        {
            using var http = httpClientFactory.CreateClient(HttpClientName);
            using var response = await http.GetAsync(url, timeoutSource.Token);
            var body = await response.Content.ReadAsStringAsync(timeoutSource.Token);

            return new ServiceProbeResult(
                service.Name,
                response.IsSuccessStatusCode,
                (int)response.StatusCode,
                Truncate(body),
                stopwatch.Elapsed);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Watchdog probe to {Service} at {Url} failed.", service.Name, url);
            return new ServiceProbeResult(service.Name, false, null, ex.Message, stopwatch.Elapsed);
        }
    }

    private static string Truncate(string value) => value.Length <= 500 ? value : value[..500] + "...";
}

public enum WatchdogTransition
{
    /// <summary>Nothing to report: the service is in the state we last notified about.</summary>
    None,
    WentDown,
    Recovered
}

/// <summary>
/// Remembers what was last reported for each service so the watchdog emails on the edge rather than
/// once a minute for as long as an outage lasts.
/// </summary>
public interface IWatchdogStateStore
{
    WatchdogTransition Record(string serviceName, bool isHealthy, int failureThreshold);
}

/// <summary>
/// In-process state. The timer trigger is a singleton within a Function app, so one instance sees
/// every probe. A restart resets the state, which can repeat a single "service is down" email; the
/// Azure Monitor alert rules in <c>infra/modules/monitoring.bicep</c> are the durable signal.
/// </summary>
public sealed class InMemoryWatchdogStateStore : IWatchdogStateStore
{
    private sealed class Entry
    {
        public int ConsecutiveFailures;
        public bool ReportedDown;
    }

    private readonly ConcurrentDictionary<string, Entry> _entries = new(StringComparer.OrdinalIgnoreCase);

    public WatchdogTransition Record(string serviceName, bool isHealthy, int failureThreshold)
    {
        var entry = _entries.GetOrAdd(serviceName, _ => new Entry());

        lock (entry)
        {
            if (isHealthy)
            {
                entry.ConsecutiveFailures = 0;
                if (!entry.ReportedDown)
                    return WatchdogTransition.None;

                entry.ReportedDown = false;
                return WatchdogTransition.Recovered;
            }

            entry.ConsecutiveFailures++;
            if (entry.ReportedDown || entry.ConsecutiveFailures < Math.Max(1, failureThreshold))
                return WatchdogTransition.None;

            entry.ReportedDown = true;
            return WatchdogTransition.WentDown;
        }
    }
}
