using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;
using OrderFlow.Notifications.Services;
using OrderFlow.Observability;

namespace OrderFlow.Notifications.Functions;

/// <summary>
/// Polls every OrderFlow service's readiness endpoint and emails operations when one crosses from up
/// to down, or back. The email is sent directly rather than published to Service Bus: an outage of
/// the broker is exactly the case this has to survive.
/// </summary>
public sealed class ServiceWatchdogFunction(
    IServiceHealthProbe probe,
    IWatchdogStateStore state,
    INotificationRenderer renderer,
    IEmailSender emailSender,
    IOptions<WatchdogOptions> watchdogOptions,
    IOptions<NotificationOptions> notificationOptions,
    ILogger<ServiceWatchdogFunction> logger)
{
    [Function(nameof(WatchServiceHealth))]
    public async Task WatchServiceHealth(
        [TimerTrigger("%Watchdog:Schedule%")] TimerInfo timer,
        CancellationToken ct)
    {
        var options = watchdogOptions.Value;
        if (!options.Enabled || options.Services.Count == 0)
        {
            logger.LogDebug("Watchdog is disabled or has no services configured.");
            return;
        }

        using var activity = OrderFlowActivity.Start(nameof(WatchServiceHealth));
        var timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);

        var probes = await Task.WhenAll(options.Services.Select(service => probe.ProbeAsync(service, timeout, ct)));

        foreach (var result in probes)
        {
            var transition = state.Record(result.Name, result.IsHealthy, options.FailureThreshold);
            if (transition == WatchdogTransition.None)
                continue;

            await NotifyAsync(result, transition, ct);
        }
    }

    private async Task NotifyAsync(ServiceProbeResult result, WatchdogTransition transition, CancellationToken ct)
    {
        var wentDown = transition == WatchdogTransition.WentDown;

        var notification = new NotificationRequested(
            NotificationId: Guid.NewGuid(),
            Kind: wentDown ? NotificationKind.ServiceUnhealthy : NotificationKind.ServiceRecovered,
            Severity: wentDown ? NotificationSeverity.Critical : NotificationSeverity.Information,
            Subject: wentDown ? $"{result.Name} is not responding" : $"{result.Name} has recovered",
            Summary: wentDown
                ? $"The readiness probe for {result.Name} failed repeatedly. Orders may be queueing rather than processing."
                : $"{result.Name} is answering its readiness probe again.",
            Recipients: [],
            Facts:
            [
                new NotificationFact("Service", result.Name),
                new NotificationFact("HTTP status", result.StatusCode?.ToString() ?? "no response"),
                new NotificationFact("Probe duration", $"{result.Duration.TotalMilliseconds:F0} ms"),
                new NotificationFact("Detail", result.Detail ?? "none")
            ],
            RaisedAtUtc: DateTimeOffset.UtcNow);

        var recipients = notificationOptions.Value.ResolveRecipients(notification);
        if (recipients.Count == 0)
        {
            logger.LogError("{Service} transitioned to {Transition} but no operations recipients are configured.",
                result.Name, transition);
            return;
        }

        var outcome = await emailSender.SendAsync(renderer.Render(notification, recipients), ct);

        if (outcome.Delivered)
        {
            logger.LogWarning("Watchdog reported {Service} as {Transition} to {RecipientCount} recipient(s).",
                result.Name, transition, recipients.Count);
        }
        else
        {
            logger.LogError("Watchdog could not send the {Transition} notification for {Service}: {Error}",
                transition, result.Name, outcome.Error);
        }
    }
}
