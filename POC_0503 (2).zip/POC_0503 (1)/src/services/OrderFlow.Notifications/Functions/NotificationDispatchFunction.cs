using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;
using OrderFlow.Notifications.Services;
using OrderFlow.Observability;

namespace OrderFlow.Notifications.Functions;

/// <summary>
/// Consumes <see cref="NotificationRequested"/> off <c>orders/sub-notifications</c> and sends the
/// email. Failures throw, so the message is retried and eventually dead-lettered rather than lost.
/// </summary>
public sealed class NotificationDispatchFunction(
    INotificationRenderer renderer,
    IEmailSender emailSender,
    IOptions<NotificationOptions> options,
    OrderFlowMetrics metrics,
    ILogger<NotificationDispatchFunction> logger)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    [Function(nameof(DispatchNotification))]
    public async Task DispatchNotification(
        [ServiceBusTrigger(Topics.Orders, Topics.SubNotifications, Connection = "ServiceBus")] string body,
        CancellationToken ct)
    {
        var notification = JsonSerializer.Deserialize<NotificationRequested>(body, Json)
            ?? throw new InvalidOperationException("Message is not a valid NotificationRequested; it will dead-letter.");

        using var activity = OrderFlowActivity.Start(nameof(DispatchNotification));
        CorrelationContext.Ensure(notification.CorrelationId?.ToString());
        activity?.SetTag("notification.kind", notification.Kind.ToString());

        var settings = options.Value;
        if (!settings.Enabled)
        {
            logger.LogInformation("Notifications are disabled; dropping {Kind} {NotificationId}.",
                notification.Kind, notification.NotificationId);
            return;
        }

        var recipients = settings.ResolveRecipients(notification);
        if (recipients.Count == 0)
        {
            logger.LogWarning(
                "No recipients resolved for {Kind} {NotificationId}. Configure {Section}:DefaultRecipients or a per-kind list.",
                notification.Kind, notification.NotificationId, NotificationOptions.Section);
            return;
        }

        var email = renderer.Render(notification, recipients);
        var outcome = await emailSender.SendAsync(email, ct);

        if (!outcome.Delivered)
        {
            metrics.NotificationsFailed.Add(1, new KeyValuePair<string, object?>("kind", notification.Kind.ToString()));
            throw new InvalidOperationException($"Notification {notification.NotificationId} was not accepted: {outcome.Error}");
        }

        metrics.NotificationsSent.Add(1, new KeyValuePair<string, object?>("kind", notification.Kind.ToString()));
        logger.LogInformation("Sent {Kind} notification {NotificationId} to {RecipientCount} recipient(s).",
            notification.Kind, notification.NotificationId, recipients.Count);
    }
}
