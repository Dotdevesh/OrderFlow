using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.BuildingBlocks.Health;
using OrderFlow.Notifications.Services;
using OrderFlow.Observability;

var builder = FunctionsApplication.CreateBuilder(args);
builder.ConfigureFunctionsWebApplication();

var cfg = builder.Configuration;

builder.AddOrderFlowObservability("Notifications");
builder.Services.AddOrderFlowAzureCredentials();

builder.Services.Configure<NotificationOptions>(cfg.GetSection(NotificationOptions.Section));
builder.Services.Configure<WatchdogOptions>(cfg.GetSection(WatchdogOptions.Section));

builder.Services.AddSingleton<INotificationRenderer, NotificationRenderer>();

// Azure Communication Services when it is configured; otherwise log the rendered email so the
// pipeline still runs end to end in Docker Compose and in tests.
var acsConfigured = !string.IsNullOrWhiteSpace(cfg[$"{NotificationOptions.Section}:AcsEndpoint"])
                    || !string.IsNullOrWhiteSpace(cfg[$"{NotificationOptions.Section}:AcsConnectionString"]);

if (acsConfigured)
    builder.Services.AddSingleton<IEmailSender, AcsEmailSender>();
else
    builder.Services.AddSingleton<IEmailSender, LoggingEmailSender>();

builder.Services.AddHttpClient(HttpServiceHealthProbe.HttpClientName, c => c.Timeout = TimeSpan.FromSeconds(30));
builder.Services.AddSingleton<IServiceHealthProbe, HttpServiceHealthProbe>();
builder.Services.AddSingleton<IWatchdogStateStore, InMemoryWatchdogStateStore>();

var health = builder.Services.AddOrderFlowHealthChecks("Notifications");
if (builder.Services.TryAddOrderFlowServiceBusClient(cfg))
    health.AddServiceBus();

builder.Build().Run();
