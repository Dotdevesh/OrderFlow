using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrderFlow.Contracts;
using OrderFlow.CustomerModel;

namespace OrderFlow.Orchestrator.Services;

/// <summary>Extracts order entities from a PDF using Azure AI Document Intelligence.</summary>
public interface IEntityExtractor
{
    Task<DocumentEntities> AnalyzeAsync(AnalyzeInput input, Stream pdf, CancellationToken ct = default);
}

/// <summary>
/// Document Intelligence-backed extractor driven by the customer's code-first schema
/// (<see cref="ICustomerSchemaRegistry"/>). When the endpoint is not configured, returns
/// representative entities matching the customer's schema so the human-in-the-loop UI can be
/// exercised locally. A global semaphore bounds concurrency to respect the provisioned TPS.
/// </summary>
public sealed class DocumentIntelligenceExtractor(
    IConfiguration cfg,
    ICustomerSchemaRegistry schemas,
    ILogger<DocumentIntelligenceExtractor> logger) : IEntityExtractor
{
    private static readonly SemaphoreSlim Throttle = new(8, 8);

    public async Task<DocumentEntities> AnalyzeAsync(AnalyzeInput input, Stream pdf, CancellationToken ct = default)
    {
        await Throttle.WaitAsync(ct);
        try
        {
            // The customer's entity class defines the model and exact fields to pull (config drives extraction).
            var schema = schemas.Describe(input.CustomerId);
            var plan = schema?.Plan;
            var modelId = plan?.ModelId ?? input.ModelId;
            var includeLines = schema?.Template.Sections.Any(s => s.Type == "table") ?? false;

            var endpoint = cfg["DocumentIntelligence:Endpoint"];
            if (string.IsNullOrWhiteSpace(endpoint))
            {
                logger.LogWarning(
                    "Document Intelligence not configured; returning sample entities for {Blob} (customer {Customer}, model {Model}, {FieldCount} planned fields)",
                    input.Blob.BlobPath, input.CustomerId, modelId, plan?.Fields.Count ?? 0);
                return Sample(input.Blob.BlobPath, modelId, plan, includeLines);
            }

            // Production path (sketch):
            //   var client = new DocumentIntelligenceClient(new Uri(endpoint), new DefaultAzureCredential());
            //   var op = await client.AnalyzeDocumentAsync(WaitUntil.Completed, modelId, BinaryData.FromStream(pdf), ct);
            //   For each plan.Fields entry, read op.Value.Documents[].Fields[plan.ExtractionField]
            //   -> ExtractedFieldDto with Confidence + bounding regions; emit candidates for Localized fields.
            await Task.CompletedTask;
            return Sample(input.Blob.BlobPath, modelId, plan, includeLines);
        }
        finally
        {
            Throttle.Release();
        }
    }

    /// <summary>
    /// Produces representative entities matching the customer's plan (including valid format/option
    /// values and localized disambiguation candidates). Falls back to a generic invoice if unregistered.
    /// </summary>
    private static DocumentEntities Sample(string blobPath, string modelId, ExtractionPlan? plan, bool includeLines)
    {
        if (plan is null || plan.Fields.Count == 0)
            return GenericInvoiceSample(blobPath, modelId);

        var fields = new List<ExtractedFieldDto>(plan.Fields.Count);
        foreach (var f in plan.Fields)
        {
            var value = SampleValue(f);
            if (f.Localized)
            {
                fields.Add(new ExtractedFieldDto(f.ExtractionField, value, 0.74,
                    "{\"page\":1,\"polygon\":[1.2,2.4,3.6,2.4,3.6,2.7,1.2,2.7]}",
                    Candidates:
                    [
                        new FieldCandidateDto(value, 0.74, "Primary match", "{\"page\":1,\"polygon\":[1.2,2.4,3.6,2.4,3.6,2.7,1.2,2.7]}"),
                        new FieldCandidateDto($"{value} (Alt)", 0.68, "Secondary match", "{\"page\":1,\"polygon\":[1.2,3.1,3.6,3.1,3.6,3.4,1.2,3.4]}"),
                        new FieldCandidateDto($"{f.Label} - Header", 0.61, "Header mention", "{\"page\":1,\"polygon\":[1.2,1.1,3.6,1.1,3.6,1.4,1.2,1.4]}")
                    ]));
            }
            else
            {
                fields.Add(new ExtractedFieldDto(f.ExtractionField, value, f.Required ? 0.92 : 0.86, null));
            }
        }

        IReadOnlyList<ExtractedLineDto> lines = includeLines
            ?
            [
                new ExtractedLineDto("SKU-001", "Widget A", 10, 25.00m, 0.91),
                new ExtractedLineDto("SKU-002", "Widget B", 5, 200.00m, 0.68)
            ]
            : [];

        var minConf = fields.Select(f => f.Confidence)
            .Concat(lines.Select(l => l.Confidence))
            .DefaultIfEmpty(1.0)
            .Min();

        return new DocumentEntities(blobPath, fields, lines, minConf, modelId);
    }

    private static string SampleValue(ExtractionFieldPlan f) => f.ExtractionField switch
    {
        "FileNumber" => "TI-10045",
        "PONumber" => "PO-10045",
        "OrderType" => "Purchase",
        "PolicyType" => "ALTA Owner",
        "Currency" => "USD",
        "Incoterm" => "DDP",
        "APN" => "104-22-019",
        "PropertyAddress" => "742 Evergreen Terrace",
        "PropertyCity" => "Springfield",
        "PropertyState" => "IL",
        "PropertyZip" => "62704",
        "PropertyCounty" => "Sangamon",
        "LenderName" => "First Horizon Bank",
        "BuyerName" => "Jane Doe",
        "SellerName" => "Acme Holdings LLC",
        "ShipToName" => "Acme Receiving Dept",
        "SoldToName" => "Acme Corp",
        "BillToName" => "Acme HQ Billing",
        _ => f.Type switch
        {
            "number" => "1250.00",
            "date" => "2026-11-12",
            "checkbox" => "false",
            _ => $"Sample {f.Label}"
        }
    };

    private static DocumentEntities GenericInvoiceSample(string blobPath, string modelId) => new(
        blobPath,
        Fields:
        [
            new ExtractedFieldDto("PONumber", "PO-10045", 0.98, null),
            new ExtractedFieldDto("OrderDate", "2026-11-12", 0.95, null),
            new ExtractedFieldDto("Total", "1250.00", 0.72, null),
            new ExtractedFieldDto("ShipToName", "Acme Receiving Dept", 0.74,
                "{\"page\":1,\"polygon\":[1.2,2.4,3.6,2.4,3.6,2.7,1.2,2.7]}",
                Candidates:
                [
                    new FieldCandidateDto("Acme Receiving Dept", 0.74, "Ship-To", "{\"page\":1,\"polygon\":[1.2,2.4,3.6,2.4,3.6,2.7,1.2,2.7]}"),
                    new FieldCandidateDto("Acme HQ Billing", 0.68, "Bill-To", "{\"page\":1,\"polygon\":[1.2,3.1,3.6,3.1,3.6,3.4,1.2,3.4]}"),
                    new FieldCandidateDto("Acme Corp", 0.91, "Sold-To", "{\"page\":1,\"polygon\":[1.2,1.1,3.6,1.1,3.6,1.4,1.2,1.4]}")
                ])
        ],
        Lines:
        [
            new ExtractedLineDto("SKU-001", "Widget A", 10, 25.00m, 0.91),
            new ExtractedLineDto("SKU-002", "Widget B", 5, 200.00m, 0.68)
        ],
        MinConfidence: 0.68,
        ModelId: modelId);
}
