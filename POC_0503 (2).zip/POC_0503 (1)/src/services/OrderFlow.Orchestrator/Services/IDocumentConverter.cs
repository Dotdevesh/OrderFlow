using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using OrderFlow.Domain;

namespace OrderFlow.Orchestrator.Services;

/// <summary>Converts an email body and heterogeneous attachments into a uniform set of PDFs.</summary>
public interface IDocumentConverter
{
    Task<IReadOnlyList<PdfDoc>> ConvertAsync(FetchedEmail email, CancellationToken ct = default);
}

/// <summary>
/// Pluggable converter. Production wires headless Chromium (email HTML→PDF) and LibreOffice (Office→PDF)
/// behind this interface; images are wrapped into PDF pages and existing PDFs pass through.
/// Locally, synthesizes a valid, browser-renderable PDF 1.4 document containing the email text
/// so the Action Center PDF pane opens without errors.
/// </summary>
public sealed partial class PassthroughDocumentConverter : IDocumentConverter
{
    public Task<IReadOnlyList<PdfDoc>> ConvertAsync(FetchedEmail email, CancellationToken ct = default)
    {
        var bodyText = StripHtml(email.BodyHtml);
        var lines = new List<string>
        {
            $"OrderFlow - Inbound Email",
            $"Subject: {email.Subject ?? "(none)"}",
            $"From: {email.SenderAddress ?? "(unknown)"}",
            $"Mailbox: {email.Mailbox}",
            $"CorrelationId: {email.CorrelationId}",
            "------------------------------------------------------------"
        };
        lines.AddRange(WrapLines(bodyText, 78));

        var docs = new List<PdfDoc>
        {
            new(DocumentKind.EmailBody, "email-body.pdf", BuildSimplePdf(lines))
        };

        docs.AddRange(email.Attachments.Select(a =>
            new PdfDoc(DocumentKind.Attachment, EnsurePdfName(a.FileName), NormalizeToPdf(a))));

        return Task.FromResult<IReadOnlyList<PdfDoc>>(docs);
    }

    private static byte[] NormalizeToPdf(EmailAttachment a)
    {
        // Only pass through bytes that actually start with a real PDF header and trailer;
        // otherwise wrap content in a valid minimal PDF so browser PDF viewers never fail.
        if (a.ContentType == "application/pdf"
            && a.Content.Length > 20
            && Encoding.ASCII.GetString(a.Content, 0, Math.Min(8, a.Content.Length)).StartsWith("%PDF-", StringComparison.Ordinal)
            && Encoding.ASCII.GetString(a.Content).Contains("%%EOF", StringComparison.Ordinal))
        {
            return a.Content;
        }

        return BuildSimplePdf(
        [
            $"Attachment: {a.FileName}",
            $"Content-Type: {a.ContentType}",
            "------------------------------------------------------------",
            "Rendered locally by OrderFlow PassthroughDocumentConverter.",
            $"Original payload size: {a.Content.LongLength} bytes."
        ]);
    }

    /// <summary>
    /// Builds a standards-compliant minimal PDF 1.4 (5 objects + xref + trailer) using the built-in
    /// Helvetica font so Chrome/Edge/PDF.js render it reliably with zero native dependencies.
    /// </summary>
    public static byte[] BuildSimplePdf(IReadOnlyList<string> lines)
    {
        var content = new StringBuilder();
        content.AppendLine("BT");
        content.AppendLine("/F1 11 Tf");
        content.AppendLine("50 750 Td");
        content.AppendLine("15 TL");

        foreach (var line in lines.Take(45))
        {
            var escaped = EscapePdfText(line);
            content.Append('(').Append(escaped).AppendLine(") Tj T*");
        }
        content.AppendLine("ET");

        var streamBytes = Encoding.ASCII.GetBytes(content.ToString());

        var sb = new StringBuilder();
        sb.Append("%PDF-1.4\n");

        var offsets = new List<int> { 0 };

        void AppendObj(int num, string body)
        {
            offsets.Add(Encoding.ASCII.GetByteCount(sb.ToString()));
            sb.Append(CultureInfo.InvariantCulture, $"{num} 0 obj\n{body}\nendobj\n");
        }

        AppendObj(1, "<< /Type /Catalog /Pages 2 0 R >>");
        AppendObj(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        AppendObj(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>");
        AppendObj(4, string.Create(CultureInfo.InvariantCulture, $"<< /Length {streamBytes.Length} >>\nstream\n{Encoding.ASCII.GetString(streamBytes)}endstream"));
        AppendObj(5, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");

        var xrefOffset = Encoding.ASCII.GetByteCount(sb.ToString());
        sb.Append(CultureInfo.InvariantCulture, $"xref\n0 {offsets.Count}\n");
        sb.Append("0000000000 65535 f \n");
        for (var i = 1; i < offsets.Count; i++)
            sb.Append(CultureInfo.InvariantCulture, $"{offsets[i]:D10} 00000 n \n");

        sb.Append(CultureInfo.InvariantCulture, $"trailer\n<< /Size {offsets.Count} /Root 1 0 R >>\nstartxref\n{xrefOffset}\n%%EOF\n");
        return Encoding.ASCII.GetBytes(sb.ToString());
    }

    private static string EscapePdfText(string input)
    {
        var sb = new StringBuilder(input.Length);
        foreach (var ch in input)
        {
            var ascii = ch is >= ' ' and <= '~' ? ch : '?';
            if (ascii is '(' or ')' or '\\') sb.Append('\\');
            sb.Append(ascii);
        }
        return sb.ToString();
    }

    private static string StripHtml(string html)
        => HtmlTagRegex().Replace(html ?? string.Empty, " ").Trim();

    private static IEnumerable<string> WrapLines(string text, int maxLen)
    {
        if (string.IsNullOrWhiteSpace(text)) yield break;
        var words = text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        var line = new StringBuilder();
        foreach (var w in words)
        {
            if (line.Length + w.Length + 1 > maxLen && line.Length > 0)
            {
                yield return line.ToString();
                line.Clear();
            }
            if (line.Length > 0) line.Append(' ');
            line.Append(w);
        }
        if (line.Length > 0) yield return line.ToString();
    }

    private static string EnsurePdfName(string name) =>
        name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase) ? name : Path.ChangeExtension(name, ".pdf");

    [GeneratedRegex("<[^>]+>", RegexOptions.Compiled)]
    private static partial Regex HtmlTagRegex();
}
