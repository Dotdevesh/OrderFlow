using System.Net.Http.Json;
using OrderFlow.Contracts;

namespace OrderFlow.Orchestrator.Services;

/// <summary>Typed client for the Order API internal endpoints (service-to-service).</summary>
public interface IOrderApiClient
{
    Task<CreateOrderResponse> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default);
    Task CreateValidationTaskAsync(Guid orderId, CreateValidationTaskRequest request, CancellationToken ct = default);
    Task EscalateAsync(Guid orderId, EscalateOrderRequest request, CancellationToken ct = default);
    Task FinalizeAsync(Guid orderId, FinalizeOrderRequest request, CancellationToken ct = default);
}

public sealed class OrderApiClient(HttpClient http) : IOrderApiClient
{
    public async Task<CreateOrderResponse> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default)
    {
        var res = await http.PostAsJsonAsync("/internal/orders", request, ct);
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<CreateOrderResponse>(ct))!;
    }

    public async Task CreateValidationTaskAsync(Guid orderId, CreateValidationTaskRequest request, CancellationToken ct = default)
    {
        var res = await http.PostAsJsonAsync($"/internal/orders/{orderId}/validation-task", request, ct);
        res.EnsureSuccessStatusCode();
    }

    public async Task EscalateAsync(Guid orderId, EscalateOrderRequest request, CancellationToken ct = default)
    {
        var res = await http.PostAsJsonAsync($"/internal/orders/{orderId}/escalate", request, ct);
        res.EnsureSuccessStatusCode();
    }

    public async Task FinalizeAsync(Guid orderId, FinalizeOrderRequest request, CancellationToken ct = default)
    {
        var res = await http.PostAsJsonAsync($"/internal/orders/{orderId}/finalize", request, ct);
        res.EnsureSuccessStatusCode();
    }
}
