using Microsoft.Extensions.Logging;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.Orchestrator.Services;

/// <summary>
/// Raises <see cref="NotificationRequested"/> for the operational moments humans need to hear about.
/// The orchestrator decides <em>what happened</em>; <c>OrderFlow.Notifications</c> decides who is told
/// and what the email looks like.
/// </summary>
public interface INotificationPublisher
{
    Task NotifyAsync(NotificationRequested notification, CancellationToken ct = default);
}

public sealed class NotificationPublisher(
    ILogger<NotificationPublisher> logger,
    IEventPublisher? events = null) : INotificationPublisher
{
    public async Task NotifyAsync(NotificationRequested notification, CancellationToken ct = default)
    {
        if (events is null)
        {
            logger.LogInformation(
                "Service Bus is not configured; skipping {Kind} notification for order {OrderId}.",
                notification.Kind, notification.OrderId);
            return;
        }

        // The notification id doubles as the Service Bus MessageId, so a retried activity cannot
        // produce a second email within the topic's duplicate detection window.
        await events.PublishAsync(
            notification,
            notification.NotificationId.ToString("N"),
            notification.CorrelationId ?? Guid.Empty,
            notification.CustomerId ?? "unknown",
            Priority.High,
            sessionId: notification.CustomerId,
            ct);
    }
}
