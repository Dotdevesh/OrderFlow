using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace OrderFlow.Orchestrator.Services;

/// <summary>Reads an email (body + attachments) from Microsoft Graph.</summary>
public interface IEmailReader
{
    Task<FetchedEmail> FetchAsync(Guid correlationId, string mailbox, string messageId, string? customerId = null, CancellationToken ct = default);
}

/// <summary>
/// Graph-backed reader. Uses app-only auth (DefaultAzureCredential / Managed Identity). When Graph is
/// not configured (local dev), returns a representative sample matching the customer so the
/// pipeline runs end-to-end.
/// </summary>
public sealed class GraphEmailReader(
    IConfiguration cfg,
    ILogger<GraphEmailReader> logger) : IEmailReader
{
    public async Task<FetchedEmail> FetchAsync(Guid correlationId, string mailbox, string messageId, string? customerId = null, CancellationToken ct = default)
    {
        var tenant = cfg["Graph:TenantId"];
        if (string.IsNullOrWhiteSpace(tenant))
        {
            logger.LogWarning("Graph not configured; returning a sample email for {MessageId} (customer {Customer})", messageId, customerId);
            return Sample(correlationId, mailbox, messageId, customerId);
        }

        // Production path (sketch): create GraphServiceClient with DefaultAzureCredential and read:
        //   var msg  = await graph.Users[mailbox].Messages[messageId].GetAsync(...);
        //   var mime = await graph.Users[mailbox].Messages[messageId].Content.GetAsync();
        //   var atts = await graph.Users[mailbox].Messages[messageId].Attachments.GetAsync();
        // Mapped into FetchedEmail. Omitted here to keep the POC runnable without a tenant.
        await Task.CompletedTask;
        return Sample(correlationId, mailbox, messageId, customerId);
    }

    private static FetchedEmail Sample(Guid correlationId, string mailbox, string messageId, string? customerId)
    {
        var (subject, sender, body, attachmentName) = customerId?.ToLowerInvariant() switch
        {
            "acme-title" => (
                "Title Order TI-10045 - 742 Evergreen Terrace",
                "escrow@acmetitle.com",
                "<html><body><h1>Title Insurance Order TI-10045</h1><p>Property: 742 Evergreen Terrace, Springfield, IL 62704. APN: 104-22-019. Lender: First Horizon Bank.</p></body></html>",
                "ti-10045-commitment.pdf"),
            "first-national" => (
                "Title Order TI-20410 - Closing Package",
                "closing@fntitle.com",
                "<html><body><h1>Title Order TI-20410</h1><p>Buyer: Jane Doe. Seller: Acme Holdings LLC. Property: 742 Evergreen Terrace.</p></body></html>",
                "ti-20410-package.pdf"),
            "globex" => (
                "Purchase Order PO-20890",
                "orders@globex.com",
                "<html><body><h1>Purchase Order PO-20890</h1><p>Extended PO with Sold-To, Ship-To, Bill-To and logistics details.</p></body></html>",
                "po-20890.pdf"),
            "initech" => (
                "Purchase Order PO-30112",
                "procurement@initech.com",
                "<html><body><h1>Purchase Order PO-30112</h1><p>Standard purchase order.</p></body></html>",
                "po-30112.pdf"),
            _ => (
                "Purchase Order PO-10045",
                "buyer@acme.com",
                "<html><body><h1>Purchase Order PO-10045</h1><p>Please supply the items below.</p></body></html>",
                "po-10045.pdf")
        };

        var attachmentPdf = PassthroughDocumentConverter.BuildSimplePdf(
        [
            subject,
            $"Customer: {customerId ?? "acme"}",
            $"Sender: {sender}",
            $"MessageId: {messageId}",
            "------------------------------------------------------------",
            "Sample PDF attachment generated for local validation."
        ]);

        return new FetchedEmail(
            correlationId,
            mailbox,
            messageId,
            Subject: subject,
            SenderAddress: sender,
            BodyHtml: body,
            Attachments: [new EmailAttachment(attachmentName, "application/pdf", attachmentPdf)]);
    }
}
