using Microsoft.Azure.Functions.Worker;
using Microsoft.DurableTask;
using Microsoft.Extensions.Logging;
using OrderFlow.Contracts;

namespace OrderFlow.Orchestrator;

/// <summary>
/// The core saga: fetch → PDF → store → create → extract (fan-out/fan-in) → create task →
/// WAIT for human validation (external event) with an SLA durable timer → finalize / escalate.
///
/// NOTE: orchestrator code must be deterministic — no I/O, no DateTime.Now, no Guid.NewGuid().
/// </summary>
public static class OrderOrchestrator
{
    public const string EventName = "ValidationCompleted";

    private static readonly TaskOptions Retry = TaskOptions.FromRetryPolicy(new RetryPolicy(
        maxNumberOfAttempts: 5,
        firstRetryInterval: TimeSpan.FromSeconds(2),
        backoffCoefficient: 2.0,
        maxRetryInterval: TimeSpan.FromMinutes(2)));

    [Function(nameof(OrderOrchestrator))]
    public static async Task RunAsync([OrchestrationTrigger] TaskOrchestrationContext ctx)
    {
        var input = ctx.GetInput<OrderReceived>()!;
        var log = ctx.CreateReplaySafeLogger(nameof(OrderOrchestrator));

        var email = await ctx.CallActivityAsync<FetchedEmail>(nameof(Activities.FetchEmail), input, Retry);
        var pdfs = await ctx.CallActivityAsync<IReadOnlyList<PdfDoc>>(nameof(Activities.ConvertToPdf), email, Retry);
        var stored = await ctx.CallActivityAsync<StoredDocuments>(nameof(Activities.StoreDocuments), new StoreRequest(input, pdfs), Retry);
        var order = await ctx.CallActivityAsync<OrderCreated>(nameof(Activities.CreateOrder), new CreateOrderActivityInput(input, stored), Retry);

        // Fan-out / fan-in: analyze every stored document in parallel. The customer's extraction
        // plan (derived from its entity class) chooses the model and the fields to pull.
        var defaultModelId = "prebuilt-document";
        var analyses = stored.Blobs
            .Select(b => ctx.CallActivityAsync<DocumentEntities>(
                nameof(Activities.AnalyzeDocument), new AnalyzeInput(order.OrderId, input.CustomerId, b, defaultModelId), Retry))
            .ToList();
        var entities = await Task.WhenAll(analyses);

        await ctx.CallActivityAsync(nameof(Activities.CreateValidationTask),
            new CreateTaskActivityInput(order.OrderId, ctx.InstanceId, entities), Retry);

        // ---------------- HUMAN IN THE LOOP ----------------
        var outcome = await WaitForValidationWithSlaAsync(ctx, order, input, log);

        var finalPayload = outcome ?? new ValidationCompletedPayload(
            order.OrderId, "system", false, [], [], "Abandoned after max escalations");
        await ctx.CallActivityAsync(nameof(Activities.FinalizeOrder),
            new FinalizeActivityInput(finalPayload, input.CustomerId, input.CorrelationId, Abandoned: outcome is null), Retry);

        log.LogInformation("Order {OrderId} completed. Approved={Approved}", order.OrderId, finalPayload.Approved);
    }

    /// <summary>
    /// Races the "ValidationCompleted" external event against an SLA durable timer. On breach,
    /// escalates and re-arms a shorter timer. Returns null if abandoned after max escalations.
    /// </summary>
    private static async Task<ValidationCompletedPayload?> WaitForValidationWithSlaAsync(
        TaskOrchestrationContext ctx, OrderCreated order, OrderReceived input, ILogger log)
    {
        const int maxEscalations = 3;
        var deadline = order.SlaDueAtUtc.UtcDateTime;

        for (var attempt = 0; attempt <= maxEscalations; attempt++)
        {
            using var cts = new CancellationTokenSource();
            var slaTimer = ctx.CreateTimer(deadline, cts.Token);
            var validated = ctx.WaitForExternalEvent<ValidationCompletedPayload>(EventName);

            var winner = await Task.WhenAny(validated, slaTimer);
            if (winner == validated)
            {
                cts.Cancel();                       // cancel the durable timer
                return validated.Result;            // RESUME — human submitted
            }

            // SLA breached: escalate and re-arm a shorter window.
            var newDeadline = ctx.CurrentUtcDateTime.AddMinutes(order.EscalationIntervalMinutes);
            await ctx.CallActivityAsync(nameof(Activities.Escalate),
                new EscalateInput(order.OrderId, ctx.InstanceId, attempt + 1, new DateTimeOffset(newDeadline, TimeSpan.Zero),
                    input.CustomerId, input.CorrelationId), Retry);
            deadline = newDeadline;
            log.LogWarning("SLA breach #{Attempt} for order {OrderId}; new deadline {Deadline}",
                attempt + 1, order.OrderId, deadline);
        }

        return null;
    }
}
