using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.Orchestrator;

// Data passed between activities. Kept serializable for Durable checkpointing.

public sealed record EmailAttachment(string FileName, string ContentType, byte[] Content);

public sealed record FetchedEmail(
    Guid CorrelationId,
    string Mailbox,
    string MessageId,
    string? Subject,
    string? SenderAddress,
    string BodyHtml,
    IReadOnlyList<EmailAttachment> Attachments);

public sealed record PdfDoc(DocumentKind Kind, string FileName, byte[] Content);

public sealed record StoreRequest(OrderReceived Input, IReadOnlyList<PdfDoc> Pdfs);

public sealed record StoredBlob(DocumentKind Kind, string FileName, string BlobPath, string ContentType, long SizeBytes);

public sealed record StoredDocuments(IReadOnlyList<StoredBlob> Blobs);

public sealed record CreateOrderActivityInput(OrderReceived Input, StoredDocuments Stored);

public sealed record OrderCreated(Guid OrderId, DateTimeOffset SlaDueAtUtc, int EscalationIntervalMinutes);

public sealed record AnalyzeInput(Guid OrderId, string CustomerId, StoredBlob Blob, string ModelId);

public sealed record DocumentEntities(
    string BlobPath,
    IReadOnlyList<ExtractedFieldDto> Fields,
    IReadOnlyList<ExtractedLineDto> Lines,
    double MinConfidence,
    string? ModelId = null);

public sealed record CreateTaskActivityInput(Guid OrderId, string InstanceId, IReadOnlyList<DocumentEntities> Entities);

public sealed record EscalateInput(
    Guid OrderId,
    string InstanceId,
    int Attempt,
    DateTimeOffset NewSlaDueAtUtc,
    string CustomerId,
    Guid CorrelationId);

/// <param name="Abandoned">True when the orchestration gave up after the last escalation rather than a human submitting.</param>
public sealed record FinalizeActivityInput(
    ValidationCompletedPayload Payload,
    string CustomerId,
    Guid CorrelationId,
    bool Abandoned);
