using System.Security.Cryptography;
using System.Text;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.Observability;
using OrderFlow.Orchestrator.Services;

namespace OrderFlow.Orchestrator;

/// <summary>
/// The idempotent units of work. Each is retryable and does all the I/O (the orchestrator itself
/// performs none, to stay deterministic for replay).
/// </summary>
public sealed class Activities(
    IEmailReader emailReader,
    IDocumentConverter converter,
    IBlobDocumentStore blobs,
    IEntityExtractor extractor,
    IOrderApiClient orderApi,
    INotificationPublisher notifications,
    OrderFlowMetrics metrics,
    ILogger<Activities> logger)
{
    [Function(nameof(FetchEmail))]
    public async Task<FetchedEmail> FetchEmail([ActivityTrigger] OrderReceived input, CancellationToken ct)
        => await emailReader.FetchAsync(input.CorrelationId, input.MailboxAddress, input.GraphMessageId, input.CustomerId, ct);

    [Function(nameof(ConvertToPdf))]
    public async Task<IReadOnlyList<PdfDoc>> ConvertToPdf([ActivityTrigger] FetchedEmail email, CancellationToken ct)
        => await converter.ConvertAsync(email, ct);

    [Function(nameof(StoreDocuments))]
    public async Task<StoredDocuments> StoreDocuments([ActivityTrigger] StoreRequest request, CancellationToken ct)
    {
        var results = new List<StoredBlob>();
        foreach (var pdf in request.Pdfs)
        {
            // Deterministic path => idempotent on replay.
            var path = $"{request.Input.CustomerId}/{request.Input.CorrelationId}/{pdf.FileName}";
            using var ms = new MemoryStream(pdf.Content);
            await blobs.UploadAsync(path, ms, "application/pdf", ct);
            results.Add(new StoredBlob(pdf.Kind, pdf.FileName, path, "application/pdf", pdf.Content.LongLength));
        }
        logger.LogInformation("Stored {Count} documents for corr {Corr}", results.Count, request.Input.CorrelationId);
        return new StoredDocuments(results);
    }

    [Function(nameof(CreateOrder))]
    public async Task<OrderCreated> CreateOrder([ActivityTrigger] CreateOrderActivityInput input, CancellationToken ct)
    {
        var req = new CreateOrderRequest(
            input.Input.CorrelationId, input.Input.CustomerId, input.Input.Priority,
            input.Input.CorrelationId.ToString("N"), // instance id seed == correlation id
            input.Input.SenderAddress, input.Input.Subject, input.Input.ReceivedAtUtc,
            input.Stored.Blobs.Select(b => new StoredDocumentDto(b.Kind, b.FileName, b.BlobPath, b.ContentType, b.SizeBytes)).ToList(),
            input.Input.GraphMessageId);

        var res = await orderApi.CreateOrderAsync(req, ct);
        return new OrderCreated(res.OrderId, res.SlaDueAtUtc, res.EscalationIntervalMinutes);
    }

    [Function(nameof(AnalyzeDocument))]
    public async Task<DocumentEntities> AnalyzeDocument([ActivityTrigger] AnalyzeInput input, CancellationToken ct)
    {
        await using var stream = await blobs.OpenReadAsync(input.Blob.BlobPath, ct);
        var result = await extractor.AnalyzeAsync(input, stream, ct);
        logger.LogInformation("Analyzed {Blob}: {Fields} fields, minConf {Conf}",
            input.Blob.BlobPath, result.Fields.Count, result.MinConfidence);
        return result;
    }

    [Function(nameof(CreateValidationTask))]
    public async Task CreateValidationTask([ActivityTrigger] CreateTaskActivityInput input, CancellationToken ct)
    {
        // Merge entities from all documents (first non-null value per field wins; lines concatenated).
        var fields = input.Entities.SelectMany(e => e.Fields)
            .GroupBy(f => f.Name)
            .Select(g => g.OrderByDescending(x => x.Confidence).First())
            .ToList();
        var lines = input.Entities.SelectMany(e => e.Lines).ToList();
        var minConf = input.Entities.Count > 0 ? input.Entities.Min(e => e.MinConfidence) : 1.0;
        var modelId = input.Entities.Select(e => e.ModelId).FirstOrDefault(m => !string.IsNullOrWhiteSpace(m));

        await orderApi.CreateValidationTaskAsync(input.OrderId,
            new CreateValidationTaskRequest(input.OrderId, input.InstanceId, fields, lines, minConf, modelId), ct);
        metrics.ValidationTasksCreated.Add(1);
    }

    [Function(nameof(FinalizeOrder))]
    public async Task FinalizeOrder([ActivityTrigger] FinalizeActivityInput input, CancellationToken ct)
    {
        var payload = input.Payload;
        await orderApi.FinalizeAsync(payload.OrderId,
            new FinalizeOrderRequest(payload.OrderId, payload.ValidatedByUserId, payload.Approved, payload.Note), ct);

        metrics.OrdersFinalized.Add(1, new KeyValuePair<string, object?>("approved", payload.Approved));

        await notifications.NotifyAsync(new NotificationRequested(
            NotificationId: DeterministicId($"finalize:{payload.OrderId}"),
            Kind: input.Abandoned ? NotificationKind.OrderFailed : NotificationKind.OrderFinalized,
            Severity: input.Abandoned ? NotificationSeverity.Critical : NotificationSeverity.Information,
            Subject: input.Abandoned
                ? $"Order {payload.OrderId} was abandoned without validation"
                : $"Order {payload.OrderId} is finalized",
            Summary: input.Abandoned
                ? "Nobody validated this order before the last escalation expired. It is parked in SQL and needs manual attention."
                : $"A human {(payload.Approved ? "approved" : "rejected")} this order and the orchestration has completed.",
            Recipients: [],
            Facts:
            [
                new NotificationFact("Approved", payload.Approved ? "yes" : "no"),
                new NotificationFact("Validated by", payload.ValidatedByUserId),
                new NotificationFact("Note", payload.Note ?? "none")
            ],
            CorrelationId: input.CorrelationId,
            CustomerId: input.CustomerId,
            OrderId: payload.OrderId,
            RaisedAtUtc: DateTimeOffset.UtcNow), ct);
    }

    [Function(nameof(Escalate))]
    public async Task Escalate([ActivityTrigger] EscalateInput input, CancellationToken ct)
    {
        logger.LogWarning("SLA breach for order {OrderId} (attempt {Attempt}); escalating to manager.",
            input.OrderId, input.Attempt);

        await orderApi.EscalateAsync(input.OrderId,
            new EscalateOrderRequest(input.OrderId, input.NewSlaDueAtUtc, input.Attempt), ct);

        metrics.SlaBreaches.Add(1, new KeyValuePair<string, object?>("customer", input.CustomerId));

        await notifications.NotifyAsync(new NotificationRequested(
            NotificationId: DeterministicId($"sla:{input.OrderId}:{input.Attempt}"),
            Kind: NotificationKind.SlaBreached,
            Severity: NotificationSeverity.Warning,
            Subject: $"SLA breached on order {input.OrderId}",
            Summary: $"Escalation {input.Attempt}: no human validated this order before its SLA expired. It has been reassigned to a manager.",
            Recipients: [],
            Facts:
            [
                new NotificationFact("Escalation attempt", input.Attempt.ToString()),
                new NotificationFact("New SLA due (UTC)", input.NewSlaDueAtUtc.UtcDateTime.ToString("yyyy-MM-dd HH:mm:ss")),
                new NotificationFact("Orchestration", input.InstanceId)
            ],
            CorrelationId: input.CorrelationId,
            CustomerId: input.CustomerId,
            OrderId: input.OrderId,
            RaisedAtUtc: DateTimeOffset.UtcNow), ct);
    }

    /// <summary>
    /// Derives a stable notification id from the event it describes, so an activity retry reuses the
    /// same Service Bus MessageId and duplicate detection suppresses a second email.
    /// </summary>
    private static Guid DeterministicId(string seed)
        => new(SHA256.HashData(Encoding.UTF8.GetBytes(seed)).AsSpan(0, 16));
}
