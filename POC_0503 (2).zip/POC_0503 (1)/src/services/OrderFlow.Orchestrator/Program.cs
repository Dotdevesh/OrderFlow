using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.BuildingBlocks.Health;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.CustomerModel;
using OrderFlow.Observability;
using OrderFlow.Orchestrator.Services;

var builder = FunctionsApplication.CreateBuilder(args);
builder.ConfigureFunctionsWebApplication();

var cfg = builder.Configuration;

// Traces, metrics, and logs through one OpenTelemetry pipeline.
builder.AddOrderFlowObservability("Orchestrator");

// Blob storage: endpoint plus a token credential in Azure, Azurite or a connection string locally.
builder.Services.AddOrderFlowBlobDocumentStore();

// Service Bus publisher, used to raise notification events from the SLA and finalize paths.
var serviceBusConfigured = builder.Services.TryAddOrderFlowServiceBusClient(cfg);
if (serviceBusConfigured)
    builder.Services.AddSingleton<IEventPublisher, ServiceBusEventPublisher>();
builder.Services.AddSingleton<INotificationPublisher, NotificationPublisher>();

// Service-to-service authentication via Entra Managed Identity / IdentityApi service token.
builder.Services.Configure<IdentityClientOptions>(opts =>
{
    cfg.GetSection(IdentityClientOptions.Section).Bind(opts);
    opts.ServiceName = "Orchestrator";
    if (string.IsNullOrWhiteSpace(opts.FallbackInternalApiKey))
        opts.FallbackInternalApiKey = cfg["OrderApi:InternalApiKey"];
});
builder.Services.AddTransient<ServiceToServiceBearerHandler>();

// Typed Order API client (service-to-service).
builder.Services.AddHttpClient<IOrderApiClient, OrderApiClient>(c =>
{
    c.BaseAddress = new Uri(cfg["OrderApi:BaseUrl"] ?? "http://localhost:5080");
})
.AddHttpMessageHandler<ServiceToServiceBearerHandler>()
.AddHttpMessageHandler<CorrelationIdPropagationHandler>();

// Pipeline collaborators (Graph reader / converter / Doc Intelligence) behind interfaces.
builder.Services.AddSingleton<IEmailReader, GraphEmailReader>();
builder.Services.AddSingleton<IDocumentConverter, PassthroughDocumentConverter>();
builder.Services.AddSingleton<IEntityExtractor, DocumentIntelligenceExtractor>();

// Code-first per-customer schemas: the same entity classes drive extraction plans here and
// form rendering in the Order API.
builder.Services.AddCustomerSchemas();

var health = builder.Services.AddOrderFlowHealthChecks("Orchestrator");
health.AddBlobStorage();
if (serviceBusConfigured)
    health.AddServiceBus();
if (!string.IsNullOrWhiteSpace(cfg["OrderApi:BaseUrl"]))
    health.AddHttpDependency("order-api", cfg["OrderApi:BaseUrl"]!);

builder.Build().Run();
