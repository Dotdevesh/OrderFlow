using OrderFlow.Contracts;

namespace OrderFlow.OrderApi.Services;

/// <summary>
/// Resumes a suspended Durable Functions orchestration by raising the "ValidationCompleted"
/// external event. Decoupled behind an interface so the transport (Durable HTTP management API)
/// can be swapped for the gRPC client.
/// </summary>
public interface IWorkflowClient
{
    Task RaiseValidationCompletedAsync(string instanceId, ValidationCompletedPayload payload, CancellationToken ct = default);
}
