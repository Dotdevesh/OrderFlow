using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Services;

/// <summary>
/// Transactional outbox dispatcher: polls unprocessed <c>OutboxMessages</c> and either publishes
/// integration events to Service Bus or retries Durable <c>ValidationCompleted</c> resume calls.
/// Guarantees work is never lost even if a downstream service is down during DB commit.
/// </summary>
public sealed class OutboxDispatcher(
    IServiceScopeFactory scopeFactory,
    ILogger<OutboxDispatcher> logger,
    IEventPublisher? publisher = null) : BackgroundService
{
    private static readonly TimeSpan Interval = TimeSpan.FromSeconds(5);
    private static readonly JsonSerializerOptions WebJson = new(JsonSerializerDefaults.Web);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(Interval);
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                await DispatchBatchAsync(stoppingToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Outbox dispatch failed");
            }
        }
    }

    public async Task<int> DispatchBatchAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderFlowDbContext>();
        var workflow = scope.ServiceProvider.GetService<IWorkflowClient>();

        var pending = await db.Outbox
            .Where(m => m.ProcessedAtUtc == null && m.Attempts < 10)
            .OrderBy(m => m.OccurredAtUtc)
            .Take(50)
            .ToListAsync(ct);

        if (pending.Count == 0) return 0;

        var processedCount = 0;
        foreach (var msg in pending)
        {
            msg.Attempts++;
            try
            {
                if (msg.Type == "ValidationCompleted")
                {
                    if (workflow is null)
                        continue;

                    var env = JsonSerializer.Deserialize<ValidationResumeEnvelope>(msg.Payload);
                    if (env is not null)
                        await workflow.RaiseValidationCompletedAsync(env.OrchestrationInstanceId, env.Payload, ct);
                }
                else if (publisher is not null && msg.Type == nameof(OrderFinalized))
                {
                    var evt = JsonSerializer.Deserialize<OrderFinalized>(msg.Payload, WebJson);
                    if (evt is not null)
                    {
                        await publisher.PublishAsync(
                            evt, msg.Id.ToString("N"), msg.CorrelationId, evt.CustomerId,
                            Priority.Standard, sessionId: evt.CustomerId, ct);
                    }
                }

                msg.ProcessedAtUtc = DateTimeOffset.UtcNow;
                processedCount++;
                logger.LogInformation("Dispatched outbox {Type} corr={Corr}", msg.Type, msg.CorrelationId);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning(ex, "Outbox dispatch attempt {Attempt} failed for {Type} {Id}; will retry",
                    msg.Attempts, msg.Type, msg.Id);
            }
        }

        await db.SaveChangesAsync(ct);
        return processedCount;
    }
}
