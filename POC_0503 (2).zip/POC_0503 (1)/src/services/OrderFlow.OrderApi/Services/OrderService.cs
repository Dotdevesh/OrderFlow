using Microsoft.EntityFrameworkCore;
using OrderFlow.BuildingBlocks;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Services;

public interface IOrderService
{
    Task<CreateOrderResponse> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct);
    Task<Result> CreateValidationTaskAsync(CreateValidationTaskRequest request, CancellationToken ct);
    Task<Result> EscalateAsync(EscalateOrderRequest request, CancellationToken ct);
    Task<Result> FinalizeAsync(FinalizeOrderRequest request, CancellationToken ct);
    Task RecordIntakeAsync(RecordIntakeRequest request, CancellationToken ct);
    Task UpdateIntakeStatusAsync(UpdateIntakeStatusRequest request, CancellationToken ct);
    Task<IReadOnlyList<IntakeLedgerEntry>> GetStaleIntakeAsync(TimeSpan olderThan, CancellationToken ct);
}

/// <summary>Write-side service invoked by the Orchestrator (internal endpoints). Idempotent by CorrelationId.</summary>
public sealed class OrderService(
    OrderFlowDbContext db,
    ITaskNotifier notifier,
    ILogger<OrderService> logger) : IOrderService
{
    public async Task<CreateOrderResponse> CreateOrderAsync(CreateOrderRequest r, CancellationToken ct)
    {
        // Resolve SLA from the customer profile (falls back to a safe default for triage/unknown).
        var customer = await db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.CustomerId == r.CustomerId, ct);
        var slaMinutes = customer?.SlaMinutes ?? 240;
        var escalationInterval = customer?.EscalationIntervalMinutes ?? 60;

        // Idempotency: a replayed activity must not create a duplicate order.
        var existing = await db.Orders.FirstOrDefaultAsync(o => o.CorrelationId == r.CorrelationId, ct);
        if (existing is not null)
            return new CreateOrderResponse(existing.Id, existing.SlaDueAtUtc, escalationInterval);

        var slaDue = r.ReceivedAtUtc.AddMinutes(slaMinutes);
        var order = new Order
        {
            CustomerId = r.CustomerId,
            CorrelationId = r.CorrelationId,
            OrchestrationInstanceId = r.OrchestrationInstanceId,
            Priority = r.Priority,
            ReceivedAtUtc = r.ReceivedAtUtc,
            SlaDueAtUtc = slaDue,
            SubjectLine = r.Subject,
            SenderAddress = r.SenderAddress
        };
        foreach (var d in r.Documents)
            order.Documents.Add(new OrderDocument
            {
                OrderId = order.Id, Kind = d.Kind, FileName = d.FileName,
                BlobPath = d.BlobPath, ContentType = d.ContentType, SizeBytes = d.SizeBytes
            });
        order.Advance(OrderStatus.Stored);

        db.Orders.Add(order);
        db.AuditEvents.Add(new AuditEvent { OrderId = order.Id, Action = "OrderCreated", UserId = "system" });

        // Advance intake ledger entry to Orchestrated (if recorded by EmailIntake).
        if (!string.IsNullOrWhiteSpace(r.GraphMessageId))
        {
            var ledger = await db.IntakeLedger.FirstOrDefaultAsync(x => x.GraphMessageId == r.GraphMessageId, ct);
            if (ledger is not null)
                ledger.Status = IntakeStatus.Orchestrated;
        }

        await db.SaveChangesAsync(ct);

        logger.LogInformation("Created order {OrderId} for {CustomerId} (corr {Corr})", order.Id, r.CustomerId, r.CorrelationId);
        return new CreateOrderResponse(order.Id, slaDue, escalationInterval);
    }

    public async Task<Result> CreateValidationTaskAsync(CreateValidationTaskRequest r, CancellationToken ct)
    {
        var order = await db.Orders
            .Include(o => o.Fields).Include(o => o.Lines).Include(o => o.Documents)
            .FirstOrDefaultAsync(o => o.Id == r.OrderId, ct);
        if (order is null) return Result.Failure("Order not found", "order_not_found");

        if (await db.ValidationTasks.AnyAsync(t => t.OrderId == r.OrderId, ct))
            return Result.Success(); // idempotent

        // Persist extraction confidence & model on the order's documents so the Inbox shows real confidence.
        foreach (var doc in order.Documents)
        {
            doc.MinConfidence = r.MinConfidence;
            if (!string.IsNullOrWhiteSpace(r.ModelId))
                doc.AnalyzeModelId = r.ModelId;
        }

        foreach (var f in r.Fields)
        {
            var field = new OrderField
            {
                OrderId = order.Id, Name = f.Name, ExtractedValue = f.Value, Confidence = f.Confidence,
                BoundingRegionJson = f.BoundingRegionJson,
                CandidatesJson = f.Candidates is { Count: > 0 }
                    ? System.Text.Json.JsonSerializer.Serialize(f.Candidates)
                    : null
            };
            order.Fields.Add(field);
            db.OrderFields.Add(field);
        }
        foreach (var l in r.Lines)
        {
            var line = new OrderLine { OrderId = order.Id, Sku = l.Sku, Description = l.Description, Quantity = l.Quantity, UnitPrice = l.UnitPrice, Confidence = l.Confidence };
            order.Lines.Add(line);
            db.OrderLines.Add(line);
        }

        order.Advance(OrderStatus.Extracted);
        order.Advance(OrderStatus.PendingValidation);

        // Route to the team pool. A real system maps customer -> team; demo uses the single manager.
        var task = new ValidationTask
        {
            OrderId = order.Id,
            OrchestrationInstanceId = r.OrchestrationInstanceId,
            Priority = order.Priority,
            SlaDueAtUtc = order.SlaDueAtUtc,
            TeamManagerId = "mgr-1"
        };
        db.ValidationTasks.Add(task);
        db.AuditEvents.Add(new AuditEvent { OrderId = order.Id, TaskId = task.Id, Action = "ValidationTaskCreated", UserId = "system" });
        await db.SaveChangesAsync(ct);

        await notifier.NotifyTaskCreatedAsync(task, order, ct);
        logger.LogInformation("Created validation task {TaskId} for order {OrderId} (minConf {Conf:P0})", task.Id, order.Id, r.MinConfidence);
        return Result.Success();
    }

    public async Task<Result> EscalateAsync(EscalateOrderRequest r, CancellationToken ct)
    {
        var task = await db.ValidationTasks.FirstOrDefaultAsync(t => t.OrderId == r.OrderId, ct);
        if (task is null) return Result.Failure("Validation task not found", "task_not_found");
        if (task.Status is Domain.TaskStatus.Completed or Domain.TaskStatus.Cancelled)
            return Result.Success(); // already closed, nothing to escalate

        var managerId = task.TeamManagerId ?? "mgr-1";
        task.Escalate(managerId, r.NewSlaDueAtUtc);
        db.AuditEvents.Add(new AuditEvent
        {
            OrderId = task.OrderId,
            TaskId = task.Id,
            Action = "SlaEscalated",
            UserId = "system",
            DataJson = $"{{\"attempt\":{r.Attempt},\"escalatedTo\":\"{managerId}\"}}"
        });
        await db.SaveChangesAsync(ct);

        await notifier.NotifyTaskChangedAsync(task, "escalated", ct);
        logger.LogWarning("Escalated task {TaskId} for order {OrderId} (attempt {Attempt}) to {Manager}",
            task.Id, task.OrderId, r.Attempt, managerId);
        return Result.Success();
    }

    public async Task<Result> FinalizeAsync(FinalizeOrderRequest r, CancellationToken ct)
    {
        var order = await db.Orders.FirstOrDefaultAsync(o => o.Id == r.OrderId, ct);
        if (order is null) return Result.Failure("Order not found", "order_not_found");

        order.Advance(OrderStatus.Validated);
        order.Advance(OrderStatus.Finalized);

        // Outbox: reliably publish OrderFinalized within the same transaction.
        db.Outbox.Add(new OutboxMessage
        {
            Type = nameof(OrderFinalized),
            CorrelationId = order.CorrelationId,
            Payload = System.Text.Json.JsonSerializer.Serialize(
                new OrderFinalized(order.Id, order.CustomerId, DateTimeOffset.UtcNow))
        });
        db.AuditEvents.Add(new AuditEvent { OrderId = order.Id, Action = r.Approved ? "OrderFinalized" : "OrderRejected", UserId = r.ValidatedByUserId });

        var ledger = await db.IntakeLedger.FirstOrDefaultAsync(x => x.CorrelationId == order.CorrelationId, ct);
        if (ledger is not null)
            ledger.Status = IntakeStatus.Finalized;

        await db.SaveChangesAsync(ct);

        logger.LogInformation("Finalized order {OrderId} approved={Approved}", order.Id, r.Approved);
        return Result.Success();
    }

    public async Task RecordIntakeAsync(RecordIntakeRequest r, CancellationToken ct)
    {
        var existing = await db.IntakeLedger.FirstOrDefaultAsync(x => x.GraphMessageId == r.GraphMessageId, ct);
        if (existing is not null) return;

        db.IntakeLedger.Add(new IntakeLedgerEntry
        {
            GraphMessageId = r.GraphMessageId,
            Mailbox = r.Mailbox,
            CustomerId = r.CustomerId,
            Priority = r.Priority,
            CorrelationId = r.CorrelationId,
            Status = IntakeStatus.Received
        });
        await db.SaveChangesAsync(ct);
    }

    public async Task UpdateIntakeStatusAsync(UpdateIntakeStatusRequest r, CancellationToken ct)
    {
        var entry = await db.IntakeLedger.FirstOrDefaultAsync(x => x.GraphMessageId == r.GraphMessageId, ct);
        if (entry is null) return;

        entry.Status = r.Status;
        if (r.Status == IntakeStatus.Published && entry.PublishedAtUtc is null)
            entry.PublishedAtUtc = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(ct);
    }

    public async Task<IReadOnlyList<IntakeLedgerEntry>> GetStaleIntakeAsync(TimeSpan olderThan, CancellationToken ct)
    {
        var cutoff = DateTimeOffset.UtcNow.Subtract(olderThan);
        return await db.IntakeLedger.AsNoTracking()
            .Where(x => (x.Status == IntakeStatus.Received || x.Status == IntakeStatus.Published)
                        && x.ReceivedAtUtc < cutoff)
            .OrderBy(x => x.ReceivedAtUtc)
            .Take(200)
            .ToListAsync(ct);
    }
}
