using System.Security.Claims;
using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.OrderApi.Services;

/// <summary>
/// Resolves the authenticated &amp; Identity-verified user's id, role, and manager scope from claims.
/// </summary>
public sealed class CurrentUser(IHttpContextAccessor accessor)
{
    private ClaimsPrincipal? Principal => accessor.HttpContext?.User;

    public string Id =>
        Principal?.FindFirstValue(OrderFlowIdentityConstants.ClaimObjectId)
        ?? Principal?.FindFirstValue("http://schemas.microsoft.com/identity/claims/objectidentifier")
        ?? Principal?.FindFirstValue(ClaimTypes.NameIdentifier)
        ?? Principal?.FindFirstValue("sub")
        ?? "anonymous";

    public string DisplayName => Principal?.FindFirstValue("name") ?? Id;

    public string? ManagerId => Principal?.FindFirstValue(OrderFlowIdentityConstants.ClaimManagerId);

    public bool IsAdGroupVerified =>
        string.Equals(Principal?.FindFirstValue(OrderFlowIdentityConstants.ClaimAdGroupVerified), "true", StringComparison.OrdinalIgnoreCase);

    public bool HasValidRole =>
        Principal?.IsInRole(OrderFlowIdentityConstants.RoleManager) == true
        || Principal?.IsInRole(OrderFlowIdentityConstants.RoleReportee) == true;

    public UserRole Role
    {
        get
        {
            if (Principal?.IsInRole(OrderFlowIdentityConstants.RoleManager) == true)
                return UserRole.Manager;
            if (Principal?.IsInRole(OrderFlowIdentityConstants.RoleReportee) == true)
                return UserRole.Reportee;
            throw new UnauthorizedAccessException("Current user does not hold an authorized OrderFlow role.");
        }
    }

    public bool IsManager => Principal?.IsInRole(OrderFlowIdentityConstants.RoleManager) == true;
}
