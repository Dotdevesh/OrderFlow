using Microsoft.AspNetCore.SignalR;
using OrderFlow.Domain;
using OrderFlow.OrderApi.Hubs;

namespace OrderFlow.OrderApi.Services;

public interface ITaskNotifier
{
    Task NotifyTaskCreatedAsync(ValidationTask task, Order order, CancellationToken ct);
    Task NotifyTaskChangedAsync(ValidationTask task, string action, CancellationToken ct);
}

public sealed class SignalRTaskNotifier(IHubContext<TasksHub> hub) : ITaskNotifier
{
    public Task NotifyTaskCreatedAsync(ValidationTask task, Order order, CancellationToken ct) =>
        hub.Clients.Group($"team:{task.TeamManagerId}").SendAsync("taskCreated", new
        {
            task.Id, task.OrderId, order.CustomerId, Priority = (int)task.Priority,
            order.SubjectLine, task.SlaDueAtUtc
        }, ct);

    public Task NotifyTaskChangedAsync(ValidationTask task, string action, CancellationToken ct) =>
        hub.Clients.Group($"team:{task.TeamManagerId}").SendAsync("taskChanged", new
        {
            task.Id, task.OrderId, Status = task.Status.ToString(), action,
            task.AssignedToUserId, task.SlaDueAtUtc
        }, ct);
}
