using System.Net.Http.Json;
using Microsoft.Extensions.Options;
using OrderFlow.Contracts;

namespace OrderFlow.OrderApi.Services;

public sealed class DurableTaskOptions
{
    public const string Section = "DurableTask";
    /// <summary>Base URL of the Orchestrator Function app, e.g. https://orderflow-orch.azurewebsites.net</summary>
    public string BaseUrl { get; set; } = "http://localhost:7072";
    /// <summary>Durable task system key (webhook auth). Injected from Key Vault / app settings.</summary>
    public string? SystemKey { get; set; }
    public const string EventName = "ValidationCompleted";
}

/// <summary>
/// Raises the external event through the Durable Functions HTTP management API:
/// POST {base}/runtime/webhooks/durabletask/instances/{instanceId}/raiseEvent/{eventName}
/// </summary>
public sealed class DurableHttpWorkflowClient(
    HttpClient http,
    IOptions<DurableTaskOptions> options,
    ILogger<DurableHttpWorkflowClient> logger) : IWorkflowClient
{
    private readonly DurableTaskOptions _opts = options.Value;

    public async Task RaiseValidationCompletedAsync(string instanceId, ValidationCompletedPayload payload, CancellationToken ct = default)
    {
        var url = $"{_opts.BaseUrl.TrimEnd('/')}/runtime/webhooks/durabletask/instances/{instanceId}/raiseEvent/{DurableTaskOptions.EventName}";
        if (!string.IsNullOrEmpty(_opts.SystemKey))
            url += $"?code={_opts.SystemKey}";

        var response = await http.PostAsJsonAsync(url, payload, ct);
        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            logger.LogError("RaiseEvent to {InstanceId} failed: {Status} {Body}", instanceId, response.StatusCode, body);
            response.EnsureSuccessStatusCode();
        }
        logger.LogInformation("Raised ValidationCompleted for instance {InstanceId}", instanceId);
    }
}
