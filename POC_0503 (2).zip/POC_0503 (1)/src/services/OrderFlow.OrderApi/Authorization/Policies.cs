using Microsoft.AspNetCore.Authorization;
using OrderFlow.Contracts;

namespace OrderFlow.OrderApi.Authorization;

public static class Policies
{
    /// <summary>Authenticated validator who belongs to an authorized AD group AND holds an assigned Role in DB.</summary>
    public const string Validator = "Validator";
    /// <summary>Manager-only operations: assign, delegate, team view, escalations (requires AD group + Manager role).</summary>
    public const string ManagerOnly = "ManagerOnly";
    /// <summary>Service-to-service (Orchestrator / EmailIntake) internal endpoints.</summary>
    public const string Internal = "Internal";

    public static AuthorizationBuilder AddOrderFlowPolicies(this AuthorizationBuilder builder) =>
        builder
            .AddPolicy(Validator, p => p
                .RequireAuthenticatedUser()
                .RequireClaim(OrderFlowIdentityConstants.ClaimAdGroupVerified, "true")
                .RequireClaim(OrderFlowIdentityConstants.ClaimDbRoleVerified, "true")
                .RequireRole(OrderFlowIdentityConstants.RoleManager, OrderFlowIdentityConstants.RoleReportee))
            .AddPolicy(ManagerOnly, p => p
                .RequireAuthenticatedUser()
                .RequireClaim(OrderFlowIdentityConstants.ClaimAdGroupVerified, "true")
                .RequireClaim(OrderFlowIdentityConstants.ClaimDbRoleVerified, "true")
                .RequireRole(OrderFlowIdentityConstants.RoleManager))
            .AddPolicy(Internal, p => p.RequireAssertion(ctx =>
            {
                var http = ctx.Resource as HttpContext;
                var cfg = http?.RequestServices.GetService<IConfiguration>();
                var env = http?.RequestServices.GetService<IHostEnvironment>();
                var internalApiKey = cfg?["InternalAuth:ApiKey"];
                var entraAuthority = cfg?["Entra:Authority"];
                var s2sSecret = cfg?["Identity:ServiceSharedSecret"];

                // 1) Entra Managed Identity / Client Credentials JWT or IdentityApi S2S token
                if (ctx.User.Identity?.IsAuthenticated == true
                    && ctx.User.IsInRole(OrderFlowIdentityConstants.RoleInternalService))
                {
                    return true;
                }

                // 2) Explicit X-Internal-ApiKey fallback if configured
                if (!string.IsNullOrWhiteSpace(internalApiKey)
                    && http is not null
                    && http.Request.Headers.TryGetValue("X-Internal-ApiKey", out var header)
                    && string.Equals(header.FirstOrDefault(), internalApiKey, StringComparison.Ordinal))
                {
                    return true;
                }

                // 3) Local development convenience ONLY when neither Entra nor S2S secret nor ApiKey is configured
                return env?.IsDevelopment() == true
                       && string.IsNullOrWhiteSpace(entraAuthority)
                       && string.IsNullOrWhiteSpace(s2sSecret)
                       && string.IsNullOrWhiteSpace(internalApiKey);
            }));
}
