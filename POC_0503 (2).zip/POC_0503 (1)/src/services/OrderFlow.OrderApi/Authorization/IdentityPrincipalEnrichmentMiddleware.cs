using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.Contracts;
using OrderFlow.Domain;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Authorization;

/// <summary>
/// Enriches incoming user principals by verifying AD Security Group membership and App Role
/// assignment against <c>OrderFlow.IdentityApi</c> (or the synced <c>dbo.Users</c> projection when
/// running standalone locally). Immediately strips access if a user is missing AD group or role.
/// </summary>
public sealed class IdentityPrincipalEnrichmentMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(
        HttpContext context,
        OrderFlowDbContext db,
        IServiceProvider services)
    {
        var identityClient = services.GetService<IIdentityServiceClient>();
        var principal = context.User;
        if (principal.Identity?.IsAuthenticated == true
            && principal.Identity is ClaimsIdentity claimsIdentity
            && !IsServicePrincipal(principal)
            && !string.Equals(claimsIdentity.AuthenticationType, DevAuthenticationHandler.SchemeName, StringComparison.Ordinal))
        {
            await VerifyAndEnrichUserAsync(claimsIdentity, principal, db, identityClient, context.RequestAborted);
        }

        await next(context);
    }

    private static bool IsServicePrincipal(ClaimsPrincipal principal) =>
        string.Equals(
            principal.FindFirstValue(OrderFlowIdentityConstants.ClaimTokenKind),
            OrderFlowIdentityConstants.TokenKindService,
            StringComparison.OrdinalIgnoreCase)
        || principal.IsInRole(OrderFlowIdentityConstants.RoleInternalService);

    private static async Task VerifyAndEnrichUserAsync(
        ClaimsIdentity identity,
        ClaimsPrincipal principal,
        OrderFlowDbContext db,
        IIdentityServiceClient? identityClient,
        CancellationToken ct)
    {
        var oid = principal.FindFirstValue(OrderFlowIdentityConstants.ClaimObjectId)
                  ?? principal.FindFirstValue("http://schemas.microsoft.com/identity/claims/objectidentifier")
                  ?? principal.FindFirstValue(ClaimTypes.NameIdentifier)
                  ?? principal.FindFirstValue("sub");

        var upn = principal.FindFirstValue(OrderFlowIdentityConstants.ClaimUpn)
                  ?? principal.FindFirstValue(ClaimTypes.Upn)
                  ?? principal.FindFirstValue("upn")
                  ?? principal.FindFirstValue("email");

        var name = principal.FindFirstValue("name") ?? principal.Identity?.Name;
        var win = principal.FindFirstValue(OrderFlowIdentityConstants.ClaimWindowsAccount);

        var tokenRoles = principal.FindAll("roles").Select(c => c.Value)
            .Concat(principal.FindAll(ClaimTypes.Role).Select(c => c.Value))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var tokenGroups = principal.FindAll(OrderFlowIdentityConstants.ClaimGroupId).Select(c => c.Value)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (identityClient is not null)
        {
            var evaluated = await identityClient.IntrospectUserAsync(
                new IntrospectUserRequest(oid, upn, win, name, tokenRoles, tokenGroups, identity.AuthenticationType ?? "Jwt"),
                ct);

            ApplyEvaluationToClaims(identity, evaluated.IsAuthorized, evaluated.UserId, evaluated.DisplayName, evaluated.Role, evaluated.ManagerId);
            return;
        }

        // Standalone fallback when IdentityApi URL is not configured: check synced dbo.Users projection
        AppUser? dbUser = null;
        if (!string.IsNullOrWhiteSpace(oid))
            dbUser = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == oid, ct);
        if (dbUser is null && !string.IsNullOrWhiteSpace(upn))
            dbUser = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Upn == upn || u.Email == upn, ct);

        if (dbUser is null || !dbUser.IsActive || !dbUser.IsInAuthorizedGroup)
        {
            ApplyEvaluationToClaims(identity, isAuthorized: false, oid, name, null, null);
            return;
        }

        ApplyEvaluationToClaims(identity, isAuthorized: true, dbUser.Id, dbUser.DisplayName, dbUser.Role, dbUser.ManagerId);
    }

    private static void ApplyEvaluationToClaims(
        ClaimsIdentity identity,
        bool isAuthorized,
        string? canonicalUserId,
        string? displayName,
        UserRole? verifiedRole,
        string? managerId)
    {
        // Remove any untrusted/stale role or verification claims from the raw token before stamping DB-verified values
        foreach (var c in identity.FindAll(c =>
                     c.Type == ClaimTypes.Role ||
                     c.Type == "roles" ||
                     c.Type == OrderFlowIdentityConstants.ClaimAdGroupVerified ||
                     c.Type == OrderFlowIdentityConstants.ClaimDbRoleVerified ||
                     c.Type == OrderFlowIdentityConstants.ClaimManagerId).ToList())
        {
            identity.RemoveClaim(c);
        }

        if (!isAuthorized || verifiedRole is null)
        {
            identity.AddClaim(new Claim(OrderFlowIdentityConstants.ClaimAdGroupVerified, "false"));
            identity.AddClaim(new Claim(OrderFlowIdentityConstants.ClaimDbRoleVerified, "false"));
            return;
        }

        if (!string.IsNullOrWhiteSpace(canonicalUserId) && identity.FindFirst(OrderFlowIdentityConstants.ClaimObjectId) is null)
            identity.AddClaim(new Claim(OrderFlowIdentityConstants.ClaimObjectId, canonicalUserId));

        if (!string.IsNullOrWhiteSpace(displayName) && identity.FindFirst("name") is null)
            identity.AddClaim(new Claim("name", displayName));

        if (!string.IsNullOrWhiteSpace(managerId))
            identity.AddClaim(new Claim(OrderFlowIdentityConstants.ClaimManagerId, managerId));

        var roleName = verifiedRole == UserRole.Manager
            ? OrderFlowIdentityConstants.RoleManager
            : OrderFlowIdentityConstants.RoleReportee;

        identity.AddClaim(new Claim("roles", roleName));
        identity.AddClaim(new Claim(ClaimTypes.Role, roleName));
        identity.AddClaim(new Claim(OrderFlowIdentityConstants.ClaimAdGroupVerified, "true"));
        identity.AddClaim(new Claim(OrderFlowIdentityConstants.ClaimDbRoleVerified, "true"));
    }
}
