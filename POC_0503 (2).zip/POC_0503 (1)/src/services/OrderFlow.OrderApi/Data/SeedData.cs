using Microsoft.EntityFrameworkCore;
using OrderFlow.Domain;

namespace OrderFlow.OrderApi.Data;

/// <summary>Seeds demo customers and users (manager + reportees) for local development.</summary>
public static class SeedData
{
    public static async Task EnsureSeededAsync(OrderFlowDbContext db, CancellationToken ct = default)
    {
        await db.Database.EnsureCreatedAsync(ct);

        if (!await db.Customers.AnyAsync(ct))
        {
            db.Customers.AddRange(
                new CustomerProfile { CustomerId = "acme", DisplayName = "Acme Corp (Platinum)", Tier = CustomerTier.Platinum, SlaMinutes = 15, EscalationIntervalMinutes = 5, SenderDomains = { "acme.com" } },
                new CustomerProfile { CustomerId = "globex", DisplayName = "Globex (Gold)", Tier = CustomerTier.Gold, SlaMinutes = 60, EscalationIntervalMinutes = 20, SenderDomains = { "globex.com" } },
                new CustomerProfile { CustomerId = "initech", DisplayName = "Initech (Silver)", Tier = CustomerTier.Silver, SlaMinutes = 240, EscalationIntervalMinutes = 60, SenderDomains = { "initech.com" } },
                // Title-insurance customers driven by their code-first entity classes (OrderFlow.CustomerModel).
                new CustomerProfile { CustomerId = "acme-title", DisplayName = "Acme Title (Platinum)", Tier = CustomerTier.Platinum, SlaMinutes = 20, EscalationIntervalMinutes = 10, SenderDomains = { "acmetitle.com" } },
                new CustomerProfile { CustomerId = "first-national", DisplayName = "First National Title (Gold)", Tier = CustomerTier.Gold, SlaMinutes = 90, EscalationIntervalMinutes = 30, SenderDomains = { "fntitle.com" } });
        }

        if (!await db.Users.AnyAsync(ct))
        {
            db.Users.AddRange(
                new AppUser { Id = "mgr-1", DisplayName = "Morgan (Manager)", Email = "morgan@contoso.com", Role = UserRole.Manager },
                new AppUser { Id = "rep-1", DisplayName = "Riley (Reportee)", Email = "riley@contoso.com", Role = UserRole.Reportee, ManagerId = "mgr-1" },
                new AppUser { Id = "rep-2", DisplayName = "Jordan (Reportee)", Email = "jordan@contoso.com", Role = UserRole.Reportee, ManagerId = "mgr-1" });
        }

        await db.SaveChangesAsync(ct);
    }
}
