using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace OrderFlow.OrderApi.Hubs;

/// <summary>Realtime channel for task inbox updates and SLA countdowns.</summary>
[Authorize]
public sealed class TasksHub : Hub
{
    // Clients join a group per team so managers/reportees receive scoped updates.
    public Task JoinTeam(string teamManagerId) =>
        Groups.AddToGroupAsync(Context.ConnectionId, $"team:{teamManagerId}");
}
