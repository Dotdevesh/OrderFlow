using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.BuildingBlocks.Health;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.BuildingBlocks.Messaging;
using OrderFlow.CustomerModel;
using OrderFlow.Observability;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Data;
using OrderFlow.OrderApi.Endpoints;
using OrderFlow.OrderApi.Hubs;
using OrderFlow.OrderApi.Services;

var builder = WebApplication.CreateBuilder(args);
var cfg = builder.Configuration;

// ---------- Telemetry: traces, metrics, and logs through one OpenTelemetry pipeline ----------
builder.AddOrderFlowObservability("OrderApi");
builder.Services.AddOrderFlowAzureCredentials();

// ---------- Persistence ----------
builder.Services.AddDbContext<OrderFlowDbContext>(o =>
    o.UseSqlServer(cfg.GetConnectionString("Sql")
        ?? "Server=(localdb)\\mssqllocaldb;Database=OrderFlow;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=true",
        sql => sql.EnableRetryOnFailure(          // transient SQL fault resilience
            maxRetryCount: 6,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null)));

// ---------- Identity Microservice & S2S Configuration ----------
builder.Services.AddOptions<IdentityClientOptions>()
    .Configure<IConfiguration>((opts, config) =>
    {
        config.GetSection(IdentityClientOptions.Section).Bind(opts);
        opts.ServiceName = "OrderApi";
        if (string.IsNullOrWhiteSpace(opts.FallbackInternalApiKey))
            opts.FallbackInternalApiKey = config["InternalAuth:ApiKey"];
    });
builder.Services.AddTransient<ServiceToServiceBearerHandler>();

if (!string.IsNullOrWhiteSpace(cfg["Identity:BaseUrl"]))
{
    builder.Services.AddHttpClient<IIdentityServiceClient, HttpIdentityServiceClient>((sp, c) =>
    {
        var liveCfg = sp.GetRequiredService<IConfiguration>();
        c.BaseAddress = new Uri(liveCfg["Identity:BaseUrl"]!);
        c.Timeout = TimeSpan.FromSeconds(10);
    })
    .AddHttpMessageHandler<ServiceToServiceBearerHandler>()
    .AddHttpMessageHandler<CorrelationIdPropagationHandler>();
}

// ---------- AuthN: Entra (JWT) + IdentityApi Windows/S2S JWT (+ Dev locally) ----------
var authority = cfg["Entra:Authority"];
if (!builder.Environment.IsDevelopment() && string.IsNullOrWhiteSpace(authority))
{
    throw new InvalidOperationException(
        "Entra:Authority is required outside Development; the dev authentication handler is local-only.");
}

static string? ExtractBearerOrHubToken(HttpContext ctx)
{
    var authHeader = ctx.Request.Headers.Authorization.FirstOrDefault();
    if (!string.IsNullOrWhiteSpace(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        return authHeader["Bearer ".Length..].Trim();

    if (ctx.Request.Path.StartsWithSegments("/hubs/tasks")
        && ctx.Request.Query.TryGetValue("access_token", out var hubToken)
        && !string.IsNullOrWhiteSpace(hubToken))
    {
        return hubToken.ToString();
    }

    return null;
}

var authBuilder = builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = "OrderFlowSmartAuth";
    options.DefaultChallengeScheme = "OrderFlowSmartAuth";
})
.AddPolicyScheme("OrderFlowSmartAuth", "Routes Entra JWT, IdentityApi JWT, or Local Dev Auth", options =>
{
    options.ForwardDefaultSelector = ctx =>
    {
        var liveCfg = ctx.RequestServices.GetRequiredService<IConfiguration>();
        var liveEnv = ctx.RequestServices.GetRequiredService<IHostEnvironment>();
        var liveAuthority = liveCfg["Entra:Authority"];
        var liveInternalIssuer = liveCfg["Identity:InternalJwtIssuer"] ?? "https://identity.orderflow.internal";

        var rawToken = ExtractBearerOrHubToken(ctx);
        if (!string.IsNullOrWhiteSpace(rawToken))
        {
            var jwtReader = new Microsoft.IdentityModel.JsonWebTokens.JsonWebTokenHandler();
            if (jwtReader.CanReadToken(rawToken))
            {
                var jwt = jwtReader.ReadJsonWebToken(rawToken);
                if (string.Equals(jwt.Issuer, liveInternalIssuer, StringComparison.OrdinalIgnoreCase))
                    return "InternalIdentityJwt";
            }

            return !string.IsNullOrWhiteSpace(liveAuthority)
                ? JwtBearerDefaults.AuthenticationScheme
                : "InternalIdentityJwt";
        }

        // Only use Dev impersonation when S2S/Entra auth is not active
        if (liveEnv.IsDevelopment()
            && string.IsNullOrWhiteSpace(liveAuthority)
            && (!ctx.Request.Path.StartsWithSegments("/internal") || string.IsNullOrWhiteSpace(liveCfg["Identity:ServiceSharedSecret"])))
        {
            return DevAuthenticationHandler.SchemeName;
        }

        return !string.IsNullOrWhiteSpace(liveAuthority)
            ? JwtBearerDefaults.AuthenticationScheme
            : "InternalIdentityJwt";
    };
})
.AddJwtBearer("InternalIdentityJwt");

builder.Services.AddOptions<JwtBearerOptions>("InternalIdentityJwt")
    .Configure<IConfiguration>((options, config) =>
    {
        var issuer = config["Identity:InternalJwtIssuer"] ?? "https://identity.orderflow.internal";
        var signingKey = config["Identity:InternalJwtSigningKey"] ?? "orderflow-local-dev-signing-key-minimum-32-bytes!";

        options.MapInboundClaims = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = issuer,
            ValidateAudience = false,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            RoleClaimType = "roles",
            NameClaimType = "name"
        };
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = ctx =>
            {
                if (ctx.Request.Path.StartsWithSegments("/hubs/tasks")
                    && ctx.Request.Query.TryGetValue("access_token", out var accessToken))
                {
                    ctx.Token = accessToken;
                }
                return Task.CompletedTask;
            }
        };
    });

if (!string.IsNullOrWhiteSpace(authority))
{
    authBuilder.AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
    {
        options.Authority = authority;
        options.Audience = cfg["Entra:Audience"];
        options.MapInboundClaims = false;
        options.TokenValidationParameters.RoleClaimType = "roles";
        options.TokenValidationParameters.NameClaimType = "name";
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = ctx =>
            {
                if (ctx.Request.Path.StartsWithSegments("/hubs/tasks")
                    && ctx.Request.Query.TryGetValue("access_token", out var accessToken))
                {
                    ctx.Token = accessToken;
                }
                return Task.CompletedTask;
            }
        };
    });
}
else if (builder.Environment.IsDevelopment())
{
    authBuilder.AddScheme<AuthenticationSchemeOptions, DevAuthenticationHandler>(DevAuthenticationHandler.SchemeName, _ => { });
}

builder.Services.AddAuthorizationBuilder().AddOrderFlowPolicies();

// ---------- Optional Service Bus publisher for OutboxDispatcher ----------
var serviceBusConfigured = builder.Services.TryAddOrderFlowServiceBusClient(cfg);
if (serviceBusConfigured)
    builder.Services.AddSingleton<IEventPublisher, ServiceBusEventPublisher>();

// ---------- Realtime ----------
builder.Services.AddSignalR();

// ---------- Blob storage ----------
builder.Services.AddOrderFlowBlobDocumentStore();

// ---------- Durable workflow client (resume orchestrations via S2S auth) ----------
builder.Services.Configure<DurableTaskOptions>(cfg.GetSection(DurableTaskOptions.Section));
builder.Services.AddHttpClient<IWorkflowClient, DurableHttpWorkflowClient>()
    .AddHttpMessageHandler<ServiceToServiceBearerHandler>()
    .AddHttpMessageHandler<CorrelationIdPropagationHandler>();

// ---------- Application services ----------
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<CurrentUser>();
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<ITaskService, TaskService>();
builder.Services.AddCustomerSchemas();
builder.Services.AddScoped<ITaskNotifier, SignalRTaskNotifier>();
builder.Services.AddHostedService<OutboxDispatcher>();

builder.Services.AddProblemDetails();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .WithOrigins(cfg.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:4200"])
    .AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

// ---------- Health: liveness is the process, readiness is SQL plus whatever else is configured ----------
var healthChecks = builder.Services.AddOrderFlowHealthChecks("OrderApi");
healthChecks.AddDbContextCheck<OrderFlowDbContext>("sql", tags: [HealthTags.Ready]);
healthChecks.AddBlobStorage();
if (serviceBusConfigured)
    healthChecks.AddServiceBus();
if (!string.IsNullOrWhiteSpace(cfg["Identity:BaseUrl"]))
    healthChecks.AddHttpDependency("identity-api", cfg["Identity:BaseUrl"]!);

var app = builder.Build();

if (!app.Environment.IsDevelopment())
    app.UseExceptionHandler();
app.UseOrderFlowCorrelationId();
app.UseCors();
app.UseAuthentication();
app.UseMiddleware<IdentityPrincipalEnrichmentMiddleware>();
app.UseAuthorization();

app.MapOrderFlowHealthEndpoints("OrderApi");

app.MapInternalEndpoints();
app.MapTaskEndpoints();
app.MapDocumentEndpoints();
app.MapCustomerEndpoints();
app.MapUserEndpoints();
app.MapHub<TasksHub>("/hubs/tasks");

// ---------- Dev: ensure DB + seed ----------
if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<OrderFlowDbContext>();
    try { await SeedData.EnsureSeededAsync(db); }
    catch (Exception ex) { app.Logger.LogWarning(ex, "DB seed skipped (no SQL available in this environment)."); }
}

app.Run();

namespace OrderFlow.OrderApi
{
    /// <summary><c>WebApplicationFactory&lt;OrderApiMarker&gt;</c> anchor for integration tests.</summary>
    public sealed class OrderApiMarker;
}
