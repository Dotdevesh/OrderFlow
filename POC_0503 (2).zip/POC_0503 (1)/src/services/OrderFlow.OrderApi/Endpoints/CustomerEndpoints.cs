using Microsoft.EntityFrameworkCore;
using OrderFlow.Contracts;
using OrderFlow.CustomerModel;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Endpoints;

/// <summary>Customer list (for the Action Center customer selector) and per-customer form templates.</summary>
public static class CustomerEndpoints
{
    public static IEndpointRouteBuilder MapCustomerEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/customers").WithTags("Customers").RequireAuthorization(Policies.Validator);

        // Customers the signed-in user may work on. (POC: all customers; production scopes by team.)
        group.MapGet("/", async (OrderFlowDbContext db, CancellationToken ct) =>
        {
            var customers = await db.Customers.AsNoTracking()
                .OrderBy(c => c.Tier).ThenBy(c => c.DisplayName)
                .Select(c => new CustomerDto(c.CustomerId, c.DisplayName, (int)c.Tier, (int)c.Priority, c.SlaMinutes))
                .ToListAsync(ct);
            return Results.Ok(customers);
        });

        // Resolved form template for the dynamic validation form, built from the customer's
        // code-first entity class (OrderFlow.CustomerModel). This is the single source of truth:
        // the same class drives both rendering here and extraction in the orchestrator.
        group.MapGet("/{customerId}/form-template", (string customerId, ICustomerSchemaRegistry schemas) =>
            schemas.Describe(customerId) is { } schema
                ? Results.Ok(schema.Template)
                : Results.NotFound(new { error = $"No schema class registered for customer '{customerId}'." }));

        return app;
    }
}
