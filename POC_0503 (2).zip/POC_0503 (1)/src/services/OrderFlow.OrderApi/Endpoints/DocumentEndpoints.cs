using Microsoft.EntityFrameworkCore;
using OrderFlow.BuildingBlocks.Storage;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Endpoints;

/// <summary>Issues short-lived read SAS URLs so the SPA can render PDFs directly from Blob.</summary>
public static class DocumentEndpoints
{
    public static IEndpointRouteBuilder MapDocumentEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/documents/{orderId:guid}/{docId:guid}/sas",
            async (Guid orderId, Guid docId, OrderFlowDbContext db, IBlobDocumentStore blobs, IConfiguration cfg, CancellationToken ct) =>
            {
                var doc = await db.OrderDocuments.AsNoTracking()
                    .FirstOrDefaultAsync(d => d.Id == docId && d.OrderId == orderId, ct);
                if (doc is null) return Results.NotFound();

                var uri = await blobs.GetReadSasAsync(doc.BlobPath, TimeSpan.FromMinutes(10), ct);

                // When running OrderApi inside Docker against Azurite, the SAS URI uses the internal
                // container hostname (e.g. http://azurite:10000/...). Rewrite to PublicBlobBaseUrl
                // (e.g. http://localhost:10000) so the user's browser can fetch the PDF directly.
                var publicBase = cfg["Storage:PublicBlobBaseUrl"];
                if (!string.IsNullOrWhiteSpace(publicBase) && Uri.TryCreate(publicBase, UriKind.Absolute, out var pub))
                {
                    uri = new UriBuilder(uri)
                    {
                        Scheme = pub.Scheme,
                        Host = pub.Host,
                        Port = pub.Port
                    }.Uri;
                }

                return Results.Ok(new { url = uri.ToString(), doc.FileName, doc.ContentType });
            })
            .WithTags("Documents")
            .RequireAuthorization(Policies.Validator);

        return app;
    }
}
