using OrderFlow.Contracts;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Services;

namespace OrderFlow.OrderApi.Endpoints;

/// <summary>Action Center task inbox + validation operations.</summary>
public static class TaskEndpoints
{
    public static IEndpointRouteBuilder MapTaskEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/tasks").WithTags("Tasks").RequireAuthorization(Policies.Validator);

        group.MapGet("/", async (string? scope, string? customerId, int? status, ITaskService svc, CancellationToken ct) =>
            Results.Ok(await svc.GetInboxAsync(scope ?? "mine", customerId, status, ct)));

        group.MapGet("/{id:guid}", async (Guid id, ITaskService svc, CancellationToken ct) =>
        {
            var r = await svc.GetDetailAsync(id, ct);
            return r.IsSuccess ? Results.Ok(r.Value) : Results.NotFound(new { r.Error, r.Code });
        });

        group.MapPost("/{id:guid}/open", async (Guid id, ITaskService svc, CancellationToken ct) =>
            Respond(await svc.OpenAsync(id, ct)));

        group.MapPost("/{id:guid}/claim", async (Guid id, ITaskService svc, CancellationToken ct) =>
            Respond(await svc.ClaimAsync(id, ct)));

        // Manager-only: assign a new task to a team member.
        group.MapPost("/{id:guid}/assign", async (Guid id, AssignRequest body, ITaskService svc, CancellationToken ct) =>
            Respond(await svc.AssignAsync(id, body.TargetUserId, ct)))
            .RequireAuthorization(Policies.ManagerOnly);

        // Manager-only: delegate (reassign) an existing task.
        group.MapPost("/{id:guid}/delegate", async (Guid id, AssignRequest body, ITaskService svc, CancellationToken ct) =>
            Respond(await svc.DelegateAsync(id, body.TargetUserId, ct)))
            .RequireAuthorization(Policies.ManagerOnly);

        // Submit = the human-in-the-loop RESUME point.
        // ValidationCompleted is persisted in the Outbox atomically with task completion; we also
        // raise immediately for low latency and fall back to OutboxDispatcher if Orchestrator is down.
        group.MapPost("/{id:guid}/submit", async (
            Guid id, SubmitValidationRequest body, ITaskService svc, IWorkflowClient workflow,
            ILoggerFactory loggerFactory, CancellationToken ct) =>
        {
            var result = await svc.SubmitAsync(id, body, ct);
            if (result.IsFailure || result.Value is null)
                return Results.BadRequest(new { result.Error, result.Code });

            try
            {
                await workflow.RaiseValidationCompletedAsync(
                    result.Value.OrchestrationInstanceId, result.Value.Payload, ct);
                await svc.MarkOutboxDispatchedAsync(result.Value.OutboxMessageId, ct);
                return Results.Ok(new { resumedImmediately = true });
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                loggerFactory.CreateLogger("TaskSubmit").LogWarning(ex,
                    "Immediate RaiseEvent failed for {Instance}; OutboxDispatcher will retry message {OutboxId}.",
                    result.Value.OrchestrationInstanceId, result.Value.OutboxMessageId);
                return Results.Accepted(value: new { resumedImmediately = false, queuedInOutbox = true });
            }
        });

        return app;
    }

    private static IResult Respond(OrderFlow.BuildingBlocks.Result r) =>
        r.IsSuccess ? Results.Ok() : Results.BadRequest(new { r.Error, r.Code });
}
