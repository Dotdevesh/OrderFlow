using Microsoft.EntityFrameworkCore;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.Contracts;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Data;

namespace OrderFlow.OrderApi.Endpoints;

/// <summary>Team member directory for Manager assign / delegate pickers in the Action Center.</summary>
public static class UserEndpoints
{
    public static IEndpointRouteBuilder MapUserEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/users", async (
            OrderFlowDbContext db,
            IServiceProvider services,
            CancellationToken ct) =>
        {
            var identityClient = services.GetService<IIdentityServiceClient>();
            if (identityClient is not null)
            {
                var syncedUsers = await identityClient.GetAuthorizedUsersAsync(ct);
                return Results.Ok(syncedUsers);
            }

            var users = await db.Users.AsNoTracking()
                .Where(u => u.IsActive && u.IsInAuthorizedGroup)
                .OrderBy(u => u.Role).ThenBy(u => u.DisplayName)
                .Select(u => new UserSummaryDto(u.Id, u.DisplayName, u.Email ?? u.Upn, u.Role, u.ManagerId))
                .ToListAsync(ct);
            return Results.Ok(users);
        }).WithTags("Users").RequireAuthorization(Policies.Validator);

        return app;
    }
}
