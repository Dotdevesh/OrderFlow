using OrderFlow.Contracts;
using OrderFlow.OrderApi.Authorization;
using OrderFlow.OrderApi.Services;

namespace OrderFlow.OrderApi.Endpoints;

/// <summary>Endpoints called by the Orchestrator and EmailIntake (service-to-service).</summary>
public static class InternalEndpoints
{
    public static IEndpointRouteBuilder MapInternalEndpoints(this IEndpointRouteBuilder app)
    {
        var orders = app.MapGroup("/internal/orders")
            .WithTags("Internal")
            .RequireAuthorization(Policies.Internal);

        orders.MapPost("/", async (CreateOrderRequest req, IOrderService svc, CancellationToken ct) =>
            Results.Ok(await svc.CreateOrderAsync(req, ct)));

        orders.MapPost("/{id:guid}/validation-task", async (Guid id, CreateValidationTaskRequest req, IOrderService svc, CancellationToken ct) =>
        {
            var result = await svc.CreateValidationTaskAsync(req with { OrderId = id }, ct);
            return result.IsSuccess ? Results.Ok() : Results.BadRequest(new { result.Error, result.Code });
        });

        orders.MapPost("/{id:guid}/escalate", async (Guid id, EscalateOrderRequest req, IOrderService svc, CancellationToken ct) =>
        {
            var result = await svc.EscalateAsync(req with { OrderId = id }, ct);
            return result.IsSuccess ? Results.Ok() : Results.BadRequest(new { result.Error, result.Code });
        });

        orders.MapPost("/{id:guid}/finalize", async (Guid id, FinalizeOrderRequest req, IOrderService svc, CancellationToken ct) =>
        {
            var result = await svc.FinalizeAsync(req with { OrderId = id }, ct);
            return result.IsSuccess ? Results.Ok() : Results.BadRequest(new { result.Error, result.Code });
        });

        // Intake ledger (no-order-loss reconciliation)
        var intake = app.MapGroup("/internal/intake")
            .WithTags("Internal")
            .RequireAuthorization(Policies.Internal);

        intake.MapPost("/", async (RecordIntakeRequest req, IOrderService svc, CancellationToken ct) =>
        {
            await svc.RecordIntakeAsync(req, ct);
            return Results.Ok();
        });

        intake.MapPost("/status", async (UpdateIntakeStatusRequest req, IOrderService svc, CancellationToken ct) =>
        {
            await svc.UpdateIntakeStatusAsync(req, ct);
            return Results.Ok();
        });

        intake.MapGet("/stale", async (int? olderThanMinutes, IOrderService svc, CancellationToken ct) =>
            Results.Ok(await svc.GetStaleIntakeAsync(TimeSpan.FromMinutes(olderThanMinutes ?? 2), ct)));

        return app;
    }
}
