using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.BuildingBlocks.Health;
using OrderFlow.BuildingBlocks.Identity;
using OrderFlow.IdentitySync.Services;
using OrderFlow.Observability;

namespace OrderFlow.IdentitySync;

public static class IdentitySyncHost
{
    public static void Main(string[] args)
    {
        var builder = FunctionsApplication.CreateBuilder(args);
        builder.ConfigureFunctionsWebApplication();

        var cfg = builder.Configuration;

        // Traces, metrics, and logs through one OpenTelemetry pipeline.
        builder.AddOrderFlowObservability("IdentitySync");
        builder.Services.AddOrderFlowAzureCredentials();

        builder.Services.Configure<DirectorySyncOptions>(cfg.GetSection(DirectorySyncOptions.Section));
        builder.Services.Configure<IdentityClientOptions>(opts =>
        {
            cfg.GetSection(IdentityClientOptions.Section).Bind(opts);
            opts.ServiceName = "IdentitySync";
            if (string.IsNullOrWhiteSpace(opts.BaseUrl))
                opts.BaseUrl = cfg["IdentityApi:BaseUrl"] ?? "http://localhost:5085";
            if (string.IsNullOrWhiteSpace(opts.FallbackInternalApiKey))
                opts.FallbackInternalApiKey = cfg["IdentityApi:InternalApiKey"];
        });

        var identityBaseUrl = cfg["Identity:BaseUrl"] ?? cfg["IdentityApi:BaseUrl"] ?? "http://localhost:5085";

        builder.Services.AddTransient<ServiceToServiceBearerHandler>();
        builder.Services.AddHttpClient<IDirectorySyncApiClient, HttpDirectorySyncApiClient>(c =>
        {
            c.BaseAddress = new Uri(identityBaseUrl);
            c.Timeout = TimeSpan.FromSeconds(30);
        })
        .AddHttpMessageHandler<ServiceToServiceBearerHandler>()
        .AddHttpMessageHandler<CorrelationIdPropagationHandler>();

        builder.Services.AddSingleton<IEntraDirectoryProvider, GraphEntraDirectoryProvider>();

        builder.Services.AddOrderFlowHealthChecks("IdentitySync")
            .AddHttpDependency("identity-api", identityBaseUrl);

        builder.Build().Run();
    }
}
