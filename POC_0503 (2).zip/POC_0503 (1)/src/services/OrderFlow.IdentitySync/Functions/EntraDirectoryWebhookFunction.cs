using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrderFlow.IdentitySync.Services;

namespace OrderFlow.IdentitySync.Functions;

/// <summary>
/// Receives Microsoft Graph change notifications when AD Security Group memberships or directory
/// objects change, validates <c>clientState</c>, and immediately syncs affected groups and
/// Azure App Registration roles into <c>OrderFlow.IdentityApi</c>.
/// </summary>
public sealed class EntraDirectoryWebhookFunction(
    IEntraDirectoryProvider directoryProvider,
    IDirectorySyncApiClient syncApi,
    IConfiguration cfg,
    ILogger<EntraDirectoryWebhookFunction> logger)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    [Function("EntraDirectoryWebhook")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "graph/directory-webhook")] HttpRequest req,
        CancellationToken ct)
    {
        // 1) Microsoft Graph webhook validation handshake
        if (req.Query.TryGetValue("validationToken", out var validationToken))
        {
            logger.LogInformation("Microsoft Graph directory webhook validation handshake succeeded.");
            return new ContentResult
            {
                Content = validationToken!,
                ContentType = "text/plain",
                StatusCode = StatusCodes.Status200OK
            };
        }

        using var reader = new StreamReader(req.Body);
        var body = await reader.ReadToEndAsync(ct);
        var payload = JsonSerializer.Deserialize<GraphDirectoryNotificationPayload>(body, Json);
        if (payload?.Value is null || payload.Value.Count == 0)
            return new OkResult();

        var expectedClientState = cfg["Graph:ClientState"];
        var affectedGroupIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var validNotifications = 0;

        foreach (var item in payload.Value)
        {
            if (!string.IsNullOrWhiteSpace(expectedClientState) && item.ClientState != expectedClientState)
            {
                logger.LogWarning("Rejected Entra directory webhook notification with mismatched clientState.");
                continue;
            }

            validNotifications++;
            var groupId = TryExtractGroupId(item.Resource);
            if (!string.IsNullOrWhiteSpace(groupId))
                affectedGroupIds.Add(groupId);
        }

        if (validNotifications == 0)
            return new AcceptedResult();

        var batch = await directoryProvider.ReadDirectoryStateAsync(
            syncSource: "GraphDirectoryWebhook",
            filterGroupIds: affectedGroupIds.Count > 0 ? affectedGroupIds : null,
            ct: ct);

        var outcome = await syncApi.PushSyncBatchAsync(batch, ct);
        logger.LogInformation(
            "Processed {Count} Entra webhook notifications -> authorized={Authorized}, revoked={Revoked}",
            validNotifications, outcome.UsersAuthorized, outcome.UsersRevoked);

        return new AcceptedResult();
    }

    private static string? TryExtractGroupId(string? resource)
    {
        if (string.IsNullOrWhiteSpace(resource)) return null;
        // Graph resource formats: "groups/{id}", "Groups/{id}/members", "/groups/{id}"
        var segments = resource.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        for (var i = 0; i < segments.Length - 1; i++)
        {
            if (string.Equals(segments[i], "groups", StringComparison.OrdinalIgnoreCase))
                return segments[i + 1];
        }
        return null;
    }

    private sealed class GraphDirectoryNotificationPayload
    {
        public List<GraphDirectoryNotificationItem>? Value { get; set; }
    }

    private sealed class GraphDirectoryNotificationItem
    {
        public string? SubscriptionId { get; set; }
        public string? ClientState { get; set; }
        public string? ChangeType { get; set; }
        public string? Resource { get; set; }
    }
}
