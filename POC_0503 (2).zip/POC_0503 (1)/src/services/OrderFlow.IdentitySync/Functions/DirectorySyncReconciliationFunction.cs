using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OrderFlow.IdentitySync.Services;

namespace OrderFlow.IdentitySync.Functions;

/// <summary>
/// Periodic reconciliation + on-demand admin trigger that:
/// 1) Syncs all watched AD Security Groups + Azure App Registration role assignments (<c>appRoleAssignedTo</c>)
///    so App Registration role changes are reflected in SQL even if no group webhook fired.
/// 2) Creates/renews Microsoft Graph change-notification subscriptions on watched AD Groups.
/// </summary>
public sealed class DirectorySyncReconciliationFunction(
    IEntraDirectoryProvider directoryProvider,
    IDirectorySyncApiClient syncApi,
    ILogger<DirectorySyncReconciliationFunction> logger)
{
    [Function("DirectoryRoleAndGroupSyncTimer")]
    public async Task RunTimer(
        [TimerTrigger("0 */15 * * * *")] TimerInfo timer,
        CancellationToken ct)
    {
        logger.LogInformation("Running scheduled Entra AD Group & App Role sync at {Now}; next={Next}",
            DateTimeOffset.UtcNow, timer.ScheduleStatus?.Next);

        var batch = await directoryProvider.ReadDirectoryStateAsync("TimerReconciliation", filterGroupIds: null, ct);
        var result = await syncApi.PushSyncBatchAsync(batch, ct);

        var groups = await syncApi.GetTrackedGroupsAsync(ct);
        await directoryProvider.EnsureGroupWebhookSubscriptionsAsync(groups, syncApi, ct);

        logger.LogInformation(
            "Scheduled directory sync complete: upserted={Upserted}, authorized={Authorized}, revoked={Revoked}",
            result.UsersUpserted, result.UsersAuthorized, result.UsersRevoked);
    }

    [Function("ManualDirectorySyncTrigger")]
    public async Task<IActionResult> RunManual(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = "sync/run")] HttpRequest req,
        CancellationToken ct)
    {
        var batch = await directoryProvider.ReadDirectoryStateAsync("ManualTrigger", filterGroupIds: null, ct);
        var result = await syncApi.PushSyncBatchAsync(batch, ct);
        return new OkObjectResult(result);
    }
}
