namespace OrderFlow.IdentitySync.Services;

public sealed class DirectorySyncOptions
{
    public const string Section = "DirectorySync";

    /// <summary>Application (Client) ID of the OrderFlow Entra App Registration whose App Roles are synced.</summary>
    public string? AppClientId { get; set; }

    /// <summary>Optional Enterprise Application (Service Principal) Object ID in Entra ID.</summary>
    public string? EnterpriseAppObjectId { get; set; }

    /// <summary>Entra Security Group Object ID required for general Action Center access.</summary>
    public string? AccessGroupId { get; set; }

    /// <summary>Entra Security Group Object ID mapped to the Manager role.</summary>
    public string? ManagerGroupId { get; set; }

    /// <summary>Entra Security Group Object ID mapped to the Reportee role.</summary>
    public string? ReporteeGroupId { get; set; }

    /// <summary>Public HTTPS URL of <c>EntraDirectoryWebhookFunction</c> registered with Microsoft Graph.</summary>
    public string? WebhookNotificationUrl { get; set; }
}
