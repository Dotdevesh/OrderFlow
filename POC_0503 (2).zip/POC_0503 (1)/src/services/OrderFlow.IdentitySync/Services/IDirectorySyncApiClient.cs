using System.Net.Http.Json;
using OrderFlow.Contracts;

namespace OrderFlow.IdentitySync.Services;

/// <summary>Typed S2S HTTP client pushing Entra AD Group &amp; App Role changes into <c>OrderFlow.IdentityApi</c>.</summary>
public interface IDirectorySyncApiClient
{
    Task<DirectorySyncResultDto> PushSyncBatchAsync(DirectorySyncBatchRequest batch, CancellationToken ct = default);
    Task<IReadOnlyList<DirectoryGroupStateDto>> GetTrackedGroupsAsync(CancellationToken ct = default);
    Task RecordWebhookSubscriptionAsync(UpdateWebhookSubscriptionRequest request, CancellationToken ct = default);
}

public sealed class HttpDirectorySyncApiClient(HttpClient http) : IDirectorySyncApiClient
{
    public async Task<DirectorySyncResultDto> PushSyncBatchAsync(DirectorySyncBatchRequest batch, CancellationToken ct = default)
    {
        using var res = await http.PostAsJsonAsync("/internal/sync/directory", batch, ct);
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<DirectorySyncResultDto>(ct))!;
    }

    public async Task<IReadOnlyList<DirectoryGroupStateDto>> GetTrackedGroupsAsync(CancellationToken ct = default)
    {
        var groups = await http.GetFromJsonAsync<List<DirectoryGroupStateDto>>("/internal/sync/groups", ct);
        return groups ?? [];
    }

    public async Task RecordWebhookSubscriptionAsync(UpdateWebhookSubscriptionRequest request, CancellationToken ct = default)
    {
        using var res = await http.PostAsJsonAsync("/internal/sync/subscriptions", request, ct);
        res.EnsureSuccessStatusCode();
    }
}
