using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Graph;
using Microsoft.Graph.Models;
using OrderFlow.BuildingBlocks.AzureClients;
using OrderFlow.Contracts;
using OrderFlow.Domain;

namespace OrderFlow.IdentitySync.Services;

public interface IEntraDirectoryProvider
{
    Task<DirectorySyncBatchRequest> ReadDirectoryStateAsync(
        string syncSource,
        IReadOnlyCollection<string>? filterGroupIds = null,
        CancellationToken ct = default);

    Task EnsureGroupWebhookSubscriptionsAsync(
        IReadOnlyList<DirectoryGroupStateDto> currentGroups,
        IDirectorySyncApiClient apiClient,
        CancellationToken ct = default);
}

/// <summary>
/// Queries Microsoft Graph for AD Security Group memberships (<c>transitiveMembers</c>),
/// Azure App Registration App Role assignments (<c>appRoleAssignedTo</c>), and user manager hierarchy.
/// Falls back to deterministic sample data locally when <c>Graph:TenantId</c> is empty.
/// </summary>
public sealed class GraphEntraDirectoryProvider(
    IConfiguration cfg,
    IOptions<DirectorySyncOptions> options,
    IAzureCredentialFactory credentials,
    ILogger<GraphEntraDirectoryProvider> logger) : IEntraDirectoryProvider
{
    private readonly DirectorySyncOptions _opts = options.Value;

    public async Task<DirectorySyncBatchRequest> ReadDirectoryStateAsync(
        string syncSource,
        IReadOnlyCollection<string>? filterGroupIds = null,
        CancellationToken ct = default)
    {
        var tenantId = cfg["Graph:TenantId"];
        if (string.IsNullOrWhiteSpace(tenantId))
        {
            logger.LogInformation("Graph:TenantId is empty; using local sample AD group & App Role snapshot.");
            return BuildLocalSampleSnapshot(syncSource);
        }

        using var graph = CreateGraphClient(tenantId);

        var configuredGroups = GetConfiguredGroups();
        var targetGroups = filterGroupIds is { Count: > 0 }
            ? configuredGroups.Where(g => filterGroupIds.Contains(g.GroupId, StringComparer.OrdinalIgnoreCase)).ToList()
            : configuredGroups;

        var discoveredUsers = new Dictionary<string, SyncedUserDto>(StringComparer.OrdinalIgnoreCase);
        var memberships = new List<SyncedGroupMembershipDto>();

        // 1) Read transitive user members of each watched AD Security Group
        foreach (var grp in targetGroups)
        {
            var memberIds = new List<string>();
            var page = await graph.Groups[grp.GroupId].TransitiveMembers.GraphUser.GetAsync(req =>
            {
                req.QueryParameters.Select =
                [
                    "id", "displayName", "userPrincipalName", "mail",
                    "accountEnabled", "onPremisesDomainName", "onPremisesSamAccountName"
                ];
                req.QueryParameters.Top = 999;
            }, ct);

            while (page?.Value is not null)
            {
                foreach (var u in page.Value)
                {
                    if (string.IsNullOrWhiteSpace(u.Id)) continue;
                    memberIds.Add(u.Id);
                    discoveredUsers[u.Id] = MapGraphUser(u);
                }

                if (string.IsNullOrWhiteSpace(page.OdataNextLink))
                    break;

                page = await graph.Groups[grp.GroupId].TransitiveMembers.GraphUser
                    .WithUrl(page.OdataNextLink)
                    .GetAsync(cancellationToken: ct);
            }

            memberships.Add(new SyncedGroupMembershipDto(
                GroupId: grp.GroupId,
                MemberUserIds: memberIds,
                RemovedUserIds: null,
                IsFullSnapshot: true));
        }

        // 2) Read Azure App Registration App Role assignments (servicePrincipals/{id}/appRoleAssignedTo)
        var appRoleAssignments = new List<SyncedAppRoleAssignmentDto>();
        var isFullAppRoleSnapshot = false;
        var sp = await ResolveServicePrincipalAsync(graph, ct);

        if (sp?.Id is not null)
        {
            isFullAppRoleSnapshot = true;
            var roleIdToValue = (sp.AppRoles ?? [])
                .Where(r => r.Id.HasValue && !string.IsNullOrWhiteSpace(r.Value))
                .ToDictionary(r => r.Id!.Value.ToString(), r => r.Value!, StringComparer.OrdinalIgnoreCase);

            var assignmentsPage = await graph.ServicePrincipals[sp.Id].AppRoleAssignedTo.GetAsync(req =>
            {
                req.QueryParameters.Top = 999;
            }, ct);

            var groupIdSet = configuredGroups.ToDictionary(g => g.GroupId, StringComparer.OrdinalIgnoreCase);

            while (assignmentsPage?.Value is not null)
            {
                foreach (var a in assignmentsPage.Value)
                {
                    if (string.IsNullOrWhiteSpace(a.Id) || a.PrincipalId is null || a.AppRoleId is null)
                        continue;

                    var roleIdStr = a.AppRoleId.Value.ToString();
                    var roleName = roleIdToValue.TryGetValue(roleIdStr, out var mapped)
                        ? mapped
                        : OrderFlowIdentityConstants.RoleReportee;

                    // App roles can be assigned directly to a User OR to an AD Group in Enterprise Applications!
                    if (string.Equals(a.PrincipalType, "User", StringComparison.OrdinalIgnoreCase))
                    {
                        var userId = a.PrincipalId.Value.ToString();
                        if (!discoveredUsers.ContainsKey(userId))
                        {
                            var u = await TryFetchGraphUserAsync(graph, userId, ct);
                            if (u is not null)
                                discoveredUsers[userId] = u;
                        }

                        appRoleAssignments.Add(new SyncedAppRoleAssignmentDto(
                            AssignmentId: a.Id,
                            PrincipalId: userId,
                            AppRoleId: roleIdStr,
                            RoleName: roleName,
                            CreatedAtUtc: a.CreatedDateTime));
                    }
                    else if (string.Equals(a.PrincipalType, "Group", StringComparison.OrdinalIgnoreCase))
                    {
                        // Expand group-assigned App Role to all discovered members of that AD group
                        var groupId = a.PrincipalId.Value.ToString();
                        var groupMembership = memberships.FirstOrDefault(m => string.Equals(m.GroupId, groupId, StringComparison.OrdinalIgnoreCase));
                        if (groupMembership is not null)
                        {
                            foreach (var memberId in groupMembership.MemberUserIds)
                            {
                                appRoleAssignments.Add(new SyncedAppRoleAssignmentDto(
                                    AssignmentId: $"{a.Id}:{memberId}",
                                    PrincipalId: memberId,
                                    AppRoleId: roleIdStr,
                                    RoleName: roleName,
                                    CreatedAtUtc: a.CreatedDateTime));
                            }
                        }
                        else if (groupIdSet.ContainsKey(groupId))
                        {
                            logger.LogDebug("Group {GroupId} was not in current filter batch; group role expansion skipped.", groupId);
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(assignmentsPage.OdataNextLink))
                    break;

                assignmentsPage = await graph.ServicePrincipals[sp.Id].AppRoleAssignedTo
                    .WithUrl(assignmentsPage.OdataNextLink)
                    .GetAsync(cancellationToken: ct);
            }
        }

        // 3) Enrich Manager hierarchy (/users/{id}/manager) for discovered users
        var enrichedUsers = new List<SyncedUserDto>(discoveredUsers.Count);
        foreach (var u in discoveredUsers.Values)
        {
            var managerId = await TryFetchManagerIdAsync(graph, u.ObjectId, ct);
            enrichedUsers.Add(u with { ManagerObjectId = managerId });
        }

        return new DirectorySyncBatchRequest(
            SyncSource: syncSource,
            IsFullAppRoleSnapshot: isFullAppRoleSnapshot,
            Groups: configuredGroups,
            Users: enrichedUsers,
            Memberships: memberships,
            AppRoleAssignments: appRoleAssignments);
    }

    public async Task EnsureGroupWebhookSubscriptionsAsync(
        IReadOnlyList<DirectoryGroupStateDto> currentGroups,
        IDirectorySyncApiClient apiClient,
        CancellationToken ct = default)
    {
        var tenantId = cfg["Graph:TenantId"];
        var notificationUrl = _opts.WebhookNotificationUrl;
        var clientState = cfg["Graph:ClientState"];

        if (string.IsNullOrWhiteSpace(tenantId) || string.IsNullOrWhiteSpace(notificationUrl))
            return;

        using var graph = CreateGraphClient(tenantId);
        var renewThreshold = DateTimeOffset.UtcNow.AddHours(6);
        var desiredExpiry = DateTimeOffset.UtcNow.AddHours(48);

        foreach (var grp in currentGroups)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(grp.WebhookSubscriptionId)
                    && grp.WebhookExpiresAtUtc.HasValue
                    && grp.WebhookExpiresAtUtc.Value > renewThreshold)
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(grp.WebhookSubscriptionId))
                {
                    var renewed = await graph.Subscriptions[grp.WebhookSubscriptionId].PatchAsync(
                        new Subscription { ExpirationDateTime = desiredExpiry }, cancellationToken: ct);

                    if (renewed?.Id is not null && renewed.ExpirationDateTime.HasValue)
                    {
                        await apiClient.RecordWebhookSubscriptionAsync(
                            new UpdateWebhookSubscriptionRequest(grp.GroupId, renewed.Id, renewed.ExpirationDateTime.Value), ct);
                        continue;
                    }
                }

                var created = await graph.Subscriptions.PostAsync(new Subscription
                {
                    ChangeType = "updated",
                    NotificationUrl = notificationUrl,
                    Resource = $"groups/{grp.GroupId}",
                    ExpirationDateTime = desiredExpiry,
                    ClientState = clientState
                }, cancellationToken: ct);

                if (created?.Id is not null && created.ExpirationDateTime.HasValue)
                {
                    await apiClient.RecordWebhookSubscriptionAsync(
                        new UpdateWebhookSubscriptionRequest(grp.GroupId, created.Id, created.ExpirationDateTime.Value), ct);
                    logger.LogInformation("Registered Graph group change webhook {SubId} for group {GroupId}", created.Id, grp.GroupId);
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning(ex, "Failed to create/renew Graph webhook subscription for group {GroupId}", grp.GroupId);
            }
        }
    }

    /// <summary>
    /// Honours <c>Graph:Credential:Mode</c> so the same build can use a managed identity in Azure and
    /// an app registration secret elsewhere. The flat <c>Graph:ClientId</c> and <c>Graph:ClientSecret</c>
    /// keys still apply when that section is absent.
    /// </summary>
    private GraphServiceClient CreateGraphClient(string tenantId)
    {
        var credentialOptions = credentials.Resolve("Graph");
        credentialOptions.TenantId ??= tenantId;
        credentialOptions.ClientId ??= cfg["Graph:ClientId"];
        credentialOptions.ClientSecret ??= cfg["Graph:ClientSecret"];

        if (credentialOptions.Mode == AzureCredentialMode.Default && !string.IsNullOrWhiteSpace(credentialOptions.ClientSecret))
            credentialOptions.Mode = AzureCredentialMode.ClientSecret;

        var credential = credentials.Create(credentialOptions)
            ?? throw new InvalidOperationException("Microsoft Graph requires a token credential; ConnectionString mode does not apply here.");

        return new GraphServiceClient(credential, ["https://graph.microsoft.com/.default"]);
    }

    private List<SyncedGroupConfigDto> GetConfiguredGroups()
    {
        var groups = new List<SyncedGroupConfigDto>();
        if (!string.IsNullOrWhiteSpace(_opts.AccessGroupId))
            groups.Add(new SyncedGroupConfigDto(_opts.AccessGroupId, "OrderFlow Access Group", IsRequiredAccessGroup: true, MappedRole: null));
        if (!string.IsNullOrWhiteSpace(_opts.ManagerGroupId))
            groups.Add(new SyncedGroupConfigDto(_opts.ManagerGroupId, "OrderFlow Managers Group", IsRequiredAccessGroup: true, MappedRole: UserRole.Manager));
        if (!string.IsNullOrWhiteSpace(_opts.ReporteeGroupId))
            groups.Add(new SyncedGroupConfigDto(_opts.ReporteeGroupId, "OrderFlow Reportees Group", IsRequiredAccessGroup: true, MappedRole: UserRole.Reportee));
        return groups;
    }

    private async Task<ServicePrincipal?> ResolveServicePrincipalAsync(GraphServiceClient graph, CancellationToken ct)
    {
        if (!string.IsNullOrWhiteSpace(_opts.EnterpriseAppObjectId))
        {
            return await graph.ServicePrincipals[_opts.EnterpriseAppObjectId].GetAsync(req =>
            {
                req.QueryParameters.Select = ["id", "appId", "appRoles"];
            }, ct);
        }

        if (!string.IsNullOrWhiteSpace(_opts.AppClientId))
        {
            var list = await graph.ServicePrincipals.GetAsync(req =>
            {
                req.QueryParameters.Filter = $"appId eq '{_opts.AppClientId}'";
                req.QueryParameters.Select = ["id", "appId", "appRoles"];
                req.QueryParameters.Top = 1;
            }, ct);
            return list?.Value?.FirstOrDefault();
        }

        return null;
    }

    private static SyncedUserDto MapGraphUser(User u)
    {
        string? windowsAccount = null;
        if (!string.IsNullOrWhiteSpace(u.OnPremisesSamAccountName))
        {
            windowsAccount = !string.IsNullOrWhiteSpace(u.OnPremisesDomainName)
                ? $"{u.OnPremisesDomainName}\\{u.OnPremisesSamAccountName}"
                : u.OnPremisesSamAccountName;
        }

        return new SyncedUserDto(
            ObjectId: u.Id!,
            DisplayName: u.DisplayName ?? u.UserPrincipalName ?? u.Id!,
            Upn: u.UserPrincipalName,
            Email: u.Mail ?? u.UserPrincipalName,
            WindowsAccountName: windowsAccount,
            ManagerObjectId: null,
            AccountEnabled: u.AccountEnabled ?? true);
    }

    private async Task<SyncedUserDto?> TryFetchGraphUserAsync(GraphServiceClient graph, string userId, CancellationToken ct)
    {
        try
        {
            var u = await graph.Users[userId].GetAsync(req =>
            {
                req.QueryParameters.Select =
                [
                    "id", "displayName", "userPrincipalName", "mail",
                    "accountEnabled", "onPremisesDomainName", "onPremisesSamAccountName"
                ];
            }, ct);
            return u?.Id is not null ? MapGraphUser(u) : null;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not read Graph user {UserId}", userId);
            return null;
        }
    }

    private static async Task<string?> TryFetchManagerIdAsync(GraphServiceClient graph, string userId, CancellationToken ct)
    {
        try
        {
            var mgr = await graph.Users[userId].Manager.GetAsync(cancellationToken: ct);
            return mgr?.Id;
        }
        catch
        {
            return null;
        }
    }

    private static DirectorySyncBatchRequest BuildLocalSampleSnapshot(string syncSource) =>
        new(
            SyncSource: syncSource,
            IsFullAppRoleSnapshot: true,
            Groups:
            [
                new SyncedGroupConfigDto("grp-orderflow-access", "SG-OrderFlow-ActionCenter-Users", IsRequiredAccessGroup: true, MappedRole: null),
                new SyncedGroupConfigDto("grp-orderflow-managers", "SG-OrderFlow-Managers", IsRequiredAccessGroup: true, MappedRole: UserRole.Manager),
                new SyncedGroupConfigDto("grp-orderflow-reportees", "SG-OrderFlow-Reportees", IsRequiredAccessGroup: true, MappedRole: UserRole.Reportee)
            ],
            Users:
            [
                new SyncedUserDto("mgr-1", "Morgan (Manager)", "morgan@contoso.com", "morgan@contoso.com", "CONTOSO\\morgan", null, true),
                new SyncedUserDto("rep-1", "Riley (Reportee)", "riley@contoso.com", "riley@contoso.com", "CONTOSO\\riley", "mgr-1", true),
                new SyncedUserDto("rep-2", "Jordan (Reportee)", "jordan@contoso.com", "jordan@contoso.com", "CONTOSO\\jordan", "mgr-1", true)
            ],
            Memberships:
            [
                new SyncedGroupMembershipDto("grp-orderflow-access", ["mgr-1", "rep-1", "rep-2"], IsFullSnapshot: true),
                new SyncedGroupMembershipDto("grp-orderflow-managers", ["mgr-1"], IsFullSnapshot: true),
                new SyncedGroupMembershipDto("grp-orderflow-reportees", ["rep-1", "rep-2"], IsFullSnapshot: true)
            ],
            AppRoleAssignments:
            [
                new SyncedAppRoleAssignmentDto("seed-role-mgr-1", "mgr-1", "approle-manager", "Manager"),
                new SyncedAppRoleAssignmentDto("seed-role-rep-1", "rep-1", "approle-reportee", "Reportee"),
                new SyncedAppRoleAssignmentDto("seed-role-rep-2", "rep-2", "approle-reportee", "Reportee")
            ]);
}
